# VaultPool Library — M0.22

The Library is an encrypted metadata layer above managed multi-cloud files.
It never changes shard placement and is never required to decrypt or restore file contents.

## Base categories

- Vídeos
- Imágenes
- Documentos
- Audio
- Comprimidos
- Código
- Aplicaciones
- Otros

Classification is derived from the filename extension and can evolve without rewriting remote data.

## Virtual folders

Users may create, rename, delete and assign files to custom virtual folders.
Folder assignments live in `SecretVault` as `library_metadata`. They are private but non-critical: losing the organizational metadata may lose the user's filing arrangement, but cannot make the protected file contents unrecoverable.

Deleting a virtual folder only removes its assignments. It does not delete files and does not move or rewrite any remote object.

## Search, filters and ordering

The desktop UI supports free-text search plus category/folder filters and ordering by newest, oldest, name, size and type. Filtering is local against the private managed-file catalog; it does not query provider contents or expose filenames to search APIs.

## Recoverable field-test format invariant

M0.22 field-test writes are limited to two or three independent providers and use canonical `1+1` / `1+2` replication. Every replica is byte-for-byte the encrypted block, so field-test data is independent of the production Reed-Solomon implementation.

If compression is retained, its algorithm name is authenticated in the manifest. Field-test `zlib` blocks remain readable by later builds through named-codec compatibility even when those builds prefer Zstandard for new data.

A field-test build refuses 4+ provider writes. Adaptive Reed-Solomon remains a production-build path only.
