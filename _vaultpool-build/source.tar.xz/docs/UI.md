# VaultPool UI — M0.20

VaultPool serves one local control surface used by the desktop launcher while GUI and CLI share the same storage/services underneath.

## Dashboard and protection status

`GET /api/overview` exposes account/quota state plus an explicit protection status. The UI labels the active safe mode as:

- **Espejo seguro 2×** for two independent providers;
- **Triple réplica** for three;
- **Reed-Solomon adaptativo** for four or more.

Insufficient independent providers or an unconfirmed recovery kit make protection unavailable. The Files view and top **Añadir archivo/carpeta** action reflect that state, while the backend independently rejects unsafe protect requests.

The dashboard may show real physical capacity per connected account. The Windows virtual drive separately reports planner-derived safe logical capacity; the two values are intentionally not conflated.

## Native file selection and managed transfers

On Windows the top **Añadir archivo/carpeta** action opens the Files view with separate actions. **Elegir archivo** opens the native Open common dialog so the user can navigate folders and queue one local file. **Proteger carpeta completa** opens the native folder picker and queues the selected folder as a single local package before encryption and fragmentation. The browser does not upload file bytes to learn the local path. Manual absolute-path entry remains a fallback where native dialogs are unavailable and accepts both files and folders. Native dialog endpoints require exact-origin + CSRF protections and are serialized to avoid overlapping intent.

Restore uses the corresponding native destination flow. Activity shows sanitized phase/progress/cancellation state and never returns full local paths. Refreshing or switching views does not terminate transfers.

## Provider discovery and account lifecycle

Providers are addable only when their reviewed catalog policy is `allowed`, account limits permit another account and an approved authentication strategy exists. A newly associated account remains `pending_auth` and contributes no trusted capacity until its connector completes authentication and returns a coherent validated identity/quota snapshot.

Multiple accounts at one service may appear separately in the account list but count as **one provider failure domain** for protection.

## CAPTCHA/authentication UX

VaultPool never solves or bypasses CAPTCHA. Login uses the approved provider flow (preferably native OAuth/system browser). If the official page presents a CAPTCHA, the user completes it manually and VaultPool continues only with the resulting permitted session/token.

## Local security boundary

The UI:

- listens only on loopback;
- validates loopback Host/Origin and exact same-origin state changes;
- requires a per-process CSRF token for mutations;
- uses restrictive CSP, no-store, anti-framing and no-sniff headers;
- verifies `/api/identity` before a launcher reuses a service on port 8742;
- permits only one live instance per profile/data root;
- exposes a CSRF-protected controlled-shutdown request used by `vaultpool app`.

## Recovery-secret presentation

A revealed recovery code is temporary: the UI automatically hides it again (and hides it on focus/visibility loss). When the user copies the recovery code, VaultPool makes a best-effort clipboard cleanup after 45 seconds **only if the clipboard still contains that same code**, so newer user clipboard content is not deliberately erased.

## Unknown providers

An unknown provider can only enter a pending local policy review. It is not connectable until terms/API/account limits/authentication/CAPTCHA/storage restrictions have been reviewed and encoded into the local provider catalog. This queue lives in the app state; it is not a call to a VaultPool-hosted service.
