# VaultPool Storage Planner — M0.20

## Goal

The planner chooses the complete storage geometry and target placement **before any remote data write begins**. Its priorities are:

1. keep the file recoverable under the declared protection mode;
2. respect independent provider failure domains;
3. respect free capacity and per-object limits;
4. avoid disproportionate redundancy overhead;
5. then minimize shard count/encoded size while preserving provider diversity.

A second account at the same service never creates another provider failure domain. Two Google Drive accounts are two physical targets but one Google failure domain.

## M0.20 protection modes

### Two independent providers — mirror 1+1

A file is stored as two complete protected copies, one in each provider domain. Complete loss of either provider is recoverable. After that loss only one copy remains, so VaultPool records **zero additional shard margin** and does not pretend a second provider loss would be safe.

### Three independent providers — triple replica 1+2

The preferred layout is one data shard plus two parity/replica shards, one per provider domain. Complete loss of any one provider leaves two copies. If the third provider does not have enough capacity/object-size headroom to participate, the planner may retain a valid two-provider mirror using the existing capable pair. Adding a constrained third provider must not make a previously viable two-provider pool unusable.

### Four or more independent providers — adaptive Reed-Solomon

The default policy requires a one-shard recovery margin **after complete loss of the worst single provider**, while limiting parity/data ratio to 50%. The current search bounds are 64 data shards and 32 parity shards. With ample unconstrained capacity, representative minimal layouts are:

- 4 providers → `8 data + 4 parity`;
- 5 providers → `6 + 3`;
- 6 providers → `4 + 2`.

Near capacity/object-size boundaries the optimizer may select a different safe geometry; the safety invariant is authoritative, not the example shard counts.

## Failure-domain accounting

For a Reed-Solomon plan, if a provider domain holds `c` shards and the plan has `m` parity shards, its raw margin after loss of that provider is `m - c`. M0.20 stores the protection target actually used by the plan, so mirror/triple-replica files are audited against their real semantics rather than against a stronger default that they never promised.

A provider outage is not automatically data loss. Health reporting distinguishes current recoverability from whether the original configured provider-failure margin is still met. For example, a two-provider mirror remains recoverable after one provider disappears, but it correctly reports that no further provider-loss safety remains.

## Capacity and object limits

Each target supplies:

- stable target ID;
- provider failure-domain ID;
- coherent free-byte quota;
- maximum object size when known;
- enabled/connected state.

A shard cannot be placed where it exceeds free space or object limits. Batch planning reserves capacity cumulatively across every encoded block plus required manifest headroom before the first data shard is written.

`MaxLogicalCapacity` searches for the largest payload that the current targets can actually place under these rules. This is intentionally different from summing physical quotas. A pair of independent 15 GB accounts in mirror mode exposes about 15 GB of safe logical capacity, not 30 GB.

## Legal eligibility

The planner is not a Terms-of-Service bypass layer. Connector/catalog policy must prevent ineligible accounts from reaching placement. Multiple allowed accounts at one provider may add physical capacity/account resilience but never independent provider-failure credit.

## Validation

M0.20 includes boundary tests plus destructive simulations that remove a complete provider domain from two-provider mirror and three-provider triple-replica layouts and verify the resulting recoverability/margin reporting.
