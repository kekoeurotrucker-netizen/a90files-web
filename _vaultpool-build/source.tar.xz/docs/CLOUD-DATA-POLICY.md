# VaultPool cloud data policy (M0.23.3)

VaultPool treats existing user data in every connected cloud account as external data.

Rules:

1. Existing files/folders already present in Google Drive, MEGA, OneDrive, Dropbox, or any future provider are never moved, deleted, renamed, compressed, encrypted or rebalanced by VaultPool.
2. Provider-reported used space is authoritative for capacity planning. Space already occupied by non-VaultPool files is unavailable to VaultPool and reduces usable free capacity.
3. VaultPool only writes inside its own reserved provider namespace, app folder, app properties, or `/VaultPool` bridge root depending on the provider.
4. VaultPool-managed objects are authenticated by VaultPool manifests/recovery records and object naming/properties. Name or extension alone is never enough to trust a file as managed.
5. Future repair/rebalance may copy VaultPool-managed encrypted/compressed objects between providers, but must not touch external user data.
6. UI must make this clear: “ocupado” includes previous user files; VaultPool consumes only free space.
