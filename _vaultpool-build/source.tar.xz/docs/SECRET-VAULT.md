# VaultPool Secret Vault — M0.6

M0.6 adds a dedicated local secret vault before any live cloud OAuth is enabled.

## Local protection

- A random 256-bit vault master key encrypts secret data with AES-256-GCM.
- On Windows the master key is wrapped using DPAPI in current-user scope (`CryptProtectData` / `CryptUnprotectData`) with UI forbidden.
- Vault files are authenticated, transactionally replaced and written with restrictive permissions where supported.
- Tampering is detected before decrypted data is accepted.
- OAuth tokens can be stored in this local vault because losing them can be recovered by re-authentication.

## Portable recovery for user/password credentials

VaultPool deliberately refuses to store recoverable usernames/passwords until portable recovery is configured.

Portable recovery generates:

1. an encrypted `VaultPool-Recovery.vpr` package;
2. a random 256-bit recovery code shown to the user and never stored in plaintext by VaultPool.

The package contains the encrypted/recoverable vault material but never contains the recovery code itself. The recovery key is not encrypted under itself. A wrong code or modified package fails authenticated decryption.

Once portable recovery is enabled, a recoverable credential is written to the recovery package **before** VaultPool acknowledges the local write. This biases failure handling toward preservation rather than convenience.

`RestoreFromRecovery` can re-create the vault on a new Windows profile and re-wrap its master key with that profile's DPAPI protector.

## Security boundaries

- Secret values are byte slices and never included in metadata listings.
- Vault metadata can list kind/account/timestamps without revealing values.
- M0.6 does not expose secrets in logs or the HTTP UI.
- The Windows WebView/Windows Hello reveal experience remains a later UI-shell integration.
