# VaultPool M0.15 — Guided recovery and credential snapshot freshness

M0.15 separates two recovery guarantees that must not be confused:

1. **File recovery is continuously durable.** M0.14 stores each file data key as an authenticated recovery record replicated across independent provider failure domains. Uploading/registering a file therefore does not require the user to download a new `.vpr` package.
2. **Recoverable cloud credentials are an offline snapshot.** A username/password that VaultPool is explicitly allowed to retain cannot safely depend on the same cloud account for its own recovery. Creating, changing or deleting such a credential increments a credential revision and marks the external `.vpr` copy as needing refresh.

OAuth access/refresh tokens remain re-authenticatable provider secrets rather than recoverable passwords and do not by themselves require an offline credential snapshot update.

## External credential snapshot state

The SecretVault tracks:

- `credential_revision`: latest recoverable username/password state;
- `external_credential_revision`: latest revision explicitly confirmed as saved outside the machine;
- `credentials_refresh_required`: true when the first value is newer than the second.

File data keys and private file metadata do **not** increment this revision. They are recovered through M0.14 recovery records plus authenticated manifests.

The Recovery Center refuses to acknowledge a credential refresh merely because the user ticks a checkbox. In the current process VaultPool must first have exported the exact current credential revision. If another recoverable credential changes after that export, confirmation is rejected until a new package is exported.

## Metadata-only disaster recovery

After restoring a `.vpr` package and reconnecting available cloud accounts, `recoveryassistant.Service` performs this sequence:

1. resolve all known storage targets, including known-but-temporarily-disabled targets;
2. recover authenticated per-file data keys from M0.14 recovery records;
3. enumerate only those recovered keys from the encrypted SecretVault;
4. discover reserved encrypted manifest replicas from the connected providers;
5. route each manifest to the FileID/key it declares through provider-reserved metadata or object naming;
6. authenticate the manifest with AES-GCM before trusting any file metadata;
7. reject authenticated same-generation conflicts instead of choosing arbitrarily;
8. import the authenticated manifest into the private local catalog;
9. report files restored/updated/already-known, unavailable targets and warnings.

The assistant deliberately **does not download or audit all data shards**. Large health audits remain explicit user actions after the catalog is rebuilt so a reinstall cannot unexpectedly consume provider transfer quotas or trigger rate limits.

## Cross-file key isolation

A manifest is never decrypted with an arbitrary recovered key. Current Google Drive and OneDrive replicas include an opaque FileID routing hint in provider-reserved metadata/naming. Local targets derive the same hint from their reserved manifest path. VaultPool then authenticates the candidate with that file's recovered key and verifies that the decrypted manifest contains the same FileID.

For older replicas without a routing hint, compatibility fallback tries only file keys that have already been authenticated through the recovery root. AES-GCM authentication still decides whether a candidate is valid; a failed key is never accepted or associated with another file.

## Provider outages

Recovery is intentionally partial-tolerant. A disabled/unavailable provider remains a known target and is reported as unavailable; it is not silently reclassified as permanent data loss. Independent available providers continue to be scanned. A successful catalog rebuild can therefore finish with `needs_review=true` when one provider is offline.

## UI behavior

The Recovery Center shows two independent states:

- portable/file recovery protection;
- external recoverable-credential snapshot freshness.

When credentials need a refresh, the UI asks for a new `.vpr` download and explicit confirmation. A separate **Reconstruir catálogo** action runs the metadata-only recovery assistant and reports keys recovered, manifests found, catalog entries rebuilt and health audits still pending.

## Security boundaries retained

- exact same-origin local control plane;
- per-process CSRF token on every state-changing request;
- `.vpr` recovery code is never persisted in plaintext;
- provider recovery-list/read APIs remain restricted to VaultPool-reserved manifest/recovery-record objects;
- no automatic CAPTCHA solving;
- no automatic provider-policy fallback;
- no bulk shard audit during catalog rebuild.
