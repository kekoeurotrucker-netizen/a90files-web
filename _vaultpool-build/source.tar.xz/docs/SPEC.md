# VaultPool Product Specification — Frozen Decisions v0.2

## Product

VaultPool is a **Windows-first virtual multi-cloud disk**. The future website distributes/document the application; it is not a relay for users' files. Android may follow later.

## Core principles, in priority order

1. Prevent data loss.
2. Protect accounts, credentials, and recovery material.
3. Respect provider terms, APIs, quotas, rate limits, and applicable law.
4. Preserve recoverability after reinstall/device loss.
5. Verify integrity before any destructive operation.
6. Then optimize storage, compression, fragment count, and transfer speed.

No optimization may reduce required safety.

## Storage behavior

- Capacity, free space, plan restrictions, object limits, and transfer status are queried dynamically where APIs permit.
- VaultPool imposes no artificial upload/download quota.
- Initial placement is automatic.
- It minimizes physical fragments/objects **only after** satisfying redundancy, provider separation, provider limits, and integrity requirements.
- Existing data is not automatically rebalanced when accounts/providers are added.
- Rebalance/optimize is an explicit user action.
- Repair protection is distinct from rebalance.
- Health auditing may be automatic and non-destructive.
- Repair/migration that changes stored data requires an explicit user action in the product design.

## Compression

VaultPool attempts compression when technically reasonable. The compressed representation is kept whenever it is actually smaller, even if the saving is modest. It is rejected if it increases size. Compression occurs before encryption.

Production design uses independent logical blocks so random-access behavior can be added later. Remote object aggregation is a later layer and must not weaken recovery.

## Resilience

Reed-Solomon/erasure coding is adaptive in the finished product; 10+4 is an example, not a universal constant. UI must show:

- availability (e.g. 14/14);
- verified integrity;
- remaining redundancy;
- provider count/health;
- last audit;
- human-readable loss risk.

Warnings escalate as recoverable margin falls. Example for 10+4:

- 14/14: healthy;
- 12/14: warning, two missing, two further losses tolerated;
- 11/14: high risk, one further loss tolerated;
- 10/14: critical, still recoverable but zero redundancy left;
- below 10/14: recovery may be impossible.

Never market VaultPool as making loss impossible.

### Provider failure domains

VaultPool measures diversity by independent provider, not by account count. Two accounts at MEGA are still one MEGA failure domain.

The default safety target is **high**: losing any single complete provider should leave the file recoverable **and still leave at least one further shard of recovery margin**, when enough legally usable providers are available. If the requested safety target cannot be met, VaultPool must warn/reject rather than silently weaken it.

The planner minimizes the number of physical fragments/providers only after this safety target is satisfied. Rebalance/migration must re-run the same safety calculation before committing a move.

### Planner efficiency rule (M0.2)

The planner must not satisfy “minimum fragments” by creating disproportionate redundancy. The M0.2 conservative default caps parity/data overhead at 50%, then minimizes total shard count among safe layouts. Equal-size plans prefer lower encoded bytes and wider provider-domain diversity. This ceiling may become a user/profile setting later, but reducing it or increasing it must never silently lower the selected safety target.

Provider/account free space and known maximum object size are hard planning constraints. Accounts disallowed by provider terms must be filtered by the connector/policy layer before planning.

## Migration invariant

All moves use:

1. read/copy source;
2. verify source if needed;
3. write destination;
4. verify destination completely;
5. commit manifest atomically;
6. delete source.

A destination is never counted as protection before verification.

## Credentials

The vault is only for accounts connected to VaultPool.

- OAuth is preferred; VaultPool stores tokens, not provider passwords it never receives.
- When a provider requires credentials entered into VaultPool, they may be stored reversibly only in the encrypted local vault.
- User/email and password are hidden by default.
- Eye button reveals voluntarily.
- Copy is supported.
- Sensitive display auto-hides; clipboard is cleared after a short interval.
- Reveal/copy requires local authentication policy (master password/Windows Hello as implemented).
- Secrets never appear in logs/telemetry.

## Business model

The complete application is free. Donations are optional support only and unlock no features, speed, connectors, storage, or priority support.
