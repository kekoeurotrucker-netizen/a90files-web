# VaultPool authentication architecture — M0.5

VaultPool treats authentication as provider policy, not UI preference.

Approved strategies:

- `system_browser_oauth`: native/public-client OAuth in the system browser. PKCE is mandatory when the provider supports/requires it.
- `embedded_webview`: only if the reviewed provider explicitly allows embedded authentication and the Windows shell can isolate the WebView.
- `device_code`: only for providers that officially support it.
- `direct_credentials`: only when the provider policy explicitly requires it and the dedicated encrypted credential vault is available.
- `external_session`: credentials are entered only in an approved official provider client; VaultPool consumes the already-authenticated local session without copying the password/session secret.
- `unsupported`: no connection.

There is no automatic fallback to a weaker strategy. If the approved route is unavailable, authentication is blocked.

CAPTCHA is always human-operated. VaultPool never solves, outsources, bypasses, reads or automates CAPTCHA challenges.

## OAuth session safety

`internal/authflow.SessionManager` creates short-lived in-memory authorization state. For PKCE flows it generates an S256 challenge and keeps the verifier only in process memory. OAuth state is validated in constant time and each session is single-use. Sessions are not persisted.

No OAuth token is stored in M0.5. Live OAuth must not be enabled until the credential vault can persist sensitive token material safely.

## Current reviewed direction

- Google Drive: system browser OAuth; PKCE; embedded user agents are not allowed by Google OAuth policy.
- Microsoft OneDrive: desktop authorization-code flow with PKCE; system browser is VaultPool's preferred route.
- MEGA: `external_session` through official MEGAcmd. VaultPool opens `MEGAcmdShell.exe` on Windows for human login and then uses only official scriptable MEGAcmd commands. One MEGA account is allowed per VaultPool profile; every storage operation verifies that the active MEGA session still belongs to the previously registered stable target.
- Filen: `direct_credentials` through the official Filen Go SDK. VaultPool sends email, password and the optional 2FA code directly from the local UI to the SDK, reads the real account/quota/base folder, creates or reuses `/VaultPool`, and stores only the SDK's serialized session blob in the Windows DPAPI-backed `SecretVault`. Passwords and 2FA codes are never persisted, logged, exposed to the frontend, or used for later probes.
- pCloud: held in review because the documented code exchange uses `client_secret`; a safe distributed-desktop design has not yet been approved.
- Box: held in review for the same client-secret concern in the documented OAuth exchange.
- Proton Drive: held in review because the current official Drive SDK explicitly does not provide authentication/login/session management for standalone integrations.

The catalog is deliberately more restrictive than what may be technically possible.
