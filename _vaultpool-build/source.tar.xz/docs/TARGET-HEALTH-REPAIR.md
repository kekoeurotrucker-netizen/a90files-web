# M0.11 — Target health, fault classification and safe repair

M0.11 moves VaultPool's audit/repair semantics onto provider-neutral storage targets.

## Fault classes

A shard probe has four states:

- **valid** — exact trusted size and SHA-256 verified;
- **missing** — account/target is absent or provider confirms object not found;
- **corrupt** — bytes/size fail VaultPool integrity verification;
- **unavailable** — provider/auth/rate-limit/transport problem prevents a trustworthy conclusion.

An unavailable shard is not called lost or corrupt. VaultPool may reconstruct around it for reading if parity permits, but the normal repair action deliberately does not migrate it as proof of loss has not been established.

## Failure-domain health

Provider-failure margin is calculated by provider failure domain, not account count. Stable target IDs map to a provider domain; an unavailable historical target can still be attributed from its stable ID prefix. The audit reports valid, missing, corrupt and unavailable counts per block plus the recovery margin and worst-provider-loss margin.

## Repair invariant

`RepairTargets` is an explicit mutating action. It repairs only confirmed missing/corrupt shards:

1. verify every reachable shard;
2. ensure all currently unavailable+missing+corrupt shards still fit inside the parity budget;
3. reconstruct in memory;
4. choose a destination satisfying free space, per-object limit and provider-failure margin;
5. upload and read-back verify the replacement;
6. update the in-memory manifest;
7. replicate/authenticate the new manifest generation to every enabled target;
8. atomically commit the local manifest;
9. only then delete superseded corrupt/missing locators.

A cleanup failure after commit leaves a harmless old duplicate/orphan and is reported as a warning. If manifest commit fails, old references remain authoritative and the new objects are cleaned with the M0.10 manifest-first cleanup rule.

## Capacity and independence

Repair reserves actual free bytes as replacement objects are created and obeys `MaxObjectBytes`. It prefers the original healthy account when topology remains safe; otherwise it prefers an unused provider failure domain. If the configured safety margin cannot be restored, repair fails and tells the caller to reconnect/add an independent provider rather than concentrating shards and silently weakening protection.

## Proven cases

- one corrupt shard -> repaired -> manifest generation increments -> audit healthy -> file restores byte-for-byte;
- one complete provider removed -> repair refused when only same/insufficient domains remain;
- independent replacement provider added -> shard rebuilt there -> old provider no longer referenced;
- disabled/temporarily unavailable target -> no migration, generation unchanged, deferred count reported;
- remote integrity failures are typed separately from provider/API unavailability.
