# VaultPool Transfers — M0.20

Managed protect/restore operations use the same provider-neutral storage core from GUI and CLI.

## Protection admission gate

A new protect operation is refused before work starts unless:

- a portable recovery kit has been created and confirmed;
- at least two independent connected provider failure domains are available;
- the current protection mode can safely plan the file.

The UI disables unsafe actions for clarity, but the backend enforces the same gate and is the security boundary.

## Selecting and protecting a local file

On Windows, **Añadir archivo/carpeta** opens the Files view. **Elegir archivo** opens the native file picker so the user can browse folders and select one file. **Proteger carpeta completa** opens the native folder picker and queues that folder as one local `.vaultpool-folder.zip` package; the package is then encrypted, fragmented and verified through the normal VaultPool pipeline. Manual absolute-path entry accepts either a file or a folder. The browser never uploads local plaintext merely to discover a path.

VaultPool does **not** stage a whole plaintext copy. The operation is:

1. validate an absolute regular-file path and reject symlinks;
2. generate FileID + random file data key;
3. replicate/verify the encrypted file-key recovery record across at least two independent provider domains;
4. preflight compression/encryption sizes and reserve cumulative provider capacity;
5. reserve manifest-commit headroom before the first shard write;
6. stream blocks through compression → AES-256-GCM → the selected mirror/replica/Reed-Solomon plan;
7. upload and verify every shard/object;
8. seal and replicate the authenticated manifest;
9. atomically persist local manifest/catalog state;
10. only then report completion.

The monolithic manifest currently has a 64 MiB recovery-safe ceiling, reserved during planning so data cannot consume the metadata space needed for commit.

## Restore

Restore writes to a private temporary file, reconstructs/decrypts/decompresses blocks, verifies the final original SHA-256 and only then atomically replaces the requested destination. Relative output paths and destinations inside VaultPool's managed metadata directory are rejected.

## Background jobs and cancellation

The activity API exposes only sanitized transfer ID/type/label/FileID, phase, progress, timestamps and sanitized errors. Full local paths stay process-memory-only. Refreshing or switching views does not cancel a job.

Cancellation before commit triggers rollback according to recoverability rules. If cancellation races a successful commit, the committed result remains authoritative and the transfer is reported completed.

## Controlled application shutdown

M0.20 closes a real admission race during shutdown. The sequence is:

1. stop accepting new transfers;
2. cancel active/queued transfers;
3. wait for their safe rollback/cleanup;
4. unmount the optional Windows virtual drive;
5. stop the local HTTP service.

`vaultpool app` requests this controlled shutdown through the authenticated same-profile local service and gives rollback time to finish before a last-resort process termination is considered.

## No artificial transfer throttle

VaultPool does not impose an application bandwidth cap. Throughput is bounded by local/network/provider limits; typed quota/throttle/auth failures remain available for UI handling.
