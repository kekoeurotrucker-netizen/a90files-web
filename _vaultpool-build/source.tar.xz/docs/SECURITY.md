# Security Design — M0.1 Baseline

## Threat model

VaultPool must assume:

- a provider/account may become unavailable;
- one or more remote objects may disappear or be corrupted;
- transfers may stop mid-write;
- Windows may crash or power may fail during an operation;
- a token may expire/revoke;
- users may reinstall Windows or lose the local database;
- malformed/corrupted remote input is untrusted input;
- logs/screenshots may leak secrets if the UI is careless.

## Cryptographic rules

- Do not invent cryptography.
- M0.1 uses AES-256-GCM from Go standard library.
- Unique random nonces are generated with `crypto/rand` for every encryption operation.
- AEAD authentication is mandatory on every block and on the encrypted manifest.
- SHA-256 is used as an independent integrity/identity checksum in M0.1.
- Data encryption keys, vault keys, and recovery/manifest protection must be separable in production.
- No key/secret/token/password in logs.

## Recovery-key baseline

M0.1 uses a raw 32-byte recovery key file only as a core-development mechanism. It is **not the final user vault format**.

Production must provide an encrypted recovery kit that is portable across Windows reinstalls/devices. Windows DPAPI/Hello may protect local unlock, but must not be the only way to recover data.

## Atomicity rules

- write temporary file;
- `fsync`/close where appropriate;
- verify full content/hash;
- atomic rename/commit;
- only then delete superseded source.

Interrupted uploads are never considered valid shards.

## Provider separation

VaultPool reasons in **provider failure domains**, not account count. Multiple accounts at one company are not independent providers.

The default M0.1 policy is stronger than bare recoverability: placement must reject a layout unless loss of any one complete provider still leaves at least one additional shard of recovery margin. For 4 data + 2 parity this means each of the six shards must be on a different provider failure domain.

A lower policy may deliberately allow zero margin after one full-provider loss, but the UI must label that weaker state truthfully. No placement or migration may silently reduce the configured provider-failure margin.

## Remote-control surfaces

If rclone is introduced, its RC endpoint must never be exposed publicly. Prefer a minimal local-only adapter and authenticated/isolated process boundary. Do not treat rclone RC as a normal web API.

## Logging / telemetry

- Telemetry should be off by default unless product requirements later justify otherwise.
- Diagnostics must be opt-in and sanitized.
- Never log credentials, OAuth tokens, encryption keys, full sensitive paths, or decrypted manifest contents unnecessarily.

## Release gates

No stable release until:

- destructive recovery tests pass;
- race/static/security scans pass;
- dependency advisories reviewed;
- secret scanning enabled;
- signed release/update mechanism designed;
- external security review/pentest performed for vault + update path + provider auth.

## Path and object hardening

Provider object names are treated as untrusted input. The local provider mock rejects absolute paths, `..`, empty/dot segments, and Windows-style backslash traversal before any filesystem operation. Production provider adapters must apply equivalent canonicalization appropriate to their APIs.

Encrypted block AEAD associated data includes both FileID and block index. A ciphertext valid for one VaultPool file/block must not authenticate as another file/block.

## Manifest generations

Every manifest-changing operation increments a generation. Encrypted replicas are immutable/versioned in M0.1. Recovery selects the highest authenticated generation for a requested FileID and rejects conflicting authenticated manifests at the same generation instead of guessing. Migration does not delete the old source until the new manifest generation has been committed locally and replicated to all currently available mock providers.

## Local UI boundary (M0.4)

The embedded web UI is treated as a privileged local control surface. It is loopback-only, validates Host/Origin, ships with a restrictive Content Security Policy, and does not expose permissive CORS headers. Provider policy is revalidated server-side for every account-add operation.

Unknown providers cannot self-approve. Authentication flow selection is centralized in `internal/authflow`; CAPTCHA is manual-only.

## M0.13 local control-plane hardening

State-changing local UI requests require a random per-process CSRF token. If an Origin header is present it must match the exact VaultPool origin, including host and port; merely being another loopback origin is not sufficient. Recovery uploads are size-limited and authenticated before staging. Pending restore codes are protected by the OS secret protector and expire with the request.

## M0.16 transfer/commit boundary

Protecting a file establishes a recoverable encrypted file key before any data shard is written. No whole-file plaintext staging copy is created. Provider capacity planning includes cumulative shard use plus a conservative manifest-commit reserve on every enabled target. The sealed manifest is rejected if it exceeds the same 64 MiB ceiling accepted by remote recovery or a provider object-size limit.

Restore never exposes an unverified final file: reconstructed bytes go to a private temporary file and the original SHA-256 must match before atomic replacement. Transfer API responses omit local paths. Cancellation before commit follows cleanup rules; a cancellation racing with a successful commit cannot rewrite a completed storage state as canceled.
