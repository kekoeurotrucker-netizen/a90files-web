# M0.9 — Stable cloud storage targets

VaultPool's erasure-coding core now writes through a provider-neutral `storage.Target` abstraction. A target represents one authenticated storage account and carries:

- a stable opaque target ID derived from provider ID + provider-owned stable storage subject;
- provider failure domain;
- local account/vault lookup ID;
- free capacity and per-object limits;
- a verified remote object store implementation.

## Stable identity rule

Manifest shard locations never use a transient VaultPool account UUID or an email address. They use a SHA-256-derived target identifier. The raw provider subject is treated as ephemeral probe data and is not persisted in normal app state.

Google Drive currently derives the subject from Drive's user `permissionId`. OneDrive derives it from the concrete `drive.id`, not merely the Microsoft user object, so a manifest maps back to the same storage drive after reinstall/reauthentication.

## Commit invariant

Cloud-capable pack follows:

1. complete-file preflight and capacity reservation;
2. compress, encrypt and erasure-code blocks;
3. upload each shard and verify it;
4. build and authenticate the manifest;
5. replicate the authenticated manifest to every enabled target and verify each copy;
6. atomically write the local manifest;
7. mark the operation committed.

Before step 7, failure triggers best-effort cleanup of every remote object created by that operation. A failed operation is never presented as a committed file.

## Restore invariant

Restore resolves each manifest target ID against currently authenticated targets. Missing/unavailable/corrupt shards are treated as unusable and Reed-Solomon reconstruction is attempted only within the manifest's parity budget. The final recovered file SHA-256 must match the original before the temporary output is renamed into place.

## Next hardening step

M0.10 adds remote manifest discovery/recovery after local state loss. Recovery must authenticate every candidate, reject same-generation conflicts, select only the newest unambiguous generation per FileID, and never guess which file to recover when multiple candidates exist.
