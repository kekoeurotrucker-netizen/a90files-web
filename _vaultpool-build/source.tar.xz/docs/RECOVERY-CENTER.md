# VaultPool M0.13 — Recovery Center

M0.13 turns portable recovery into an explicit, user-visible security workflow. A recovery kit is not considered active merely because VaultPool generated a file.

## Two-step recovery-kit setup

1. `Begin` creates `VaultPool-Recovery.vpr` and returns a random 256-bit recovery code once.
2. The package is encrypted with AES-256-GCM. The recovery code is never persisted in plaintext.
3. Recoverable usernames/passwords and per-file data keys remain blocked while the kit is pending.
4. The user must explicitly confirm that both the package and the independent code were saved.
5. Only after confirmation does the SecretVault allow recovery-critical secrets.

A confirmed kit cannot be silently regenerated. Rotation will be implemented later as a two-phase transaction so the old external kit remains valid until the replacement has been saved and confirmed.

## Restore flow

Restoration is staged, never applied to the live SecretVault from the web UI:

1. user supplies `.vpr` package + recovery code;
2. VaultPool authenticates/decrypts the package into a private temporary vault;
3. if validation succeeds, the encrypted package is copied to a pending path and the recovery code is protected by the current OS secret protector;
4. the pending request expires after 24 hours;
5. at the next VaultPool start, before the ordinary vault is opened, VaultPool verifies the pending package hash and expiry;
6. the previous local vault and existing recovery package are preserved as private backups;
7. the restored vault is created and verified before atomic activation;
8. its portable recovery package is relocated to the canonical path;
9. pending restore artifacts are deleted only after success.

Wrong codes, modified packages, expired requests and oversized files cannot replace the active vault.

## Local web-control security

The local UI is a privileged control plane. M0.13 adds:

- loopback-only listening;
- exact same-origin validation when an `Origin` header is present (another localhost port/hostname is not considered equivalent);
- a random 256-bit CSRF token per VaultPool process;
- CSRF enforcement on every state-changing HTTP method;
- restrictive CSP, no permissive CORS, clickjacking protection and `Cache-Control: no-store`;
- OAuth callback protection remains based on one-time `state` + PKCE and is not weakened by the CSRF layer.

The recovery package is downloaded through a CSRF-protected POST rather than a public static path.

## File-system hardening

Recovery inputs are treated as untrusted:

- package maximum: 64 MiB;
- pending request maximum: 64 KiB;
- regular-file checks before reading;
- random temporary restore filenames;
- atomic Windows-aware replacement via `safefile`;
- previous recovery backups are never overwritten; additional restores receive distinct backup paths.

## Deliberately not implemented

- one-click recovery-kit rotation;
- cloud-hosted copies of the recovery code;
- automatic recovery-code escrow;
- bypassing Windows/local authentication to reveal recovery credentials;
- applying a restore without an explicit replacement acknowledgement and process restart.

## M0.15 credential snapshot freshness

M0.15 narrows what makes an external recovery package stale. File uploads no longer require a newly downloaded `.vpr`: per-file keys are protected by M0.14 authenticated recovery records. Only recoverable username/password changes advance the external credential snapshot revision.

The UI will not accept “I saved the current credential copy” unless the current process has actually exported the exact current revision. A credential change after that export invalidates the acknowledgement and forces another export. This prevents a checked box from being treated as evidence that the newest credentials exist outside the PC.

After a reinstall, the Recovery Center can also invoke the M0.15 metadata-only catalog assistant. It restores authenticated file keys and manifests but deliberately leaves data-shard health audits to explicit user actions. See `RECOVERY-ASSISTANT.md`.
