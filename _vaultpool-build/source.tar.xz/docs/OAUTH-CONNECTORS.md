# VaultPool M0.7 — Native OAuth connectors

## Scope

M0.7 prepares the first real desktop OAuth connectors for Google Drive and OneDrive. It does **not** ship provider application registrations or hard-coded production client IDs. A build is connector-ready only when the public client ID is supplied by configuration and the Windows secret vault can be opened.

## Security invariants

- VaultPool is a public/native OAuth client. No provider `client_secret` is embedded in the executable or sent during code exchange/refresh.
- Authorization Code + PKCE (`S256`) is mandatory.
- Authorization uses the system browser. VaultPool does not put Google/Microsoft login pages inside an embedded WebView.
- Redirects are loopback HTTP only (`127.0.0.1`, `::1`, or localhost) and terminate at VaultPool's local-only server.
- Every login session receives a cryptographically random `state` and PKCE verifier. Both are in memory only, expire after ten minutes, and `state` is single-use.
- Receiving an authorization code does not mark an account connected. VaultPool must exchange the code, store the token in the encrypted vault, probe the official provider API, validate the resulting identity/quota snapshot, and only then persist `connected`.
- A failed probe never invents capacity and never overwrites the last trusted quota snapshot.
- OAuth tokens never enter the general UI state file.

## Google Drive

Requested scopes:

- `openid`
- `email`
- `https://www.googleapis.com/auth/drive.file`

`drive.file` is intentionally preferred over broad Drive scopes. It is sufficient for files created/opened through VaultPool and is also accepted by Drive `about.get`, which VaultPool uses to obtain the account identity and storage quota.

Authorization endpoint: `https://accounts.google.com/o/oauth2/v2/auth`
Token endpoint: `https://oauth2.googleapis.com/token`
Quota probe: Drive API `about.get` with explicit fields.

VaultPool requests offline access so an approved refresh token can be encrypted in the local secret vault.

## OneDrive

Requested delegated scopes:

- `offline_access`
- `Files.ReadWrite`
- `User.Read`

`Files.ReadWrite` is used instead of `Files.ReadWrite.All`. VaultPool needs read/write/delete access for its own remote objects. `User.Read` is currently used only to resolve the signed-in identity through `/me`; this should be reevaluated before release if identity can be obtained safely with less privilege.

Authorization/token endpoints use Microsoft identity platform v2.0. Quota is read from `/me/drive` and identity from `/me`.

For desktop app registrations, register `http://localhost` under Mobile and
desktop applications. OneDrive returns to `http://localhost:<UI-port>/`, not to
`/oauth/callback`. Microsoft ignores the port when matching localhost redirects,
but the path must match. The root handler routes OAuth responses through the same
single-use state and PKCE validation as the other providers. Dropbox continues
to use `http://127.0.0.1:<UI-port>/oauth/callback`.

## Provider gating

A provider remains `review_required` if VaultPool has not approved a native/public-client authentication design. There is no fallback to an embedded browser, direct credentials, or a secret embedded in the executable merely to make a connector work.

## Before public release

- Register the VaultPool desktop application with each provider and obtain production public client IDs.
- Complete required OAuth consent-screen / publisher verification.
- Re-review scopes and provider terms at release time.
- Add signed application builds and signed updates before real users are encouraged to authorize accounts.

## MEGA is intentionally not OAuth

MEGA support introduced in M0.21 does not use this OAuth subsystem. VaultPool relies on the official MEGAcmd application's authenticated local session. The user enters credentials only in MEGAcmd's interactive shell; VaultPool neither receives the password nor persists the MEGAcmd session string. See `MEGA-CONNECTOR.md`.
