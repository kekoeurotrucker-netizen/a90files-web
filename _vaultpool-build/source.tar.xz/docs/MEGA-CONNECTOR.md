# VaultPool M0.21 — MEGA via official MEGAcmd

## Why this route

MEGA is deliberately integrated through its official MEGAcmd application rather than by embedding a password form or reproducing MEGA authentication. MEGAcmd exposes both an interactive shell and scriptable commands suitable for another local program.

## Authentication boundary

1. VaultPool may launch the official MEGAcmd interactive shell (`MEGAcmdShell.exe` on Windows).
2. The user performs login/MFA manually inside MEGAcmd.
3. VaultPool polls `mega-whoami -l` / `mega-df` to verify identity and quota.
4. VaultPool does not receive the MEGA password and does not persist a MEGAcmd session token.
5. One MEGA account is allowed per VaultPool profile because MEGAcmd maintains one active account entity at a time.

`VaultPool` checks the command `PATH` and the official Windows installer location under `%ProgramFiles%\MEGAcmd`. `VAULTPOOL_MEGACMD_DIR` or `--megacmd-dir` may override the location; `VAULTPOOL_MEGACMD_SHELL` may explicitly identify the official interactive shell.

## Required official commands

VaultPool requires these scriptable commands to be available together:

- `mega-whoami`
- `mega-df`
- `mega-du`
- `mega-mkdir`
- `mega-put`
- `mega-get`
- `mega-rm`
- `mega-find`

`vaultpool doctor` reports the bridge unavailable unless the complete set is found.

## Storage boundary and integrity

All VaultPool-owned MEGA objects live below `/VaultPool`. Uploads use fresh opaque names and follow the same trust rule as other providers:

`local SHA-256 -> upload -> download -> exact size + SHA-256 verification -> trusted object`

A failed post-upload verification removes only the new untrusted object. It never deletes a previously valid replica first. Recovery scans use provider-side `find` only below `/VaultPool`, restrict filename classes and enforce size caps before authenticated VaultPool envelope verification.

## Account-switch protection

A MEGAcmd session can be changed outside VaultPool. Therefore every bound MEGA remote operation re-runs identity discovery and derives the same stable VaultPool target ID. If the active session belongs to another MEGA account, upload/download/delete/recovery access fails closed.

VaultPool also rejects provider-identity replacement at the generic account-state layer, so reauthentication cannot silently change the cloud account behind an existing stable target.

## Limits and policy

VaultPool does not rotate MEGA accounts to evade limits, does not bypass transfer quotas/throttling, does not automate account creation, and does not solve or bypass CAPTCHA/MFA. Any challenge remains human-in-the-loop inside the official client.

## Release gate

M0.21 has unit/integration tests against a deterministic MEGAcmd runner but has not yet been exercised here against a real MEGA account or real Windows MEGAcmd installation. Before trusting real data, run disposable-account upload/readback/delete, restore, recovery-discovery, logout/account-switch, quota, interruption and destructive provider-loss tests on Windows.

## M0.22.7 user-experience gate

Real Windows testing showed that exposing the MEGAcmd console as the normal MEGA onboarding path is not acceptable for non-technical users. VaultPool therefore gates the MEGAcmd shell bridge behind an explicit developer/test mode in the local UI. A normal user must not be dropped into a command prompt, asked to compose `login` commands, or expected to paste long passwords into a terminal.

The bridge remains valid for internal testing because VaultPool does not store MEGA passwords or copy MEGAcmd session tokens. However, before any public/beta release, MEGA must either have a polished guided connector or remain hidden/advanced-only. The standard onboarding bar is: connect, authenticate through a clear official flow, return to VaultPool, verify quota and identity.
