# Filen direct connector

VaultPool connects Filen in-process. The user does not install a Filen CLI or desktop client, create an API application, configure a server, or open a console.

## Authentication and secrets

The local Filen modal submits email, password and an optional 2FA code to the direct connector. The SDK derives the authentication material during login. If Filen requires 2FA, the UI changes to a second verification step without repeating the email/password form. The 2FA code is used once and is not written to VaultPool state.

After a successful login, VaultPool verifies the email, account/base folder and real used/total quota. It then creates or reuses the `/VaultPool` namespace and serializes the SDK session with `SerializeTo`. That serialized blob can contain API/session and encryption key material, so it is stored only as `secretvault.FilenSession` inside the existing encrypted Windows DPAPI-backed SecretVault. It is never placed in `accounts.json`, manifests, logs, HTML, JavaScript or local storage. The password is not stored.

On a later probe, VaultPool reconstructs the session with `DeserializeFrom`, rechecks identity and quota, and rejects a different stable provider identity. A missing or invalid session produces a reauthentication state; existing remote objects and manifests are preserved.

## Remote object contract

Filen implements the same `remoteobject.Store` contract used by the other providers. All VaultPool objects are written below `/VaultPool` with opaque names. Uploads follow `upload -> locate -> size check -> download -> SHA-256 check`; only the verified result is returned to the storage core. Downloads check the expected size and SHA-256 before returning bytes. Deletes are permanent provider deletes followed by a fresh lookup that must confirm absence. Recovery listing is restricted to VaultPool manifest and file-key name patterns and bounded reads.

Every login, probe, list, upload, download and delete operation receives a caller context and a connector timeout. The UI login endpoint has an additional 90-second request budget and maps provider failures to safe messages for the frontend. SDK/API error strings are not returned to the browser.

## Disconnect

Disconnecting Filen deletes the serialized session and encrypted display identity from SecretVault and marks the local account as requiring authentication. It does not delete `/VaultPool`, remote files, manifests or the local account record. Remote deletion remains a separate, authenticated data operation.

## SDK audit

The compiled dependency is:

- `github.com/FilenCloudDienste/filen-sdk-go` v0.0.39, official repository, MIT license.

The SDK's module dependencies are resolved and pinned through `go.mod`/`go.sum`. The SDK supports the server-selected authentication versions 1, 2 and 3; VaultPool does not force a single version. Version 3 sessions use the SDK's DEK/KEK and private-key state, while legacy versions retain their master-key state. Deserialization in the pinned SDK does not restore its public encryption-version fields, so VaultPool restores those fields from the serialized auth version before any file operation.

The SDK brings cryptographic, UUID, HTTP/download and text helpers, including `github.com/dromara/dongle`, `github.com/google/uuid`, `github.com/rclone/rclone`, `github.com/zeebo/blake3`, `golang.org/x/crypto`, `golang.org/x/sync` and `golang.org/x/text`. Their exact versions are recorded by Go module resolution and must be included in the release notice generated from the final `go.sum`.

The official SDK source and its license are linked here for release review: [official Go SDK](https://github.com/FilenCloudDienste/filen-sdk-go), [Go package documentation](https://pkg.go.dev/github.com/FilenCloudDienste/filen-sdk-go/filen), [SDK MIT license](https://raw.githubusercontent.com/FilenCloudDienste/filen-sdk-go/main/LICENSE), and [Filen API documentation](https://docs.filen.io/).

## Field-test gate

Unit tests use a fake session and verify login, serialized-session storage, restored probes, identity binding, quota, namespace idempotence, verified upload/download/delete, recovery discovery, cancellation, timeout and logout. A real field test remains required with a disposable Filen account: connect, verify quota, upload a disposable object, redownload and hash it, restart VaultPool, restore the session without the password, redownload and hash it again, then delete and confirm absence.
