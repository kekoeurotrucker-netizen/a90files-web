# Local storage placement policy

VaultPool classifies a file locally from its extension before it is encrypted.
The classification never changes the redundancy rules, failure-domain rules or
the requirement to verify every remote object by SHA-256.

| Class | Examples | Local handling |
| --- | --- | --- |
| Video | mp4, webm, mov, avi, mkv | 1 MiB blocks, no recompression, favour measured fast targets when the safe placement choices are equivalent. |
| Audio | mp3, m4a, flac, wav | 2 MiB blocks, no recompression, favour measured fast targets when safety is equivalent. |
| Image | jpg, png, webp, heic | 2 MiB blocks, no recompression. |
| Archive | zip, rar, 7z, gz, iso | 4 MiB blocks, no recompression. These are normally download-oriented. |
| Creative project | blend, prproj, aep, psd, ai | 1 MiB blocks, compression remains enabled for data that benefits from it. |
| General | documents and unknown extensions | 2 MiB blocks, compression remains enabled. |

Bandwidth observations are per account, never shared between accounts. The
planner may use them only to break ties between placements that already meet
quota, health and independent failure-domain requirements. Multiple MediaFire
accounts are always one `mediafire` failure domain and cannot increase the
claimed redundancy level.
