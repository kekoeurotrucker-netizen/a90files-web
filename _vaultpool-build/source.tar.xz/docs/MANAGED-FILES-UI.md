# VaultPool M0.12 — Managed Files UI and Recovery-Safe Catalog

M0.12 connects the provider-neutral health/repair core to the local VaultPool UI without exposing recovery-critical secrets in ordinary application state.

## Privacy boundary

The ordinary UI state file is not a secret store. It must not contain:

- file data keys;
- file names or original SHA-256 values for managed files;
- OAuth access/refresh tokens;
- recoverable passwords/usernames;
- provider account identity strings such as email addresses.

Managed-file names, original hashes and other private catalog metadata are stored as encrypted `FileMetadata` entries inside the SecretVault. File encryption keys are stored separately as `FileDataKey`. Provider display identities are stored as `AccountIdentity`.

Stable target IDs used by manifests are opaque SHA-256-derived identifiers, not raw provider user IDs.

## Recovery gate

A managed file cannot be registered until portable recovery is configured. `FileDataKey` and `FileMetadata` are recovery-critical kinds, and SecretVault refuses to store them otherwise.

This is intentional: Reed-Solomon can recover missing storage shards, but it cannot recover a lost encryption key or undiscoverable file metadata.

## File health

The Files screen exposes verified health rather than optimistic status. An audit classifies each shard as:

- valid;
- confirmed missing;
- corrupt;
- temporarily unavailable.

Temporary provider outage, rate limiting or reauthentication is never presented as permanent loss. The UI does not automatically audit every file on page load, avoiding unnecessary provider API traffic and rate-limit pressure.

Repair is enabled only for confirmed missing/corrupt shards and only when the current target set can preserve the configured provider-failure margin. Temporarily unavailable shards are not silently migrated.

## Long operations

File audit/repair endpoints deliberately have no arbitrary application write timeout. They are bounded by request cancellation, application shutdown and provider-level failures/retry policy rather than a VaultPool-imposed transfer deadline.

## Transactional catalog registration

Updating an existing FileID is transactional across:

1. encrypted file key;
2. encrypted file metadata;
3. encrypted local manifest.

If a later write fails, the previous key and metadata are restored. A stale generation or conflicting name/hash/size/key for an existing FileID is rejected rather than silently accepted.

## Windows-safe atomic replacement

Critical local files use `internal/safefile`:

- manifests;
- SecretVault;
- portable recovery package;
- UI/app state;
- verified local provider objects;
- restored output files.

On Windows VaultPool uses `MoveFileExW(MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)`. On Unix it uses rename semantics with best-effort parent directory syncing.

This removes the previous Windows/Unix inconsistency around replacement of an existing destination.
