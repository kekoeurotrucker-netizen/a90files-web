# VaultPool virtual drive — M0.20

VaultPool exposes an optional Windows virtual drive backed by the same authenticated managed-file core used by the GUI and CLI.

## Security model

The first stable mount is deliberately **read-only**. Explorer can list, open and copy managed files, while create/write/rename/delete/truncate requests are rejected as write-protected. Windows filesystem writes may be random and concurrent; VaultPool will not let Explorer report a successful copy before the remote copy → verify → authenticated manifest commit has completed. New protected files therefore enter through the VaultPool GUI or CLI.

Reads are reconstructed on demand by range. VaultPool resolves the private catalog entry, authenticated manifest and file key, retrieves only intersecting blocks, verifies shard/object hashes, reconstructs Reed-Solomon data when required, authenticates AES-GCM, decompresses when needed and returns only the requested bytes. There is no permanent plaintext virtual-drive cache.

Compression access is serialized inside the shared Engine because the codec instance is not assumed concurrency-safe while Explorer and managed transfers may read concurrently.

## Dokany 2.3.1 / API 231 boundary

The Windows host dynamically loads `dokan2.dll`; VaultPool does not require cgo and never silently installs or removes a kernel driver. M0.20 targets the current Dokany 2.3.1 ABI and requires both the loaded library and driver to report API version **231**. A mismatched installation is reported as incompatible rather than guessed safe.

Runtime status distinguishes:

- supported platform;
- Dokany DLL installed;
- signed driver available;
- exact compatible API version;
- mounted/running state.

The mount uses write protection and current-session semantics. The preferred default is `P:` but another free drive letter may be selected. GUI and CLI storage remain usable when Dokany is missing or incompatible.

## Safe logical capacity

Explorer must not see the sum of physical cloud quotas as writable capacity. M0.20 groups connected accounts by provider failure domain and asks the storage planner for the maximum logical payload that can actually be protected with the current targets.

Examples:

- two independent 15 GB accounts in mirror mode expose about **15 GB logical**, not 30 GB;
- multiple accounts at the same provider do not create another failure domain;
- incoherent/missing quota snapshots are excluded rather than replaced with advertised plan sizes.

The GUI may still show each account's real physical used/free capacity separately. Logical drive capacity and physical provider capacity deliberately answer different questions.

## Commands

```text
vaultpool drive-status
vaultpool mount --drive P:\nvaultpool unmount
```

The same operations are available in **Ajustes → Unidad virtual de Windows**.

## Validation boundary

The pure-Go Windows binding and x64 ABI layouts are compile-time guarded and cross-compiled during source validation. A real kernel mount still requires a physical/VM Windows test with the signed Dokany 2.3.1 driver. That real-runtime test is a release gate and must not be inferred from cross-compilation alone.
