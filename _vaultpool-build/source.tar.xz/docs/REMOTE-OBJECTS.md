# VaultPool M0.8 — Verified remote object stores

M0.8 added the first provider object-operation layer for Google Drive and OneDrive. M0.21 adds MEGA through the official MEGAcmd bridge while preserving the same verified-write invariant.

## Non-negotiable write invariant

A remote fragment is not trusted merely because an upload request succeeded:

`validate local SHA-256 -> upload -> obtain provider object ID -> read object back -> verify exact size + SHA-256 -> return trusted object`

If post-upload verification fails, VaultPool attempts to delete the untrusted remote object and never returns it as valid. The manifest/core integration in a later milestone must only commit object IDs returned by `PutVerified`.

This costs an additional read after upload. It is deliberately conservative. Provider-native checksums can later reduce that cost only where their semantics are documented and our implementation can prove equivalent integrity guarantees.

## Google Drive

- Uses `drive.file` OAuth scope from M0.7.
- Creates/finds a VaultPool-owned `VaultPool` folder using Drive `appProperties`.
- Fragment filenames contain a hash of the logical object key plus random entropy; the original object path is not exposed in the filename.
- Uses resumable upload sessions for a single consistent path regardless of object size.
- The resumable `Location` must remain on the configured HTTPS Google upload origin before VaultPool sends a bearer token to it.
- Downloads use `files.get?alt=media` and are verified locally with SHA-256.

## OneDrive

- Stores VaultPool data under OneDrive's special App Root (`Apps/VaultPool`) rather than the user's normal root.
- Creates upload sessions and uploads sequential byte ranges.
- Transfer chunks are 6.25 MiB, a multiple of the required 320 KiB and within Microsoft's recommended 5–10 MiB range.
- OneDrive `uploadUrl` and `@microsoft.graph.downloadUrl` are preauthenticated URLs. VaultPool **never attaches the user's bearer token** to them.
- Preauthenticated URLs must be HTTPS. In production, loopback/private/link-local/IP-literal targets are rejected to reduce SSRF risk.
- Full readback and SHA-256 verification occur after upload because OneDrive does not guarantee a server SHA-256 field.

## MEGA via official MEGAcmd (M0.21)

- VaultPool does not implement MEGA login or retain a MEGA password/session token. Login occurs in the official interactive MEGAcmd shell.
- Storage operations use the official scriptable commands with argument arrays, never shell-concatenated command strings.
- VaultPool data is restricted to `/VaultPool` and uses opaque/randomized object names.
- A new object is uploaded under a fresh name, downloaded again and verified for exact size + SHA-256 before it is returned as trusted. An older valid object is never pre-deleted.
- Manifest/recovery discovery is restricted to VaultPool filename prefixes under `/VaultPool` and candidates are size-bounded before authenticated envelope verification.
- Each operation re-checks the active MEGAcmd account against the stable target ID recorded when the account was connected. If the user has switched MEGA accounts, the operation fails closed.

## Redirect/token safety

- OAuth token endpoints do not follow HTTP redirects.
- Authenticated provider API calls do not follow redirects.
- Google resumable upload requests carrying bearer authorization do not follow redirects.
- OneDrive preauthenticated transfer URLs may follow HTTPS redirects only after each target passes the preauthenticated-URL safety policy; no bearer header is present.

## Transfer error classification

Remote API errors are represented as typed `APIError` values. VaultPool currently classifies:

- authentication failure (`401`),
- provider rate limit (`429`),
- quota/capacity exhaustion (`507` and quota-related provider codes/messages),
- temporary provider/network-side HTTP failures (`408`, `429`, `502`, `503`, `504`),
- `Retry-After` when supplied.

This is the basis for future UI messages such as "paused by provider limit" versus "transfer is unusually slow" without making unsupported claims.

## No VaultPool bandwidth cap

The remote object stores do not configure an overall HTTP transfer timeout. Transfer cancellation comes from context/user cancellation. A later transfer supervisor will implement stall detection and provider-limit reporting without imposing an artificial VaultPool bandwidth or duration quota.

## Still pending before real user data

- Wire this object layer into the storage core through a generic provider interface.
- Transaction journal for interrupted remote writes and orphan cleanup.
- Retry/resume policy that respects provider `Retry-After` and never rotates accounts to evade limits.
- Real provider application registrations/client IDs and interactive test accounts.
- Final review of OneDrive's narrower `Files.ReadWrite.AppFolder` permission versus quota/identity requirements before release.
