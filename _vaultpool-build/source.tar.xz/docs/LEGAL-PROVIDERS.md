# Provider Compliance Policy

This is an engineering compliance gate, not legal advice.

## Default-deny rule

A real provider connector is **disabled by default** until the current official terms/API policies have been reviewed and recorded for that exact connector version.

Each connector must carry a machine-readable policy describing at least:

- official API/SDK route;
- allowed account types;
- whether multiple accounts per user/profile are allowed;
- whether pooling/aggregation is allowed;
- object-size restrictions;
- transfer/rate limits;
- OAuth scopes/verification requirements;
- prohibited automation/circumvention behavior;
- review date + source URLs.

## Multi-account rule

If a provider prohibits multiple free accounts or using multiple accounts to bypass quotas/limits, VaultPool exposes **maximum 1 account** of that provider per VaultPool user/profile. Technical capability never overrides this policy.

If terms are unclear, use one account or keep the connector disabled until clarified.

## Never allowed by VaultPool

- automatic account creation to multiply free storage;
- fake identities;
- referral/promotion abuse;
- rotating accounts to evade transfer quotas or API throttles;
- bypassing provider-imposed waiting periods;
- undocumented/private APIs used to evade restrictions;
- presenting VaultPool as a way to avoid paying providers by circumventing their rules.

## User-facing wording

VaultPool is a multi-cloud storage, resilience, encryption, and recovery tool. Do not market it as a quota-circumvention tool.

## Change handling

Provider rules change. A connector policy can be updated by a future local application/catalog release or by a signed local policy package, but VaultPool must not require a hosted VaultPool server to stay usable. Any policy update that reduces allowed behavior must fail safely. Existing data stays readable/recoverable; prohibited new placement is blocked and the user is guided to migrate safely.

## Unknown-provider onboarding gate (M0.4)

The UI may show or accept a suggestion for a provider that VaultPool does not yet know, but **unknown never means connectable**.

A suggested provider enters `pending_review` in the local app state. Before a future connector can be marked `allowed`, the local review must cover the provider's current official terms, official integration route, account types/subscriptions, multi-account rules, pooling/aggregation, quotas, file/object limits, OAuth/MFA/CAPTCHA flow, and other restrictions relevant to VaultPool.

Showing a provider as an alternative is informational, not an endorsement and not a method for quota circumvention. VaultPool should use official provider links. If affiliate/sponsored placement is ever introduced, it must be clearly disclosed and must never change the compliance gate or ranking of safety-critical choices.

## Local standard-protocol onboarding (M0.24.3)

Users may add a cloud locally only through a declarative protocol already implemented and audited by VaultPool. The current self-service policy is `vaultpool-generic-webdav-v1`: public HTTPS WebDAV, one account per profile, verified quota, and a temporary create/upload/read/hash/delete round trip. The policy version is persisted with the provider and unknown or future versions fail closed. The checker runs from the user's machine; it does not call a VaultPool-hosted approval service.

This technical gate is not an automatic legal opinion about the provider's terms. If the provider does not clearly permit the standard route, or does not expose a supported standard endpoint, the service remains `pending_review` and cannot be connected. VaultPool never loads arbitrary provider plugins, embeds confidential client secrets, depends on a hosted VaultPool backend, scrapes websites, bypasses MFA/CAPTCHA, creates accounts, or rotates accounts to evade quotas.

## CAPTCHA

CAPTCHA is always human-in-the-loop. VaultPool does not implement CAPTCHA solvers or anti-bot bypasses. Embedded verification is used only when the provider policy permits it; otherwise the system browser is mandatory.

## Reviewed M0.21 MEGA route

MEGA is enabled only through the official MEGAcmd client/command interface. VaultPool allows one MEGA account per profile, does not create accounts automatically, does not rotate accounts to evade transfer/quota restrictions, and does not bypass MFA/CAPTCHA or provider waiting/rate limits. Any interactive challenge remains human-operated in the official MEGA client.

Review sources used for this engineering gate:

- https://github.com/meganz/MEGAcmd
- https://github.com/meganz/MEGAcmd/blob/master/UserGuide.md
- https://mega.nz/cmd

This is an engineering policy, not a permanent legal conclusion; provider terms and client behavior must be re-reviewed before public release.
