# Recovery Model

## M0.1

The encrypted `.cpm` manifest contains the map from logical blocks to provider objects and their expected hashes. A 32-byte recovery key decrypts/authenticates the manifest and each block.

The key and manifest must not have a single point of failure in the finished product. M0.1 now versions the encrypted manifest and replicates each committed generation across all available mock providers. A recovery scan authenticates those copies and groups them by FileID; it never guesses when multiple files are present.

## Finished-product recovery kit

VaultPool will export a portable, encrypted recovery package containing enough metadata to rediscover/rebuild the pool after reinstall, without depending solely on a Windows-machine-bound secret.

Expected workflow:

1. reinstall VaultPool;
2. import recovery kit;
3. authenticate/unlock it;
4. reconnect provider accounts as needed;
5. audit all referenced objects;
6. rebuild the local index;
7. restore degraded redundancy on explicit user request.

## Degraded states

The UI must distinguish:

- account authentication problem;
- provider outage/rate limit;
- missing object;
- corrupt object/hash mismatch;
- insufficient free space to repair;
- redundancy reduced but file recoverable;
- critical zero-margin state;
- insufficient shards for recovery.

The application must explain the next safe action rather than silently retry destructive operations.

## Provider-loss safety

Health reports include both the current shard recovery margin and the margin that would remain after the worst additional single-provider failure. This prevents a superficially healthy `14/14` state from hiding dangerous concentration on one provider.

Provider-loss simulation is part of destructive testing and later becomes part of the user-facing health score.

## Repair transaction

`RepairProtection` reconstructs only missing/corrupt shards. Healthy shards are left in place. If an entire provider is gone, repair requires a destination that preserves the configured provider-failure margin; otherwise it fails with an instruction to add/reconnect an independent provider. Repaired data is verified first, then a new manifest generation is committed and replicated. No healthy/original data is deleted as part of repair.

## M0.13 Recovery Center

Portable recovery is now implemented as a two-step setup: generation is only `pending`; recoverable secrets remain blocked until the user confirms both package and recovery code were saved. Restoration is validated into temporary encrypted state, staged for at most 24 hours and applied before normal vault open on restart. The active vault is never replaced directly by an HTTP request. See `RECOVERY-CENTER.md`.
