# TeraBox candidate policy — M0.23.5

TeraBox is visible only as a candidate provider until VaultPool validates a supported, legal and safe integration surface for personal cloud files.

## Allowed direction

- Prefer official OAuth/Open Platform or a written/developer-approved integration path.
- VaultPool may store provider tokens or refresh tokens only inside SecretVault after user authorization.
- CAPTCHA, MFA and risk checks remain human-only through the provider's official page or app.

## Not allowed

- Do not ask the user for their TeraBox password inside VaultPool for provider automation.
- Do not store provider account passwords as connector credentials.
- Do not use browser cookies, NDUS/session cookies, scraping, reverse engineered endpoints or anti-bot bypass as a production connector.
- Do not make TeraBox part of redundancy planning until upload, download, quota, deletion and identity checks are validated through the approved path.

## Password-manager distinction

VaultPool may later include a local encrypted password-note vault for the user's own reference, with blurred display and explicit reveal, but those saved passwords must not be used to automate unsupported cloud logins. That feature is separate from cloud connectors.
