# Connector contract — M0.5

A cloud connector cannot mutate VaultPool account state directly.

It returns a validated `connector.Snapshot` containing:

- authenticated identity and plan name;
- authentication and health state;
- total / used / free quota;
- transfer readiness;
- observed upload/download throughput fields;
- provider limits and rate-limit notes;
- last-check timestamp and machine-readable error code.

`appstate.ApplySnapshot` rejects provider/account mismatches and inconsistent quota before persisting anything. A failed probe preserves the previous trusted state.

The UI aggregates only accounts whose trusted state is `connected`; pending accounts do not inflate the displayed total capacity.

## Stable account binding (M0.21)

After the first authenticated probe, VaultPool stores only a one-way stable target identifier derived from the provider's stable subject; the raw provider subject is not persisted in application state. A later probe that resolves to a different stable target is rejected rather than silently repointing an existing account. External-session connectors such as MEGA additionally verify the current official-client session on remote operations.
