# VaultPool build and dependency security — M0.20

## Toolchain policy

The production module declares **Go 1.24** as its minimum because the pinned production dependency graph requires it. Release/CI builds must use a currently supported stable Go compiler; the module minimum and the compiler chosen for release are separate controls.

## Pinned dependencies

Production dependencies are pinned in `go.mod` and authenticated sums are committed in `go.sum`, including:

- `github.com/klauspost/compress v1.19.2`;
- `github.com/klauspost/reedsolomon v1.14.2`;
- their pinned transitive dependencies.

Updates are explicit security changes and require review/regression testing. Every source checkpoint must contain both `go.mod` and `go.sum`.

## OAuth release identifiers

Google and Microsoft native/desktop OAuth **Client IDs** are public application identifiers, not client secrets. Source checkpoints deliberately leave the production values blank. `packaging/windows/build-release.ps1` injects approved production Client IDs through linker variables at build time and refuses a normal release build when either is missing. Environment variables may override embedded values for controlled development/testing.

No OAuth client secret belongs in the desktop binary, repository or installer.

## Windows packaging

`packaging/windows/` contains:

- `build-release.ps1` — validates the production build prerequisites, tests/vets, creates Windows x64 payload and portable ZIP, optionally invokes NSIS and Authenticode signing, and emits SHA-256 hashes;
- `VaultPool.nsi` — per-user NSIS installer with VaultPool/VaultPool Doctor shortcuts and uninstaller;
- packaging/readme and third-party notice index.

The installer does **not** silently install/uninstall Dokany and does not remove the VaultPool data/recovery directories when the application is uninstalled. Public distribution must include the exact required upstream license texts after dependency/legal review; the checkpoint does not fabricate them.

## Restricted checkpoint validation

The current development container has Go 1.23.2 and no network route for fetching the real production toolchain/modules. To validate source logic without misrepresenting a production build, a temporary copy changes only the `go` directive to 1.23 and uses the repository's `offline` implementations. The real checkpoint remains Go 1.24.

Source validation includes JavaScript syntax, offline Go test/vet, grouped race-detector runs and a Windows/amd64 offline cross-build. These checks can prove source/platform regressions but **cannot** certify the real cloud dependencies, signed Dokany driver, OAuth apps or Authenticode chain.

## Production release gates

Before a public binary may be called stable, VaultPool still requires:

1. approved Google and Microsoft desktop OAuth Client IDs;
2. a real build/test/vet with Go ≥1.24 and the pinned production dependencies;
3. Windows tests against disposable real Google Drive + OneDrive + MEGA/MEGAcmd accounts;
4. a real read-only mount with the signed Dokany 2.3.1/231 driver;
5. Authenticode signing of the executable and installer;
6. destructive real-cloud provider-loss/recovery tests;
7. final third-party license/security review of the shipped bundle.
