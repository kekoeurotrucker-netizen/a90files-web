# User credentials policy — M0.23.5

VaultPool separates three concepts:

1. **OAuth/app identifiers**: public app IDs such as Google Client ID, Microsoft Application ID or Dropbox App Key. In public builds these are bundled by VaultPool so normal users do not configure developer consoles.
2. **OAuth tokens**: access/refresh tokens returned by official provider authorization. These may be stored encrypted in SecretVault and covered by the recovery flow where appropriate.
3. **Human passwords**: the user's login passwords for Google, Microsoft, Dropbox, MEGA, TeraBox, etc.

Human provider passwords are not connector credentials. VaultPool must not request, store or replay them to automate cloud login unless a future password-manager feature is explicitly separated from provider automation and protected locally for user reference only.

A possible future password-note feature is allowed only as a local encrypted vault:

- blurred by default;
- reveal only after explicit user action;
- auto-hide on blur/timeout;
- copy-to-clipboard with timeout cleanup;
- never sent to cloud providers by VaultPool;
- never included in logs, diagnostics, screenshots or crash reports.

For normal provider connection, the goal is always: **one button → official browser/app authorization → connected**.
