# M0.10 — Remote manifest recovery after reinstall

VaultPool can now rediscover authenticated encrypted manifests from storage targets after local state/manifests are lost.

## Recovery-only surface

Remote connectors do **not** expose a generic unverified object read. The recovery interface is intentionally limited to:

1. enumerate objects that the provider can prove belong to VaultPool's manifest namespace;
2. bounded-read only one such candidate;
3. authenticate/decrypt the bytes with the VaultPool recovery key using AES-256-GCM.

The default candidate cap is 64 MiB. Data shards never use this relaxed discovery read path.

### Google Drive

Manifest objects carry `appProperties.vaultpool_kind=manifest`. Discovery scans every folder marked as a VaultPool root, so a historical duplicate root cannot silently hide recovery metadata. Before reading bytes, VaultPool re-fetches object metadata and refuses objects not marked as manifests.

### OneDrive

Manifest replicas use a reserved deterministic name namespace `vp-manifest-<sha256(logical-key)>.cpm` directly under the application's isolated `Apps/VaultPool` App Root. Discovery lists only that namespace. Before downloading, VaultPool re-fetches metadata and rejects non-manifest names. The preauthenticated download URL never receives the user's bearer token.

## Failure behavior

A provider that is offline or cannot list/read does not abort the entire scan; VaultPool records a recovery issue and continues with independent targets.

Corrupt or unauthenticated replicas are ignored and reported. However, two different manifests that both authenticate under the recovery key with the same FileID and generation are a hard integrity error. VaultPool does not guess by majority, date, or provider preference.

For each FileID, the newest unambiguous authenticated generation is selected. Multiple recoverable files require explicit FileID selection.

## Cleanup invariant strengthened in M0.10

Failed write cleanup removes newly-created manifest replicas before data shards. If even one manifest replica cannot be deleted, VaultPool deliberately retains **all** new data shards from that operation. This prevents VaultPool itself from leaving an authenticated surviving manifest that points to data it subsequently deleted. Orphan data is preferable to unrecoverable authenticated metadata.

## Proven destructive tests

- local manifest deleted -> recovered from replicas;
- one complete provider deleted -> manifest recovered from remaining targets -> file restored byte-for-byte;
- corrupt manifest replica -> ignored, other replicas used;
- same-generation authenticated conflict -> hard failure;
- multiple files -> explicit selection required;
- manifest-only readers reject normal data objects;
- manifest recovery reads enforce a hard size cap;
- OneDrive preauthenticated recovery downloads receive no bearer token.
