# VaultPool — Milestone 0.22.7 Release Candidate

VaultPool is a Windows-first virtual multi-cloud storage project focused on data safety, provider-rule compliance, recovery, and transparent storage optimization.

The storage core is tested against local simulated providers for destructive data-safety tests. Google Drive and OneDrive use native/public-client OAuth with PKCE, encrypted token storage and verified identity/quota probes. M0.21 additionally introduces an approved MEGA bridge through the official MEGAcmd application: login remains inside MEGA's own interactive client and VaultPool never receives or stores the MEGA password or session string. Production Google/Microsoft client IDs are intentionally not embedded in source checkpoints. M0.22.6 fixes Windows MEGA launch so VaultPool uses the interactive MEGAcmd shell rather than the scriptable client for human login. M0.22.7 gates that MEGA console bridge behind an explicit developer/test mode and fixes the authentication modal so closing or cancelling external login cannot leave the UI blocked.

## M0.22 biblioteca multinube y formato recuperable de campo

M0.22 añade una biblioteca unificada encima de todos los proveedores conectados. La GUI permite buscar por nombre/extensión/tipo/carpeta, filtrar por categoría, ordenar por fecha/nombre/tamaño/tipo y crear, renombrar o eliminar carpetas virtuales personalizadas. Las carpetas son metadatos privados cifrados: reorganizar un archivo no mueve fragmentos, no consume cuota y no cambia su capacidad de recuperación. Las categorías base son Vídeos, Imágenes, Documentos, Audio, Comprimidos, Código, Aplicaciones y Otros.

La build de campo M0.22 permite pruebas extremo a extremo sin un límite artificial de 64 MiB por archivo, pero queda limitada a 2 o 3 proveedores independientes. Esos modos usan una implementación canónica compartida de **replicación 1+1 / 1+2**, donde cada shard es una copia exacta del bloque cifrado. Por tanto no dependen de matrices Reed-Solomon distintas entre builds. Si la build de campo comprime un bloque, el manifiesto autenticado registra `zlib`; las builds posteriores despachan la descompresión por el nombre almacenado aunque su compresor preferido sea Zstandard. Una build de campo se niega a escribir con 4+ proveedores, reservando Reed-Solomon para builds de producción con la dependencia revisada.

**Regla de formato:** VaultPool no debe crear deliberadamente un formato de prueba que una build futura no pueda leer. Los algoritmos necesarios para restaurar se conservan identificados y soportados, y las pruebas de compatibilidad forman parte del checkpoint.

## Safety invariant

VaultPool never treats a new copy as valid until it is cryptographically/integrity verified. A move is always:

`copy -> verify destination -> persist manifest -> delete source`

If any step before the final delete fails, the source remains.


## M0.21 MEGA bridge and account-identity binding

M0.21 adds MEGA as a third approved storage provider through the official **MEGAcmd** client rather than implementing or imitating MEGA login. VaultPool launches MEGAcmd's interactive shell for human login, probes the resulting session with official scriptable commands, and uses `mega-put`, `mega-get`, `mega-rm`, `mega-find`, `mega-du`, `mega-df` and `mega-whoami` through direct argument arrays. VaultPool never passes a MEGA password on a command line and never copies the MEGAcmd session token into its own state.

MEGA storage is confined to `/VaultPool`. Uploaded VaultPool objects receive opaque/randomized names, are read back and SHA-256 verified before they become trusted, and older valid replicas are never deleted before a replacement is verified. Recovery discovery is restricted to the reserved VaultPool namespace. Because MEGAcmd has one active account entity at a time, the catalog permits one MEGA account per VaultPool profile and each remote operation rechecks that the active MEGA identity matches the stable account target already registered in VaultPool. A manual switch to another MEGA account therefore blocks transfers instead of redirecting data.

M0.21 also hardens account identity binding for every provider: once a VaultPool account has a verified stable provider identity, a later authentication result with a different provider identity is rejected and must be added as a separate VaultPool account. `vaultpool doctor` now reports whether the official MEGAcmd command set is available. On Windows, launching `VaultPool.exe` without CLI arguments now opens the desktop application directly. Release builds use the Windows GUI subsystem and detach the background UI service from console handles, so opening VaultPool from Explorer or a shortcut does not flash a console window.

## Direct Filen connector

Filen uses the official Go SDK directly from VaultPool. The local modal accepts email, password and optional 2FA, validates the real identity/quota/base folder, creates or reuses `/VaultPool`, verifies uploads with a read-back SHA-256, and stores only the serialized SDK session in the existing encrypted SecretVault. See `docs/FILEN-CONNECTOR.md`.

M0.21 is code-tested but **not yet validated against a real MEGA account in this environment**. Real-Windows MEGAcmd upload/restore/recovery tests remain a release gate, together with real OneDrive/Google tests, production OAuth registrations, supported production-Go compilation, Dokany, Authenticode and destructive disposable-account validation.

## M0.20 release-candidate hardening

M0.20 closes the first release-candidate safety pass around the existing cloud/storage core. Protection is now explicit for small provider sets: **2 independent providers use a full 1+1 mirror**, **3 independent providers use 1+2 triple replication**, and **4+ independent providers use the adaptive Reed-Solomon planner**. Multiple accounts at one service still count as one provider failure domain. If a constrained third provider cannot participate safely, VaultPool preserves the already-viable 2-provider mirror instead of making the pool unusable.

The Windows virtual drive remains read-only, but its reported logical capacity now comes from the safety planner instead of summing physical cloud quota. The GUI continues to show physical account capacity separately. M0.20 also adds controlled transfer shutdown/rollback, one live VaultPool instance per profile, authenticated local-service identity checks, `vaultpool version`, `vaultpool doctor`, a working top-level **Añadir archivo/carpeta** flow, explicit protection-mode status, recovery-secret auto-hide/clipboard cleanup, exact Dokany 2.3.1/231 compatibility checks, and Windows release packaging scaffolding.

The source is release-candidate quality, not yet a public production release. Real Google Drive/OneDrive OAuth registrations, a supported production Go build, real-Windows Dokany/cloud tests including official MEGAcmd, Authenticode signing and destructive tests against disposable real cloud accounts remain release gates.

## Proven M0.1 Local Core pipeline

`file -> block -> try compression -> AES-256-GCM -> Reed-Solomon -> provider placement -> SHA-256 verification -> encrypted manifest`

Restore performs the reverse operation and checks the final SHA-256 against the original. Each encrypted block is AEAD-bound to both its FileID and block index, preventing cross-file block substitution.

Encrypted manifests are versioned and replicated to every available mock provider in the proven M0.1 Local Core. Recovery discovery authenticates replicas, groups them by FileID, rejects conflicting same-generation metadata, and restores the newest valid generation for the selected file.

## M0.19 optional read-only Windows virtual drive

M0.19 introduced the optional read-only Windows virtual drive; M0.20 updates its runtime compatibility boundary to Dokany 2.3.1 / API version 231. The mount is deliberately read-only: Explorer can list/open/copy managed files through authenticated range reconstruction, while create/write/rename/delete/truncate requests return write-protected. VaultPool dynamically detects the Dokany DLL and signed driver and never claims a mount or silently installs a driver when the dependency is absent. GUI and CLI continue to work without it. Physical quota snapshots come only from connected accounts; the drive capacity exposed to Windows is the planner-derived logical capacity that can actually be protected under the current provider layout. See `docs/VIRTUAL-DRIVE.md`.

## M0.18 desktop shell, CLI controls and authenticated range reads

M0.18 adds the Windows desktop launcher, a loopback-only CLI control client and provider-neutral authenticated range reconstruction. `vaultpool app` launches the local service and opens an isolated Edge app window when available, falling back to the system browser. The CLI can inspect accounts/files/recovery/transfers and invoke the same protected operations as the GUI. Range reads reconstruct only the blocks intersecting the requested byte interval and continue to work inside the configured Reed-Solomon loss budget.

## M0.17 native Windows file dialogs

M0.17 connects the managed transfer UI to native Windows Open/Save common dialogs without uploading file contents through the browser surface. Dialog requests remain exact-same-origin + CSRF protected, are serialized to avoid overlapping user intent, do not change the process working directory, and are unavailable on unsupported platforms. Manual absolute-path entry remains a fallback for non-Windows development.

## M0.16 managed transfers

M0.16 connects the managed-file catalog to the provider-neutral storage core for real long-running protect/restore operations. A protect operation uses the selected local file directly (no whole-file plaintext staging), establishes durable recovery-key replicas before uploading data, performs full preflight/capacity planning, uploads and verifies shards, commits authenticated manifest replicas, and only then registers the private catalog. Restore verifies the final original SHA-256 before atomically replacing the destination.

Transfers run as in-process background jobs with sanitized progress/cancellation state; local paths are never returned by the activity API. Late cancellation cannot relabel an already committed transfer as canceled. Planner preflight now also reserves manifest commit headroom on every enabled target. The current monolithic manifest is capped at the same 64 MiB accepted by remote recovery; paged manifests remain a future hardening milestone for very large files. See `docs/TRANSFERS.md`.

## M0.15 guided recovery and credential snapshot tracking

M0.15 separates continuously durable file recovery from the offline snapshot needed for recoverable usernames/passwords. File keys and private file metadata no longer rewrite or stale the external `.vpr`: M0.14 recovery records carry those keys across reinstalls. Recoverable credential changes instead increment an explicit credential revision; the Recovery Center requires the current revision to be exported before the user can confirm the external copy as up to date.

The new metadata-only recovery assistant rebuilds a lost local catalog after restoring a kit and reconnecting available accounts: it restores authenticated per-file keys, discovers authenticated remote manifests, routes each manifest to the correct FileID/key and imports the private catalog. Provider outages become warnings rather than false data-loss claims, and shard health audits remain explicit to avoid unexpected transfer/rate-limit consumption. See `docs/RECOVERY-ASSISTANT.md`.

## M0.14 durable per-file recovery records

M0.14 removes the requirement to re-download the portable package after every new file. Before a normal file registration is committed, its data key is sealed under a key derived from the portable recovery root and replicated as a tiny authenticated recovery record across at least two independent provider failure domains. Multiple accounts at one provider add account-level resilience but count as one provider domain. Conflicting authenticated records are a hard recovery error. An older `.vpr` therefore supplies the recovery root while newer file keys can be rediscovered from the providers.

## M0.13 Recovery Center

M0.13 exposes portable recovery as a two-step security workflow in the local UI. VaultPool generates an encrypted `.vpr` package plus a one-time 256-bit recovery code, but recovery-critical secrets remain blocked until the user confirms that both were saved separately. Restore requests are authenticated and staged without touching the live vault, expire after 24 hours, and are applied only at the next process start after preserving private backups. The local control surface now requires exact same-origin requests plus a per-process CSRF token for every state-changing action. See `docs/RECOVERY-CENTER.md`.

## M0.12 managed files UI and recovery-safe catalog

M0.12 connects file health/repair to the real local UI while keeping recovery-critical data out of plaintext application state. File keys, file names/original hashes and provider display identities live in the encrypted SecretVault. Managed files cannot be registered until portable recovery exists. The UI distinguishes missing/corrupt shards from temporary provider unavailability, performs audits only on request, and enables repair only when it is safe. Critical local replacements now use a Windows-aware atomic file layer. See `docs/MANAGED-FILES-UI.md`.

M0.12 also introduces a reproducible dependency policy: `go.sum` is part of every checkpoint, the module minimum is Go 1.24 because current pinned dependencies require it, and release builds must use a supported Go compiler. The restricted development container can validate the full offline test path and Windows-specific code, but it does not claim a real production dependency build. See `docs/BUILD-SECURITY.md`.

## M0.11 target health and safe repair

M0.11 brings verified audit and explicit repair to provider-neutral targets. Shards are classified as valid, missing, corrupt or temporarily unavailable; provider/API outages are never mislabeled as permanent loss. Repair touches only confirmed missing/corrupt shards, preserves configured provider-failure margin and hard capacity/object limits, verifies replacements before manifest commit, and deletes superseded objects only after the new authenticated manifest generation is committed. Unavailable shards are deferred rather than silently migrated. See `docs/TARGET-HEALTH-REPAIR.md`.

## M0.10 remote manifest recovery

M0.10 adds reinstall-safe manifest discovery across provider-neutral targets. Recovery uses a narrow provider surface that can enumerate/read only VaultPool manifest replicas, applies a 64 MiB candidate cap, and then requires AES-GCM authentication before metadata is trusted. Google uses manifest `appProperties`; OneDrive uses a reserved manifest namespace inside `Apps/VaultPool`. Provider outages are recorded and skipped, corrupt replicas are ignored, and conflicting authenticated same-generation manifests cause a hard failure. The cleanup invariant was strengthened so data shards are retained if any failed-operation manifest replica cannot be removed. See `docs/REMOTE-RECOVERY.md`.

## M0.9 stable cloud targets

M0.9 connects the erasure-coding core to a provider-neutral storage target abstraction. Manifest shard locations use stable opaque target IDs rather than transient VaultPool account IDs. Raw provider-owned subjects are not persisted in normal app state; VaultPool stores only a SHA-256-derived stable target ID. OneDrive binds to the concrete `drive.id`, while Google Drive uses its stable permission identifier.

The cloud-capable pack path performs complete preflight, verified shard writes, authenticated manifest replication and only then atomically commits the local manifest. Any failure before commit triggers best-effort cleanup of every object created by that attempt. Restore resolves stable target IDs, reconstructs within the parity budget and verifies the final original SHA-256 before exposing output. See `docs/TARGET-STORAGE.md`.

## M0.8 verified remote objects

M0.8 adds independently tested Google Drive and OneDrive remote-object stores. A remote upload is not considered trustworthy until VaultPool downloads the object again and verifies exact size and SHA-256. Google uses resumable uploads inside a VaultPool-owned Drive folder. OneDrive uses its isolated App Root (`Apps/VaultPool`) and sequential upload-session ranges. Preauthenticated OneDrive transfer URLs never receive the user's bearer token, while authenticated API/token requests are configured not to follow redirects. Typed API errors preserve rate-limit/quota/authentication classification and `Retry-After` for future UI notifications. See `docs/REMOTE-OBJECTS.md`.

## M0.7 native OAuth connectors

M0.7 adds public/native OAuth clients for Google Drive and OneDrive. Authorization is system-browser only, uses loopback redirects, one-time state and PKCE S256, and never sends a client secret. OAuth tokens are stored only in the M0.6 encrypted secret vault. An authorization callback does not make an account trusted: VaultPool probes the provider API and validates identity/quota before changing the account to `connected`.

The local UI now has a direct POST-to-redirect launch path so a deliberate user click opens the provider authorization flow without an asynchronous popup workaround. Providers without an approved native authentication design remain gated. See `docs/OAUTH-CONNECTORS.md`.

## Adaptive protection planner (M0.2, evolved in M0.20)

The storage planner (`internal/planner`) receives post-compression/encryption sizes plus current target capabilities and chooses a complete safe placement before any remote data write. The original M0.2 Reed-Solomon policy remains the efficient default when there are at least four independent provider failure domains. M0.20 adds explicit safe behavior for smaller sets instead of pretending those layouts have the same margin:

- **2 independent providers:** full 1+1 mirror. Either provider may disappear and the file remains recoverable, but there is no additional provider-loss margin afterward.
- **3 independent providers:** 1+2 triple replica. After one provider disappears, two copies remain. If the third provider is too constrained for that layout, VaultPool falls back to the viable 2-provider mirror rather than breaking an existing safe pair.
- **4+ independent providers:** adaptive Reed-Solomon subject to the configured provider-loss margin and efficiency ceiling. With ample capacity the familiar geometries include 8+4 across 4 providers, 6+3 across 5, and 4+2 across 6.

Multiple accounts at one service count as one failure domain. The planner respects free space and object-size limits, reserves capacity cumulatively for the full operation, and exposes `MaxLogicalCapacity` so Windows never presents the physical quota sum as safely writable logical space. See `docs/PLANNER.md`.

Example planner target file:

```json
[
  {"id":"drive-main","failure_domain":"google-drive","free_bytes":1000000000,"enabled":true},
  {"id":"mega-main","failure_domain":"mega","free_bytes":1000000000,"enabled":true}
]
```

Example command:

```bash
vaultpool plan --bytes 600000000 --targets ./targets.json
```

## Production dependencies

- `github.com/klauspost/compress` v1.19.2 — Zstandard.
- `github.com/klauspost/reedsolomon` v1.14.2 — erasure coding.
- AES-256-GCM uses Go's standard library.

Dependencies are pinned. Production releases must run dependency/security review before updating.

## Commands

```bash
vaultpool keygen --out recovery.key
vaultpool init-pool --dir ./pool --providers 6
vaultpool pack --in ./example.bin --pool ./pool --manifest ./example.cpm --key ./recovery.key
vaultpool audit --pool ./pool --manifest ./example.cpm --key ./recovery.key
vaultpool repair --pool ./pool --manifest ./example.cpm --key ./recovery.key
vaultpool discover --pool ./pool --key ./recovery.key
vaultpool recover-manifest --pool ./pool --file-id <id> --out ./recovered.cpm --key ./recovery.key
vaultpool unpack --pool ./pool --manifest ./example.cpm --key ./recovery.key --out ./recovered.bin

# Local desktop/control surface
vaultpool app
vaultpool version
vaultpool doctor
vaultpool status
vaultpool accounts
vaultpool files
vaultpool protect --path C:\Data\example.bin
vaultpool restore-file --id <id> --out C:\Data\restored.bin
vaultpool health --id <id>
vaultpool repair-file --id <id>
vaultpool transfers
vaultpool cancel-transfer --id <id>
vaultpool recovery-status
vaultpool rebuild-catalog
vaultpool drive-status
vaultpool mount --drive P:
vaultpool unmount
```

M0.1's fixed regression path remains 4 data shards + 2 parity shards. The M0.2 CLI pack path is adaptive: with ample capacity it currently selects 4+2 across 6 independent providers, 6+3 across 5, and 8+4 across 4. It preflights compression-derived encrypted block sizes, reserves capacity for all blocks, writes only after a complete safe plan exists, and restores using the Reed-Solomon geometry stored in the encrypted manifest.

## Deliberately not implemented yet

- additional production providers beyond the reviewed Google Drive/OneDrive/MEGA substrate;
- Windows Hello UI and final end-user credential-vault surface;
- automatic provider Terms-of-Service updater;
- production policy for how many remote manifest replicas to keep (M0.1 deliberately replicates them to all mock providers);
- object aggregation to minimize remote object count;
- direct write/rename/delete semantics through the Windows virtual drive (the first stable release remains read-only by design);
- production Authenticode signing credentials and real-Windows/cloud release certification;
- final audited third-party license bundle for the public binary distribution.

Those come only after the Local Core passes destructive testing.

## Provider failure-domain rule

VaultPool does not count multiple accounts at the same company as independent safety domains. The placement planner evaluates the worst complete loss of any one provider before accepting a layout. For 4+ independent domains the adaptive policy defaults to a minimum **one-shard margin after that provider loss**. The 2-provider mirror and 3-provider triple-replica modes intentionally report their different margin semantics instead of claiming the Reed-Solomon target.

This rule also applies to migrations: a move that would concentrate too many shards on one provider is rejected before data is copied.

## Local UI (M0.4)

Run the current interface locally:

```bash
go run -tags offline ./cmd/vaultpool ui --listen 127.0.0.1:8742 --state ./vaultpool-data/ui-state.json
```

Then open `http://127.0.0.1:8742/`.

The M0.4 UI implements provider discovery, account-limit enforcement, compliance gating, unknown-provider review requests, and authentication/CAPTCHA policy planning. It does not yet perform real provider OAuth or store real credentials.

## M0.5 authentication and connector substrate

M0.5 adds machine-enforced authentication strategies, short-lived OAuth/PKCE session state, a provider connector contract, validated quota/health snapshots and UI account lifecycle states. Adding a provider creates `pending_auth`; it does **not** count as connected capacity until a real connector successfully authenticates and returns a coherent snapshot.

The current UI exposes the approved auth route but deliberately does not collect real credentials or persist OAuth tokens yet. The next security prerequisite is the encrypted credential/token vault.

Provider gating is default-deny. Google Drive and OneDrive retain a reviewed native-browser direction; MEGA uses an external session in the official MEGAcmd client; pCloud, Box and Proton Drive remain `review_required` until a safe standalone desktop authentication design is proven.

## M0.6 secret vault

M0.6 introduces the Windows-targeted encrypted secret vault required before enabling live OAuth. A random AES-256-GCM master key is protected with current-user Windows DPAPI. OAuth tokens may be stored locally; recoverable usernames/passwords are rejected until a portable recovery package and independent 256-bit recovery code have been configured. Recovery has been tested across a different protector profile, including tamper and wrong-code failure cases.


## M0.22.8
Hotfix de UX: no congelar UI tras cancelar/acceso externo; MEGA no abre consola en flujo normal; Comprobar tiene feedback y timeout.

## M0.22.9 hotfix note

MEGA console launch is disabled for normal users. VaultPool may still call official MEGAcmd silently for quota/session checks and transfers, but the visible command-line login flow is not acceptable for public/beta users and is gated behind developer diagnostics only.


## M0.23.1 hotfix

Dropbox usa terminología propia en UI: App Key público, no Client ID genérico. Los textos de Google quedan fuera del flujo de Dropbox.


## M0.23.2 — Dropbox redirect URI hotfix

Dropbox exige que la `redirect_uri` usada en OAuth coincida exactamente con una de las registradas en su App Console. Esta build fija el retorno de Dropbox/PKCE a:

```text
http://127.0.0.1:8742/oauth/callback
```

El modal de Dropbox lo muestra explícitamente para evitar errores por registrar `localhost`, otra ruta o un puerto distinto.

## M0.23.5 — TeraBox gate, Opera/browser fix and one-click add file UX

M0.23.5 adds TeraBox as a visible but blocked candidate provider. It is not used for storage until VaultPool validates an official, safe integration path for OAuth/API access to files, quota, upload, download and deletion. Passwords, cookies, scraping and anti-bot bypass are explicitly rejected for provider automation.

The OAuth browser selector now validates selected browsers before saving and improves Opera/Opera GX discovery through registry and explicit install paths. “Añadir archivo/carpeta” is explicit: users can browse to a single file or protect a whole folder as one local `.vaultpool-folder.zip` package before encryption/fragmentation; manual path entry remains an advanced fallback.

## M0.24.3 guided custom cloud onboarding and policy gate

The Providers view now includes a non-developer assistant for adding a cloud through a safe generic connector. The first supported self-service protocol is HTTPS WebDAV. VaultPool requires a public HTTPS endpoint, blocks local/private addresses and redirects, verifies WebDAV authentication and quota, and performs a temporary PUT/GET/byte-verify/DELETE test before the provider can be added. The machine-enforced policy is versioned as `vaultpool-generic-webdav-v1`; unknown or future policy versions fail closed. Credentials are stored only in SecretVault. Arbitrary plugins, scraping/private APIs, confidential client secrets embedded in the executable, and providers that require a VaultPool-hosted backend remain blocked. The checker and pending-review queue are local to the user's app state, so VaultPool does not need an external server to stay usable. A technical pass is not a legal opinion about the provider's terms: unsupported or unclear services are left pending review and cannot connect.

## M0.24.11 local media player

The Files view now shows `Reproducir` for video files. Playback prepares a decrypted temporary cache file under the local VaultPool profile, serves it only from the loopback UI (`127.0.0.1`), and keeps remote cloud fragments encrypted. The integrated player attempts common formats including MP4, M4V, MOV, WebM, AVI, MPEG/MPG, OGV/OGG, 3GP/3G2 and TS. Because AVI/MOV/MKV are containers and codec support depends on the Windows media engine, VaultPool exposes a fallback panel when the browser cannot decode the prepared file.

VLC portable support is optional and user-initiated. VaultPool can download the official Windows ZIP from VideoLAN, verify SHA-256 `26d556648d4a67e8938d6d4b4d99ba0359f1979bfef985c8f6710882c7ed5975`, extract it under the user's local VaultPool plugin directory, and launch it without administrator permissions or global codec installation. VLC is not bundled in the portable VaultPool ZIP.

## M0.24.12 media player progress

The video modal made the preparation model explicit with percentage, average speed, approximate ETA, block progress, and a cancel/clear action. M0.24.13 replaces the full-cache wait for integrated formats with range streaming.

## M0.24.13 adaptive range streaming

Integrated video playback now uses HTTP byte ranges over the loopback server. VaultPool reconstructs and authenticates only the requested plaintext blocks through the existing range reader, stores them in a private per-file chunk cache, and starts by fetching only the first block. Once playback begins it prefetches the next three blocks concurrently. The cache geometry follows the manifest block size: new files use 1 MiB blocks, while catalogs created before the field existed use their historic 4 MiB layout, avoiding repeated reconstruction of the same encrypted fragments. The browser or VLC can start after the first requested chunk instead of waiting for the complete video. Remote ciphertext remains encrypted, and the cache can be cleared explicitly from the player modal.

The core now reads the minimum number of shards for each block in parallel and cancels slower shard reads after the recovery threshold is met. Target placement accepts measured upload/download speeds and prefers faster targets when the recovery and capacity constraints are equivalent. New uploads use a 1 MiB default block size to reduce startup latency; existing manifests retain their original block geometry.
