package main

import (
	"os"
	"path/filepath"
	"strings"
)

func launchedFromArchiveTemp() bool {
	exe, err := os.Executable()
	if err != nil {
		return false
	}
	return pathLooksLikeArchiveTemp(exe, os.TempDir())
}

func pathLooksLikeArchiveTemp(exePath, tempDir string) bool {
	if strings.TrimSpace(exePath) == "" || strings.TrimSpace(tempDir) == "" {
		return false
	}
	absExe, err := filepath.Abs(exePath)
	if err != nil {
		return false
	}
	absTemp, err := filepath.Abs(tempDir)
	if err != nil {
		return false
	}
	rel, err := filepath.Rel(absTemp, absExe)
	if err != nil || rel == "." || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
		return false
	}
	lower := strings.ToLower(filepath.ToSlash(rel))
	markers := []string{"rar$", ".rartemp", "7z", ".zip", "winrar", "winzip", "temp1_"}
	for _, marker := range markers {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	return false
}
