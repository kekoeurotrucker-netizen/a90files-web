package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/controlclient"
)

func ctl(args []string) (*controlclient.Client, []string) {
	fs := flag.NewFlagSet("control", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	server := fs.String("server", "http://127.0.0.1:8742", "running VaultPool local service")
	if err := fs.Parse(args); err != nil {
		die("control options: %v", err)
	}
	c, err := controlclient.New(*server)
	if err != nil {
		die("control client: %v", err)
	}
	return c, fs.Args()
}

func printJSON(v any) {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		die("encode output: %v", err)
	}
	fmt.Println(string(b))
}

func controlGet(path string, args []string) {
	c, rest := ctl(args)
	if len(rest) != 0 {
		die("unexpected arguments: %s", strings.Join(rest, " "))
	}
	var out any
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	if err := c.Get(ctx, path, &out); err != nil {
		die("%v", err)
	}
	printJSON(out)
}

func runStatus(args []string) {
	c, rest := ctl(args)
	if len(rest) != 0 {
		die("unexpected arguments: %s", strings.Join(rest, " "))
	}
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	var overview struct {
		Accounts []struct {
			State string `json:"state"`
		} `json:"accounts"`
	}
	var files struct {
		Ready bool  `json:"ready"`
		Files []any `json:"files"`
	}
	var recovery map[string]any
	var transfers struct {
		Jobs []any `json:"jobs"`
	}
	var drive map[string]any
	if err := c.Get(ctx, "/api/overview", &overview); err != nil {
		die("%v", err)
	}
	_ = c.Get(ctx, "/api/files", &files)
	_ = c.Get(ctx, "/api/recovery/status", &recovery)
	_ = c.Get(ctx, "/api/transfers", &transfers)
	_ = c.Get(ctx, "/api/drive/status", &drive)
	connected := 0
	for _, a := range overview.Accounts {
		if a.State == "connected" {
			connected++
		}
	}
	printJSON(map[string]any{"service": "online", "accounts": len(overview.Accounts), "connected_accounts": connected, "managed_files": len(files.Files), "files_ready": files.Ready, "transfers": len(transfers.Jobs), "recovery": recovery, "drive": drive})
}

func runProtect(args []string) {
	fs := flag.NewFlagSet("protect", flag.ExitOnError)
	server := fs.String("server", "http://127.0.0.1:8742", "local service")
	path := fs.String("path", "", "absolute local file or folder path")
	wait := fs.Bool("wait", true, "wait for transfer completion")
	_ = fs.Parse(args)
	if *path == "" {
		die("--path required")
	}
	c, err := controlclient.New(*server)
	if err != nil {
		die("%v", err)
	}
	ctx := context.Background()
	var out struct {
		Job struct {
			ID string `json:"id"`
		} `json:"job"`
	}
	if err := c.Post(ctx, "/api/transfers/upload", map[string]string{"path": *path}, &out); err != nil {
		die("protect: %v", err)
	}
	if !*wait {
		printJSON(out)
		return
	}
	waitJob(c, out.Job.ID)
}

func runRestoreFile(args []string) {
	fs := flag.NewFlagSet("restore-file", flag.ExitOnError)
	server := fs.String("server", "http://127.0.0.1:8742", "local service")
	id := fs.String("id", "", "managed file id")
	outPath := fs.String("out", "", "absolute destination path")
	wait := fs.Bool("wait", true, "wait for completion")
	_ = fs.Parse(args)
	if *id == "" || *outPath == "" {
		die("--id and --out required")
	}
	c, err := controlclient.New(*server)
	if err != nil {
		die("%v", err)
	}
	var out struct {
		Job struct {
			ID string `json:"id"`
		} `json:"job"`
	}
	if err := c.Post(context.Background(), "/api/transfers/restore", map[string]string{"file_id": *id, "output_path": *outPath}, &out); err != nil {
		die("restore: %v", err)
	}
	if !*wait {
		printJSON(out)
		return
	}
	waitJob(c, out.Job.ID)
}

func waitJob(c *controlclient.Client, id string) {
	for {
		var r struct {
			Jobs []struct {
				ID, State, Phase, Error, FileID string
				BytesProcessed, BytesTotal      int64
			} `json:"jobs"`
		}
		ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
		err := c.Get(ctx, "/api/transfers", &r)
		cancel()
		if err != nil {
			die("transfer: %v", err)
		}
		found := false
		for _, j := range r.Jobs {
			if j.ID == id {
				found = true
				fmt.Fprintf(os.Stderr, "\r%-12s %d/%d bytes", j.Phase, j.BytesProcessed, j.BytesTotal)
				switch j.State {
				case "completed":
					fmt.Fprintln(os.Stderr)
					printJSON(j)
					return
				case "failed", "canceled":
					fmt.Fprintln(os.Stderr)
					if j.Error != "" {
						die("transfer %s: %s", j.State, j.Error)
					}
					die("transfer %s", j.State)
				}
				break
			}
		}
		if !found {
			die("transfer disappeared")
		}
		time.Sleep(700 * time.Millisecond)
	}
}

func runFileAction(action string, args []string) {
	fs := flag.NewFlagSet(action, flag.ExitOnError)
	server := fs.String("server", "http://127.0.0.1:8742", "local service")
	id := fs.String("id", "", "file id")
	_ = fs.Parse(args)
	if *id == "" {
		die("--id required")
	}
	c, err := controlclient.New(*server)
	if err != nil {
		die("%v", err)
	}
	var out any
	if err := c.Post(context.Background(), "/api/files/"+*id+"/"+action, nil, &out); err != nil {
		die("%s: %v", action, err)
	}
	printJSON(out)
}

func runCancelTransfer(args []string) {
	fs := flag.NewFlagSet("cancel-transfer", flag.ExitOnError)
	server := fs.String("server", "http://127.0.0.1:8742", "local service")
	id := fs.String("id", "", "transfer id")
	_ = fs.Parse(args)
	if *id == "" {
		die("--id required")
	}
	c, err := controlclient.New(*server)
	if err != nil {
		die("%v", err)
	}
	var out any
	if err := c.Post(context.Background(), "/api/transfers/"+*id+"/cancel", nil, &out); err != nil {
		die("cancel: %v", err)
	}
	printJSON(out)
}

func runRebuildCatalog(args []string) {
	c, rest := ctl(args)
	if len(rest) != 0 {
		die("unexpected arguments")
	}
	var out any
	if err := c.Post(context.Background(), "/api/recovery/rebuild-catalog", nil, &out); err != nil {
		die("rebuild: %v", err)
	}
	printJSON(out)
}

func runMountDrive(args []string) {
	fs := flag.NewFlagSet("mount", flag.ExitOnError)
	server := fs.String("server", "http://127.0.0.1:8742", "local service")
	mountPoint := fs.String("drive", "P:", "Windows drive letter")
	_ = fs.Parse(args)
	if fs.NArg() != 0 {
		die("unexpected arguments: %s", strings.Join(fs.Args(), " "))
	}
	c, err := controlclient.New(*server)
	if err != nil {
		die("%v", err)
	}
	var out any
	if err := c.Post(context.Background(), "/api/drive/mount", map[string]string{"mount_point": *mountPoint}, &out); err != nil {
		die("mount: %v", err)
	}
	printJSON(out)
}

func runUnmountDrive(args []string) {
	c, rest := ctl(args)
	if len(rest) != 0 {
		die("unexpected arguments: %s", strings.Join(rest, " "))
	}
	var out any
	if err := c.Post(context.Background(), "/api/drive/unmount", nil, &out); err != nil {
		die("unmount: %v", err)
	}
	printJSON(out)
}
