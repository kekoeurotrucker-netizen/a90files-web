package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/buildinfo"
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/cloudconnector"
	"github.com/vaultpool-project/vaultpool/internal/cloudtargets"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/drivehost"
	"github.com/vaultpool-project/vaultpool/internal/library"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
	"github.com/vaultpool-project/vaultpool/internal/megacmd"
	"github.com/vaultpool-project/vaultpool/internal/oauthconfig"
	"github.com/vaultpool-project/vaultpool/internal/oauthnative"
	mediaplayer "github.com/vaultpool-project/vaultpool/internal/player"
	"github.com/vaultpool-project/vaultpool/internal/recoveryassistant"
	"github.com/vaultpool-project/vaultpool/internal/recoverycenter"
	"github.com/vaultpool-project/vaultpool/internal/recoveryrecords"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/transfers"
	uiapp "github.com/vaultpool-project/vaultpool/internal/ui"
	"github.com/vaultpool-project/vaultpool/internal/virtualdrive"
	"github.com/vaultpool-project/vaultpool/internal/webdavgeneric"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/filedialog"
	filenconnector "github.com/vaultpool-project/vaultpool/internal/filen"
	"github.com/vaultpool-project/vaultpool/internal/instance"
	mediafireconnector "github.com/vaultpool-project/vaultpool/internal/mediafire"
	"github.com/vaultpool-project/vaultpool/internal/paths"
	"github.com/vaultpool-project/vaultpool/internal/planner"
)

func die(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "error: "+format+"\n", args...)
	os.Exit(1)
}
func usage() {
	fmt.Println("vaultpool <version|doctor|app|ui|status|accounts|files|protect|restore-file|health|repair-file|transfers|cancel-transfer|recovery-status|rebuild-catalog|drive-status|mount|unmount|keygen|init-pool|plan|pack|unpack|audit|repair|discover|recover-manifest> [options]")
}

func main() {
	if len(os.Args) < 2 {
		if runtime.GOOS == "windows" {
			runApp(nil)
			return
		}
		usage()
		os.Exit(2)
	}
	switch os.Args[1] {
	case filedialog.HelperCommand:
		os.Exit(filedialog.RunHelper(os.Args[2:], os.Stdout, os.Stderr))
	case "version":
		runVersion(os.Args[2:])
	case "doctor":
		runDoctor(os.Args[2:])
	case "app":
		runApp(os.Args[2:])
	case "status":
		runStatus(os.Args[2:])
	case "accounts":
		controlGet("/api/overview", os.Args[2:])
	case "files":
		controlGet("/api/files", os.Args[2:])
	case "protect":
		runProtect(os.Args[2:])
	case "restore-file":
		runRestoreFile(os.Args[2:])
	case "health":
		runFileAction("audit", os.Args[2:])
	case "repair-file":
		runFileAction("repair", os.Args[2:])
	case "transfers":
		controlGet("/api/transfers", os.Args[2:])
	case "cancel-transfer":
		runCancelTransfer(os.Args[2:])
	case "recovery-status":
		controlGet("/api/recovery/status", os.Args[2:])
	case "rebuild-catalog":
		runRebuildCatalog(os.Args[2:])
	case "drive-status":
		controlGet("/api/drive/status", os.Args[2:])
	case "mount":
		runMountDrive(os.Args[2:])
	case "unmount":
		runUnmountDrive(os.Args[2:])
	case "ui":
		runUI(os.Args[2:])
	case "keygen":
		keygen(os.Args[2:])
	case "init-pool":
		initPool(os.Args[2:])
	case "plan":
		plan(os.Args[2:])
	case "pack":
		pack(os.Args[2:])
	case "unpack":
		unpack(os.Args[2:])
	case "audit":
		audit(os.Args[2:])
	case "repair":
		repair(os.Args[2:])
	case "discover":
		discover(os.Args[2:])
	case "recover-manifest":
		recoverManifest(os.Args[2:])
	default:
		usage()
		os.Exit(2)
	}
}

func oauthClientID(envName, embedded string) string {
	if v := strings.TrimSpace(os.Getenv(envName)); v != "" {
		return v
	}
	return strings.TrimSpace(embedded)
}

func runUI(args []string) {
	fs := flag.NewFlagSet("ui", flag.ExitOnError)
	layout, err := paths.Default()
	if err != nil {
		die("VaultPool data paths: %v", err)
	}
	if err := layout.Ensure(); err != nil {
		die("VaultPool data directory: %v", err)
	}
	listen := fs.String("listen", "127.0.0.1:8742", "local-only UI listen address")
	state := fs.String("state", layout.State, "local UI state path")
	secretsPath := fs.String("secrets", layout.Secrets, "encrypted local secret vault")
	recoveryPath := fs.String("recovery-package", layout.RecoveryPackage, "portable recovery package path")
	managedRoot := fs.String("managed-files", layout.ManagedFiles, "private managed-file metadata/manifests root")
	googleClientID := fs.String("google-client-id", oauthClientID("VAULTPOOL_GOOGLE_CLIENT_ID", buildinfo.GoogleClientID), "public Google desktop OAuth client ID")
	microsoftClientID := fs.String("microsoft-client-id", oauthClientID("VAULTPOOL_MICROSOFT_CLIENT_ID", buildinfo.MicrosoftClientID), "public Microsoft desktop OAuth client ID")
	dropboxClientID := fs.String("dropbox-client-id", oauthClientID("VAULTPOOL_DROPBOX_CLIENT_ID", buildinfo.DropboxClientID), "public Dropbox OAuth app key")
	megaCmdDir := fs.String("megacmd-dir", strings.TrimSpace(os.Getenv("VAULTPOOL_MEGACMD_DIR")), "directory containing official MEGAcmd scriptable commands")
	_ = fs.Parse(args)
	profileID := profileIdentity(layout.Root)
	instanceLock, err := instance.Acquire(filepath.Join(layout.Root, "instance.json"), *listen, profileID)
	if err != nil {
		die("profile instance: %v", err)
	}
	defer func() { _ = instanceLock.Release() }()
	cat := catalog.MustBuiltin()
	store, err := appstate.Open(*state, cat)
	if err != nil {
		die("ui state: %v", err)
	}

	var vault *secretvault.Vault
	var recovery *recoverycenter.Service
	if runtime.GOOS == "windows" {
		protector, err := secretvault.DefaultProtector()
		if err != nil {
			die("Windows secret protection: %v", err)
		}
		applied, err := recoverycenter.ApplyPendingRestore(*secretsPath, *recoveryPath, protector)
		if err != nil {
			die("pending recovery restore: %v", err)
		}
		if applied {
			fmt.Println("VaultPool recovery: staged vault restored successfully.")
		}
		vault, err = secretvault.Open(*secretsPath, protector)
		if err != nil {
			die("secret vault: %v", err)
		}
		defer vault.Close()
		recovery, err = recoverycenter.New(vault, *secretsPath, *recoveryPath, protector)
		if err != nil {
			die("recovery center: %v", err)
		}
	}

	// Development/field-test builds intentionally ship without official OAuth
	// bootstrap settings. If the user configured them from the local UI
	// previously, load them from the OS-protected Vault so the connector stays
	// usable after restart.
	var googleRuntime oauthconfig.Config
	var microsoftRuntime oauthconfig.Config
	var dropboxRuntime oauthconfig.Config
	var pcloudRuntime oauthconfig.Config
	if vault != nil {
		if cfg, ok, err := oauthconfig.Load(vault, "google-drive"); err != nil {
			die("Google OAuth stored config: %v", err)
		} else if ok {
			googleRuntime = cfg
		}
		if cfg, ok, err := oauthconfig.Load(vault, "onedrive"); err != nil {
			die("Microsoft OAuth stored config: %v", err)
		} else if ok {
			microsoftRuntime = cfg
		}
		if cfg, ok, err := oauthconfig.Load(vault, "dropbox"); err != nil {
			die("Dropbox OAuth stored config: %v", err)
		} else if ok {
			dropboxRuntime = cfg
		}
	}
	if googleRuntime.ClientID == "" {
		googleRuntime.ClientID = strings.TrimSpace(*googleClientID)
	}
	if googleRuntime.ClientSecret == "" {
		googleRuntime.ClientSecret = strings.TrimSpace(buildinfo.GoogleClientSecret)
	}
	if microsoftRuntime.ClientID == "" {
		microsoftRuntime.ClientID = strings.TrimSpace(*microsoftClientID)
	}
	if dropboxRuntime.ClientID == "" {
		dropboxRuntime.ClientID = strings.TrimSpace(*dropboxClientID)
	}

	oauthClients := map[string]*oauthnative.Client{}
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status != catalog.Allowed {
			continue
		}
		var c connector.Connector = connector.Unconfigured{ID: p.ID}
		switch p.ID {
		case "google-drive":
			if vault != nil && googleRuntime.ClientID != "" {
				o, err := oauthnative.GoogleWithSecret(googleRuntime.ClientID, googleRuntime.ClientSecret, nil)
				if err != nil {
					die("Google OAuth config: %v", err)
				}
				oauthClients[p.ID] = o
				c = &cloudconnector.OAuthConnector{ID: p.ID, OAuth: o, Secrets: vault}
			}
		case "onedrive":
			if vault != nil && microsoftRuntime.ClientID != "" {
				o, err := oauthnative.Microsoft(microsoftRuntime.ClientID, nil)
				if err != nil {
					die("Microsoft OAuth config: %v", err)
				}
				oauthClients[p.ID] = o
				c = &cloudconnector.OAuthConnector{ID: p.ID, OAuth: o, Secrets: vault}
			}
		case "dropbox":
			if vault != nil && dropboxRuntime.ClientID != "" {
				o, err := oauthnative.Dropbox(dropboxRuntime.ClientID, nil)
				if err != nil {
					die("Dropbox OAuth config: %v", err)
				}
				oauthClients[p.ID] = o
				c = &cloudconnector.OAuthConnector{ID: p.ID, OAuth: o, Secrets: vault}
			}
		case "pcloud":
			if vault != nil && pcloudRuntime.ClientID != "" && pcloudRuntime.ClientSecret != "" {
				o, err := oauthnative.PCloud(pcloudRuntime.ClientID, pcloudRuntime.ClientSecret, nil)
				if err != nil {
					die("pCloud OAuth config: %v", err)
				}
				oauthClients[p.ID] = o
				c = &cloudconnector.OAuthConnector{ID: p.ID, OAuth: o, Secrets: vault}
			}
		case "mega":
			c = megacmd.New(*megaCmdDir)
		case "filen":
			c = filenconnector.New(vault)
		case "mediafire":
			c = mediafireconnector.New(vault)
		default:
			if p.GenericProtocol == "webdav" && vault != nil {
				c = webdavgeneric.NewConnector(p, vault)
			}
		}
		if err := reg.Register(c); err != nil {
			die("connector registry: %v", err)
		}
	}
	var managed *managedfiles.Manager
	var managedEngine *core.Engine
	var recoveryAssistant *recoveryassistant.Service
	var transferService *transfers.Service
	var libraryService *library.Service
	var playerService *mediaplayer.Service
	if vault != nil {
		libraryService, err = library.New(vault)
		if err != nil {
			die("library service: %v", err)
		}
		resolver, err := cloudtargets.New(store, reg)
		if err != nil {
			die("cloud target resolver: %v", err)
		}
		managedEngine, err = core.New(core.DefaultConfig())
		if err != nil {
			die("managed file engine: %v", err)
		}
		defer managedEngine.Close()
		recoveryKeys, err := recoveryrecords.New(vault, 2)
		if err != nil {
			die("recovery-record service: %v", err)
		}
		managed, err = managedfiles.New(*managedRoot, vault, managedEngine, resolver.Resolve, recoveryKeys)
		if err != nil {
			die("managed file service: %v", err)
		}
		recoveryAssistant, err = recoveryassistant.New(vault, recoveryKeys, managedEngine, managed, resolver.Resolve)
		if err != nil {
			die("recovery assistant: %v", err)
		}
		transferService, err = transfers.New(managed)
		if err != nil {
			die("transfer service: %v", err)
		}
		playerService, err = mediaplayer.New(managed, filepath.Join(layout.Staging, "player"), filepath.Join(layout.Root, "plugins", "media"))
		if err != nil {
			die("media player service: %v", err)
		}
	}
	var drive drivehost.Host
	if managed != nil {
		capacity := func() (uint64, uint64) {
			return safeDriveCapacity(store.Snapshot().Accounts)
		}
		driveModel, err := virtualdrive.NewModel(managed, capacity)
		if err != nil {
			die("virtual drive model: %v", err)
		}
		drive = drivehost.New(driveModel)
	}
	srv, err := uiapp.NewSecureManagedRecovery(cat, store, reg, vault, oauthClients, managed, recovery)
	if err != nil {
		die("ui: %v", err)
	}
	srv.SetRecoveryAssistant(recoveryAssistant)
	srv.SetTransfers(transferService)
	srv.SetFileDialog(filedialog.NewSystem())
	srv.SetDriveHost(drive)
	srv.SetLibrary(libraryService)
	srv.SetPlayer(playerService)
	srv.SetIdentity(profileID)
	fmt.Printf("VaultPool UI: http://%s\n", *listen)
	if runtime.GOOS != "windows" {
		fmt.Println("VaultPool secure OAuth disabled: DPAPI vault requires Windows.")
	}
	if *googleClientID == "" {
		fmt.Println("Google Drive OAuth disabled: configure VAULTPOOL_GOOGLE_CLIENT_ID or --google-client-id.")
	}
	if *microsoftClientID == "" {
		fmt.Println("OneDrive OAuth disabled: configure VAULTPOOL_MICROSOFT_CLIENT_ID or --microsoft-client-id.")
	}
	if !reg.Ready("mega") {
		fmt.Println("MEGA disabled: install official MEGAcmd or configure VAULTPOOL_MEGACMD_DIR / --megacmd-dir.")
	}
	if !reg.Ready("filen") {
		fmt.Println("Filen direct connector disabled: Windows secret vault is unavailable.")
	}
	sigCtx, stopSignals := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stopSignals()
	serverErr := make(chan error, 1)
	go func() { serverErr <- srv.ListenAndServe(*listen) }()
	select {
	case err := <-serverErr:
		if err != nil {
			die("ui server: %v", err)
		}
		return
	case <-sigCtx.Done():
	case <-srv.ShutdownRequested():
	}

	// Controlled close order:
	// 1) close transfer admission; 2) cancel and await rollback; 3) unmount P:;
	// 4) stop the local HTTP service. This avoids a late upload racing teardown.
	if transferService != nil {
		transferService.BeginShutdown()
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		if err := transferService.Shutdown(ctx); err != nil {
			fmt.Fprintf(os.Stderr, "warning: transfer shutdown incomplete: %v\n", err)
		}
		cancel()
	}
	if playerService != nil {
		if err := playerService.ClearAll(); err != nil {
			fmt.Fprintf(os.Stderr, "warning: media cache cleanup failed: %v\n", err)
		}
	}
	if drive != nil && drive.Status().Running {
		if err := drive.Unmount(); err != nil {
			fmt.Fprintf(os.Stderr, "warning: virtual drive unmount failed: %v\n", err)
		}
	}
	shutdownCtx, cancelServer := context.WithTimeout(context.Background(), 10*time.Second)
	if err := srv.Shutdown(shutdownCtx); err != nil {
		fmt.Fprintf(os.Stderr, "warning: local service shutdown incomplete: %v\n", err)
	}
	cancelServer()
	select {
	case err := <-serverErr:
		if err != nil {
			fmt.Fprintf(os.Stderr, "warning: local service ended with error: %v\n", err)
		}
	case <-time.After(2 * time.Second):
		fmt.Fprintln(os.Stderr, "warning: local service did not confirm shutdown")
	}
}

func safeDriveCapacity(accounts []appstate.Account) (uint64, uint64) {
	type providerCapacity struct{ total, free int64 }
	byProvider := map[string]providerCapacity{}
	for _, a := range accounts {
		if a.State != "connected" || a.StableTargetID == "" || a.TotalBytes < 0 || a.FreeBytes < 0 || a.UsedBytes < 0 {
			continue
		}
		if a.UsedBytes+a.FreeBytes != a.TotalBytes {
			continue
		}
		c := byProvider[a.ProviderID]
		c.total += a.TotalBytes
		c.free += a.FreeBytes
		byProvider[a.ProviderID] = c
	}
	if len(byProvider) < 2 {
		return 0, 0
	}
	totalTargets := make([]planner.Target, 0, len(byProvider))
	freeTargets := make([]planner.Target, 0, len(byProvider))
	for providerID, c := range byProvider {
		totalTargets = append(totalTargets, planner.Target{ID: providerID, FailureDomain: providerID, FreeBytes: c.total, Enabled: true})
		freeTargets = append(freeTargets, planner.Target{ID: providerID, FailureDomain: providerID, FreeBytes: c.free, Enabled: true})
	}
	policy := planner.DefaultPolicy()
	total := planner.MaxLogicalCapacity(totalTargets, policy)
	free := planner.MaxLogicalCapacity(freeTargets, policy)
	if free > total {
		free = total
	}
	if total < 0 || free < 0 {
		return 0, 0
	}
	return uint64(total), uint64(free)
}

func keygen(args []string) {
	fs := flag.NewFlagSet("keygen", flag.ExitOnError)
	out := fs.String("out", "recovery.key", "key path")
	_ = fs.Parse(args)
	k, err := cryptokit.GenerateKey()
	if err != nil {
		die("keygen: %v", err)
	}
	if err := cryptokit.WriteKeyFile(*out, k); err != nil {
		die("write key: %v", err)
	}
	fmt.Println("created", *out)
}
func initPool(args []string) {
	fs := flag.NewFlagSet("init-pool", flag.ExitOnError)
	dir := fs.String("dir", "pool", "pool dir")
	n := fs.Int("providers", 6, "mock providers")
	_ = fs.Parse(args)
	if *n < 1 {
		die("providers must be positive")
	}
	for i := 1; i <= *n; i++ {
		p := filepath.Join(*dir, fmt.Sprintf("provider-%02d", i))
		if err := os.MkdirAll(p, 0o700); err != nil {
			die("create %s: %v", p, err)
		}
	}
	fmt.Printf("created %d mock providers in %s\n", *n, *dir)
}

func newEngine() *core.Engine {
	e, err := core.New(core.DefaultConfig())
	if err != nil {
		die("engine: %v", err)
	}
	return e
}
func loadKey(path string) []byte {
	k, err := cryptokit.ReadKeyFile(path)
	if err != nil {
		die("key: %v", err)
	}
	return k
}

func plan(args []string) {
	fs := flag.NewFlagSet("plan", flag.ExitOnError)
	bytesN := fs.Int64("bytes", 0, "post-compression/encryption payload bytes to place")
	targetsPath := fs.String("targets", "", "JSON file containing storage targets")
	margin := fs.Int("provider-margin", 1, "recovery shards still available after losing the worst whole provider")
	maxRedundancy := fs.Float64("max-redundancy", 0.50, "maximum parity/data storage ratio")
	_ = fs.Parse(args)
	if *bytesN <= 0 || *targetsPath == "" {
		die("--bytes > 0 and --targets are required")
	}
	b, err := os.ReadFile(*targetsPath)
	if err != nil {
		die("read targets: %v", err)
	}
	var targets []planner.Target
	if err := json.Unmarshal(b, &targets); err != nil {
		die("parse targets: %v", err)
	}
	policy := planner.DefaultPolicy()
	policy.MinProviderFailureMargin = *margin
	policy.MaxRedundancyRatio = *maxRedundancy
	p, err := planner.Build(*bytesN, targets, policy)
	if err != nil {
		die("plan: %v", err)
	}
	fmt.Printf("safe plan: data=%d parity=%d total=%d shard-bytes=%d encoded-bytes=%d provider-margin=%d domains=%d\n",
		p.DataShards, p.ParityShards, p.TotalShards, p.ShardBytes, p.EncodedBytes, p.ProviderFailureMargin, p.FailureDomainsUsed)
	for _, x := range p.Placements {
		fmt.Printf("shard %d -> %s [%s] (%d bytes)\n", x.ShardIndex, x.TargetID, x.FailureDomain, x.Bytes)
	}
}

func pack(args []string) {
	fs := flag.NewFlagSet("pack", flag.ExitOnError)
	in := fs.String("in", "", "input")
	pool := fs.String("pool", "pool", "pool")
	mf := fs.String("manifest", "", "manifest")
	key := fs.String("key", "recovery.key", "key")
	_ = fs.Parse(args)
	if *in == "" || *mf == "" {
		die("--in and --manifest required")
	}
	e := newEngine()
	defer e.Close()
	if err := e.PackAdaptive(*in, *pool, *mf, loadKey(*key)); err != nil {
		die("pack: %v", err)
	}
	fmt.Println("packed safely with adaptive placement; encrypted manifest:", *mf)
}
func unpack(args []string) {
	fs := flag.NewFlagSet("unpack", flag.ExitOnError)
	out := fs.String("out", "", "output")
	pool := fs.String("pool", "pool", "pool")
	mf := fs.String("manifest", "", "manifest")
	key := fs.String("key", "recovery.key", "key")
	_ = fs.Parse(args)
	if *out == "" || *mf == "" {
		die("--out and --manifest required")
	}
	e := newEngine()
	defer e.Close()
	if err := e.Restore(*mf, *pool, *out, loadKey(*key)); err != nil {
		die("unpack: %v", err)
	}
	fmt.Println("restored and final SHA-256 verified:", *out)
}
func audit(args []string) {
	fs := flag.NewFlagSet("audit", flag.ExitOnError)
	pool := fs.String("pool", "pool", "pool")
	mf := fs.String("manifest", "", "manifest")
	key := fs.String("key", "recovery.key", "key")
	_ = fs.Parse(args)
	if *mf == "" {
		die("--manifest required")
	}
	e := newEngine()
	defer e.Close()
	r, err := e.Audit(*mf, *pool, loadKey(*key))
	if err != nil {
		die("audit: %v", err)
	}
	fmt.Printf("%s: worst recovery margin=%d; worst margin after one additional provider failure=%d\n", r.FileName, r.WorstMargin, r.WorstProviderFailureMargin)
	fmt.Printf("risk=%s: %s\n", r.Risk.Level, r.Risk.Summary)
	fmt.Printf("recommended-action: %s\n", r.Risk.RecommendedAction)
	for _, b := range r.Blocks {
		fmt.Printf("block %d: %d/%d valid, missing=%d corrupt=%d margin=%d provider-failure-margin=%d\n", b.Index, b.Valid, b.Total, b.Missing, b.Corrupt, b.Margin, b.ProviderFailureMargin)
	}
}

func repair(args []string) {
	fs := flag.NewFlagSet("repair", flag.ExitOnError)
	pool := fs.String("pool", "pool", "pool")
	mf := fs.String("manifest", "", "manifest")
	key := fs.String("key", "recovery.key", "key")
	_ = fs.Parse(args)
	if *mf == "" {
		die("--manifest required")
	}
	e := newEngine()
	defer e.Close()
	r, err := e.RepairProtection(*mf, *pool, loadKey(*key))
	if err != nil {
		die("repair: %v", err)
	}
	fmt.Printf("repair complete: file=%s repaired-shards=%d repaired-blocks=%d manifest-generation=%d\n", r.FileName, r.RepairedShards, r.RepairedBlocks, r.ManifestGeneration)
}

func discover(args []string) {
	fs := flag.NewFlagSet("discover", flag.ExitOnError)
	pool := fs.String("pool", "pool", "pool")
	key := fs.String("key", "recovery.key", "key")
	_ = fs.Parse(args)
	e := newEngine()
	defer e.Close()
	items, err := e.DiscoverRecoverableManifests(*pool, loadKey(*key))
	if err != nil {
		die("discover: %v", err)
	}
	if len(items) == 0 {
		fmt.Println("no authenticated recoverable manifests found")
		return
	}
	for _, item := range items {
		fmt.Printf("file-id=%s name=%q generation=%d replicas=%d\n", item.FileID, item.FileName, item.Generation, item.Replicas)
	}
}

func recoverManifest(args []string) {
	fs := flag.NewFlagSet("recover-manifest", flag.ExitOnError)
	pool := fs.String("pool", "pool", "pool")
	out := fs.String("out", "", "output manifest path")
	fileID := fs.String("file-id", "", "file ID from discover (required when multiple files exist)")
	key := fs.String("key", "recovery.key", "key")
	_ = fs.Parse(args)
	if *out == "" {
		die("--out required")
	}
	e := newEngine()
	defer e.Close()
	m, err := e.RecoverManifest(*pool, *out, loadKey(*key), *fileID)
	if err != nil {
		die("recover-manifest: %v", err)
	}
	fmt.Printf("recovered manifest: file-id=%s name=%q generation=%d -> %s\n", m.FileID, m.FileName, m.Generation, *out)
}
