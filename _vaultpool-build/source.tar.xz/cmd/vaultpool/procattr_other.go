//go:build !windows

package main

import "syscall"

func childSysProcAttr() *syscall.SysProcAttr { return nil }
