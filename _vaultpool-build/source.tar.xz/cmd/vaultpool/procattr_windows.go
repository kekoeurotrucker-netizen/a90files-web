//go:build windows

package main

import "syscall"

const createNoWindow = 0x08000000

func childSysProcAttr() *syscall.SysProcAttr {
	return &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
}
