//go:build !windows

package main

import "fmt"

func showArchiveLaunchWarning() {
	fmt.Println("VaultPool se ha abierto desde una carpeta temporal de ZIP. Extrae el ZIP completo antes de abrir vaultpool.")
}

func showStartupError(message string) {
	fmt.Println("VaultPool no se pudo iniciar:", message)
}
