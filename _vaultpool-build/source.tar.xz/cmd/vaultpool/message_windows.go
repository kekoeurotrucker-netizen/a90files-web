//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

var (
	user32            = syscall.NewLazyDLL("user32.dll")
	procMessageBoxW   = user32.NewProc("MessageBoxW")
	messageBoxOK      = uintptr(0x00000000)
	messageBoxWarning = uintptr(0x00000030)
	messageBoxTopmost = uintptr(0x00040000)
)

func showArchiveLaunchWarning() {
	title, _ := syscall.UTF16PtrFromString("VaultPool: extrae el ZIP primero")
	body, _ := syscall.UTF16PtrFromString("VaultPool se ha abierto desde una carpeta temporal de WinRAR/ZIP.\n\nExtrae el ZIP completo a una carpeta normal y abre vaultpool.exe desde alli.\n\nAsi evitaras instancias invisibles, cierres raros y datos temporales.")
	procMessageBoxW.Call(0, uintptr(unsafePointer(body)), uintptr(unsafePointer(title)), messageBoxOK|messageBoxWarning|messageBoxTopmost)
}

func showStartupError(message string) {
	title, _ := syscall.UTF16PtrFromString("VaultPool no se pudo iniciar")
	body, _ := syscall.UTF16PtrFromString(message + "\n\nRevisa el archivo local logs\\startup.log para ver el detalle.")
	procMessageBoxW.Call(0, uintptr(unsafePointer(body)), uintptr(unsafePointer(title)), messageBoxOK|messageBoxWarning|messageBoxTopmost)
}

func unsafePointer(p *uint16) unsafe.Pointer {
	return unsafe.Pointer(p)
}
