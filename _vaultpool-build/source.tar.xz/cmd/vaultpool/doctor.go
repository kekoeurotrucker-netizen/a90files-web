package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"runtime"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/buildinfo"
	"github.com/vaultpool-project/vaultpool/internal/controlclient"
	"github.com/vaultpool-project/vaultpool/internal/drivehost"
	"github.com/vaultpool-project/vaultpool/internal/megacmd"
	"github.com/vaultpool-project/vaultpool/internal/paths"
)

func runVersion(args []string) {
	fs := flag.NewFlagSet("version", flag.ExitOnError)
	_ = fs.Parse(args)
	if fs.NArg() != 0 {
		die("version takes no arguments")
	}
	if buildinfo.BuildPurpose == "release" {
		fmt.Printf("%s %s (%s)\n", buildinfo.Product, buildinfo.Version, buildinfo.Milestone)
	} else {
		fmt.Printf("%s %s (%s; %s)\n", buildinfo.Product, buildinfo.Version, buildinfo.Milestone, buildinfo.BuildPurpose)
	}
}

type doctorStateFile struct {
	Accounts []struct {
		State          string `json:"state"`
		ProviderID     string `json:"provider_id"`
		StableTargetID string `json:"stable_target_id"`
		TotalBytes     int64  `json:"total_bytes"`
		UsedBytes      int64  `json:"used_bytes"`
		FreeBytes      int64  `json:"free_bytes"`
		Health         string `json:"health"`
	} `json:"accounts"`
}

func doctorLine(ok bool, name, detail string) {
	mark := "!"
	if ok {
		mark = "✓"
	}
	if strings.TrimSpace(detail) == "" {
		fmt.Printf("%s %s\n", mark, name)
		return
	}
	fmt.Printf("%s %s — %s\n", mark, name, detail)
}

func doctorBytes(n int64) string {
	if n <= 0 {
		return "0 B"
	}
	units := []string{"B", "KB", "MB", "GB", "TB", "PB"}
	x := float64(n)
	i := 0
	for x >= 1000 && i < len(units)-1 {
		x /= 1000
		i++
	}
	switch {
	case x >= 100:
		return fmt.Sprintf("%.0f %s", x, units[i])
	case x >= 10:
		return fmt.Sprintf("%.1f %s", x, units[i])
	default:
		return fmt.Sprintf("%.2f %s", x, units[i])
	}
}

func runDoctor(args []string) {
	fs := flag.NewFlagSet("doctor", flag.ExitOnError)
	server := fs.String("server", "http://127.0.0.1:8742", "local VaultPool service")
	megaCmdDir := fs.String("megacmd-dir", strings.TrimSpace(os.Getenv("VAULTPOOL_MEGACMD_DIR")), "directory containing official MEGAcmd commands")
	_ = fs.Parse(args)
	if fs.NArg() != 0 {
		die("doctor: unexpected arguments: %s", strings.Join(fs.Args(), " "))
	}
	layout, err := paths.Default()
	if err != nil {
		doctorLine(false, "Rutas de datos", err.Error())
		return
	}
	if err := layout.Ensure(); err != nil {
		doctorLine(false, "Rutas de datos", err.Error())
	} else {
		doctorLine(true, "Rutas de datos", layout.Root)
	}

	if runtime.GOOS != "windows" {
		doctorLine(false, "Bóveda local", "DPAPI requiere Windows")
	} else if st, err := os.Stat(layout.Secrets); err == nil && st.Mode().IsRegular() {
		doctorLine(true, "Bóveda local", "presente")
	} else {
		doctorLine(false, "Bóveda local", "todavía no creada")
	}
	if st, err := os.Stat(layout.RecoveryPackage); err == nil && st.Mode().IsRegular() {
		doctorLine(true, "Kit de recuperación", "paquete portable presente")
	} else {
		doctorLine(false, "Kit de recuperación", "pendiente")
	}
	googleID := oauthClientID("VAULTPOOL_GOOGLE_CLIENT_ID", buildinfo.GoogleClientID)
	googleDetail := "Client ID público pendiente"
	if googleID != "" {
		googleDetail = "Client ID público configurado"
	}
	doctorLine(googleID != "", "OAuth Google Drive", googleDetail)
	microsoftID := oauthClientID("VAULTPOOL_MICROSOFT_CLIENT_ID", buildinfo.MicrosoftClientID)
	microsoftDetail := "Client ID público pendiente"
	if microsoftID != "" {
		microsoftDetail = "Client ID público configurado"
	}
	doctorLine(microsoftID != "", "OAuth OneDrive", microsoftDetail)
	megaBridge := megacmd.New(*megaCmdDir)
	megaDetail := "MEGAcmd oficial no detectado"
	if megaBridge.Ready() {
		megaDetail = "MEGAcmd oficial detectado"
	}
	doctorLine(megaBridge.Ready(), "MEGA / MEGAcmd", megaDetail)
	filenDetail := "conector directo disponible mediante SDK oficial"
	if runtime.GOOS != "windows" {
		filenDetail = "la sesión directa requiere la bóveda DPAPI de Windows"
	}
	doctorLine(runtime.GOOS == "windows", "Filen directo", filenDetail)

	connected := -1
	independent := -1
	filenSeen := false
	filenConnected := false
	filenQuota := ""
	var protection struct {
		Ready                bool   `json:"ready"`
		Label                string `json:"label"`
		IndependentProviders int    `json:"independent_providers"`
		Reason               string `json:"reason"`
	}
	var drive drivehost.Status
	serviceOK := false
	c, err := controlclient.New(*server)
	if err == nil {
		ctx, cancel := context.WithTimeout(context.Background(), 800*time.Millisecond)
		var identity struct {
			Product string `json:"product"`
			Profile string `json:"profile"`
		}
		if err := c.Get(ctx, "/api/identity", &identity); err == nil && identity.Product == buildinfo.Product && identity.Profile == profileIdentity(layout.Root) {
			serviceOK = true
			var overview struct {
				Accounts []struct {
					State      string `json:"state"`
					ProviderID string `json:"provider_id"`
					TotalBytes int64  `json:"total_bytes"`
					UsedBytes  int64  `json:"used_bytes"`
					FreeBytes  int64  `json:"free_bytes"`
					Health     string `json:"health"`
				} `json:"accounts"`
				Protection struct {
					Ready                bool   `json:"ready"`
					Label                string `json:"label"`
					IndependentProviders int    `json:"independent_providers"`
					Reason               string `json:"reason"`
				} `json:"protection"`
			}
			if c.Get(ctx, "/api/overview", &overview) == nil {
				connected = 0
				for _, a := range overview.Accounts {
					if a.State == "connected" {
						connected++
					}
					if a.ProviderID == "filen" {
						filenSeen = true
						if a.State == "connected" {
							filenConnected = true
							filenQuota = fmt.Sprintf("%s usado · %s libre · %s total", doctorBytes(a.UsedBytes), doctorBytes(a.FreeBytes), doctorBytes(a.TotalBytes))
							if a.Health != "" {
								filenQuota += " · salud " + a.Health
							}
						}
					}
				}
				protection = overview.Protection
				independent = overview.Protection.IndependentProviders
			}
			_ = c.Get(ctx, "/api/drive/status", &drive)
		}
		cancel()
	}
	doctorLine(serviceOK, "Servicio VaultPool", func() string {
		if serviceOK {
			return "online y con identidad verificada"
		}
		return "no disponible"
	}())

	if connected < 0 || independent < 0 {
		if b, err := os.ReadFile(layout.State); err == nil {
			var d doctorStateFile
			if json.Unmarshal(b, &d) == nil {
				connected = 0
				domains := map[string]struct{}{}
				for _, a := range d.Accounts {
					if a.State == "connected" {
						connected++
						if strings.TrimSpace(a.ProviderID) != "" && strings.TrimSpace(a.StableTargetID) != "" {
							domains[a.ProviderID] = struct{}{}
						}
					}
					if a.ProviderID == "filen" {
						filenSeen = true
						if a.State == "connected" {
							filenConnected = true
							filenQuota = fmt.Sprintf("%s usado · %s libre · %s total", doctorBytes(a.UsedBytes), doctorBytes(a.FreeBytes), doctorBytes(a.TotalBytes))
							if a.Health != "" {
								filenQuota += " · salud " + a.Health
							}
						}
					}
				}
				independent = len(domains)
			}
		}
	}
	if connected < 0 || independent < 0 {
		doctorLine(false, "Cuentas conectadas", "sin estado verificable")
	} else {
		detail := fmt.Sprintf("%d conectada(s) · %d proveedor(es) independiente(s)", connected, independent)
		if serviceOK && protection.Label != "" {
			detail += " · " + protection.Label
			if !protection.Ready && protection.Reason != "" {
				detail += " · " + protection.Reason
			}
		}
		doctorLine(independent >= 2, "Cuentas conectadas", detail)
	}
	if filenConnected {
		if !serviceOK {
			filenQuota += " · leído del estado local; inicia VaultPool para revalidar"
		}
		doctorLine(true, "Sesión Filen", filenQuota)
	} else if filenSeen {
		doctorLine(false, "Sesión Filen", "cuenta añadida pero todavía no conectada o requiere reautenticación")
	} else {
		doctorLine(false, "Sesión Filen", "sin cuenta Filen añadida")
	}

	if runtime.GOOS != "windows" {
		doctorLine(false, "Dokany", "solo se comprueba en Windows")
	} else if serviceOK {
		detail := fmt.Sprintf("library=%d driver=%d", drive.LibraryVersion, drive.DriverVersion)
		doctorLine(drive.Installed && drive.Compatible, "Dokany", detail)
	} else {
		doctorLine(false, "Dokany", "inicia VaultPool para comprobar DLL y driver")
	}
}
