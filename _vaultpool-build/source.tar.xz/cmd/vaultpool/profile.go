package main

import (
	"crypto/sha256"
	"encoding/hex"
	"path/filepath"
	"runtime"
	"strings"
)

func profileIdentity(root string) string {
	root = filepath.Clean(strings.TrimSpace(root))
	if runtime.GOOS == "windows" {
		root = strings.ToLower(root)
	}
	h := sha256.Sum256([]byte(root))
	return hex.EncodeToString(h[:16])
}
