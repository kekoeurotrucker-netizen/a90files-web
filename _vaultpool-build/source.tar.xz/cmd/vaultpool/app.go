package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/buildinfo"
	"github.com/vaultpool-project/vaultpool/internal/controlclient"
	"github.com/vaultpool-project/vaultpool/internal/desktop"
	"github.com/vaultpool-project/vaultpool/internal/instance"
	"github.com/vaultpool-project/vaultpool/internal/paths"
)

type vaultPoolIdentity struct {
	Product string `json:"product"`
	Version string `json:"version"`
	Profile string `json:"profile"`
}

func runApp(args []string) {
	fs := flag.NewFlagSet("app", flag.ExitOnError)
	listen := fs.String("listen", "127.0.0.1:8742", "local VaultPool service address")
	_ = fs.Parse(args)

	if launchedFromArchiveTemp() {
		showArchiveLaunchWarning()
		return
	}

	layout, err := paths.Default()
	if err != nil {
		failApp(paths.Layout{}, "No se pudieron preparar las rutas locales de VaultPool: %v", err)
	}
	if err := layout.Ensure(); err != nil {
		failApp(layout, "No se pudo preparar la carpeta local de VaultPool: %v", err)
	}
	profileID := profileIdentity(layout.Root)
	lockPath := filepath.Join(layout.Root, "instance.json")

	// Reuse only the same VaultPool build/profile. A field-test hotfix must not
	// silently reopen an older resident backend, otherwise the visible EXE and
	// the local service could be different versions.
	if rec, err := instance.Read(lockPath); err == nil && rec.Profile == profileID {
		base := "http://" + rec.Listen
		if ident, err := readVaultPoolIdentity(base, 1500*time.Millisecond); err == nil && ident.Product == buildinfo.Product && ident.Profile == profileID {
			if ident.Version == buildinfo.Version {
				openDesktopOnce(base+"/", layout)
				return
			}
			_ = requestVaultPoolShutdown(base)
			waitPortFree(rec.Listen, 4*time.Second)
		}
	}

	// A listener on the requested port is not enough proof that it is VaultPool.
	// If it is this profile but an older build, shut it down cleanly first.
	if portInUse(*listen) {
		base := "http://" + *listen
		if ident, err := readVaultPoolIdentity(base, 800*time.Millisecond); err == nil && ident.Product == buildinfo.Product && ident.Profile == profileID {
			if ident.Version == buildinfo.Version {
				openDesktopOnce(base+"/", layout)
				return
			}
			_ = requestVaultPoolShutdown(base)
			waitPortFree(*listen, 4*time.Second)
		}
		if portInUse(*listen) {
			failApp(layout, "El puerto local %s ya esta ocupado por otro servicio.", *listen)
		}
	}

	base := "http://" + *listen
	child := exec.Command(os.Args[0], "ui", "--listen", *listen)
	if runtime.GOOS == "windows" {
		// The Windows release is linked as windowsgui, so Explorer launches do
		// not have console handles to inherit. Keep the background service
		// detached from any console while the desktop window remains visible.
		child.SysProcAttr = childSysProcAttr()
	} else {
		child.Stdout = os.Stdout
		child.Stderr = os.Stderr
	}
	if err := child.Start(); err != nil {
		failApp(layout, "No se pudo iniciar el servicio local de VaultPool: %v", err)
	}

	if err := waitVaultPool(base, profileID, 12*time.Second); err != nil {
		// A near-simultaneous launcher may have won the profile lock on another
		// configured loopback address. Re-read the authoritative instance record.
		if rec, readErr := instance.Read(lockPath); readErr == nil && rec.Profile == profileID {
			existing := "http://" + rec.Listen
			if ident, identityErr := readVaultPoolIdentity(existing, 2*time.Second); identityErr == nil && ident.Product == buildinfo.Product && ident.Profile == profileID && ident.Version == buildinfo.Version {
				_ = child.Process.Kill()
				_ = child.Wait()
				openDesktopOnce(existing+"/", layout)
				return
			}
		}
		_ = child.Process.Kill()
		_ = child.Wait()
		failApp(layout, "El servicio local de VaultPool no pudo iniciar correctamente. Detalle: %v", err)
	}

	// Important: do not tie the callback listener lifetime to the process used to
	// launch an Edge/Chromium app window. Chromium may delegate the visible window
	// to another process and let the launcher exit. The verified VaultPool service
	// therefore stays resident and is reused by later launches of this same build.
	// This guarantees that OAuth can return to the loopback callback even if the
	// desktop shell process changes underneath it.
	openDesktopOnce(base+"/", layout)
}

func openDesktopOnce(url string, layout paths.Layout) {
	shellProfile := filepath.Join(layout.Root, "shell-profile")
	_ = os.MkdirAll(shellProfile, 0o700)
	if _, err := desktop.OpenApp(url, shellProfile); err != nil {
		failApp(layout, "No se pudo abrir la ventana local de VaultPool: %v", err)
	}
	fmt.Printf("VaultPool desktop: %s\n", url)
}

func readVaultPoolIdentity(base string, timeout time.Duration) (vaultPoolIdentity, error) {
	deadline := time.Now().Add(timeout)
	var last error
	for {
		c, err := controlclient.New(base)
		if err != nil {
			return vaultPoolIdentity{}, err
		}
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		var identity vaultPoolIdentity
		err = c.Get(ctx, "/api/identity", &identity)
		cancel()
		if err == nil {
			return identity, nil
		}
		last = err
		if time.Now().After(deadline) {
			if last == nil {
				last = errors.New("identity endpoint unavailable")
			}
			return vaultPoolIdentity{}, last
		}
		time.Sleep(80 * time.Millisecond)
	}
}

func requestVaultPoolShutdown(base string) error {
	c, err := controlclient.New(base)
	if err != nil {
		return err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 1500*time.Millisecond)
	defer cancel()
	return c.Post(ctx, "/api/shutdown", nil, nil)
}

func waitPortFree(addr string, timeout time.Duration) {
	deadline := time.Now().Add(timeout)
	for portInUse(addr) && time.Now().Before(deadline) {
		time.Sleep(80 * time.Millisecond)
	}
}

func portInUse(addr string) bool {
	c, err := net.DialTimeout("tcp", addr, 200*time.Millisecond)
	if err != nil {
		return false
	}
	_ = c.Close()
	return true
}

func waitVaultPool(base, profileID string, timeout time.Duration) error {
	identity, err := readVaultPoolIdentity(base, timeout)
	if err != nil {
		return err
	}
	if identity.Product != buildinfo.Product {
		return fmt.Errorf("identity mismatch: product=%q", identity.Product)
	}
	if identity.Profile != profileID {
		return errors.New("VaultPool profile mismatch")
	}
	return nil
}

func failApp(layout paths.Layout, format string, args ...any) {
	message := fmt.Sprintf(format, args...)
	writeAppStartupLog(layout, message)
	showStartupError(message)
	die("%s", message)
}

func writeAppStartupLog(layout paths.Layout, message string) {
	if layout.Logs == "" {
		return
	}
	f, err := os.OpenFile(filepath.Join(layout.Logs, "startup.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "%s %s\n", time.Now().UTC().Format(time.RFC3339), message)
}
