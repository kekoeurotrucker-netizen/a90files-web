[CmdletBinding()]
param(
    [string]$Listen = "127.0.0.1:8743",
    [string]$DataRoot = "",
    [switch]$Stop
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
if ([string]::IsNullOrWhiteSpace($DataRoot)) {
    $DataRoot = Join-Path $RepoRoot ".vaultpool-dev"
}
$DataRoot = [IO.Path]::GetFullPath($DataRoot)

# Keep experimental accounts, secrets, and state out of the installed profile.
$env:VAULTPOOL_HOME = $DataRoot
$env:GOCACHE = Join-Path $RepoRoot ".gocache"
$env:GOMODCACHE = Join-Path $RepoRoot ".gomodcache"

function Stop-DevService {
    $base = "http://$Listen"
    try {
        $session = Invoke-RestMethod -Uri "$base/api/session" -TimeoutSec 2
    } catch {
        return
    }
    if ([string]::IsNullOrWhiteSpace($session.csrf_token)) {
        throw "The local development service did not return a CSRF token."
    }
    Invoke-RestMethod -Method Post -Uri "$base/api/shutdown" -Headers @{
        "Origin" = $base
        "X-VaultPool-CSRF" = $session.csrf_token
    } -TimeoutSec 5 | Out-Null
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        Start-Sleep -Milliseconds 100
        try {
            Invoke-WebRequest -UseBasicParsing -Uri "$base/api/identity" -TimeoutSec 1 | Out-Null
        } catch {
            return
        }
    }
    throw "The development service at $Listen did not stop in time."
}

Push-Location $RepoRoot
try {
    Stop-DevService
    if ($Stop) {
        return
    }
    & go run ./cmd/vaultpool app --listen $Listen
    exit $LASTEXITCODE
} finally {
    Pop-Location
}
