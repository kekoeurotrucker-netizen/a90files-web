# VaultPool Windows packaging — M0.20

The release path is intentionally user-scoped and does not require administrator rights for VaultPool itself.

## Requirements

- Windows x64.
- Supported Go release, minimum module version Go 1.24.
- Production dependencies available through the normal Go module mechanism.
- Official Google Drive and Microsoft desktop OAuth Client IDs. These are public identifiers, never client secrets.
- NSIS 3.12 (`makensis.exe`) to create the installer. A portable ZIP can be created without NSIS.
- Optional Windows SDK `signtool.exe` plus a real Authenticode code-signing certificate for signed releases.

## Build

Run `build-release.ps1` from PowerShell. By default a release build refuses to proceed without both official OAuth Client IDs. `-AllowMissingOAuthIds` exists only for non-production packaging tests.

The script runs production `go test ./...` and `go vet ./...`, builds Windows amd64 without the `offline` tag as a GUI-subsystem executable (so opening it from Explorer does not flash a console), optionally checks JavaScript syntax, produces a portable ZIP and invokes NSIS when available. If a certificate thumbprint is supplied, both `vaultpool.exe` and the installer are signed and timestamped.

## Installer behavior

- Installs per user under `%LOCALAPPDATA%\Programs\VaultPool`.
- Creates Start Menu shortcuts for VaultPool and VaultPool Doctor.
- Creates an uninstaller.
- Does **not** delete the VaultPool data directory, encrypted vault, catalog, or recovery material on uninstall.
- Does **not** install or uninstall Dokany silently.
- Does **not** contain OAuth client secrets.

Dokany 2.3.1 is an optional external dependency for the read-only `P:` virtual drive. GUI and CLI remain usable without it.
