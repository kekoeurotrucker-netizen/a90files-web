Unicode True
RequestExecutionLevel user
SetCompressor /SOLID lzma

!include "Sections.nsh"

!ifndef VERSION
!define VERSION "0.20.0-rc1"
!endif
!ifndef PAYLOAD
!error "PAYLOAD define is required"
!endif
!ifndef OUTFILE
!define OUTFILE "VaultPool-setup.exe"
!endif

Name "VaultPool ${VERSION}"
OutFile "${OUTFILE}"
InstallDir "$LOCALAPPDATA\Programs\VaultPool"
InstallDirRegKey HKCU "Software\VaultPool" "InstallDir"
ShowInstDetails show
ShowUninstDetails show

Page components
Page directory
Page instfiles
UninstPage uninstConfirm
UninstPage instfiles

Section "VaultPool" SEC_MAIN
  SectionIn RO
  SetShellVarContext current
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD}\*"
  WriteRegStr HKCU "Software\VaultPool" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VaultPool" "DisplayName" "VaultPool"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VaultPool" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VaultPool" "Publisher" "VaultPool"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VaultPool" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  CreateDirectory "$SMPROGRAMS\VaultPool"
  CreateShortcut "$SMPROGRAMS\VaultPool\VaultPool.lnk" "$INSTDIR\vaultpool.exe" "app" "$INSTDIR\vaultpool.exe" 0
  CreateShortcut "$SMPROGRAMS\VaultPool\VaultPool Doctor.lnk" "$INSTDIR\vaultpool.exe" "doctor" "$INSTDIR\vaultpool.exe" 0
  CreateShortcut "$SMPROGRAMS\VaultPool\Desinstalar VaultPool.lnk" "$INSTDIR\Uninstall.exe"
SectionEnd

Section /o "Crear acceso directo en el escritorio" SEC_DESKTOP
  SetShellVarContext current
  IfFileExists "$DESKTOP\VaultPool.lnk" desktopShortcutDone
  CreateShortcut "$DESKTOP\VaultPool.lnk" "$INSTDIR\vaultpool.exe" "app" "$INSTDIR\vaultpool.exe" 0
  WriteRegDWORD HKCU "Software\VaultPool" "DesktopShortcut" 1
desktopShortcutDone:
SectionEnd

Function .onInit
  SectionSetFlags ${SEC_DESKTOP} ${SF_SELECTED}
FunctionEnd

Section "Uninstall"
  SetShellVarContext current
  Delete "$SMPROGRAMS\VaultPool\VaultPool.lnk"
  Delete "$SMPROGRAMS\VaultPool\VaultPool Doctor.lnk"
  Delete "$SMPROGRAMS\VaultPool\Desinstalar VaultPool.lnk"
  RMDir "$SMPROGRAMS\VaultPool"

  ReadRegDWORD $0 HKCU "Software\VaultPool" "DesktopShortcut"
  IntCmp $0 1 0 desktopShortcutNotCreated desktopShortcutNotCreated
  Delete "$DESKTOP\VaultPool.lnk"
desktopShortcutNotCreated:

  ; This directory contains program files only. User vault/state/recovery data
  ; lives separately under VaultPool's data root and is intentionally preserved.
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\VaultPool"
  DeleteRegKey HKCU "Software\VaultPool"
SectionEnd
