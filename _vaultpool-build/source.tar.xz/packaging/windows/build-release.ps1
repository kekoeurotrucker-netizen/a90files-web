[CmdletBinding()]
param(
    [string]$Version = "0.20.0-rc1",
    [string]$OutputDir = "",
    [string]$GoogleClientId = $env:VAULTPOOL_GOOGLE_CLIENT_ID,
    [string]$MicrosoftClientId = $env:VAULTPOOL_MICROSOFT_CLIENT_ID,
    [string]$MakeNSISPath = "",
    [string]$SignToolPath = "",
    [string]$CertificateThumbprint = "",
    [string]$TimestampUrl = "http://timestamp.digicert.com",
    [switch]$SkipTests,
    [switch]$AllowMissingOAuthIds
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = (Resolve-Path (Join-Path $ScriptDir "..\..")).Path
if ([string]::IsNullOrWhiteSpace($OutputDir)) {
    $OutputDir = Join-Path $RepoRoot "dist\windows"
}
$OutputDir = [IO.Path]::GetFullPath($OutputDir)
$PayloadDir = Join-Path $OutputDir "VaultPool"
$ExePath = Join-Path $PayloadDir "vaultpool.exe"
$ZipPath = Join-Path $OutputDir ("VaultPool-{0}-windows-x64-portable.zip" -f $Version)
$InstallerPath = Join-Path $OutputDir ("VaultPool-{0}-windows-x64-setup.exe" -f $Version)

function Require-Command([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if (-not $cmd) { throw "Required command not found: $Name" }
    return $cmd.Source
}

function Assert-GoVersion {
    $go = Require-Command "go"
    $raw = (& $go env GOVERSION).Trim()
    if ($raw -notmatch '^go(?<major>\d+)\.(?<minor>\d+)(?:\.(?<patch>\d+))?') {
        throw "Could not parse Go version: $raw"
    }
    $major = [int]$Matches.major
    $minor = [int]$Matches.minor
    if ($major -lt 1 -or ($major -eq 1 -and $minor -lt 24)) {
        throw "VaultPool production builds require Go >= 1.24; found $raw"
    }
    Write-Host "Go toolchain: $raw"
}

function Invoke-CodeSign([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($CertificateThumbprint)) { return }
    $tool = $SignToolPath
    if ([string]::IsNullOrWhiteSpace($tool)) {
        $cmd = Get-Command signtool.exe -ErrorAction SilentlyContinue
        if (-not $cmd) { throw "Certificate thumbprint supplied but signtool.exe was not found" }
        $tool = $cmd.Source
    }
    & $tool sign /sha1 $CertificateThumbprint /fd SHA256 /tr $TimestampUrl /td SHA256 $Path
    if ($LASTEXITCODE -ne 0) { throw "Authenticode signing failed: $Path" }
}

Assert-GoVersion
if (-not $AllowMissingOAuthIds) {
    if ([string]::IsNullOrWhiteSpace($GoogleClientId)) { throw "Official Google Drive desktop OAuth Client ID is required for a release build" }
    if ([string]::IsNullOrWhiteSpace($MicrosoftClientId)) { throw "Official Microsoft desktop OAuth Client ID is required for a release build" }
}

Push-Location $RepoRoot
try {
    if (-not $SkipTests) {
        & go test ./...
        if ($LASTEXITCODE -ne 0) { throw "go test failed" }
        & go vet ./...
        if ($LASTEXITCODE -ne 0) { throw "go vet failed" }
        $node = Get-Command node -ErrorAction SilentlyContinue
        if ($node) {
            & $node.Source --check "internal/ui/assets/app.js"
            if ($LASTEXITCODE -ne 0) { throw "JavaScript syntax check failed" }
        }
    }

    if (Test-Path $PayloadDir) { Remove-Item -Recurse -Force $PayloadDir }
    New-Item -ItemType Directory -Force -Path $PayloadDir | Out-Null

    $ld = @(
        '-s', '-w',
        "-X", "github.com/vaultpool-project/vaultpool/internal/buildinfo.Version=$Version"
    )
    if (-not [string]::IsNullOrWhiteSpace($GoogleClientId)) {
        $ld += @("-X", "github.com/vaultpool-project/vaultpool/internal/buildinfo.GoogleClientID=$GoogleClientId")
    }
    if (-not [string]::IsNullOrWhiteSpace($MicrosoftClientId)) {
        $ld += @("-X", "github.com/vaultpool-project/vaultpool/internal/buildinfo.MicrosoftClientID=$MicrosoftClientId")
    }
    $ldflags = $ld -join ' '

    $oldGOOS = $env:GOOS; $oldGOARCH = $env:GOARCH; $oldCGO = $env:CGO_ENABLED
    try {
        $env:GOOS = "windows"; $env:GOARCH = "amd64"; $env:CGO_ENABLED = "0"
        # The packaged application is a GUI executable. This prevents the
        # Windows console window from flashing when VaultPool is opened from
        # Explorer or a desktop shortcut.
        $ldflags += ' -H=windowsgui'
        & go build -trimpath -ldflags $ldflags -o $ExePath ./cmd/vaultpool
        if ($LASTEXITCODE -ne 0) { throw "Windows production build failed" }
    } finally {
        $env:GOOS = $oldGOOS; $env:GOARCH = $oldGOARCH; $env:CGO_ENABLED = $oldCGO
    }

    Copy-Item "README.md" (Join-Path $PayloadDir "README.md")
    Copy-Item (Join-Path $ScriptDir "THIRD-PARTY-NOTICES.txt") (Join-Path $PayloadDir "THIRD-PARTY-NOTICES.txt")
    Invoke-CodeSign $ExePath

    if (Test-Path $ZipPath) { Remove-Item -Force $ZipPath }
    Compress-Archive -Path (Join-Path $PayloadDir '*') -DestinationPath $ZipPath -CompressionLevel Optimal

    if ([string]::IsNullOrWhiteSpace($MakeNSISPath)) {
        $nsis = Get-Command makensis.exe -ErrorAction SilentlyContinue
        if ($nsis) { $MakeNSISPath = $nsis.Source }
    }
    if (-not [string]::IsNullOrWhiteSpace($MakeNSISPath)) {
        & $MakeNSISPath "/DVERSION=$Version" "/DPAYLOAD=$PayloadDir" "/DOUTFILE=$InstallerPath" (Join-Path $ScriptDir "VaultPool.nsi")
        if ($LASTEXITCODE -ne 0) { throw "NSIS packaging failed" }
        Invoke-CodeSign $InstallerPath
    } else {
        Write-Warning "makensis.exe not found: portable ZIP created, installer not generated."
    }

    $exeHash = (Get-FileHash -Algorithm SHA256 $ExePath).Hash.ToLowerInvariant()
    $zipHash = (Get-FileHash -Algorithm SHA256 $ZipPath).Hash.ToLowerInvariant()
    Write-Host "vaultpool.exe SHA-256: $exeHash"
    Write-Host "portable ZIP SHA-256: $zipHash"
    if (Test-Path $InstallerPath) {
        $installerHash = (Get-FileHash -Algorithm SHA256 $InstallerPath).Hash.ToLowerInvariant()
        Write-Host "installer SHA-256: $installerHash"
    }
} finally {
    Pop-Location
}
