package recoveryrecords

import (
	"bytes"
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

const maxRecoveryRecordBytes int64 = 64 << 10

// A recovery record is intentionally tiny. A provider that cannot finish its
// verified write within this window must not keep a user cancellation pending
// forever before any file shard has been sent.
const recoveryWriteTimeout = 90 * time.Second

type Vault interface {
	SealRecoveryValue(string, []byte) ([]byte, error)
	OpenRecoveryValue(string, []byte) ([]byte, error)
	Get(string, secretvault.Kind) ([]byte, bool, error)
	Put(string, secretvault.Kind, []byte) error
}

type ReplicationFailure struct {
	TargetID      string `json:"target_id"`
	FailureDomain string `json:"failure_domain"`
	Error         string `json:"error"`
}

type ReplicationReport struct {
	FileID             string               `json:"file_id"`
	RecordBytes        int64                `json:"record_bytes"`
	AttemptedDomains   int                  `json:"attempted_domains"`
	SuccessfulDomains  int                  `json:"successful_domains"`
	SuccessfulTargetID []string             `json:"successful_target_ids"`
	Failures           []ReplicationFailure `json:"failures,omitempty"`
}

type DiscoveryWarning struct {
	TargetID string `json:"target_id"`
	Error    string `json:"error"`
}

type RestoreReport struct {
	Recovered []string           `json:"recovered_file_ids,omitempty"`
	Existing  []string           `json:"existing_file_ids,omitempty"`
	Warnings  []DiscoveryWarning `json:"warnings,omitempty"`
}

type Service struct {
	vault      Vault
	minDomains int
}

func New(vault Vault, minDomains int) (*Service, error) {
	if vault == nil {
		return nil, errors.New("recovery-record vault required")
	}
	if minDomains < 2 {
		return nil, errors.New("recovery records require at least two independent failure domains")
	}
	return &Service{vault: vault, minDomains: minDomains}, nil
}

func validFileID(id string) bool {
	if len(id) != 32 {
		return false
	}
	_, err := hex.DecodeString(id)
	return err == nil
}

func recordKey(fileID string) string {
	return "metadata/recovery/filekeys/" + strings.ToLower(fileID) + ".vprk"
}

func recordLabel(fileID string) string {
	return "file-key/" + strings.ToLower(fileID)
}

func enabledTargets(targets []storage.Target) []storage.Target {
	out := append([]storage.Target(nil), targets...)
	sort.Slice(out, func(i, j int) bool {
		if out[i].FailureDomain == out[j].FailureDomain {
			return out[i].ID < out[j].ID
		}
		return out[i].FailureDomain < out[j].FailureDomain
	})
	filtered := out[:0]
	for _, t := range out {
		if t.Enabled && strings.TrimSpace(t.FailureDomain) != "" {
			filtered = append(filtered, t)
		}
	}
	return filtered
}

func domainCount(targets []storage.Target) int {
	seen := map[string]bool{}
	for _, t := range targets {
		seen[t.FailureDomain] = true
	}
	return len(seen)
}

// putRecoveryRecord lets cancellation win even when a provider implementation
// fails to observe its context. The detached call receives a private sealed
// copy; at worst it may create a harmless orphan recovery record, which is the
// same crash-safe state this workflow already permits before data upload.
func putRecoveryRecord(ctx context.Context, target storage.Target, key string, sealed []byte, hash string) error {
	opCtx, cancel := context.WithTimeout(ctx, recoveryWriteTimeout)
	data := append([]byte(nil), sealed...)
	done := make(chan error, 1)
	go func() {
		_, err := target.PutVerified(opCtx, key, data, hash)
		zero(data)
		done <- err
	}()
	defer cancel()
	select {
	case err := <-done:
		return err
	case <-opCtx.Done():
		return opCtx.Err()
	}
}

// ReplicateFileKey places one authenticated recovery record in every available
// independent provider domain. Multiple accounts at the same provider are not
// counted as independent protection. A file is not considered durably
// recoverable unless at least minDomains writes have been verified.
func (s *Service) ReplicateFileKey(ctx context.Context, fileID string, fileKey []byte, targets []storage.Target) (ReplicationReport, error) {
	fileID = strings.ToLower(fileID)
	report := ReplicationReport{FileID: fileID}
	if err := ctx.Err(); err != nil {
		return report, err
	}
	if !validFileID(fileID) {
		return report, errors.New("invalid file id for recovery record")
	}
	if len(fileKey) != cryptokit.KeySize {
		return report, errors.New("invalid file data key length")
	}
	selected := enabledTargets(targets)
	sealed, err := s.vault.SealRecoveryValue(recordLabel(fileID), fileKey)
	if err != nil {
		return report, fmt.Errorf("seal file-key recovery record: %w", err)
	}
	defer zero(sealed)
	report.RecordBytes = int64(len(sealed))
	if report.RecordBytes > maxRecoveryRecordBytes {
		return report, errors.New("sealed recovery record unexpectedly exceeds size cap")
	}
	eligible := selected[:0]
	for _, t := range selected {
		n := int64(len(sealed))
		if t.FreeBytes < n || (t.MaxObjectBytes > 0 && t.MaxObjectBytes < n) {
			report.Failures = append(report.Failures, ReplicationFailure{TargetID: t.ID, FailureDomain: t.FailureDomain, Error: "insufficient known capacity for recovery record"})
			continue
		}
		eligible = append(eligible, t)
	}
	report.AttemptedDomains = domainCount(eligible)
	if report.AttemptedDomains < s.minDomains {
		return report, fmt.Errorf("durable recovery needs at least %d independent providers; only %d are currently usable", s.minDomains, report.AttemptedDomains)
	}
	hash := remoteobject.SHA256Bytes(sealed)
	key := recordKey(fileID)
	successDomains := map[string]bool{}
	for _, t := range eligible {
		if err := ctx.Err(); err != nil {
			return report, err
		}
		if err := putRecoveryRecord(ctx, t, key, sealed, hash); err != nil {
			if errors.Is(err, context.Canceled) {
				return report, err
			}
			report.Failures = append(report.Failures, ReplicationFailure{TargetID: t.ID, FailureDomain: t.FailureDomain, Error: err.Error()})
			continue
		}
		successDomains[t.FailureDomain] = true
		report.SuccessfulTargetID = append(report.SuccessfulTargetID, t.ID)
	}
	report.SuccessfulDomains = len(successDomains)
	if report.SuccessfulDomains < s.minDomains {
		return report, fmt.Errorf("durable recovery record replicated to only %d/%d required independent providers", report.SuccessfulDomains, s.minDomains)
	}
	return report, nil
}

type discoveredKey struct {
	key    []byte
	source string
}

// RestoreFileKeys discovers only provider-reserved recovery records, AEAD-
// authenticates them against the portable recovery root and FileID label, and
// restores missing FileDataKey entries. Provider outages are warnings; two
// different authenticated keys for the same FileID are a hard conflict.
func (s *Service) RestoreFileKeys(ctx context.Context, targets []storage.Target) (RestoreReport, error) {
	var report RestoreReport
	found := map[string]discoveredKey{}
	for _, t := range enabledTargets(targets) {
		rs, ok := t.RecoveryRecordStore()
		if !ok {
			report.Warnings = append(report.Warnings, DiscoveryWarning{TargetID: t.ID, Error: "provider does not support recovery-record discovery"})
			continue
		}
		candidates, err := rs.ListRecoveryRecordCandidates(ctx, t.AccountID)
		if err != nil {
			report.Warnings = append(report.Warnings, DiscoveryWarning{TargetID: t.ID, Error: err.Error()})
			continue
		}
		for _, c := range candidates {
			fileID := strings.ToLower(c.RecoveryID)
			if !validFileID(fileID) || c.Size <= 0 || c.Size > maxRecoveryRecordBytes {
				continue
			}
			sealed, err := rs.ReadRecoveryRecordCandidate(ctx, t.AccountID, c.Locator, maxRecoveryRecordBytes)
			if err != nil {
				report.Warnings = append(report.Warnings, DiscoveryWarning{TargetID: t.ID, Error: err.Error()})
				continue
			}
			plain, err := s.vault.OpenRecoveryValue(recordLabel(fileID), sealed)
			zero(sealed)
			if err != nil || len(plain) != cryptokit.KeySize {
				zero(plain)
				// Authentication failures are deliberately ignored as untrusted
				// candidates. They must never poison otherwise valid replicas.
				continue
			}
			if prev, ok := found[fileID]; ok {
				if !bytes.Equal(prev.key, plain) {
					zero(plain)
					for _, d := range found {
						zero(d.key)
					}
					return report, fmt.Errorf("conflicting authenticated recovery records for file %s from %s and %s", fileID, prev.source, t.ID)
				}
				zero(plain)
				continue
			}
			found[fileID] = discoveredKey{key: plain, source: t.ID}
		}
	}

	ids := make([]string, 0, len(found))
	for id := range found {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	defer func() {
		for _, d := range found {
			zero(d.key)
		}
	}()
	for _, fileID := range ids {
		d := found[fileID]
		existing, ok, err := s.vault.Get(fileID, secretvault.FileDataKey)
		if err != nil {
			return report, err
		}
		if ok {
			same := bytes.Equal(existing, d.key)
			zero(existing)
			if !same {
				return report, fmt.Errorf("local file key conflicts with authenticated recovery record for %s", fileID)
			}
			report.Existing = append(report.Existing, fileID)
			continue
		}
		if err := s.vault.Put(fileID, secretvault.FileDataKey, d.key); err != nil {
			return report, fmt.Errorf("restore file key %s: %w", fileID, err)
		}
		report.Recovered = append(report.Recovered, fileID)
	}
	return report, nil
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
