package recoveryrecords

import (
	"bytes"
	"context"
	"errors"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/provider"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type testProtector struct{ key byte }

func (p testProtector) Name() string { return "test" }
func (p testProtector) Protect(b []byte) ([]byte, error) {
	out := append([]byte(nil), b...)
	for i := range out {
		out[i] ^= p.key
	}
	return out, nil
}
func (p testProtector) Unprotect(b []byte) ([]byte, error) { return p.Protect(b) }

func newRecoveryVault(t *testing.T) *secretvault.Vault {
	t.Helper()
	d := t.TempDir()
	v, err := secretvault.Open(filepath.Join(d, "vault.vpv"), testProtector{0x5a})
	if err != nil {
		t.Fatal(err)
	}
	pkg := filepath.Join(d, "recovery.vpr")
	code, err := v.ConfigurePortableRecovery(pkg)
	if err != nil {
		t.Fatal(err)
	}
	_ = code
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { v.Close() })
	return v
}

func localTarget(t *testing.T, root, id, domain string) storage.Target {
	t.Helper()
	tg := storage.Target{ID: id, FailureDomain: domain, AccountID: id, Store: &storage.LocalStore{ID: domain, Local: provider.Local{Name: id, Root: filepath.Join(root, id)}}, FreeBytes: 1 << 30, MaxObjectBytes: 1 << 30, Enabled: true}
	if err := tg.Validate(); err != nil {
		t.Fatal(err)
	}
	return tg
}

type cancellationIgnoringStore struct {
	started chan struct{}
	release chan struct{}
}

func (*cancellationIgnoringStore) ProviderID() string { return "stalled-provider" }
func (s *cancellationIgnoringStore) PutVerified(context.Context, string, string, []byte, string) (remoteobject.Object, error) {
	close(s.started)
	<-s.release
	return remoteobject.Object{}, nil
}
func (*cancellationIgnoringStore) GetVerified(context.Context, string, string, int64, string) ([]byte, error) {
	return nil, errors.New("not implemented")
}
func (*cancellationIgnoringStore) Delete(context.Context, string, string) error {
	return errors.New("not implemented")
}

func TestReplicateCountsIndependentProvidersNotAccounts(t *testing.T) {
	v := newRecoveryVault(t)
	svc, _ := New(v, 2)
	root := t.TempDir()
	targets := []storage.Target{localTarget(t, root, "g1", "google-drive"), localTarget(t, root, "g2", "google-drive"), localTarget(t, root, "o1", "onedrive")}
	key := bytes.Repeat([]byte{0x42}, cryptokit.KeySize)
	r, err := svc.ReplicateFileKey(context.Background(), "0123456789abcdef0123456789abcdef", key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if r.AttemptedDomains != 2 || r.SuccessfulDomains != 2 {
		t.Fatalf("report=%+v", r)
	}
	if _, err := os.Stat(filepath.Join(root, "g2", "metadata", "recovery", "filekeys", "0123456789abcdef0123456789abcdef.vprk")); err != nil {
		t.Fatalf("small recovery record should also replicate to a second allowed account for account-level resilience: %v", err)
	}
}

func TestReplicateRefusesSingleFailureDomain(t *testing.T) {
	v := newRecoveryVault(t)
	svc, _ := New(v, 2)
	root := t.TempDir()
	key := bytes.Repeat([]byte{1}, cryptokit.KeySize)
	_, err := svc.ReplicateFileKey(context.Background(), "0123456789abcdef0123456789abcdef", key, []storage.Target{localTarget(t, root, "g1", "google-drive"), localTarget(t, root, "g2", "google-drive")})
	if err == nil {
		t.Fatal("single provider incorrectly accepted as durable recovery")
	}
}

func TestReplicateReturnsPromptlyWhenCanceledDuringUncooperativeWrite(t *testing.T) {
	v := newRecoveryVault(t)
	svc, err := New(v, 2)
	if err != nil {
		t.Fatal(err)
	}
	root := t.TempDir()
	stalled := &cancellationIgnoringStore{started: make(chan struct{}), release: make(chan struct{})}
	targets := []storage.Target{
		localTarget(t, root, "good", "google-drive"),
		{ID: "stalled", FailureDomain: "stalled-provider", AccountID: "stalled", Store: stalled, FreeBytes: 1 << 30, MaxObjectBytes: 1 << 30, Enabled: true},
	}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() {
		_, err := svc.ReplicateFileKey(ctx, "0123456789abcdef0123456789abcdef", bytes.Repeat([]byte{0x33}, cryptokit.KeySize), targets)
		done <- err
	}()
	select {
	case <-stalled.started:
	case <-time.After(time.Second):
		t.Fatal("stalled provider was not called")
	}
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("cancel result = %v, want context canceled", err)
		}
	case <-time.After(time.Second):
		t.Fatal("canceled recovery write did not return promptly")
	}
	close(stalled.release)
}

func TestRestoreFileKeyAfterLocalVaultEntryLoss(t *testing.T) {
	v := newRecoveryVault(t)
	svc, _ := New(v, 2)
	root := t.TempDir()
	targets := []storage.Target{localTarget(t, root, "g1", "google-drive"), localTarget(t, root, "o1", "onedrive"), localTarget(t, root, "p1", "pcloud")}
	id := "0123456789abcdef0123456789abcdef"
	key := bytes.Repeat([]byte{0x7c}, cryptokit.KeySize)
	if _, err := svc.ReplicateFileKey(context.Background(), id, key, targets); err != nil {
		t.Fatal(err)
	}
	if err := v.Put(id, secretvault.FileDataKey, key); err != nil {
		t.Fatal(err)
	}
	if err := v.Delete(id, secretvault.FileDataKey); err != nil {
		t.Fatal(err)
	}
	// Lose one provider completely: recovery still succeeds from the others.
	if err := os.RemoveAll(filepath.Join(root, "g1")); err != nil {
		t.Fatal(err)
	}
	r, err := svc.RestoreFileKeys(context.Background(), targets)
	if err != nil {
		t.Fatal(err)
	}
	if len(r.Recovered) != 1 || r.Recovered[0] != id {
		t.Fatalf("report=%+v", r)
	}
	got, ok, err := v.Get(id, secretvault.FileDataKey)
	if err != nil || !ok || !bytes.Equal(got, key) {
		t.Fatalf("restored key ok=%v err=%v equal=%v", ok, err, bytes.Equal(got, key))
	}
}

func TestRestoreIgnoresTamperButRejectsAuthenticatedConflict(t *testing.T) {
	v := newRecoveryVault(t)
	svc, _ := New(v, 2)
	root := t.TempDir()
	id := "0123456789abcdef0123456789abcdef"
	label := recordLabel(id)
	goodKey := bytes.Repeat([]byte{0x11}, cryptokit.KeySize)
	good, err := v.SealRecoveryValue(label, goodKey)
	if err != nil {
		t.Fatal(err)
	}
	badKey := bytes.Repeat([]byte{0x22}, cryptokit.KeySize)
	conflict, err := v.SealRecoveryValue(label, badKey)
	if err != nil {
		t.Fatal(err)
	}
	t1 := localTarget(t, root, "a", "google-drive")
	t2 := localTarget(t, root, "b", "onedrive")
	path1 := filepath.Join(root, "a", "metadata", "recovery", "filekeys", id+".vprk")
	path2 := filepath.Join(root, "b", "metadata", "recovery", "filekeys", id+".vprk")
	if err := os.MkdirAll(filepath.Dir(path1), 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Dir(path2), 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path1, good, 0600); err != nil {
		t.Fatal(err)
	}
	// First prove untrusted corruption is ignored.
	tampered := append([]byte(nil), good...)
	tampered[len(tampered)-1] ^= 1
	if err := os.WriteFile(path2, tampered, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := svc.RestoreFileKeys(context.Background(), []storage.Target{t1, t2}); err != nil {
		t.Fatal(err)
	}
	if err := v.Delete(id, secretvault.FileDataKey); err != nil {
		t.Fatal(err)
	}
	// Two different but valid records are an authenticated split-brain: abort.
	if err := os.WriteFile(path2, conflict, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := svc.RestoreFileKeys(context.Background(), []storage.Target{t1, t2}); err == nil {
		t.Fatal("authenticated recovery conflict was not blocked")
	}
}
