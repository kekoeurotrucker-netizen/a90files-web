package erasure

// Coder provides systematic erasure coding for one encrypted logical block.
type Coder interface {
	Encode(data []byte) (shards [][]byte, shardSize int, err error)
	Reconstruct(shards [][]byte) error
	Join(shards [][]byte, size int) ([]byte, error)
	DataShards() int
	ParityShards() int
}
