package erasure

import "errors"

// Replication is the canonical VaultPool 1+N protection codec. Every shard is
// an exact copy of the encrypted block. It is intentionally shared by offline,
// field-test and production builds so 1+1/1+2 data is byte-for-byte portable
// across build types and does not depend on a Reed-Solomon implementation.
type Replication struct {
	parity int
}

func newReplication(parity int) (*Replication, error) {
	if parity < 1 {
		return nil, errors.New("invalid replica count")
	}
	return &Replication{parity: parity}, nil
}

func (r *Replication) DataShards() int   { return 1 }
func (r *Replication) ParityShards() int { return r.parity }

func (r *Replication) Encode(data []byte) ([][]byte, int, error) {
	shards := make([][]byte, 1+r.parity)
	for i := range shards {
		shards[i] = append([]byte(nil), data...)
	}
	return shards, len(data), nil
}

func (r *Replication) Reconstruct(shards [][]byte) error {
	if len(shards) != 1+r.parity {
		return errors.New("wrong shard count")
	}
	var src []byte
	for _, shard := range shards {
		if len(shard) > 0 {
			src = shard
			break
		}
	}
	if src == nil {
		return errors.New("insufficient replicas")
	}
	for i := range shards {
		if len(shards[i]) == 0 {
			shards[i] = append([]byte(nil), src...)
		} else if len(shards[i]) != len(src) {
			return errors.New("replica size mismatch")
		}
	}
	return nil
}

func (r *Replication) Join(shards [][]byte, size int) ([]byte, error) {
	if len(shards) != 1+r.parity {
		return nil, errors.New("wrong shard count")
	}
	for _, shard := range shards {
		if len(shard) == 0 {
			continue
		}
		if size < 0 || size > len(shard) {
			return nil, errors.New("size exceeds replica")
		}
		return append([]byte(nil), shard[:size]...), nil
	}
	return nil, errors.New("no replica available")
}
