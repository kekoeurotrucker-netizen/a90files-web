//go:build offline

package erasure

// This is a small test-only GF(256) systematic Reed-Solomon implementation used
// exclusively to exercise orchestration in an offline sandbox. Production builds
// use github.com/klauspost/reedsolomon instead.

import (
	"errors"
	"fmt"
)

type ReedSolomon struct {
	data, parity int
	matrix       [][]byte
}

var expTable [512]byte
var logTable [256]byte

func init() {
	x := 1
	for i := 0; i < 255; i++ {
		expTable[i] = byte(x)
		logTable[byte(x)] = byte(i)
		x <<= 1
		if x&0x100 != 0 {
			x ^= 0x11d
		}
	}
	for i := 255; i < 512; i++ {
		expTable[i] = expTable[i-255]
	}
}

func gfMul(a, b byte) byte {
	if a == 0 || b == 0 {
		return 0
	}
	return expTable[int(logTable[a])+int(logTable[b])]
}
func gfInv(a byte) byte {
	if a == 0 {
		panic("inverse zero")
	}
	return expTable[255-int(logTable[a])]
}
func gfPow(a byte, n int) byte {
	if n == 0 {
		return 1
	}
	if a == 0 {
		return 0
	}
	return expTable[(int(logTable[a])*n)%255]
}

func New(data, parity int) (Coder, error) {
	if data == 1 {
		return newReplication(parity)
	}
	if data < 1 || parity < 1 || data+parity > 255 {
		return nil, errors.New("invalid shard counts")
	}
	total := data + parity
	vand := make([][]byte, total)
	for r := 0; r < total; r++ {
		vand[r] = make([]byte, data)
		for c := 0; c < data; c++ {
			vand[r][c] = gfPow(byte(r+1), c)
		}
	}
	top := make([][]byte, data)
	for i := 0; i < data; i++ {
		top[i] = append([]byte(nil), vand[i]...)
	}
	inv, err := invert(top)
	if err != nil {
		return nil, err
	}
	m := make([][]byte, total)
	for r := 0; r < total; r++ {
		m[r] = mulRow(vand[r], inv)
	}
	return &ReedSolomon{data: data, parity: parity, matrix: m}, nil
}
func (r *ReedSolomon) DataShards() int   { return r.data }
func (r *ReedSolomon) ParityShards() int { return r.parity }

func (r *ReedSolomon) Encode(data []byte) ([][]byte, int, error) {
	ss := (len(data) + r.data - 1) / r.data
	if ss == 0 {
		ss = 1
	}
	sh := make([][]byte, r.data+r.parity)
	for i := 0; i < r.data; i++ {
		sh[i] = make([]byte, ss)
		start := i * ss
		if start < len(data) {
			end := start + ss
			if end > len(data) {
				end = len(data)
			}
			copy(sh[i], data[start:end])
		}
	}
	for row := r.data; row < len(sh); row++ {
		sh[row] = make([]byte, ss)
		combine(sh[row], r.matrix[row], sh[:r.data])
	}
	return sh, ss, nil
}
func (r *ReedSolomon) Reconstruct(sh [][]byte) error {
	if len(sh) != r.data+r.parity {
		return errors.New("wrong shard count")
	}
	present := make([]int, 0, r.data)
	for i, s := range sh {
		if len(s) > 0 {
			present = append(present, i)
			if len(present) == r.data {
				break
			}
		}
	}
	if len(present) < r.data {
		return errors.New("insufficient shards")
	}
	ss := len(sh[present[0]])
	sub := make([][]byte, r.data)
	for i, idx := range present {
		sub[i] = append([]byte(nil), r.matrix[idx]...)
	}
	inv, err := invert(sub)
	if err != nil {
		return err
	}
	avail := make([][]byte, r.data)
	for i, idx := range present {
		if len(sh[idx]) != ss {
			return errors.New("shard size mismatch")
		}
		avail[i] = sh[idx]
	}
	dataOut := make([][]byte, r.data)
	for i := 0; i < r.data; i++ {
		dataOut[i] = make([]byte, ss)
		combine(dataOut[i], inv[i], avail)
	}
	for i := 0; i < r.data; i++ {
		if len(sh[i]) == 0 {
			sh[i] = dataOut[i]
		}
	}
	for i := r.data; i < len(sh); i++ {
		if len(sh[i]) == 0 {
			sh[i] = make([]byte, ss)
			combine(sh[i], r.matrix[i], sh[:r.data])
		}
	}
	return nil
}
func (r *ReedSolomon) Join(sh [][]byte, size int) ([]byte, error) {
	if len(sh) < r.data {
		return nil, errors.New("too few shards")
	}
	out := make([]byte, 0, r.data*len(sh[0]))
	for i := 0; i < r.data; i++ {
		if len(sh[i]) == 0 {
			return nil, errors.New("missing data shard")
		}
		out = append(out, sh[i]...)
	}
	if size > len(out) {
		return nil, errors.New("size exceeds data")
	}
	return out[:size], nil
}
func combine(dst []byte, co []byte, src [][]byte) {
	for j, c := range co {
		if c == 0 {
			continue
		}
		for i := range dst {
			dst[i] ^= gfMul(c, src[j][i])
		}
	}
}
func mulRow(row []byte, m [][]byte) []byte {
	out := make([]byte, len(m))
	for c := range out {
		var v byte
		for k := range row {
			v ^= gfMul(row[k], m[k][c])
		}
		out[c] = v
	}
	return out
}
func invert(a [][]byte) ([][]byte, error) {
	n := len(a)
	aug := make([][]byte, n)
	for i := 0; i < n; i++ {
		if len(a[i]) != n {
			return nil, errors.New("non-square")
		}
		aug[i] = make([]byte, 2*n)
		copy(aug[i], a[i])
		aug[i][n+i] = 1
	}
	for c := 0; c < n; c++ {
		p := c
		for p < n && aug[p][c] == 0 {
			p++
		}
		if p == n {
			return nil, fmt.Errorf("singular matrix at %d", c)
		}
		aug[c], aug[p] = aug[p], aug[c]
		iv := gfInv(aug[c][c])
		for j := 0; j < 2*n; j++ {
			aug[c][j] = gfMul(aug[c][j], iv)
		}
		for r := 0; r < n; r++ {
			if r == c {
				continue
			}
			f := aug[r][c]
			if f == 0 {
				continue
			}
			for j := 0; j < 2*n; j++ {
				aug[r][j] ^= gfMul(f, aug[c][j])
			}
		}
	}
	out := make([][]byte, n)
	for i := 0; i < n; i++ {
		out[i] = append([]byte(nil), aug[i][n:]...)
	}
	return out, nil
}
