package erasure

import (
	"bytes"
	"testing"
)

func TestCanonicalReplicationRoundTrip(t *testing.T) {
	for _, parity := range []int{1, 2} {
		c, err := New(1, parity)
		if err != nil {
			t.Fatal(err)
		}
		if _, ok := c.(*Replication); !ok {
			t.Fatalf("1+%d must use canonical replication, got %T", parity, c)
		}
		plain := []byte("vaultpool canonical recoverable replica")
		shards, size, err := c.Encode(plain)
		if err != nil {
			t.Fatal(err)
		}
		for i, s := range shards {
			if !bytes.Equal(s, plain) {
				t.Fatalf("replica %d differs", i)
			}
		}
		shards[0] = nil
		if err := c.Reconstruct(shards); err != nil {
			t.Fatal(err)
		}
		got, err := c.Join(shards, size)
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(got, plain) {
			t.Fatalf("round trip mismatch")
		}
	}
}
