//go:build !offline

package erasure

import (
	"bytes"

	"github.com/klauspost/reedsolomon"
)

type ReedSolomon struct {
	enc    reedsolomon.Encoder
	data   int
	parity int
}

func New(data, parity int) (Coder, error) {
	if data == 1 {
		return newReplication(parity)
	}
	enc, err := reedsolomon.New(data, parity, reedsolomon.WithAutoGoroutines(1<<20))
	if err != nil {
		return nil, err
	}
	return &ReedSolomon{enc: enc, data: data, parity: parity}, nil
}

func (r *ReedSolomon) DataShards() int   { return r.data }
func (r *ReedSolomon) ParityShards() int { return r.parity }

func (r *ReedSolomon) Encode(data []byte) ([][]byte, int, error) {
	shards, err := r.enc.Split(data)
	if err != nil {
		return nil, 0, err
	}
	if err := r.enc.Encode(shards); err != nil {
		return nil, 0, err
	}
	return shards, len(shards[0]), nil
}

func (r *ReedSolomon) Reconstruct(shards [][]byte) error {
	return r.enc.Reconstruct(shards)
}

func (r *ReedSolomon) Join(shards [][]byte, size int) ([]byte, error) {
	var b bytes.Buffer
	if err := r.enc.Join(&b, shards, size); err != nil {
		return nil, err
	}
	return b.Bytes(), nil
}
