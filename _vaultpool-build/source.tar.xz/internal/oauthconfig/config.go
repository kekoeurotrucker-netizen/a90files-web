package oauthconfig

import (
	"encoding/json"
	"errors"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type Config struct {
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret,omitempty"`
}

func Clean(c Config) Config {
	c.ClientID = strings.TrimSpace(c.ClientID)
	c.ClientSecret = strings.TrimSpace(c.ClientSecret)
	return c
}

func Validate(c Config) error {
	c = Clean(c)
	if c.ClientID == "" || len(c.ClientID) > 512 || strings.ContainsAny(c.ClientID, "\r\n\t ") {
		return errors.New("introduce un identificador público OAuth válido, sin espacios")
	}
	if len(c.ClientSecret) > 512 || strings.ContainsAny(c.ClientSecret, "\r\n\t ") {
		return errors.New("introduce un Client Secret válido, sin espacios ni saltos de línea")
	}
	return nil
}

func Parse(raw []byte) Config {
	text := strings.TrimSpace(string(raw))
	if text == "" {
		return Config{}
	}
	var c Config
	if strings.HasPrefix(text, "{") && json.Unmarshal(raw, &c) == nil {
		return Clean(c)
	}
	return Config{ClientID: text}
}

func Marshal(c Config) ([]byte, error) {
	c = Clean(c)
	return json.Marshal(c)
}

func Load(v *secretvault.Vault, providerID string) (Config, bool, error) {
	if v == nil {
		return Config{}, false, nil
	}
	key := "connector:" + providerID
	if b, ok, err := v.Get(key, secretvault.ConnectorOAuthConfig); err != nil || ok {
		if err != nil {
			return Config{}, false, err
		}
		c := Parse(b)
		zero(b)
		return c, c.ClientID != "", nil
	}
	// Backward compatibility with M0.22.1/M0.22.3, which stored only the public
	// client_id as a plain string under ConnectorPublicConfig.
	if b, ok, err := v.Get(key, secretvault.ConnectorPublicConfig); err != nil || ok {
		if err != nil {
			return Config{}, false, err
		}
		c := Parse(b)
		zero(b)
		return c, c.ClientID != "", nil
	}
	return Config{}, false, nil
}

func Store(v *secretvault.Vault, providerID string, c Config) error {
	if err := Validate(c); err != nil {
		return err
	}
	b, err := Marshal(c)
	if err != nil {
		return err
	}
	defer zero(b)
	return v.Put("connector:"+providerID, secretvault.ConnectorOAuthConfig, b)
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
