package appstate

import (
	"path/filepath"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/catalog"
)

func TestCustomWebDAVProviderPersistsAndRestoresCatalog(t *testing.T) {
	statePath := filepath.Join(t.TempDir(), "state.json")
	cat1 := catalog.MustBuiltin()
	st, err := Open(statePath, cat1)
	if err != nil {
		t.Fatal(err)
	}
	p := catalog.Provider{
		ID: "custom-test-abcd1234", Name: "Test DAV", ShortName: "T",
		Status: catalog.Allowed, StatusNote: "test", MaxAccounts: 0,
		AccountTypes: []string{"WebDAV"}, AuthStrategy: catalog.AuthDirectCredentials,
		CaptchaManualOnly: true, OfficialURL: "https://example.com/", FailureDomain: "webdav:dav.example.com",
		GenericProtocol: "webdav", EndpointURL: "https://dav.example.com/root/",
	}
	if err := st.AddCustomProvider(p); err != nil {
		t.Fatal(err)
	}
	if got, ok := cat1.Get(p.ID); !ok || got.EndpointURL != p.EndpointURL {
		t.Fatalf("custom provider not installed: %+v %v", got, ok)
	}

	cat2 := catalog.MustBuiltin()
	if _, err := Open(statePath, cat2); err != nil {
		t.Fatal(err)
	}
	got, ok := cat2.Get(p.ID)
	if !ok || got.FailureDomain != p.FailureDomain {
		t.Fatalf("custom provider not restored: %+v %v", got, ok)
	}
}
