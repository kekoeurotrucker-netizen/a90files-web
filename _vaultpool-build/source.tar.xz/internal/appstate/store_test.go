package appstate

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/connector"
)

func TestAvailableProvidersMovesConnectedProviderOutOfDiscoveryButAllowsMoreAccounts(t *testing.T) {
	cat := catalog.MustBuiltin()
	s, err := Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	before := AvailableProviders(cat, s.Snapshot())
	if len(before) == 0 {
		t.Fatal("expected approved providers")
	}
	if _, _, err := s.AddAccount("google-drive"); err != nil {
		t.Fatal(err)
	}
	after := AvailableProviders(cat, s.Snapshot())
	for _, p := range after {
		if p.ID == "google-drive" {
			t.Fatal("google-drive must move out of first-time discovery after the first account")
		}
	}
	if _, _, err := s.AddAccount("google-drive"); err != nil {
		t.Fatalf("second google account should be allowed: %v", err)
	}
	if _, _, err := s.AddAccount("google-drive"); err != nil {
		t.Fatalf("third google account should be allowed without an artificial local cap: %v", err)
	}
}
func TestApprovedPCloudCanBeAdded(t *testing.T) {
	cat := catalog.MustBuiltin()
	s, _ := Open(filepath.Join(t.TempDir(), "s.json"), cat)
	if _, _, err := s.AddAccount("pcloud"); err != nil {
		t.Fatalf("approved pCloud provider should be addable: %v", err)
	}
}
func TestUnknownProviderBecomesReviewOnly(t *testing.T) {
	cat := catalog.MustBuiltin()
	path := filepath.Join(t.TempDir(), "s.json")
	s, _ := Open(path, cat)
	r, err := s.RequestProviderReview("Example Cloud", "https://example.com/storage")
	if err != nil {
		t.Fatal(err)
	}
	if r.Status != ReviewStatusPendingLocalReview || len(r.Checklist) < 6 || !r.LocalOnly || r.ReviewScope != ReviewScopeLocalCatalog || r.ConnectionPolicy != ReviewPolicyBlockedUntilLocal {
		t.Fatalf("bad review request: %+v", r)
	}
	if !strings.Contains(strings.Join(r.Checklist, " "), "sin servidor hospedado") {
		t.Fatalf("review checklist must document local-only policy: %+v", r.Checklist)
	}
	if _, _, err := s.AddAccount("example-cloud"); err == nil {
		t.Fatal("unknown provider must never auto-connect")
	}
	st, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if runtime.GOOS != "windows" && st.Mode().Perm()&0o077 != 0 {
		t.Fatalf("state permissions too broad: %o", st.Mode().Perm())
	}
}

func TestApplySnapshotPromotesOnlyValidatedConnectorState(t *testing.T) {
	cat := catalog.MustBuiltin()
	st, err := Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	snap := connector.Snapshot{ProviderID: "google-drive", AccountID: a.ID, ProviderSubject: "g-subject", Identity: "user@example.com", PlanName: "Free", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: 1000, UsedBytes: 400, FreeBytes: 600, UploadBytesPerSec: 123, DownloadBytesPerSec: 456, Limits: connector.Limits{MaxObjectBytes: 789, UploadLimitNote: "upload note", DownloadLimitNote: "download note", RateLimitNote: "rate note"}}
	got, err := st.ApplySnapshot(snap)
	if err != nil {
		t.Fatal(err)
	}
	if got.State != "connected" || got.FreeBytes != 600 || got.Identity != "" || got.StableTargetID == "" || got.UploadBytesPerSec != 123 || got.DownloadBytesPerSec != 456 || got.MaxObjectBytes != 789 || got.RateLimitNote != "rate note" {
		t.Fatalf("got %+v", got)
	}
}

func TestApplySnapshotDoesNotPersistProviderSubject(t *testing.T) {
	cat := catalog.MustBuiltin()
	path := filepath.Join(t.TempDir(), "state.json")
	st, err := Open(path, cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	subject := "opaque-provider-subject-should-not-be-persisted"
	snap := connector.Snapshot{ProviderID: "google-drive", AccountID: a.ID, ProviderSubject: subject, Identity: "u@example.com", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: 100, UsedBytes: 10, FreeBytes: 90}
	if _, err := st.ApplySnapshot(snap); err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(b), subject) {
		t.Fatal("raw provider subject leaked into persisted app state")
	}
}

func TestApplySnapshotRejectsProviderIdentitySwitch(t *testing.T) {
	cat := catalog.MustBuiltin()
	st, err := Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	first := connector.Snapshot{ProviderID: "google-drive", AccountID: a.ID, ProviderSubject: "subject-one", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: 100, UsedBytes: 10, FreeBytes: 90}
	if _, err := st.ApplySnapshot(first); err != nil {
		t.Fatal(err)
	}
	second := first
	second.ProviderSubject = "subject-two"
	if _, err := st.ApplySnapshot(second); err == nil || !strings.Contains(err.Error(), "identity changed") {
		t.Fatalf("identity switch was not blocked: %v", err)
	}
}

func TestMarkReauthRequiredKeepsAccountAndRemoteBinding(t *testing.T) {
	cat := catalog.MustBuiltin()
	st, err := Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("filen")
	if err != nil {
		t.Fatal(err)
	}
	snap := connector.Snapshot{ProviderID: "filen", AccountID: a.ID, ProviderSubject: "user:42\x00base:folder", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: 100, UsedBytes: 10, FreeBytes: 90}
	connected, err := st.ApplySnapshot(snap)
	if err != nil {
		t.Fatal(err)
	}
	updated, err := st.MarkReauthRequired(a.ID, "session disconnected")
	if err != nil {
		t.Fatal(err)
	}
	if updated.State != "reauth_required" || updated.StableTargetID != connected.StableTargetID || updated.TotalBytes != connected.TotalBytes || updated.StatusNote != "session disconnected" {
		t.Fatalf("reauth transition changed account binding or quota: %+v", updated)
	}
	if _, ok := st.GetAccount(a.ID); !ok {
		t.Fatal("disconnect removed the local account record")
	}
}
