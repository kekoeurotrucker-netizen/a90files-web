package appstate

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/connector"

	"github.com/vaultpool-project/vaultpool/internal/safefile"
)

type Account struct {
	ID                  string `json:"id"`
	ProviderID          string `json:"provider_id"`
	StableTargetID      string `json:"stable_target_id,omitempty"`
	Label               string `json:"label"`
	State               string `json:"state"` // pending_auth, connected, attention, reauth_required
	Identity            string `json:"identity,omitempty"`
	PlanName            string `json:"plan_name,omitempty"`
	TotalBytes          int64  `json:"total_bytes"`
	UsedBytes           int64  `json:"used_bytes"`
	FreeBytes           int64  `json:"free_bytes"`
	Health              string `json:"health,omitempty"`
	TransferState       string `json:"transfer_state,omitempty"`
	UploadBytesPerSec   int64  `json:"upload_bytes_per_sec,omitempty"`
	DownloadBytesPerSec int64  `json:"download_bytes_per_sec,omitempty"`
	MaxObjectBytes      int64  `json:"max_object_bytes,omitempty"`
	UploadLimitNote     string `json:"upload_limit_note,omitempty"`
	DownloadLimitNote   string `json:"download_limit_note,omitempty"`
	RateLimitNote       string `json:"rate_limit_note,omitempty"`
	LastChecked         string `json:"last_checked,omitempty"`
	StatusNote          string `json:"status_note,omitempty"`
	ErrorCode           string `json:"error_code,omitempty"`
	AddedAt             string `json:"added_at"`
}

type ReviewRequest struct {
	ID               string   `json:"id"`
	Name             string   `json:"name"`
	OfficialURL      string   `json:"official_url"`
	Status           string   `json:"status"`
	CreatedAt        string   `json:"created_at"`
	Checklist        []string `json:"checklist"`
	LocalOnly        bool     `json:"local_only"`
	ReviewScope      string   `json:"review_scope"`
	ConnectionPolicy string   `json:"connection_policy"`
}

const (
	ReviewScopeLocalCatalog        = "local_catalog"
	ReviewPolicyBlockedUntilLocal  = "blocked_until_local_policy"
	ReviewStatusPendingLocalReview = "pending_review"
)

// OAuthBrowser stores a non-secret preference for the browser used during
// OAuth login. Tokens and provider credentials remain exclusively in
// SecretVault; this only controls how the public authorization URL is opened.
type OAuthBrowser struct {
	Mode       string `json:"mode,omitempty"` // default, browser, custom
	BrowserID  string `json:"browser_id,omitempty"`
	CustomPath string `json:"custom_path,omitempty"`
}

type Settings struct {
	OAuthBrowser OAuthBrowser `json:"oauth_browser,omitempty"`
}

type Data struct {
	SchemaVersion   int                `json:"schema_version"`
	Accounts        []Account          `json:"accounts"`
	ReviewRequests  []ReviewRequest    `json:"review_requests"`
	CustomProviders []catalog.Provider `json:"custom_providers,omitempty"`
	Settings        Settings           `json:"settings,omitempty"`
}

type Store struct {
	mu      sync.Mutex
	path    string
	catalog *catalog.Catalog
	data    Data
}

func Open(path string, cat *catalog.Catalog) (*Store, error) {
	if cat == nil {
		return nil, errors.New("catalog required")
	}
	s := &Store{path: path, catalog: cat, data: Data{SchemaVersion: 1}}
	b, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return s, nil
		}
		return nil, err
	}
	if err := json.Unmarshal(b, &s.data); err != nil {
		return nil, fmt.Errorf("parse app state: %w", err)
	}
	if s.data.SchemaVersion != 1 {
		return nil, fmt.Errorf("unsupported app state schema %d", s.data.SchemaVersion)
	}
	for i := range s.data.ReviewRequests {
		s.data.ReviewRequests[i] = normalizeReviewRequest(s.data.ReviewRequests[i])
	}
	migrated := false
	for i := range s.data.CustomProviders {
		p := s.data.CustomProviders[i]
		if p.Status != catalog.Allowed || p.GenericProtocol != "webdav" {
			return nil, fmt.Errorf("unsafe persisted custom provider %q", p.ID)
		}
		// M0.24.16 removes the old artificial one-account limit for audited
		// WebDAV providers. Credentials are already stored per account in
		// SecretVault, so this migration does not widen the endpoint or auth
		// surface; it only allows another independently authenticated account.
		if p.MaxAccounts == 1 {
			p.MaxAccounts = 0
			s.data.CustomProviders[i] = p
			migrated = true
		}
		if _, exists := cat.Get(p.ID); exists {
			continue
		}
		if err := cat.Add(p); err != nil {
			return nil, fmt.Errorf("restore custom provider %q: %w", p.ID, err)
		}
	}
	if migrated {
		if err := s.saveLocked(); err != nil {
			return nil, fmt.Errorf("migrate custom provider account limits: %w", err)
		}
	}
	return s, nil
}

func randID(prefix string) (string, error) {
	var b [8]byte
	if _, err := rand.Read(b[:]); err != nil {
		return "", err
	}
	return prefix + hex.EncodeToString(b[:]), nil
}

func (s *Store) saveLocked() error {
	b, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	return safefile.WriteAtomic(s.path, b, 0o600)
}

func (s *Store) Snapshot() Data {
	s.mu.Lock()
	defer s.mu.Unlock()
	b, _ := json.Marshal(s.data)
	var d Data
	_ = json.Unmarshal(b, &d)
	return d
}

func normalizeOAuthBrowser(v OAuthBrowser) OAuthBrowser {
	v.Mode = strings.TrimSpace(strings.ToLower(v.Mode))
	v.BrowserID = strings.TrimSpace(strings.ToLower(v.BrowserID))
	v.CustomPath = strings.TrimSpace(v.CustomPath)
	switch v.Mode {
	case "", "default":
		return OAuthBrowser{Mode: "default"}
	case "browser":
		if v.BrowserID == "" {
			return OAuthBrowser{Mode: "default"}
		}
		return OAuthBrowser{Mode: "browser", BrowserID: v.BrowserID}
	case "custom":
		if v.CustomPath == "" {
			return OAuthBrowser{Mode: "default"}
		}
		return OAuthBrowser{Mode: "custom", CustomPath: v.CustomPath}
	default:
		return OAuthBrowser{Mode: "default"}
	}
}

func (s *Store) OAuthBrowser() OAuthBrowser {
	s.mu.Lock()
	defer s.mu.Unlock()
	return normalizeOAuthBrowser(s.data.Settings.OAuthBrowser)
}

func (s *Store) SetOAuthBrowser(v OAuthBrowser) (OAuthBrowser, error) {
	v = normalizeOAuthBrowser(v)
	s.mu.Lock()
	defer s.mu.Unlock()
	old := s.data.Settings.OAuthBrowser
	s.data.Settings.OAuthBrowser = v
	if err := s.saveLocked(); err != nil {
		s.data.Settings.OAuthBrowser = old
		return OAuthBrowser{}, err
	}
	return v, nil
}

func (s *Store) GetAccount(id string) (Account, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, a := range s.data.Accounts {
		if a.ID == id {
			return a, true
		}
	}
	return Account{}, false
}

// ApplySnapshot is the only route from a connector probe into persisted UI
// account metadata. It rejects identity/provider mismatches and inconsistent
// quota before changing state.
func (s *Store) ApplySnapshot(snap connector.Snapshot) (Account, error) {
	if err := snap.Validate(); err != nil {
		return Account{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.data.Accounts {
		a := &s.data.Accounts[i]
		if a.ID != snap.AccountID {
			continue
		}
		if a.ProviderID != snap.ProviderID {
			return Account{}, errors.New("connector provider/account mismatch")
		}
		old := *a
		targetID, err := connector.StableTargetID(snap.ProviderID, snap.ProviderSubject)
		if err != nil {
			return Account{}, err
		}
		if a.StableTargetID != "" && a.StableTargetID != targetID {
			return Account{}, errors.New("authenticated provider identity changed; add the other cloud account as a new VaultPool account")
		}
		// Identity (email/user name) is intentionally not persisted in plaintext.
		// The UI layer stores it inside SecretVault and enriches display data at runtime.
		a.Identity = ""
		a.StableTargetID = targetID
		a.PlanName = snap.PlanName
		a.TotalBytes = snap.TotalBytes
		a.UsedBytes = snap.UsedBytes
		a.FreeBytes = snap.FreeBytes
		a.Health = string(snap.Health)
		a.TransferState = string(snap.Transfer)
		a.UploadBytesPerSec = snap.UploadBytesPerSec
		a.DownloadBytesPerSec = snap.DownloadBytesPerSec
		a.MaxObjectBytes = snap.Limits.MaxObjectBytes
		a.UploadLimitNote = snap.Limits.UploadLimitNote
		a.DownloadLimitNote = snap.Limits.DownloadLimitNote
		a.RateLimitNote = snap.Limits.RateLimitNote
		a.LastChecked = snap.LastChecked
		a.StatusNote = snap.StatusNote
		a.ErrorCode = snap.ErrorCode
		switch snap.Auth {
		case connector.Authenticated:
			a.State = "connected"
		case connector.ReauthRequired:
			a.State = "reauth_required"
		case connector.AuthFailed:
			a.State = "attention"
		default:
			a.State = "pending_auth"
		}
		if err := s.saveLocked(); err != nil {
			*a = old
			return Account{}, err
		}
		return *a, nil
	}
	return Account{}, errors.New("account not found")
}

func (s *Store) ClearIdentity(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.data.Accounts {
		if s.data.Accounts[i].ID != id {
			continue
		}
		if s.data.Accounts[i].Identity == "" {
			return nil
		}
		old := s.data.Accounts[i].Identity
		s.data.Accounts[i].Identity = ""
		if err := s.saveLocked(); err != nil {
			s.data.Accounts[i].Identity = old
			return err
		}
		return nil
	}
	return errors.New("account not found")
}

// MarkReauthRequired removes the trusted connection state without removing the
// account record or changing its stable target. Remote objects remain intact.
func (s *Store) MarkReauthRequired(id, note string) (Account, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.data.Accounts {
		a := &s.data.Accounts[i]
		if a.ID != id {
			continue
		}
		old := *a
		a.State = "reauth_required"
		a.Identity = ""
		a.Health = "attention"
		a.TransferState = "paused"
		a.StatusNote = strings.TrimSpace(note)
		a.ErrorCode = "session_disconnected"
		if err := s.saveLocked(); err != nil {
			*a = old
			return Account{}, err
		}
		return *a, nil
	}
	return Account{}, errors.New("account not found")
}

func (s *Store) Provider(providerID string) (catalog.Provider, bool) {
	return s.catalog.Get(providerID)
}

func (s *Store) AccountCount(providerID string) int {
	s.mu.Lock()
	defer s.mu.Unlock()
	n := 0
	for _, a := range s.data.Accounts {
		if a.ProviderID == providerID {
			n++
		}
	}
	return n
}

func (s *Store) AddCustomProvider(p catalog.Provider) error {
	if p.GenericProtocol == "webdav" && p.PolicyVersion == "" {
		p.PolicyVersion = catalog.GenericWebDAVPolicyVersion
	}
	if p.Status != catalog.Allowed || p.GenericProtocol != "webdav" || p.AuthStrategy != catalog.AuthDirectCredentials {
		return errors.New("only audited HTTPS WebDAV custom providers can be persisted")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, existing := range s.data.CustomProviders {
		if existing.ID == p.ID || strings.EqualFold(existing.Name, p.Name) || (existing.EndpointURL != "" && strings.EqualFold(existing.EndpointURL, p.EndpointURL)) {
			return errors.New("custom provider already exists")
		}
	}
	if _, exists := s.catalog.Get(p.ID); exists {
		return errors.New("provider id already exists")
	}
	old := append([]catalog.Provider(nil), s.data.CustomProviders...)
	s.data.CustomProviders = append(s.data.CustomProviders, p)
	if err := s.saveLocked(); err != nil {
		s.data.CustomProviders = old
		return err
	}
	if err := s.catalog.Add(p); err != nil {
		s.data.CustomProviders = old
		_ = s.saveLocked()
		return err
	}
	return nil
}

func (s *Store) RemoveAccount(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for i, a := range s.data.Accounts {
		if a.ID != id {
			continue
		}
		old := append([]Account(nil), s.data.Accounts...)
		s.data.Accounts = append(s.data.Accounts[:i], s.data.Accounts[i+1:]...)
		if err := s.saveLocked(); err != nil {
			s.data.Accounts = old
			return err
		}
		return nil
	}
	return errors.New("account not found")
}
func (s *Store) AddAccount(providerID string) (Account, catalog.Provider, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	p, ok := s.catalog.Get(providerID)
	if !ok {
		return Account{}, catalog.Provider{}, fmt.Errorf("unknown provider")
	}
	if p.Status != catalog.Allowed {
		return Account{}, p, fmt.Errorf("provider %s is not approved for connection", p.Name)
	}
	n := 0
	for _, a := range s.data.Accounts {
		if a.ProviderID == p.ID {
			n++
		}
	}
	if p.MaxAccounts > 0 && n >= p.MaxAccounts {
		return Account{}, p, fmt.Errorf("provider account limit reached (%d/%d)", n, p.MaxAccounts)
	}
	id, err := randID("acct_")
	if err != nil {
		return Account{}, p, err
	}
	a := Account{ID: id, ProviderID: p.ID, Label: p.Name, State: "pending_auth", AddedAt: time.Now().UTC().Format(time.RFC3339)}
	s.data.Accounts = append(s.data.Accounts, a)
	if err := s.saveLocked(); err != nil {
		s.data.Accounts = s.data.Accounts[:len(s.data.Accounts)-1]
		return Account{}, p, err
	}
	return a, p, nil
}

var reviewChecklist = []string{
	"Términos de uso y política de uso aceptable",
	"API/SDK oficial y automatización permitida",
	"Tipos de cuenta: gratis, pago y empresa",
	"Reglas de múltiples cuentas y pooling",
	"Cuotas de almacenamiento, transferencia y rate limits",
	"Límites máximos por objeto/archivo",
	"OAuth, MFA, CAPTCHA y flujo de autenticación permitido",
	"Restricciones de cifrado, backup y redistribución",
	"Aplicación local: sin servidor hospedado de VaultPool ni secretos centrales",
}

func normalizeReviewRequest(r ReviewRequest) ReviewRequest {
	if strings.TrimSpace(r.Status) == "" {
		r.Status = ReviewStatusPendingLocalReview
	}
	r.LocalOnly = true
	if strings.TrimSpace(r.ReviewScope) == "" {
		r.ReviewScope = ReviewScopeLocalCatalog
	}
	if strings.TrimSpace(r.ConnectionPolicy) == "" {
		r.ConnectionPolicy = ReviewPolicyBlockedUntilLocal
	}
	return r
}

func validateOfficialURL(raw string) (string, error) {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return "", err
	}
	if u.Scheme != "https" || u.Hostname() == "" {
		return "", errors.New("official URL must use https")
	}
	host := strings.ToLower(u.Hostname())
	if host == "localhost" || strings.HasSuffix(host, ".local") || strings.HasPrefix(host, "127.") || host == "::1" {
		return "", errors.New("local/private URLs are not accepted")
	}
	u.Fragment = ""
	return u.String(), nil
}

func (s *Store) RequestProviderReview(name, officialURL string) (ReviewRequest, error) {
	name = strings.TrimSpace(name)
	if len(name) < 2 || len(name) > 80 {
		return ReviewRequest{}, errors.New("provider name must be 2-80 characters")
	}
	cleanURL, err := validateOfficialURL(officialURL)
	if err != nil {
		return ReviewRequest{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	lname := strings.ToLower(name)
	for _, p := range s.catalog.All() {
		if strings.ToLower(p.Name) == lname {
			return ReviewRequest{}, fmt.Errorf("provider already exists in catalog as %s", p.Name)
		}
	}
	for _, r := range s.data.ReviewRequests {
		if strings.EqualFold(r.Name, name) || strings.EqualFold(r.OfficialURL, cleanURL) {
			return ReviewRequest{}, errors.New("provider review already requested")
		}
	}
	id, err := randID("rev_")
	if err != nil {
		return ReviewRequest{}, err
	}
	r := normalizeReviewRequest(ReviewRequest{ID: id, Name: name, OfficialURL: cleanURL, Status: ReviewStatusPendingLocalReview, CreatedAt: time.Now().UTC().Format(time.RFC3339), Checklist: append([]string(nil), reviewChecklist...)})
	s.data.ReviewRequests = append(s.data.ReviewRequests, r)
	if err := s.saveLocked(); err != nil {
		s.data.ReviewRequests = s.data.ReviewRequests[:len(s.data.ReviewRequests)-1]
		return ReviewRequest{}, err
	}
	return r, nil
}

func AvailableProviders(cat *catalog.Catalog, d Data) []catalog.Provider {
	counts := map[string]int{}
	for _, a := range d.Accounts {
		counts[a.ProviderID]++
	}
	out := []catalog.Provider{}
	for _, p := range cat.All() {
		// This list feeds the "Añadir proveedor" discovery area. Once a
		// provider already has an account it moves to its own provider group,
		// where "+ Añadir otra cuenta" remains available when policy permits.
		if p.Status == catalog.Allowed && counts[p.ID] == 0 {
			out = append(out, p)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}
