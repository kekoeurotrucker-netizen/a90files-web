//go:build !windows

package secretvault

import "errors"

func DefaultProtector() (Protector, error) {
	return nil, errors.New("VaultPool production secret vault currently requires Windows DPAPI")
}
