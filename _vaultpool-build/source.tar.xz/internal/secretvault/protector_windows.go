//go:build windows

package secretvault

import (
	"errors"
	"syscall"
	"unsafe"
)

type dataBlob struct {
	cbData uint32
	pbData *byte
}
type DPAPIProtector struct{}

func (DPAPIProtector) Name() string { return "windows-dpapi-current-user" }

var crypt32 = syscall.NewLazyDLL("crypt32.dll")
var kernel32 = syscall.NewLazyDLL("kernel32.dll")
var cryptProtectData = crypt32.NewProc("CryptProtectData")
var cryptUnprotectData = crypt32.NewProc("CryptUnprotectData")
var localFree = kernel32.NewProc("LocalFree")

const cryptProtectUIForbidden = 0x1

var dpapiEntropy = []byte("VaultPool/SecretVault/v1")

func blob(b []byte) dataBlob {
	if len(b) == 0 {
		return dataBlob{}
	}
	return dataBlob{cbData: uint32(len(b)), pbData: &b[0]}
}
func blobBytes(b dataBlob) []byte {
	if b.cbData == 0 || b.pbData == nil {
		return nil
	}
	return append([]byte(nil), unsafe.Slice(b.pbData, b.cbData)...)
}
func (DPAPIProtector) Protect(in []byte) ([]byte, error) {
	ib := blob(in)
	eb := blob(dpapiEntropy)
	var out dataBlob
	r, _, e := cryptProtectData.Call(uintptr(unsafe.Pointer(&ib)), 0, uintptr(unsafe.Pointer(&eb)), 0, 0, cryptProtectUIForbidden, uintptr(unsafe.Pointer(&out)))
	if r == 0 {
		return nil, e
	}
	defer localFree.Call(uintptr(unsafe.Pointer(out.pbData)))
	return blobBytes(out), nil
}
func (DPAPIProtector) Unprotect(in []byte) ([]byte, error) {
	ib := blob(in)
	eb := blob(dpapiEntropy)
	var out dataBlob
	r, _, e := cryptUnprotectData.Call(uintptr(unsafe.Pointer(&ib)), 0, uintptr(unsafe.Pointer(&eb)), 0, 0, cryptProtectUIForbidden, uintptr(unsafe.Pointer(&out)))
	if r == 0 {
		return nil, e
	}
	defer localFree.Call(uintptr(unsafe.Pointer(out.pbData)))
	return blobBytes(out), nil
}
func DefaultProtector() (Protector, error) { return DPAPIProtector{}, nil }

var _ Protector = DPAPIProtector{}
var _ = errors.New
