package secretvault

import (
	"bytes"
	"encoding/base64"
	"os"
	"path/filepath"
	"testing"
)

type testProtector struct{ key byte }

func (p testProtector) Name() string { return "test-only" }
func (p testProtector) Protect(in []byte) ([]byte, error) {
	out := append([]byte(nil), in...)
	for i := range out {
		out[i] ^= p.key
	}
	return out, nil
}
func (p testProtector) Unprotect(in []byte) ([]byte, error) { return p.Protect(in) }

func TestVaultRoundTripAndNoPlaintextOnDisk(t *testing.T) {
	path := filepath.Join(t.TempDir(), "secrets.vpv")
	p := testProtector{0xA7}
	v, err := Open(path, p)
	if err != nil {
		t.Fatal(err)
	}
	secret := []byte("super-secret-refresh-token-12345")
	if err := v.Put("acct1", OAuthRefreshToken, secret); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(raw, secret) {
		t.Fatal("plaintext secret found on disk")
	}
	v.Close()
	v2, err := Open(path, p)
	if err != nil {
		t.Fatal(err)
	}
	defer v2.Close()
	got, ok, err := v2.Get("acct1", OAuthRefreshToken)
	if err != nil || !ok {
		t.Fatalf("get %v %v", ok, err)
	}
	defer zero(got)
	if !bytes.Equal(got, secret) {
		t.Fatalf("mismatch")
	}
}
func TestRecoverablePasswordBlockedUntilPortableRecovery(t *testing.T) {
	v, err := Open(filepath.Join(t.TempDir(), "v"), testProtector{3})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	if err := v.Put("a", RecoverablePassword, []byte("pw")); err != ErrPortableRecoveryRequired {
		t.Fatalf("got %v", err)
	}
}
func TestPortableRecoveryRequiresExplicitConfirmation(t *testing.T) {
	dir := t.TempDir()
	v, err := Open(filepath.Join(dir, "v"), testProtector{0x22})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	code, err := v.ConfigurePortableRecovery(filepath.Join(dir, "recovery.vpr"))
	if err != nil || code == "" {
		t.Fatalf("configure: code=%q err=%v", code, err)
	}
	st := v.PortableRecoveryStatus()
	if !st.Pending || st.Configured {
		t.Fatalf("expected pending recovery, got %+v", st)
	}
	if err := v.Put("a", RecoverablePassword, []byte("pw")); err != ErrPortableRecoveryRequired {
		t.Fatalf("recoverable secret accepted before confirmation: %v", err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	st = v.PortableRecoveryStatus()
	if !st.Configured || st.Pending {
		t.Fatalf("expected configured recovery, got %+v", st)
	}
	if err := v.Put("a", RecoverablePassword, []byte("pw")); err != nil {
		t.Fatal(err)
	}
}

func TestTamperIsDetected(t *testing.T) {
	path := filepath.Join(t.TempDir(), "v")
	p := testProtector{9}
	v, err := Open(path, p)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Put("a", OAuthRefreshToken, []byte("token")); err != nil {
		t.Fatal(err)
	}
	v.Close()
	b, _ := os.ReadFile(path)
	b[len(b)-8] ^= 1
	_ = os.WriteFile(path, b, 0o600)
	if _, err := Open(path, p); err == nil {
		t.Fatal("expected tamper detection")
	}
}

func TestPortableRecoveryEnablesRecoverableCredentials(t *testing.T) {
	dir := t.TempDir()
	vaultPath := filepath.Join(dir, "secrets.vpv")
	recoveryPath := filepath.Join(dir, "usb", "VaultPool-Recovery.vpr")
	p := testProtector{0x42}
	v, err := Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	code, err := v.ConfigurePortableRecovery(recoveryPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(code) < 40 {
		t.Fatal("recovery code too short")
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	if err := v.Put("acct1", RecoverableUsername, []byte("person@example.com")); err != nil {
		t.Fatal(err)
	}
	if err := v.Put("acct1", RecoverablePassword, []byte("correct horse battery staple")); err != nil {
		t.Fatal(err)
	}
	v.Close()

	restoredPath := filepath.Join(dir, "new-windows", "secrets.vpv")
	v2, err := RestoreFromRecovery(recoveryPath, code, restoredPath, testProtector{0x19})
	if err != nil {
		t.Fatal(err)
	}
	defer v2.Close()
	got, ok, err := v2.Get("acct1", RecoverablePassword)
	if err != nil || !ok {
		t.Fatalf("get: %v %v", ok, err)
	}
	defer zero(got)
	if string(got) != "correct horse battery staple" {
		t.Fatal("recovered password mismatch")
	}
}

func TestWrongRecoveryCodeCannotDecrypt(t *testing.T) {
	dir := t.TempDir()
	p := testProtector{1}
	v, err := Open(filepath.Join(dir, "v"), p)
	if err != nil {
		t.Fatal(err)
	}
	_, err = v.ConfigurePortableRecovery(filepath.Join(dir, "r.vpr"))
	if err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	v.Close()
	wrong := base64.RawURLEncoding.EncodeToString(bytes.Repeat([]byte{7}, 32))
	if _, err := RestoreFromRecovery(filepath.Join(dir, "r.vpr"), wrong, filepath.Join(dir, "new"), testProtector{2}); err == nil {
		t.Fatal("wrong code must fail")
	}
}

func TestRecoveryPackageContainsNeitherPlainPasswordNorRecoveryCode(t *testing.T) {
	dir := t.TempDir()
	rp := filepath.Join(dir, "recovery.vpr")
	v, err := Open(filepath.Join(dir, "vault"), testProtector{5})
	if err != nil {
		t.Fatal(err)
	}
	code, err := v.ConfigurePortableRecovery(rp)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	password := []byte("very-visible-password-marker")
	if err := v.Put("acct", RecoverablePassword, password); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(rp)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(raw, password) {
		t.Fatal("plaintext password in recovery package")
	}
	if bytes.Contains(raw, []byte(code)) {
		t.Fatal("recovery code stored in recovery package")
	}
	v.Close()
}

func TestDeletingRecoverableCredentialUpdatesRecoveryPackage(t *testing.T) {
	dir := t.TempDir()
	rp := filepath.Join(dir, "r.vpr")
	p := testProtector{4}
	v, err := Open(filepath.Join(dir, "v"), p)
	if err != nil {
		t.Fatal(err)
	}
	code, err := v.ConfigurePortableRecovery(rp)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	if err := v.Put("a", RecoverablePassword, []byte("pw")); err != nil {
		t.Fatal(err)
	}
	if err := v.Delete("a", RecoverablePassword); err != nil {
		t.Fatal(err)
	}
	v.Close()
	v2, err := RestoreFromRecovery(rp, code, filepath.Join(dir, "new"), testProtector{8})
	if err != nil {
		t.Fatal(err)
	}
	defer v2.Close()
	if _, ok, err := v2.Get("a", RecoverablePassword); err != nil || ok {
		t.Fatalf("deleted secret restored: ok=%v err=%v", ok, err)
	}
}

func TestFileDataKeyRequiresPortableRecoveryButDoesNotRefreshExternalCredentialSnapshot(t *testing.T) {
	dir := t.TempDir()
	vaultPath := filepath.Join(dir, "vault")
	recoveryPath := filepath.Join(dir, "recovery.vpr")
	v, err := Open(vaultPath, testProtector{0x31})
	if err != nil {
		t.Fatal(err)
	}
	fileKey := bytes.Repeat([]byte{0xA5}, 32)
	if err := v.Put("0123456789abcdef0123456789abcdef", FileDataKey, fileKey); err != ErrPortableRecoveryRequired {
		t.Fatalf("expected portable recovery requirement, got %v", err)
	}
	code, err := v.ConfigurePortableRecovery(recoveryPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	beforePkg, err := os.ReadFile(recoveryPath)
	if err != nil {
		t.Fatal(err)
	}
	before := v.PortableRecoveryStatus()
	if before.CredentialsRefreshRequired || before.CredentialRevision != before.ExternalCredentialRevision {
		t.Fatalf("initial recovery status inconsistent: %+v", before)
	}
	id := "0123456789abcdef0123456789abcdef"
	if err := v.Put(id, FileDataKey, fileKey); err != nil {
		t.Fatal(err)
	}
	meta := []byte(`{"file_id":"0123456789abcdef0123456789abcdef","file_name":"example.bin"}`)
	if err := v.Put(id, FileMetadata, meta); err != nil {
		t.Fatal(err)
	}
	after := v.PortableRecoveryStatus()
	if after.CredentialsRefreshRequired || after.CredentialRevision != before.CredentialRevision || after.ExternalCredentialRevision != before.ExternalCredentialRevision {
		t.Fatalf("file-only changes dirtied external credential snapshot: before=%+v after=%+v", before, after)
	}
	afterPkg, err := os.ReadFile(recoveryPath)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(beforePkg, afterPkg) {
		t.Fatal("file-only changes rewrote portable credential package")
	}
	v.Close()

	// The intentionally old .vpr still unlocks the recovery root, but it no
	// longer carries file keys/metadata added after confirmation. M0.14 restores
	// those from authenticated remote recovery records/manifests.
	v2, err := RestoreFromRecovery(recoveryPath, code, filepath.Join(dir, "restored"), testProtector{0x77})
	if err != nil {
		t.Fatal(err)
	}
	defer v2.Close()
	if _, ok, err := v2.Get(id, FileDataKey); err != nil || ok {
		t.Fatalf("old package unexpectedly contained post-confirmation file key: ok=%v err=%v", ok, err)
	}
	if _, ok, err := v2.Get(id, FileMetadata); err != nil || ok {
		t.Fatalf("old package unexpectedly contained post-confirmation file metadata: ok=%v err=%v", ok, err)
	}
}

func TestRecoverableCredentialChangesRequireFreshExternalSnapshot(t *testing.T) {
	dir := t.TempDir()
	v, err := Open(filepath.Join(dir, "vault.vpv"), testProtector{0x2c})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	if _, err := v.ConfigurePortableRecovery(filepath.Join(dir, "VaultPool-Recovery.vpr")); err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	base := v.PortableRecoveryStatus()
	if base.CredentialsRefreshRequired {
		t.Fatalf("freshly confirmed package already stale: %+v", base)
	}
	if err := v.Put("acct", RecoverableUsername, []byte("person@example.com")); err != nil {
		t.Fatal(err)
	}
	st := v.PortableRecoveryStatus()
	if !st.CredentialsRefreshRequired || st.CredentialRevision != base.CredentialRevision+1 || st.ExternalCredentialRevision != base.ExternalCredentialRevision {
		t.Fatalf("username change did not mark external snapshot stale: base=%+v now=%+v", base, st)
	}
	// Writing exactly the same credential is not a new revision.
	if err := v.Put("acct", RecoverableUsername, []byte("person@example.com")); err != nil {
		t.Fatal(err)
	}
	st2 := v.PortableRecoveryStatus()
	if st2.CredentialRevision != st.CredentialRevision {
		t.Fatalf("unchanged credential advanced revision: %d -> %d", st.CredentialRevision, st2.CredentialRevision)
	}
	if err := v.ConfirmExternalCredentialSnapshot(); err != nil {
		t.Fatal(err)
	}
	st3 := v.PortableRecoveryStatus()
	if st3.CredentialsRefreshRequired || st3.ExternalCredentialRevision != st3.CredentialRevision {
		t.Fatalf("confirmed snapshot still stale: %+v", st3)
	}
	if err := v.Put("acct", RecoverablePassword, []byte("new-password")); err != nil {
		t.Fatal(err)
	}
	st4 := v.PortableRecoveryStatus()
	if !st4.CredentialsRefreshRequired || st4.CredentialRevision != st3.CredentialRevision+1 {
		t.Fatalf("password change not tracked: before=%+v after=%+v", st3, st4)
	}
	if err := v.Delete("acct", RecoverablePassword); err != nil {
		t.Fatal(err)
	}
	st5 := v.PortableRecoveryStatus()
	if st5.CredentialRevision != st4.CredentialRevision+1 {
		t.Fatalf("credential deletion not tracked: before=%+v after=%+v", st4, st5)
	}
}

func TestRestoreFromRecoveryDoesNotRewriteSourcePackage(t *testing.T) {
	dir := t.TempDir()
	p := testProtector{0x44}
	v, err := Open(filepath.Join(dir, "source.vpv"), p)
	if err != nil {
		t.Fatal(err)
	}
	rp := filepath.Join(dir, "source.vpr")
	code, err := v.ConfigurePortableRecovery(rp)
	if err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	if err := v.Put("acct", RecoverableUsername, []byte("name@example.com")); err != nil {
		t.Fatal(err)
	}
	v.Close()
	before, err := os.ReadFile(rp)
	if err != nil {
		t.Fatal(err)
	}
	restored, err := RestoreFromRecovery(rp, code, filepath.Join(dir, "restored.vpv"), testProtector{0x55})
	if err != nil {
		t.Fatal(err)
	}
	restored.Close()
	after, err := os.ReadFile(rp)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(before, after) {
		t.Fatal("RestoreFromRecovery modified its source package")
	}
}

func TestRecoveryRecordIsBoundToLabelAndDetectsTamper(t *testing.T) {
	dir := t.TempDir()
	v, err := Open(filepath.Join(dir, "v.vpv"), testProtector{0x66})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	if _, err := v.ConfigurePortableRecovery(filepath.Join(dir, "r.vpr")); err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	secret := bytes.Repeat([]byte{0xa5}, 32)
	sealed, err := v.SealRecoveryValue("file-key/0123456789abcdef0123456789abcdef", secret)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(sealed, secret) {
		t.Fatal("recovery record leaked plaintext")
	}
	got, err := v.OpenRecoveryValue("file-key/0123456789abcdef0123456789abcdef", sealed)
	if err != nil || !bytes.Equal(got, secret) {
		t.Fatalf("open: %v", err)
	}
	zero(got)
	if _, err := v.OpenRecoveryValue("file-key/ffffffffffffffffffffffffffffffff", sealed); err == nil {
		t.Fatal("recovery record authenticated under wrong label")
	}
	tampered := append([]byte(nil), sealed...)
	tampered[len(tampered)/2] ^= 1
	if _, err := v.OpenRecoveryValue("file-key/0123456789abcdef0123456789abcdef", tampered); err == nil {
		t.Fatal("tampered recovery record authenticated")
	}
}

func TestLibraryMetadataDoesNotRequirePortableRecovery(t *testing.T) {
	dir := t.TempDir()
	v, err := Open(filepath.Join(dir, "vault.vpv"), testProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	if err := v.Put("vaultpool-library-v1", LibraryMetadata, []byte(`{"folders":[]}`)); err != nil {
		t.Fatalf("non-critical library metadata should not require recovery: %v", err)
	}
	if got, ok, err := v.Get("vaultpool-library-v1", LibraryMetadata); err != nil || !ok || len(got) == 0 {
		t.Fatalf("library metadata roundtrip failed: ok=%v err=%v", ok, err)
	}
}
