package secretvault

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/safefile"
)

type Kind string

const (
	OAuthRefreshToken   Kind = "oauth_refresh_token"
	OAuthAccessToken    Kind = "oauth_access_token"
	ProviderSession     Kind = "provider_session"
	FilenSession        Kind = "filen_session"
	MediaFireSession    Kind = "mediafire_session"
	AccountIdentity     Kind = "account_identity"
	RecoverableUsername Kind = "recoverable_username"
	RecoverablePassword Kind = "recoverable_password"
	// FileDataKey and FileMetadata are recovery-critical. Losing either can make
	// an otherwise healthy distributed file undiscoverable or undecryptable, so
	// VaultPool refuses to persist them until portable recovery is configured.
	FileDataKey  Kind = "file_data_key"
	FileMetadata Kind = "file_metadata"
	// LibraryMetadata stores non-critical, user-private organization data such
	// as virtual folders. It is encrypted with SecretVault like filenames, but
	// losing it never makes file contents unrecoverable.
	LibraryMetadata Kind = "library_metadata"
	// ConnectorPublicConfig stores legacy non-secret connector bootstrap data such
	// as OAuth desktop client IDs. New OAuth connector settings use
	// ConnectorOAuthConfig because some desktop providers also return a
	// client_secret that must never be shown or logged.
	ConnectorPublicConfig Kind = "connector_public_config"
	// ConnectorOAuthConfig stores OAuth connector bootstrap settings protected by
	// the OS-backed SecretVault. It is not recovery-critical: losing it means the
	// user must reconfigure/re-authorize a provider, not that file contents become
	// unrecoverable.
	ConnectorOAuthConfig Kind = "connector_oauth_config"
)

var ErrPortableRecoveryRequired = errors.New("portable recovery must be configured before storing recoverable credentials")

const maxPortableRecoveryPackageBytes int64 = 64 << 20

type Protector interface {
	Name() string
	Protect([]byte) ([]byte, error)
	Unprotect([]byte) ([]byte, error)
}

type Entry struct {
	AccountID string `json:"account_id"`
	Kind      Kind   `json:"kind"`
	Value     []byte `json:"value"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}
type recoveryConfig struct {
	Path                       string `json:"path"`
	Key                        []byte `json:"key"`
	Confirmed                  bool   `json:"confirmed"`
	UpdatedAt                  string `json:"updated_at"`
	CredentialRevision         uint64 `json:"credential_revision,omitempty"`
	ExternalCredentialRevision uint64 `json:"external_credential_revision,omitempty"`
	ExternalConfirmedAt        string `json:"external_confirmed_at,omitempty"`
}

type plainData struct {
	Entries  map[string]Entry `json:"entries"`
	Recovery *recoveryConfig  `json:"recovery,omitempty"`
}
type envelope struct {
	Version    int    `json:"version"`
	Protector  string `json:"protector"`
	WrappedKey string `json:"wrapped_key"`
	Nonce      string `json:"nonce"`
	Ciphertext string `json:"ciphertext"`
}

type Metadata struct {
	Key       string `json:"key"`
	AccountID string `json:"account_id"`
	Kind      Kind   `json:"kind"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

type PortableRecoveryStatus struct {
	Configured                 bool   `json:"configured"`
	Pending                    bool   `json:"pending"`
	Path                       string `json:"path,omitempty"`
	UpdatedAt                  string `json:"updated_at,omitempty"`
	CredentialRevision         uint64 `json:"credential_revision"`
	ExternalCredentialRevision uint64 `json:"external_credential_revision"`
	CredentialsRefreshRequired bool   `json:"credentials_refresh_required"`
	ExternalConfirmedAt        string `json:"external_confirmed_at,omitempty"`
}

type Vault struct {
	mu        sync.Mutex
	path      string
	protector Protector
	masterKey []byte
	data      plainData
	closed    bool
}

func Open(path string, p Protector) (*Vault, error) {
	if p == nil {
		return nil, errors.New("secret protector required")
	}
	v := &Vault{path: path, protector: p, data: plainData{Entries: map[string]Entry{}}}
	b, err := os.ReadFile(path)
	if err != nil {
		if !os.IsNotExist(err) {
			return nil, err
		}
		key := make([]byte, 32)
		if _, err := rand.Read(key); err != nil {
			return nil, err
		}
		v.masterKey = key
		if err := v.saveLocked(); err != nil {
			zero(key)
			return nil, err
		}
		return v, nil
	}
	var env envelope
	if err := json.Unmarshal(b, &env); err != nil {
		return nil, fmt.Errorf("parse vault envelope: %w", err)
	}
	if env.Version != 1 {
		return nil, fmt.Errorf("unsupported vault version %d", env.Version)
	}
	if env.Protector != p.Name() {
		return nil, fmt.Errorf("vault protector mismatch: file=%s runtime=%s", env.Protector, p.Name())
	}
	wrapped, err := base64.RawStdEncoding.DecodeString(env.WrappedKey)
	if err != nil {
		return nil, errors.New("invalid wrapped key")
	}
	key, err := p.Unprotect(wrapped)
	zero(wrapped)
	if err != nil {
		return nil, fmt.Errorf("unlock vault key: %w", err)
	}
	if len(key) != 32 {
		zero(key)
		return nil, errors.New("invalid vault master key length")
	}
	nonce, err := base64.RawStdEncoding.DecodeString(env.Nonce)
	if err != nil {
		zero(key)
		return nil, errors.New("invalid nonce")
	}
	ct, err := base64.RawStdEncoding.DecodeString(env.Ciphertext)
	if err != nil {
		zero(key)
		zero(nonce)
		return nil, errors.New("invalid ciphertext")
	}
	aead, err := newAEAD(key)
	if err != nil {
		zero(key)
		zero(nonce)
		zero(ct)
		return nil, err
	}
	plain, err := aead.Open(nil, nonce, ct, aad(env.Version, env.Protector))
	zero(nonce)
	zero(ct)
	if err != nil {
		zero(key)
		return nil, errors.New("vault authentication failed")
	}
	var d plainData
	err = json.Unmarshal(plain, &d)
	zero(plain)
	if err != nil {
		zero(key)
		return nil, errors.New("invalid decrypted vault data")
	}
	if d.Entries == nil {
		d.Entries = map[string]Entry{}
	}
	v.masterKey = key
	v.data = d
	return v, nil
}

func newAEAD(key []byte) (cipher.AEAD, error) {
	b, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(b)
}
func aad(version int, protector string) []byte {
	return []byte(fmt.Sprintf("VaultPool/SecretVault/v%d/%s", version, protector))
}
func entryKey(accountID string, kind Kind) string { return accountID + "\x00" + string(kind) }
func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func (v *Vault) ensureOpen() error {
	if v.closed {
		return errors.New("vault closed")
	}
	return nil
}

func requiresPortableRecovery(kind Kind) bool {
	switch kind {
	case RecoverablePassword, RecoverableUsername, FileDataKey, FileMetadata:
		return true
	default:
		return false
	}
}

func changesExternalCredentialSnapshot(kind Kind) bool {
	switch kind {
	case RecoverablePassword, RecoverableUsername:
		return true
	default:
		return false
	}
}

func (v *Vault) recoveryReadyLocked() bool {
	r := v.data.Recovery
	return r != nil && len(r.Key) == 32 && r.Path != "" && r.Confirmed
}

func (v *Vault) Put(accountID string, kind Kind, value []byte) error {
	if accountID == "" || len(value) == 0 {
		return errors.New("account and secret value required")
	}
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return err
	}
	recoverable := requiresPortableRecovery(kind)
	if recoverable && !v.recoveryReadyLocked() {
		return ErrPortableRecoveryRequired
	}
	k := entryKey(accountID, kind)
	now := time.Now().UTC().Format(time.RFC3339Nano)
	created := now
	old, hadOld := v.data.Entries[k]
	if hadOld {
		created = old.CreatedAt
	}
	cp := append([]byte(nil), value...)
	credentialChanged := changesExternalCredentialSnapshot(kind) && (!hadOld || !bytes.Equal(old.Value, value))
	oldCredentialRevision := uint64(0)
	if v.data.Recovery != nil {
		oldCredentialRevision = v.data.Recovery.CredentialRevision
	}
	v.data.Entries[k] = Entry{AccountID: accountID, Kind: kind, Value: cp, CreatedAt: created, UpdatedAt: now}
	if credentialChanged {
		v.data.Recovery.CredentialRevision++
		v.data.Recovery.UpdatedAt = now
	}
	if err := v.saveLocked(); err != nil {
		if hadOld {
			v.data.Entries[k] = old
		} else {
			delete(v.data.Entries, k)
		}
		if v.data.Recovery != nil {
			v.data.Recovery.CredentialRevision = oldCredentialRevision
		}
		zero(cp)
		return err
	}
	// FileDataKey/FileMetadata no longer force the portable package to change:
	// M0.14 protects them through independently replicated recovery records and
	// authenticated remote manifests. Only credentials that cannot be recovered
	// from providers safely require a fresh external .vpr snapshot.
	if credentialChanged {
		if err := v.writeRecoveryLocked(); err != nil {
			if hadOld {
				v.data.Entries[k] = old
			} else {
				delete(v.data.Entries, k)
			}
			if v.data.Recovery != nil {
				v.data.Recovery.CredentialRevision = oldCredentialRevision
			}
			if rbErr := v.saveLocked(); rbErr != nil {
				zero(cp)
				return errors.Join(err, fmt.Errorf("rollback vault after recovery-package failure: %w", rbErr))
			}
			zero(cp)
			return err
		}
	}
	if hadOld {
		zero(old.Value)
	}
	return nil
}
func (v *Vault) Get(accountID string, kind Kind) ([]byte, bool, error) {
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return nil, false, err
	}
	e, ok := v.data.Entries[entryKey(accountID, kind)]
	if !ok {
		return nil, false, nil
	}
	return append([]byte(nil), e.Value...), true, nil
}
func (v *Vault) Delete(accountID string, kind Kind) error {
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return err
	}
	k := entryKey(accountID, kind)
	e, ok := v.data.Entries[k]
	if !ok {
		return nil
	}
	delete(v.data.Entries, k)
	credentialChanged := changesExternalCredentialSnapshot(kind)
	oldCredentialRevision := uint64(0)
	if v.data.Recovery != nil {
		oldCredentialRevision = v.data.Recovery.CredentialRevision
	}
	if credentialChanged && v.data.Recovery != nil {
		v.data.Recovery.CredentialRevision++
		v.data.Recovery.UpdatedAt = time.Now().UTC().Format(time.RFC3339Nano)
	}
	if err := v.saveLocked(); err != nil {
		v.data.Entries[k] = e
		if v.data.Recovery != nil {
			v.data.Recovery.CredentialRevision = oldCredentialRevision
		}
		return err
	}
	if credentialChanged && v.data.Recovery != nil {
		if err := v.writeRecoveryLocked(); err != nil {
			v.data.Entries[k] = e
			if v.data.Recovery != nil {
				v.data.Recovery.CredentialRevision = oldCredentialRevision
			}
			if rbErr := v.saveLocked(); rbErr != nil {
				return errors.Join(err, fmt.Errorf("rollback vault after recovery-package failure: %w", rbErr))
			}
			return err
		}
	}
	zero(e.Value)
	return nil
}

func (v *Vault) ListMetadata() ([]Metadata, error) {
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return nil, err
	}
	out := make([]Metadata, 0, len(v.data.Entries))
	for k, e := range v.data.Entries {
		out = append(out, Metadata{Key: k, AccountID: e.AccountID, Kind: e.Kind, CreatedAt: e.CreatedAt, UpdatedAt: e.UpdatedAt})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Key < out[j].Key })
	return out, nil
}
func (v *Vault) Close() {
	v.mu.Lock()
	defer v.mu.Unlock()
	if v.closed {
		return
	}
	for k, e := range v.data.Entries {
		zero(e.Value)
		e.Value = nil
		v.data.Entries[k] = e
	}
	if v.data.Recovery != nil {
		zero(v.data.Recovery.Key)
		v.data.Recovery.Key = nil
	}
	zero(v.masterKey)
	v.masterKey = nil
	v.closed = true
}

type recoveryPayload struct {
	Version   int       `json:"version"`
	MasterKey []byte    `json:"master_key"`
	Data      plainData `json:"data"`
}

type recoveryEnvelope struct {
	Version    int    `json:"version"`
	Nonce      string `json:"nonce"`
	Ciphertext string `json:"ciphertext"`
}

func recoveryAAD() []byte { return []byte("VaultPool/PortableRecovery/v1") }

// ConfigurePortableRecovery creates a random 256-bit recovery code and an
// encrypted portable package. The code is returned once and is never persisted
// in plaintext by VaultPool.
func (v *Vault) ConfigurePortableRecovery(path string) (string, error) {
	if path == "" {
		return "", errors.New("recovery package path required")
	}
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return "", err
	}
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		return "", err
	}
	old := v.data.Recovery
	v.data.Recovery = &recoveryConfig{Path: path, Key: key, Confirmed: false, UpdatedAt: time.Now().UTC().Format(time.RFC3339Nano)}
	if err := v.writeRecoveryLocked(); err != nil {
		v.data.Recovery = old
		zero(key)
		return "", err
	}
	if err := v.saveLocked(); err != nil {
		v.data.Recovery = old
		zero(key)
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(key), nil
}

func (v *Vault) PortableRecoveryStatus() PortableRecoveryStatus {
	v.mu.Lock()
	defer v.mu.Unlock()
	r := v.data.Recovery
	if r == nil {
		return PortableRecoveryStatus{}
	}
	readyMaterial := len(r.Key) == 32 && r.Path != ""
	return PortableRecoveryStatus{
		Configured:                 readyMaterial && r.Confirmed,
		Pending:                    readyMaterial && !r.Confirmed,
		Path:                       r.Path,
		UpdatedAt:                  r.UpdatedAt,
		CredentialRevision:         r.CredentialRevision,
		ExternalCredentialRevision: r.ExternalCredentialRevision,
		CredentialsRefreshRequired: readyMaterial && r.Confirmed && r.ExternalCredentialRevision < r.CredentialRevision,
		ExternalConfirmedAt:        r.ExternalConfirmedAt,
	}
}

type recoveryRecordEnvelope struct {
	Version    int    `json:"version"`
	Nonce      string `json:"nonce"`
	Ciphertext string `json:"ciphertext"`
}

func recoveryRecordKey(root []byte, label string) ([]byte, error) {
	if len(root) != 32 || strings.TrimSpace(label) == "" || len(label) > 512 {
		return nil, errors.New("invalid recovery-record key material")
	}
	mac := hmac.New(sha256.New, root)
	_, _ = mac.Write([]byte("VaultPool/RecoveryRecordKey/v1\x00"))
	_, _ = mac.Write([]byte(label))
	return mac.Sum(nil), nil
}

func recoveryRecordAAD(label string) []byte {
	return []byte("VaultPool/RecoveryRecord/v1/" + label)
}

// SealRecoveryValue encrypts a small recovery-critical value under a key
// derived from the portable recovery root. The recovery root never leaves the
// SecretVault. These records may be replicated to cloud providers because the
// ciphertext is independently authenticated and useless without the recovery
// code/root.
func (v *Vault) SealRecoveryValue(label string, value []byte) ([]byte, error) {
	if len(value) == 0 || len(value) > 1<<20 {
		return nil, errors.New("invalid recovery-record value size")
	}
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return nil, err
	}
	if !v.recoveryReadyLocked() {
		return nil, ErrPortableRecoveryRequired
	}
	key, err := recoveryRecordKey(v.data.Recovery.Key, label)
	if err != nil {
		return nil, err
	}
	defer zero(key)
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}
	defer zero(nonce)
	ct := aead.Seal(nil, nonce, value, recoveryRecordAAD(label))
	defer zero(ct)
	env := recoveryRecordEnvelope{Version: 1, Nonce: base64.RawStdEncoding.EncodeToString(nonce), Ciphertext: base64.RawStdEncoding.EncodeToString(ct)}
	return json.Marshal(env)
}

// OpenRecoveryValue decrypts a recovery record using the recovery root held by
// the currently unlocked SecretVault. A record sealed for another label/FileID
// cannot authenticate because the label is part of both key derivation and AAD.
func (v *Vault) OpenRecoveryValue(label string, sealed []byte) ([]byte, error) {
	if len(sealed) == 0 || len(sealed) > 2<<20 {
		return nil, errors.New("invalid recovery-record size")
	}
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return nil, err
	}
	if !v.recoveryReadyLocked() {
		return nil, ErrPortableRecoveryRequired
	}
	var env recoveryRecordEnvelope
	if err := json.Unmarshal(sealed, &env); err != nil || env.Version != 1 {
		return nil, errors.New("invalid recovery record")
	}
	nonce, err := base64.RawStdEncoding.DecodeString(env.Nonce)
	if err != nil {
		return nil, errors.New("invalid recovery-record nonce")
	}
	defer zero(nonce)
	ct, err := base64.RawStdEncoding.DecodeString(env.Ciphertext)
	if err != nil {
		return nil, errors.New("invalid recovery-record ciphertext")
	}
	defer zero(ct)
	key, err := recoveryRecordKey(v.data.Recovery.Key, label)
	if err != nil {
		return nil, err
	}
	defer zero(key)
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}
	plain, err := aead.Open(nil, nonce, ct, recoveryRecordAAD(label))
	if err != nil {
		return nil, errors.New("recovery record authentication failed")
	}
	return plain, nil
}

func (v *Vault) RecoveryConfigured() (bool, string) {
	st := v.PortableRecoveryStatus()
	return st.Configured, st.Path
}

// ConfirmPortableRecovery is a deliberate second step. Configure generates the
// package and returns the recovery code once, but recoverable secrets remain
// blocked until the user confirms they saved both pieces outside this machine.
func (v *Vault) ConfirmPortableRecovery() error {
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return err
	}
	if v.data.Recovery == nil || len(v.data.Recovery.Key) != 32 || v.data.Recovery.Path == "" {
		return ErrPortableRecoveryRequired
	}
	if v.data.Recovery.Confirmed {
		return nil
	}
	old := *v.data.Recovery
	v.data.Recovery.Confirmed = true
	now := time.Now().UTC().Format(time.RFC3339Nano)
	v.data.Recovery.ExternalCredentialRevision = v.data.Recovery.CredentialRevision
	v.data.Recovery.ExternalConfirmedAt = now
	v.data.Recovery.UpdatedAt = now
	if err := v.writeRecoveryLocked(); err != nil {
		*v.data.Recovery = old
		return err
	}
	if err := v.saveLocked(); err != nil {
		*v.data.Recovery = old
		return err
	}
	return nil
}

// ConfirmExternalCredentialSnapshot is used after the user explicitly confirms
// that the freshly exported .vpr package was saved outside this machine. It
// does not rotate the recovery key/code and therefore keeps the previous copy
// usable while acknowledging the newer credential snapshot.
func (v *Vault) ConfirmExternalCredentialSnapshot() error {
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return err
	}
	if !v.recoveryReadyLocked() {
		return ErrPortableRecoveryRequired
	}
	old := *v.data.Recovery
	now := time.Now().UTC().Format(time.RFC3339Nano)
	v.data.Recovery.ExternalCredentialRevision = v.data.Recovery.CredentialRevision
	v.data.Recovery.ExternalConfirmedAt = now
	v.data.Recovery.UpdatedAt = now
	if err := v.saveLocked(); err != nil {
		*v.data.Recovery = old
		return err
	}
	return nil
}

// RelocatePortableRecovery moves future recovery-package updates to path. It is
// used after a staged restore so the restored vault no longer depends on the
// temporary uploaded package. The old package is intentionally not deleted.
func (v *Vault) RelocatePortableRecovery(path string) error {
	if path == "" {
		return errors.New("recovery package path required")
	}
	v.mu.Lock()
	defer v.mu.Unlock()
	if err := v.ensureOpen(); err != nil {
		return err
	}
	if v.data.Recovery == nil || len(v.data.Recovery.Key) != 32 {
		return ErrPortableRecoveryRequired
	}
	old := *v.data.Recovery
	v.data.Recovery.Path = path
	v.data.Recovery.Confirmed = true
	v.data.Recovery.UpdatedAt = time.Now().UTC().Format(time.RFC3339Nano)
	if err := v.writeRecoveryLocked(); err != nil {
		*v.data.Recovery = old
		return err
	}
	if err := v.saveLocked(); err != nil {
		*v.data.Recovery = old
		return err
	}
	return nil
}

func (v *Vault) writeRecoveryLocked() error {
	r := v.data.Recovery
	if r == nil || len(r.Key) != 32 || r.Path == "" {
		return ErrPortableRecoveryRequired
	}
	dataForRecovery := v.data
	if v.data.Recovery != nil {
		rc := *v.data.Recovery
		rc.Key = nil // never encrypt the recovery key under itself
		dataForRecovery.Recovery = &rc
	}
	payload := recoveryPayload{Version: 1, MasterKey: append([]byte(nil), v.masterKey...), Data: dataForRecovery}
	raw, err := json.Marshal(payload)
	zero(payload.MasterKey)
	if err != nil {
		return err
	}
	defer zero(raw)
	aead, err := newAEAD(r.Key)
	if err != nil {
		return err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return err
	}
	defer zero(nonce)
	ct := aead.Seal(nil, nonce, raw, recoveryAAD())
	defer zero(ct)
	env := recoveryEnvelope{Version: 1, Nonce: base64.RawStdEncoding.EncodeToString(nonce), Ciphertext: base64.RawStdEncoding.EncodeToString(ct)}
	out, err := json.MarshalIndent(env, "", "  ")
	if err != nil {
		return err
	}
	if err := safefile.WriteAtomic(r.Path, out, 0o600); err != nil {
		return err
	}
	return nil
}

// RestoreFromRecovery decrypts a portable package using the user's recovery
// code and re-wraps the restored master key with the protector of the new
// Windows profile/machine.
func RestoreFromRecovery(packagePath, recoveryCode, targetVaultPath string, p Protector) (*Vault, error) {
	if p == nil {
		return nil, errors.New("secret protector required")
	}
	key, err := base64.RawURLEncoding.DecodeString(recoveryCode)
	if err != nil || len(key) != 32 {
		zero(key)
		return nil, errors.New("invalid recovery code")
	}
	defer zero(key)
	st, err := os.Stat(packagePath)
	if err != nil {
		return nil, err
	}
	if !st.Mode().IsRegular() || st.Size() < 1 || st.Size() > maxPortableRecoveryPackageBytes {
		return nil, errors.New("invalid recovery package size")
	}
	b, err := os.ReadFile(packagePath)
	if err != nil {
		return nil, err
	}
	var env recoveryEnvelope
	if err := json.Unmarshal(b, &env); err != nil || env.Version != 1 {
		return nil, errors.New("invalid recovery package")
	}
	nonce, err := base64.RawStdEncoding.DecodeString(env.Nonce)
	if err != nil {
		return nil, errors.New("invalid recovery nonce")
	}
	defer zero(nonce)
	ct, err := base64.RawStdEncoding.DecodeString(env.Ciphertext)
	if err != nil {
		return nil, errors.New("invalid recovery ciphertext")
	}
	defer zero(ct)
	aead, err := newAEAD(key)
	if err != nil {
		return nil, err
	}
	raw, err := aead.Open(nil, nonce, ct, recoveryAAD())
	if err != nil {
		return nil, errors.New("recovery package authentication failed")
	}
	defer zero(raw)
	var payload recoveryPayload
	if err := json.Unmarshal(raw, &payload); err != nil || payload.Version != 1 || len(payload.MasterKey) != 32 {
		zero(payload.MasterKey)
		return nil, errors.New("invalid recovery payload")
	}
	if payload.Data.Entries == nil {
		payload.Data.Entries = map[string]Entry{}
	}
	rc := payload.Data.Recovery
	if rc == nil {
		rc = &recoveryConfig{}
	}
	now := time.Now().UTC().Format(time.RFC3339Nano)
	rc.Path = packagePath
	rc.Key = append([]byte(nil), key...)
	rc.Confirmed = true
	rc.UpdatedAt = now
	// The package being restored is itself the external snapshot currently in
	// the user's possession, so it is current for the credential revision it
	// contains (but of course knows nothing about future revisions).
	rc.ExternalCredentialRevision = rc.CredentialRevision
	rc.ExternalConfirmedAt = now
	payload.Data.Recovery = rc
	v := &Vault{path: targetVaultPath, protector: p, masterKey: append([]byte(nil), payload.MasterKey...), data: payload.Data}
	zero(payload.MasterKey)
	if err := v.saveLocked(); err != nil {
		v.Close()
		return nil, err
	}
	// Restoring is read-only with respect to the source recovery package.
	// Rewriting it here would invalidate any external hash/staged-restore
	// transaction and could make a retry impossible after a crash. Future
	// vault mutations update the configured package; recoverycenter relocates
	// it explicitly after activation.
	return v, nil
}

func (v *Vault) saveLocked() error {
	if err := v.ensureOpen(); err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(v.path), 0o700); err != nil {
		return err
	}
	plain, err := json.Marshal(v.data)
	if err != nil {
		return err
	}
	defer zero(plain)
	aead, err := newAEAD(v.masterKey)
	if err != nil {
		return err
	}
	nonce := make([]byte, aead.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return err
	}
	defer zero(nonce)
	ct := aead.Seal(nil, nonce, plain, aad(1, v.protector.Name()))
	defer zero(ct)
	wrapped, err := v.protector.Protect(v.masterKey)
	if err != nil {
		return err
	}
	defer zero(wrapped)
	env := envelope{Version: 1, Protector: v.protector.Name(), WrappedKey: base64.RawStdEncoding.EncodeToString(wrapped), Nonce: base64.RawStdEncoding.EncodeToString(nonce), Ciphertext: base64.RawStdEncoding.EncodeToString(ct)}
	out, err := json.MarshalIndent(env, "", "  ")
	if err != nil {
		return err
	}
	if err := safefile.WriteAtomic(v.path, out, 0o600); err != nil {
		return err
	}
	return nil
}
