package buildinfo

const Product = "VaultPool"
const Milestone = "M0.24.17"

// Version is a variable so release builds may replace it with -ldflags without
// modifying source checkpoints.
var Version = "0.24.17-filen-account-quota-fix-source"

// BuildPurpose is "release" in source. Temporary validation binaries may
// override it with -ldflags to make data operations fail closed.
var BuildPurpose = "release"

// OAuth desktop client IDs are public identifiers, not client secrets. Source
// checkpoints intentionally leave them blank; official release builds inject
// the reviewed IDs with -ldflags. Runtime environment variables may override
// them for development/testing.
var GoogleClientID string
var GoogleClientSecret string
var MicrosoftClientID string
var DropboxClientID string

// DataOperationsEnabled reports whether this binary may touch real file data.
// field-test builds are intentionally allowed for disposable end-to-end tests,
// but must remain visibly distinct from production releases.
func DataOperationsEnabled() bool {
	return BuildPurpose == "release" || BuildPurpose == "field-test"
}

func FieldTest() bool { return BuildPurpose == "field-test" }
