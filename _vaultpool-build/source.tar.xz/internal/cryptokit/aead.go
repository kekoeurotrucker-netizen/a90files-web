package cryptokit

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
	"fmt"
	"io"
	"os"
)

const KeySize = 32

func RandomID(n int) (string, error) {
	if n < 1 {
		return "", errors.New("random id length must be positive")
	}
	b := make([]byte, n)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		return "", err
	}
	return fmt.Sprintf("%x", b), nil
}

func GenerateKey() ([]byte, error) {
	key := make([]byte, KeySize)
	if _, err := io.ReadFull(rand.Reader, key); err != nil {
		return nil, err
	}
	return key, nil
}

func WriteKeyFile(path string, key []byte) error {
	if len(key) != KeySize {
		return fmt.Errorf("invalid key length: %d", len(key))
	}
	return os.WriteFile(path, key, 0o600)
}

func ReadKeyFile(path string) ([]byte, error) {
	key, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if len(key) != KeySize {
		return nil, fmt.Errorf("invalid recovery key length: got %d, want %d", len(key), KeySize)
	}
	return key, nil
}

func newGCM(key []byte) (cipher.AEAD, error) {
	if len(key) != KeySize {
		return nil, errors.New("AES-256-GCM requires a 32-byte key")
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

// SealedSize returns the exact byte length produced by Seal for a plaintext of
// n bytes. AES-GCM adds a nonce and authentication tag; the size is independent
// of the plaintext contents.
func SealedSize(n int) (int, error) {
	if n < 0 {
		return 0, errors.New("negative plaintext size")
	}
	// GCM parameters are fixed for AES in Go's standard library. Build a
	// throwaway zero key so this remains derived from the implementation rather
	// than hard-coding nonce/tag sizes.
	gcm, err := newGCM(make([]byte, KeySize))
	if err != nil {
		return 0, err
	}
	return gcm.NonceSize() + n + gcm.Overhead(), nil
}

func Seal(key, plaintext, aad []byte) ([]byte, error) {
	gcm, err := newGCM(key)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	out := make([]byte, 0, len(nonce)+len(plaintext)+gcm.Overhead())
	out = append(out, nonce...)
	out = gcm.Seal(out, nonce, plaintext, aad)
	return out, nil
}

func Open(key, sealed, aad []byte) ([]byte, error) {
	gcm, err := newGCM(key)
	if err != nil {
		return nil, err
	}
	if len(sealed) < gcm.NonceSize()+gcm.Overhead() {
		return nil, errors.New("sealed data too short")
	}
	nonce := sealed[:gcm.NonceSize()]
	ciphertext := sealed[gcm.NonceSize():]
	return gcm.Open(nil, nonce, ciphertext, aad)
}
