package compression

import (
	"bytes"
	"compress/zlib"
	"errors"
	"testing"
)

type incompatibleCurrent struct{}

func (incompatibleCurrent) Name() string { return "zstd" }
func (incompatibleCurrent) TryCompress(src []byte) ([]byte, bool, error) {
	return nil, false, errors.New("not used")
}
func (incompatibleCurrent) Decompress(src []byte) ([]byte, error) {
	return nil, errors.New("wrong codec used")
}

func TestDecompressNamedKeepsZlibFieldDataForwardRecoverable(t *testing.T) {
	plain := bytes.Repeat([]byte("VaultPool recoverable format. "), 64)
	var encoded bytes.Buffer
	w := zlib.NewWriter(&encoded)
	if _, err := w.Write(plain); err != nil {
		t.Fatal(err)
	}
	if err := w.Close(); err != nil {
		t.Fatal(err)
	}
	got, err := DecompressNamed("zlib", incompatibleCurrent{}, encoded.Bytes())
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, plain) {
		t.Fatal("zlib field data was not recoverable with a different current codec")
	}
}
