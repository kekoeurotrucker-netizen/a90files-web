package compression

import (
	"bytes"
	"compress/zlib"
	"errors"
	"io"
	"strings"
)

// DecompressNamed restores a block according to the algorithm recorded in its
// authenticated manifest. Keeping this dispatch explicit lets a field-test
// zlib file remain recoverable by later production builds whose preferred
// compressor is Zstandard.
func DecompressNamed(name string, current Codec, src []byte) ([]byte, error) {
	switch strings.ToLower(strings.TrimSpace(name)) {
	case "", strings.ToLower(current.Name()):
		return current.Decompress(src)
	case "zlib":
		r, err := zlib.NewReader(bytes.NewReader(src))
		if err != nil {
			return nil, err
		}
		defer r.Close()
		return io.ReadAll(r)
	default:
		return nil, errors.New("unsupported compression algorithm in manifest: " + name)
	}
}
