//go:build offline

package compression

// Offline/field validation builds use the standard-library zlib codec so the
// end-to-end storage path can be exercised without external module downloads.
// Public release builds still prefer the pinned Zstandard implementation.

import (
	"bytes"
	"compress/zlib"
	"io"
)

type Zstd struct{}

func New() (*Zstd, error)    { return &Zstd{}, nil }
func (z *Zstd) Name() string { return "zlib" }
func (z *Zstd) Close()       {}

func (z *Zstd) TryCompress(src []byte) ([]byte, bool, error) {
	var b bytes.Buffer
	w, err := zlib.NewWriterLevel(&b, zlib.DefaultCompression)
	if err != nil {
		return nil, false, err
	}
	if _, err := w.Write(src); err != nil {
		return nil, false, err
	}
	if err := w.Close(); err != nil {
		return nil, false, err
	}
	if b.Len() < len(src) {
		return b.Bytes(), true, nil
	}
	out := append([]byte(nil), src...)
	return out, false, nil
}

func (z *Zstd) Decompress(src []byte) ([]byte, error) {
	r, err := zlib.NewReader(bytes.NewReader(src))
	if err != nil {
		return nil, err
	}
	defer r.Close()
	return io.ReadAll(r)
}
