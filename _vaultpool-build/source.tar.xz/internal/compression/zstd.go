//go:build !offline

package compression

import "github.com/klauspost/compress/zstd"

type Zstd struct {
	enc *zstd.Encoder
	dec *zstd.Decoder
}

func New() (*Zstd, error) {
	enc, err := zstd.NewWriter(nil,
		zstd.WithEncoderLevel(zstd.SpeedDefault),
		zstd.WithEncoderCRC(true),
	)
	if err != nil {
		return nil, err
	}
	dec, err := zstd.NewReader(nil,
		zstd.WithDecoderConcurrency(1),
		zstd.WithDecoderLowmem(true),
	)
	if err != nil {
		enc.Close()
		return nil, err
	}
	return &Zstd{enc: enc, dec: dec}, nil
}

func (z *Zstd) Name() string { return "zstd" }

func (z *Zstd) TryCompress(src []byte) ([]byte, bool, error) {
	encoded := z.enc.EncodeAll(src, nil)
	if len(encoded) < len(src) {
		return encoded, true, nil
	}
	out := make([]byte, len(src))
	copy(out, src)
	return out, false, nil
}

func (z *Zstd) Decompress(src []byte) ([]byte, error) {
	return z.dec.DecodeAll(src, nil)
}

func (z *Zstd) Close() {
	z.enc.Close()
	z.dec.Close()
}
