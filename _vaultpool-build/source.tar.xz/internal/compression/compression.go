package compression

// Codec compresses/decompresses independent VaultPool logical blocks.
type Codec interface {
	Name() string
	TryCompress(src []byte) (stored []byte, compressed bool, err error)
	Decompress(src []byte) ([]byte, error)
}
