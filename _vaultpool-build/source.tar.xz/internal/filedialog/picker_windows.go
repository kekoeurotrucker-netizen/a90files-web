//go:build windows

package filedialog

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	comdlg32                 = syscall.NewLazyDLL("comdlg32.dll")
	shell32                  = syscall.NewLazyDLL("shell32.dll")
	ole32                    = syscall.NewLazyDLL("ole32.dll")
	procGetOpenFileNameW     = comdlg32.NewProc("GetOpenFileNameW")
	procGetSaveFileNameW     = comdlg32.NewProc("GetSaveFileNameW")
	procCommDlgExtendedError = comdlg32.NewProc("CommDlgExtendedError")
	procSHBrowseForFolderW   = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPathFromIDListW = shell32.NewProc("SHGetPathFromIDListW")
	procCoTaskMemFree        = ole32.NewProc("CoTaskMemFree")
	user32                   = syscall.NewLazyDLL("user32.dll")
	procGetForegroundWindow  = user32.NewProc("GetForegroundWindow")
)

const (
	ofnOverwritePrompt = 0x00000002
	ofnHideReadOnly    = 0x00000004
	ofnNoChangeDir     = 0x00000008
	ofnPathMustExist   = 0x00000800
	ofnFileMustExist   = 0x00001000
	ofnExplorer        = 0x00080000
	ofnDontAddToRecent = 0x02000000
	maxDialogPathChars = 32768
	createNoWindow     = 0x08000000
	helperTimeout      = 90 * time.Second
)

const (
	bifReturnOnlyFSDirs = 0x0001
	bifNewDialogStyle   = 0x0040
)

type openFileNameW struct {
	StructSize      uint32
	Owner           uintptr
	Instance        uintptr
	Filter          *uint16
	CustomFilter    *uint16
	MaxCustomFilter uint32
	FilterIndex     uint32
	File            *uint16
	MaxFile         uint32
	FileTitle       *uint16
	MaxFileTitle    uint32
	InitialDir      *uint16
	Title           *uint16
	Flags           uint32
	FileOffset      uint16
	FileExtension   uint16
	DefaultExt      *uint16
	CustData        uintptr
	Hook            uintptr
	TemplateName    *uint16
	Reserved        uintptr
	Reserved2       uint32
	FlagsEx         uint32
}

type systemBackend struct{}
type nativeBackend struct{}

type browseInfoW struct {
	Owner        uintptr
	Root         uintptr
	DisplayName  *uint16
	Title        *uint16
	Flags        uint32
	Callback     uintptr
	CallbackData uintptr
	Image        int
}

type helperResult struct {
	Path     string `json:"path,omitempty"`
	Selected bool   `json:"selected"`
	Error    string `json:"error,omitempty"`
}

// Windows common dialogs load Explorer shell extensions. VaultPool therefore
// opens them only in a short-lived helper process that can be killed on timeout;
// the long-lived UI service never calls GetOpenFileNameW/GetSaveFileNameW in
// its own process.
func (systemBackend) Supported() bool {
	exe, err := os.Executable()
	if err != nil || strings.TrimSpace(exe) == "" {
		return false
	}
	base := strings.ToLower(filepath.Base(exe))
	return !strings.HasSuffix(base, ".test.exe")
}

func helperSysProcAttr() *syscall.SysProcAttr {
	return &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
}

func runHelper(kind, suggestedName string) (string, bool, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", false, fmt.Errorf("locate dialog helper: %w", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), helperTimeout)
	defer cancel()
	args := []string{HelperCommand, "-kind", kind}
	if strings.TrimSpace(suggestedName) != "" {
		args = append(args, "-suggested-name", suggestedName)
	}
	cmd := exec.CommandContext(ctx, exe, args...)
	cmd.SysProcAttr = helperSysProcAttr()
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if errors.Is(ctx.Err(), context.DeadlineExceeded) {
		return "", false, fmt.Errorf("%w after %s; VaultPool closed the isolated Windows selector helper", ErrTimedOut, helperTimeout)
	}
	if err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		return "", false, fmt.Errorf("isolated Windows selector helper failed: %s", msg)
	}
	var result helperResult
	if err := json.Unmarshal(out, &result); err != nil {
		return "", false, fmt.Errorf("invalid response from isolated Windows selector helper: %w", err)
	}
	if result.Error != "" {
		return "", false, errors.New(result.Error)
	}
	return result.Path, result.Selected, nil
}

func utf16z(s string) ([]uint16, error) {
	return syscall.UTF16FromString(s)
}

func commonFilter() []uint16 {
	// OPENFILENAME filters are pairs of NUL-terminated strings followed by an
	// extra NUL. This keeps selection broad; VaultPool protects arbitrary files.
	return windowsFilterUTF16("Todos los archivos (*.*)", "*.*")
}

func executableFilter() []uint16 {
	return windowsFilterUTF16("Ejecutables de Windows (*.exe)", "*.exe")
}

func foregroundWindow() uintptr {
	hwnd, _, _ := procGetForegroundWindow.Call()
	return hwnd
}

func dialogError() error {
	code, _, _ := procCommDlgExtendedError.Call()
	if code == 0 {
		return nil // user canceled
	}
	return fmt.Errorf("Windows common dialog error 0x%X", code)
}

func runDialog(save bool, suggestedName, titleOverride string, filterOverride []uint16) (string, bool, error) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	fileBuf := make([]uint16, maxDialogPathChars)
	if save && suggestedName != "" {
		name, err := utf16z(suggestedName)
		if err != nil {
			return "", false, err
		}
		if len(name) > len(fileBuf) {
			return "", false, fmt.Errorf("suggested filename is too long")
		}
		copy(fileBuf, name)
	}
	filter := filterOverride
	if len(filter) == 0 {
		filter = commonFilter()
	}
	titleText := "Selecciona un archivo para proteger con VaultPool"
	if titleOverride != "" {
		titleText = titleOverride
	}
	flags := uint32(ofnExplorer | ofnNoChangeDir | ofnPathMustExist | ofnDontAddToRecent | ofnHideReadOnly)
	proc := procGetOpenFileNameW
	if save {
		if titleOverride == "" {
			titleText = "Elige dónde recuperar el archivo de VaultPool"
		}
		flags |= ofnOverwritePrompt
		proc = procGetSaveFileNameW
	} else {
		flags |= ofnFileMustExist
	}
	title, err := utf16z(titleText)
	if err != nil {
		return "", false, err
	}

	ofn := openFileNameW{
		Owner:       foregroundWindow(),
		Filter:      &filter[0],
		FilterIndex: 1,
		File:        &fileBuf[0],
		MaxFile:     uint32(len(fileBuf)),
		Title:       &title[0],
		Flags:       flags,
	}
	ofn.StructSize = uint32(unsafe.Sizeof(ofn))
	ret, _, callErr := proc.Call(uintptr(unsafe.Pointer(&ofn)))
	if ret == 0 {
		if err := dialogError(); err != nil {
			return "", false, err
		}
		_ = callErr // Windows returns a meaningless syscall errno on dialog cancel.
		return "", false, nil
	}
	return syscall.UTF16ToString(fileBuf), true, nil
}

func (nativeBackend) Supported() bool { return true }

func (nativeBackend) OpenFile() (string, bool, error) {
	return runDialog(false, "", "", nil)
}
func (nativeBackend) OpenDirectory() (string, bool, error) {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	display := make([]uint16, maxDialogPathChars)
	title, err := utf16z("Selecciona una carpeta para proteger con VaultPool")
	if err != nil {
		return "", false, err
	}
	info := browseInfoW{Owner: foregroundWindow(), DisplayName: &display[0], Title: &title[0], Flags: bifReturnOnlyFSDirs | bifNewDialogStyle}
	pidl, _, _ := procSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&info)))
	if pidl == 0 {
		return "", false, nil
	}
	defer procCoTaskMemFree.Call(pidl)
	if ok, _, _ := procSHGetPathFromIDListW.Call(pidl, uintptr(unsafe.Pointer(&display[0]))); ok == 0 {
		return "", false, errors.New("Windows no devolvió la ruta de la carpeta")
	}
	path := syscall.UTF16ToString(display)
	if strings.TrimSpace(path) == "" {
		return "", false, errors.New("Windows devolvió una carpeta vacía")
	}
	return path, true, nil
}
func (nativeBackend) OpenExecutable() (string, bool, error) {
	return runDialog(false, "", "Selecciona el ejecutable del navegador para VaultPool", executableFilter())
}
func (nativeBackend) SaveFile(suggestedName string) (string, bool, error) {
	return runDialog(true, suggestedName, "", nil)
}

func (systemBackend) OpenFile() (string, bool, error) {
	return runHelper("open-file", "")
}
func (systemBackend) OpenDirectory() (string, bool, error) {
	return runHelper("open-directory", "")
}
func (systemBackend) OpenExecutable() (string, bool, error) {
	return runHelper("open-executable", "")
}
func (systemBackend) SaveFile(suggestedName string) (string, bool, error) {
	return runHelper("save-file", suggestedName)
}

func RunHelper(args []string, stdout, stderr io.Writer) int {
	kind, suggestedName, ok := parseHelperArgs(args, stderr)
	if !ok {
		return 2
	}
	backend := nativeBackend{}
	var (
		path     string
		selected bool
		err      error
	)
	switch kind {
	case "open-file":
		path, selected, err = backend.OpenFile()
	case "open-directory":
		path, selected, err = backend.OpenDirectory()
	case "open-executable":
		path, selected, err = backend.OpenExecutable()
	case "save-file":
		path, selected, err = backend.SaveFile(suggestedName)
	default:
		fmt.Fprintf(stderr, "unsupported dialog helper kind %q\n", kind)
		return 2
	}
	result := helperResult{Path: path, Selected: selected}
	if err != nil {
		result.Error = err.Error()
	}
	if encodeErr := json.NewEncoder(stdout).Encode(result); encodeErr != nil {
		fmt.Fprintf(stderr, "encode dialog helper result: %v\n", encodeErr)
		return 1
	}
	return 0
}

func parseHelperArgs(args []string, stderr io.Writer) (kind string, suggestedName string, ok bool) {
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-kind":
			i++
			if i >= len(args) {
				fmt.Fprintln(stderr, "missing value for -kind")
				return "", "", false
			}
			kind = strings.TrimSpace(args[i])
		case "-suggested-name":
			i++
			if i >= len(args) {
				fmt.Fprintln(stderr, "missing value for -suggested-name")
				return "", "", false
			}
			suggestedName = strings.TrimSpace(args[i])
		default:
			fmt.Fprintf(stderr, "unknown dialog helper argument %q\n", args[i])
			return "", "", false
		}
	}
	if kind == "" {
		fmt.Fprintln(stderr, "missing -kind")
		return "", "", false
	}
	return kind, suggestedName, true
}
