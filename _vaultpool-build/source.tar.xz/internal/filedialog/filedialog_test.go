package filedialog

import (
	"errors"
	"sync"
	"testing"
	"time"
)

type fakeBackend struct {
	supported bool
	openPath  string
	savePath  string
	err       error
	mu        sync.Mutex
	active    int
	maxActive int
}

func (f *fakeBackend) Supported() bool { return f.supported }
func (f *fakeBackend) enter() {
	f.mu.Lock()
	f.active++
	if f.active > f.maxActive {
		f.maxActive = f.active
	}
	f.mu.Unlock()
	time.Sleep(10 * time.Millisecond)
	f.mu.Lock()
	f.active--
	f.mu.Unlock()
}
func (f *fakeBackend) OpenFile() (string, bool, error) {
	f.enter()
	return f.openPath, f.openPath != "", f.err
}
func (f *fakeBackend) OpenExecutable() (string, bool, error) {
	f.enter()
	return f.openPath, f.openPath != "", f.err
}
func (f *fakeBackend) SaveFile(string) (string, bool, error) {
	f.enter()
	return f.savePath, f.savePath != "", f.err
}

func TestServiceReturnsSelectedPathsAndSerializesDialogs(t *testing.T) {
	b := &fakeBackend{supported: true, openPath: `C:\input.bin`, savePath: `C:\output.bin`}
	s := New(b)
	var wg sync.WaitGroup
	wg.Add(2)
	errs := make(chan error, 2)
	go func() { defer wg.Done(); _, _, err := s.OpenFile(); errs <- err }()
	go func() { defer wg.Done(); _, _, err := s.SaveFile("x.bin"); errs <- err }()
	wg.Wait()
	close(errs)
	busy := 0
	for err := range errs {
		if errors.Is(err, ErrBusy) {
			busy++
		}
	}
	if b.maxActive != 1 || busy != 1 {
		t.Fatalf("native dialog overlap protection failed: max active=%d busy=%d", b.maxActive, busy)
	}
	p, ok, err := s.OpenFile()
	if err != nil || !ok || p != `C:\input.bin` {
		t.Fatalf("open=%q selected=%v err=%v", p, ok, err)
	}
}

func TestUnsupportedAndBackendError(t *testing.T) {
	if _, _, err := New(&fakeBackend{}).OpenFile(); !errors.Is(err, ErrUnsupported) {
		t.Fatalf("unsupported error=%v", err)
	}
	want := errors.New("boom")
	if _, _, err := New(&fakeBackend{supported: true, err: want}).OpenFile(); !errors.Is(err, want) {
		t.Fatalf("backend error=%v", err)
	}
}

func TestWindowsFilterUTF16HasRequiredDoubleNULTerminator(t *testing.T) {
	f := windowsFilterUTF16("Todos", "*.*")
	if len(f) < 4 || f[len(f)-1] != 0 || f[len(f)-2] != 0 {
		t.Fatalf("filter lacks double NUL terminator: %v", f)
	}
	zeros := 0
	for _, v := range f {
		if v == 0 {
			zeros++
		}
	}
	if zeros != 3 {
		t.Fatalf("filter must contain label separator + double terminator, zeros=%d", zeros)
	}
}
