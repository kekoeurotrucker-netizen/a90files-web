package filedialog

import (
	"errors"
	"strings"
	"sync"
	"unicode/utf16"
)

var ErrUnsupported = errors.New("native file dialog is not supported on this platform")
var ErrBusy = errors.New("another native file dialog is already open")
var ErrTimedOut = errors.New("native file dialog timed out")

// HelperCommand is an internal CLI command used by the Windows UI service to
// open shell-backed dialogs outside the long-lived VaultPool process.
const HelperCommand = "__dialog-helper"

func windowsFilterUTF16(label, pattern string) []uint16 {
	// Win32 OPENFILENAME expects: label NUL pattern NUL NUL. This cannot be
	// built with syscall.UTF16FromString because that helper correctly rejects
	// embedded NULs.
	return utf16.Encode([]rune(label + "\x00" + pattern + "\x00\x00"))
}

// Backend is the minimal OS-specific surface. It deliberately returns only a
// path selected by the user; VaultPool never asks the browser to upload file
// contents merely to discover a local path.
type Backend interface {
	Supported() bool
	OpenFile() (path string, selected bool, err error)
	OpenExecutable() (path string, selected bool, err error)
	SaveFile(suggestedName string) (path string, selected bool, err error)
}

type directoryBackend interface {
	OpenDirectory() (path string, selected bool, err error)
}

// Service serializes native dialogs. Opening multiple common dialogs from
// concurrent HTTP requests is confusing and can create ambiguous user intent.
type Service struct {
	mu      sync.Mutex
	backend Backend
}

func NewSystem() *Service { return New(systemBackend{}) }

func New(backend Backend) *Service {
	return &Service{backend: backend}
}

func (s *Service) Supported() bool {
	return s != nil && s.backend != nil && s.backend.Supported()
}

func (s *Service) withDialog(fn func() (string, bool, error)) (string, bool, error) {
	if !s.Supported() {
		return "", false, ErrUnsupported
	}
	// Never queue a second modal dialog behind one that may already be hidden
	// behind the desktop shell. Queuing here made the UI look frozen after a
	// timed-out browser request while the first Windows dialog was still alive.
	if !s.mu.TryLock() {
		return "", false, ErrBusy
	}
	defer s.mu.Unlock()
	path, selected, err := fn()
	if err != nil || !selected {
		return "", selected, err
	}
	path = strings.TrimSpace(path)
	if path == "" {
		return "", false, errors.New("native file dialog returned an empty path")
	}
	return path, true, nil
}

func (s *Service) OpenFile() (string, bool, error) {
	return s.withDialog(s.backend.OpenFile)
}

func (s *Service) OpenDirectory() (string, bool, error) {
	directory, ok := s.backend.(directoryBackend)
	if !ok {
		return "", false, ErrUnsupported
	}
	return s.withDialog(directory.OpenDirectory)
}

func (s *Service) OpenExecutable() (string, bool, error) {
	return s.withDialog(s.backend.OpenExecutable)
}

func (s *Service) SaveFile(suggestedName string) (string, bool, error) {
	return s.withDialog(func() (string, bool, error) {
		return s.backend.SaveFile(strings.TrimSpace(suggestedName))
	})
}
