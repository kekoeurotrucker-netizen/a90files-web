//go:build !windows

package filedialog

import (
	"fmt"
	"io"
)

type systemBackend struct{}

func (systemBackend) Supported() bool { return false }
func (systemBackend) OpenFile() (string, bool, error) {
	return "", false, ErrUnsupported
}
func (systemBackend) OpenDirectory() (string, bool, error) {
	return "", false, ErrUnsupported
}
func (systemBackend) OpenExecutable() (string, bool, error) {
	return "", false, ErrUnsupported
}
func (systemBackend) SaveFile(string) (string, bool, error) {
	return "", false, ErrUnsupported
}

func RunHelper(_ []string, _ io.Writer, stderr io.Writer) int {
	fmt.Fprintln(stderr, ErrUnsupported)
	return 1
}
