//go:build windows

package filedialog

import (
	"bytes"
	"testing"
)

func TestDialogHelperRejectsInvalidArgumentsWithoutOpeningDialog(t *testing.T) {
	var stdout, stderr bytes.Buffer
	if code := RunHelper([]string{"-kind", "unknown"}, &stdout, &stderr); code != 2 {
		t.Fatalf("invalid helper kind exit code=%d stdout=%q stderr=%q", code, stdout.String(), stderr.String())
	}
	if stdout.Len() != 0 {
		t.Fatalf("invalid helper must not emit a successful JSON response: %q", stdout.String())
	}

	stdout.Reset()
	stderr.Reset()
	kind, suggested, ok := parseHelperArgs([]string{"-kind", "save-file", "-suggested-name", "movie.mkv"}, &stderr)
	if !ok || kind != "save-file" || suggested != "movie.mkv" {
		t.Fatalf("parse helper args kind=%q suggested=%q ok=%v stderr=%q", kind, suggested, ok, stderr.String())
	}
}
