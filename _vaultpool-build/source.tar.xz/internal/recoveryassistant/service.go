package recoveryassistant

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
	"github.com/vaultpool-project/vaultpool/internal/recoveryrecords"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type TargetResolver func(context.Context) ([]storage.Target, error)

type Vault interface {
	ListMetadata() ([]secretvault.Metadata, error)
	Get(string, secretvault.Kind) ([]byte, bool, error)
}

type KeyRestorer interface {
	RestoreFileKeys(context.Context, []storage.Target) (recoveryrecords.RestoreReport, error)
}

type Catalog interface {
	Get(string) (managedfiles.Metadata, bool, error)
	ImportRecoveredManifestBytesContext(context.Context, []byte, []byte) (managedfiles.Metadata, error)
}

type Warning struct {
	Stage    string `json:"stage"`
	TargetID string `json:"target_id,omitempty"`
	FileID   string `json:"file_id,omitempty"`
	Message  string `json:"message"`
}

type FileResult struct {
	FileID     string `json:"file_id"`
	FileName   string `json:"file_name"`
	Generation uint64 `json:"generation"`
	Replicas   int    `json:"manifest_replicas"`
	Status     string `json:"status"`
}

type Report struct {
	StartedAt           time.Time    `json:"started_at"`
	CompletedAt         time.Time    `json:"completed_at"`
	KnownTargets        int          `json:"known_targets"`
	OnlineTargets       int          `json:"online_targets"`
	OnlineDomains       int          `json:"online_provider_domains"`
	KeysRecovered       int          `json:"keys_recovered"`
	KeysAlreadyPresent  int          `json:"keys_already_present"`
	KeysAvailable       int          `json:"keys_available"`
	ManifestsFound      int          `json:"manifests_found"`
	FilesRestored       int          `json:"files_restored"`
	FilesUpdated        int          `json:"files_updated"`
	FilesAlreadyKnown   int          `json:"files_already_known"`
	FilesFailed         int          `json:"files_failed"`
	HealthAuditsPending int          `json:"health_audits_pending"`
	NeedsReview         bool         `json:"needs_review"`
	Files               []FileResult `json:"files,omitempty"`
	Warnings            []Warning    `json:"warnings,omitempty"`
}

type Service struct {
	vault   Vault
	keys    KeyRestorer
	engine  *core.Engine
	files   Catalog
	targets TargetResolver
}

func New(vault Vault, keys KeyRestorer, engine *core.Engine, files Catalog, targets TargetResolver) (*Service, error) {
	if vault == nil || keys == nil || engine == nil || files == nil || targets == nil {
		return nil, errors.New("recovery assistant requires vault, key recovery, engine, catalog and target resolver")
	}
	return &Service{vault: vault, keys: keys, engine: engine, files: files, targets: targets}, nil
}

func validFileID(id string) bool {
	if len(id) != 32 {
		return false
	}
	_, err := hex.DecodeString(id)
	return err == nil
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func onlineDomainCount(targets []storage.Target) int {
	seen := map[string]bool{}
	for _, t := range targets {
		if t.Enabled && strings.TrimSpace(t.FailureDomain) != "" {
			seen[t.FailureDomain] = true
		}
	}
	return len(seen)
}

func (s *Service) recoveredKeys() (map[string][]byte, error) {
	meta, err := s.vault.ListMetadata()
	if err != nil {
		return nil, err
	}
	keys := map[string][]byte{}
	for _, item := range meta {
		if item.Kind != secretvault.FileDataKey || !validFileID(item.AccountID) {
			continue
		}
		id := strings.ToLower(item.AccountID)
		if _, exists := keys[id]; exists {
			continue
		}
		key, ok, err := s.vault.Get(id, secretvault.FileDataKey)
		if err != nil {
			for _, b := range keys {
				zero(b)
			}
			return nil, err
		}
		if !ok || len(key) != cryptokit.KeySize {
			zero(key)
			continue
		}
		keys[id] = key
	}
	return keys, nil
}

// RebuildCatalog performs only the small-metadata phase of disaster recovery:
// authenticated file-key records -> authenticated manifests -> private local
// catalog. It deliberately does not download/audit all data shards. Large data
// health checks stay explicit so recovery cannot accidentally hammer provider
// APIs or transfer quotas just by opening the assistant.
func (s *Service) RebuildCatalog(ctx context.Context) (report Report, err error) {
	report = Report{StartedAt: time.Now().UTC()}
	defer func() { report.CompletedAt = time.Now().UTC() }()

	targets, err := s.targets(ctx)
	if err != nil {
		return report, fmt.Errorf("resolve recovery targets: %w", err)
	}
	report.KnownTargets = len(targets)
	for _, t := range targets {
		if t.Enabled {
			report.OnlineTargets++
		}
	}
	report.OnlineDomains = onlineDomainCount(targets)

	keyReport, err := s.keys.RestoreFileKeys(ctx, targets)
	if err != nil {
		return report, fmt.Errorf("restore authenticated file keys: %w", err)
	}
	report.KeysRecovered = len(keyReport.Recovered)
	report.KeysAlreadyPresent = len(keyReport.Existing)
	for _, w := range keyReport.Warnings {
		report.Warnings = append(report.Warnings, Warning{Stage: "file-keys", TargetID: w.TargetID, Message: w.Error})
	}

	keys, err := s.recoveredKeys()
	if err != nil {
		return report, fmt.Errorf("enumerate recovered file keys: %w", err)
	}
	defer func() {
		for _, b := range keys {
			zero(b)
		}
	}()
	report.KeysAvailable = len(keys)
	if len(keys) == 0 {
		report.NeedsReview = true
		report.Warnings = append(report.Warnings, Warning{Stage: "file-keys", Message: "No se encontró ninguna clave de archivo autenticada. Reconecta las cuentas que contienen registros de recuperación y vuelve a intentarlo."})
		return report, nil
	}

	scan, err := s.engine.DiscoverRecoverableTargetManifestsByKeys(ctx, keys, targets)
	if err != nil {
		return report, fmt.Errorf("discover authenticated manifests: %w", err)
	}
	for _, issue := range scan.Issues {
		report.Warnings = append(report.Warnings, Warning{Stage: "manifests-" + issue.Stage, TargetID: issue.TargetID, Message: issue.Message})
	}
	report.ManifestsFound = len(scan.Candidates)

	for _, candidate := range scan.Candidates {
		if err := ctx.Err(); err != nil {
			return report, err
		}
		key, ok := keys[strings.ToLower(candidate.FileID)]
		if !ok {
			report.FilesFailed++
			report.Warnings = append(report.Warnings, Warning{Stage: "catalog", FileID: candidate.FileID, Message: "manifiesto autenticado sin clave local recuperada"})
			continue
		}
		before, existed, beforeErr := s.files.Get(candidate.FileID)
		if beforeErr != nil {
			report.FilesFailed++
			report.Warnings = append(report.Warnings, Warning{Stage: "catalog", FileID: candidate.FileID, Message: beforeErr.Error()})
			continue
		}
		meta, importErr := s.files.ImportRecoveredManifestBytesContext(ctx, candidate.SealedManifestCopy(), key)
		if importErr != nil {
			report.FilesFailed++
			report.Warnings = append(report.Warnings, Warning{Stage: "catalog", FileID: candidate.FileID, Message: importErr.Error()})
			continue
		}
		status := "restored"
		if existed {
			if meta.Generation > before.Generation {
				status = "updated"
				report.FilesUpdated++
			} else {
				status = "already_known"
				report.FilesAlreadyKnown++
			}
		} else {
			report.FilesRestored++
		}
		report.Files = append(report.Files, FileResult{FileID: meta.FileID, FileName: meta.FileName, Generation: meta.Generation, Replicas: candidate.Replicas, Status: status})
	}

	sort.Slice(report.Files, func(i, j int) bool {
		if report.Files[i].FileName == report.Files[j].FileName {
			return report.Files[i].FileID < report.Files[j].FileID
		}
		return report.Files[i].FileName < report.Files[j].FileName
	})
	report.HealthAuditsPending = report.FilesRestored + report.FilesUpdated + report.FilesAlreadyKnown
	report.NeedsReview = report.FilesFailed > 0 || len(report.Warnings) > 0 || report.OnlineTargets < report.KnownTargets
	return report, nil
}
