package recoveryassistant

import (
	"bytes"
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/recoveryrecords"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type testProtector struct{ k byte }

func (p testProtector) Name() string { return "recoveryassistant-test" }
func (p testProtector) Protect(in []byte) ([]byte, error) {
	out := append([]byte(nil), in...)
	for i := range out {
		out[i] ^= p.k
	}
	return out, nil
}
func (p testProtector) Unprotect(in []byte) ([]byte, error) { return p.Protect(in) }

func zeroBytes(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func makeRecoveryFixture(t *testing.T) (*Service, *managedfiles.Manager, *secretvault.Vault, *core.Engine, []storage.Target, []string) {
	t.Helper()
	dir := t.TempDir()
	pool := filepath.Join(dir, "pool")
	for i := 0; i < 6; i++ {
		if err := os.MkdirAll(filepath.Join(pool, "provider-"+string(rune('a'+i))), 0o700); err != nil {
			t.Fatal(err)
		}
	}
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}

	packagePath := filepath.Join(dir, "external", "VaultPool-Recovery.vpr")
	sourceVault, err := secretvault.Open(filepath.Join(dir, "source.vpv"), testProtector{0x31})
	if err != nil {
		t.Fatal(err)
	}
	code, err := sourceVault.ConfigurePortableRecovery(packagePath)
	if err != nil {
		t.Fatal(err)
	}
	if err := sourceVault.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}

	engine, err := core.New(core.DefaultConfig())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(engine.Close)
	sourceRecords, err := recoveryrecords.New(sourceVault, 2)
	if err != nil {
		t.Fatal(err)
	}

	var ids []string
	for i, payload := range [][]byte{
		bytes.Repeat([]byte("vaultpool-recovery-one\n"), 12000),
		bytes.Repeat([]byte("vaultpool-recovery-two\n"), 9000),
	} {
		in := filepath.Join(dir, "input-"+string(rune('a'+i))+".bin")
		if err := os.WriteFile(in, payload, 0o600); err != nil {
			t.Fatal(err)
		}
		key, err := cryptokit.GenerateKey()
		if err != nil {
			t.Fatal(err)
		}
		mf := filepath.Join(dir, "source-"+string(rune('a'+i))+".vpm")
		if err := engine.PackTargets(context.Background(), in, mf, key, targets); err != nil {
			zeroBytes(key)
			t.Fatal(err)
		}
		m, err := manifest.Load(mf, key)
		if err != nil {
			zeroBytes(key)
			t.Fatal(err)
		}
		if _, err := sourceRecords.ReplicateFileKey(context.Background(), m.FileID, key, targets); err != nil {
			zeroBytes(key)
			t.Fatal(err)
		}
		ids = append(ids, m.FileID)
		zeroBytes(key)
	}
	sourceVault.Close()

	// Simulate a clean reinstall: restore only the external kit. It predates all
	// file keys, so M0.14 records and remote manifests must rebuild the catalog.
	restoredVault, err := secretvault.RestoreFromRecovery(packagePath, code, filepath.Join(dir, "new", "secrets.vpv"), testProtector{0x77})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(restoredVault.Close)
	restoredRecords, err := recoveryrecords.New(restoredVault, 2)
	if err != nil {
		t.Fatal(err)
	}
	resolver := func(context.Context) ([]storage.Target, error) { return append([]storage.Target(nil), targets...), nil }
	mgr, err := managedfiles.New(filepath.Join(dir, "new", "files"), restoredVault, engine, resolver, restoredRecords)
	if err != nil {
		t.Fatal(err)
	}
	svc, err := New(restoredVault, restoredRecords, engine, mgr, resolver)
	if err != nil {
		t.Fatal(err)
	}
	return svc, mgr, restoredVault, engine, targets, ids
}

func TestRebuildCatalogFromOldKitAndRemoteRecoveryRecords(t *testing.T) {
	svc, mgr, _, _, _, ids := makeRecoveryFixture(t)
	r, err := svc.RebuildCatalog(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if r.KeysRecovered != 2 || r.KeysAvailable != 2 || r.ManifestsFound != 2 || r.FilesRestored != 2 || r.FilesFailed != 0 {
		t.Fatalf("unexpected report: %+v", r)
	}
	if r.CompletedAt.IsZero() || !r.CompletedAt.After(r.StartedAt) {
		t.Fatalf("report timestamps incomplete: %+v", r)
	}
	items, err := mgr.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 2 {
		t.Fatalf("catalog size=%d want 2: %+v", len(items), items)
	}
	seen := map[string]bool{}
	for _, item := range items {
		seen[item.FileID] = true
	}
	for _, id := range ids {
		if !seen[id] {
			t.Fatalf("recovered catalog missing %s", id)
		}
	}
}

func TestRebuildCatalogSurvivesOneProviderLoss(t *testing.T) {
	svc, _, _, _, targets, _ := makeRecoveryFixture(t)
	// Simulate the real application state for an account/provider outage: the
	// target remains known so old manifests can still reference it, but it is
	// disabled and must not be contacted during recovery.
	targets[0].Enabled = false
	svc.targets = func(context.Context) ([]storage.Target, error) {
		return append([]storage.Target(nil), targets...), nil
	}
	r, err := svc.RebuildCatalog(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if r.FilesRestored != 2 || r.FilesFailed != 0 {
		t.Fatalf("provider-loss recovery failed: %+v", r)
	}
	if r.OnlineTargets != len(targets)-1 || !r.NeedsReview {
		t.Fatalf("disabled provider was not reflected in recovery status: %+v", r)
	}
}
