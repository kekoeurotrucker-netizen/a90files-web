package transfers

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
	"testing"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
)

type fakeManager struct {
	mu           sync.Mutex
	uploadBlock  chan struct{}
	restoreBlock chan struct{}
	uploadErr    error
	restoreErr   error
}

func (f *fakeManager) AddPath(ctx context.Context, path string, progress core.ProgressFunc) (managedfiles.Metadata, error) {
	metrics := core.TransferProgress{OriginalBytes: 100, StoredBytes: 75, EncryptedBytes: 103, DistributedBytes: 206}
	metrics.Phase = "recovering"
	progress(metrics)
	metrics.Phase = "preflight"
	progress(metrics)
	metrics.Phase = "compressing"
	progress(metrics)
	metrics.Phase = "encrypting"
	progress(metrics)
	metrics.Phase = "fragmenting"
	progress(metrics)
	metrics.Phase = "uploading"
	metrics.BlocksDone, metrics.BlocksTotal = 1, 2
	metrics.BytesProcessed, metrics.BytesTotal = 50, 100
	progress(metrics)
	if f.uploadBlock != nil {
		select {
		case <-ctx.Done():
			return managedfiles.Metadata{}, ctx.Err()
		case <-f.uploadBlock:
		}
	}
	if f.uploadErr != nil {
		return managedfiles.Metadata{}, f.uploadErr
	}
	metrics.Phase = "complete"
	metrics.BlocksDone, metrics.BytesProcessed = 2, 100
	progress(metrics)
	return managedfiles.Metadata{FileID: "00112233445566778899aabbccddeeff", FileName: "a.bin"}, nil
}

func (f *fakeManager) RestoreToPath(ctx context.Context, fileID, out string, progress core.ProgressFunc) error {
	progress(core.TransferProgress{Phase: "restoring", BlocksDone: 1, BlocksTotal: 1, BytesProcessed: 10, BytesTotal: 10})
	if f.restoreBlock != nil {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-f.restoreBlock:
		}
	}
	return f.restoreErr
}

func waitFinished(t *testing.T, s *Service, id string) Job {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		j, ok := s.Get(id)
		if !ok {
			t.Fatal("job disappeared")
		}
		if j.State == Completed || j.State == Failed || j.State == Canceled {
			return j
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal("job did not finish")
	return Job{}
}

func TestUploadCompletesAndExposesOnlySanitizedJob(t *testing.T) {
	s, err := New(&fakeManager{})
	if err != nil {
		t.Fatal(err)
	}
	j, err := s.StartUpload("/secret/private/a.bin")
	if err != nil {
		t.Fatal(err)
	}
	j = waitFinished(t, s, j.ID)
	if j.State != Completed || j.FileID == "" || j.BytesProcessed != 100 || j.BytesTotal != 100 {
		t.Fatalf("unexpected completed job: %+v", j)
	}
	if j.UploadReport == nil || j.UploadReport.StoredBytes != 75 || j.UploadReport.CompressionSavingsBytes != 25 || j.UploadReport.DistributedBytes != 206 {
		t.Fatalf("unexpected upload report: %+v", j.UploadReport)
	}
	b, err := json.Marshal(j)
	if err != nil {
		t.Fatal(err)
	}
	if string(b) == "" || contains(string(b), "/secret/private") {
		t.Fatalf("private path leaked in public job JSON: %s", b)
	}
}

func TestCancelUploadCancelsContext(t *testing.T) {
	f := &fakeManager{uploadBlock: make(chan struct{})}
	s, _ := New(f)
	j, err := s.StartUpload("/tmp/a.bin")
	if err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		cur, _ := s.Get(j.ID)
		if cur.State == Running {
			break
		}
		time.Sleep(2 * time.Millisecond)
	}
	if _, err := s.Cancel(j.ID); err != nil {
		t.Fatal(err)
	}
	j = waitFinished(t, s, j.ID)
	if j.State != Canceled || j.Error != "" {
		t.Fatalf("cancel result: %+v", j)
	}
}

func TestRestoreFailureIsReported(t *testing.T) {
	s, _ := New(&fakeManager{restoreErr: errors.New("provider unavailable")})
	j, err := s.StartRestore("00112233445566778899aabbccddeeff", "/tmp/out.bin", "out.bin")
	if err != nil {
		t.Fatal(err)
	}
	j = waitFinished(t, s, j.ID)
	if j.State != Failed || j.Error != "provider unavailable" {
		t.Fatalf("unexpected restore failure: %+v", j)
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}

func TestSuccessfulCommitWinsLateCancelRace(t *testing.T) {
	s, _ := New(&fakeManager{})
	id := "00112233445566778899aabbccddeeff"
	s.jobs[id] = &Job{ID: id, Kind: Upload, State: Canceling, Phase: "canceling", CreatedAt: time.Now().UTC()}
	meta := managedfiles.Metadata{FileID: "ffeeddccbbaa99887766554433221100", FileName: "done.bin"}
	s.finish(id, &meta, nil)
	j, ok := s.Get(id)
	if !ok || j.State != Completed || j.FileID != meta.FileID {
		t.Fatalf("successful commit was mislabeled by late cancel: %+v", j)
	}
}

func TestShutdownCancelsActiveTransferAndRejectsNewOnes(t *testing.T) {
	f := &fakeManager{uploadBlock: make(chan struct{})}
	s, _ := New(f)
	j, err := s.StartUpload("/tmp/a.bin")
	if err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		cur, _ := s.Get(j.ID)
		if cur.State == Running {
			break
		}
		time.Sleep(2 * time.Millisecond)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := s.Shutdown(ctx); err != nil {
		t.Fatal(err)
	}
	cur, _ := s.Get(j.ID)
	if cur.State != Canceled {
		t.Fatalf("active transfer not canceled during shutdown: %+v", cur)
	}
	if _, err := s.StartUpload("/tmp/late.bin"); err == nil {
		t.Fatal("shutdown admission gate accepted a new transfer")
	}
}

func TestBeginShutdownClosesAdmissionBeforeCancellationPass(t *testing.T) {
	s, _ := New(&fakeManager{})
	s.BeginShutdown()
	if s.Accepting() {
		t.Fatal("service still reports accepting after BeginShutdown")
	}
	if _, err := s.StartRestore("00112233445566778899aabbccddeeff", "/tmp/out.bin", "out.bin"); err == nil {
		t.Fatal("restore slipped through shutdown admission gate")
	}
}
