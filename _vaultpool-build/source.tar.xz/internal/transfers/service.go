package transfers

import (
	"context"
	"errors"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
)

type Kind string
type State string

const (
	Upload  Kind = "upload"
	Restore Kind = "restore"

	Queued    State = "queued"
	Running   State = "running"
	Canceling State = "canceling"
	Completed State = "completed"
	Failed    State = "failed"
	Canceled  State = "canceled"
)

type FileManager interface {
	AddPath(context.Context, string, core.ProgressFunc) (managedfiles.Metadata, error)
	RestoreToPath(context.Context, string, string, core.ProgressFunc) error
}

type Job struct {
	ID             string        `json:"id"`
	Kind           Kind          `json:"kind"`
	State          State         `json:"state"`
	Phase          string        `json:"phase"`
	Label          string        `json:"label"`
	FileID         string        `json:"file_id,omitempty"`
	BytesProcessed int64         `json:"bytes_processed"`
	BytesTotal     int64         `json:"bytes_total"`
	BlocksDone     int           `json:"blocks_done"`
	BlocksTotal    int           `json:"blocks_total"`
	Error          string        `json:"error,omitempty"`
	CreatedAt      time.Time     `json:"created_at"`
	StartedAt      time.Time     `json:"started_at,omitempty"`
	FinishedAt     time.Time     `json:"finished_at,omitempty"`
	UploadReport   *UploadReport `json:"upload_report,omitempty"`

	inputPath      string
	outputPath     string
	cancel         context.CancelFunc
	phaseStartedAt time.Time
}

// UploadReport contains aggregate transfer measurements. It intentionally
// excludes paths, keys, object locators, and any plaintext-derived content.
type UploadReport struct {
	OriginalBytes           int64            `json:"original_bytes"`
	StoredBytes             int64            `json:"stored_bytes"`
	EncryptedBytes          int64            `json:"encrypted_bytes"`
	DistributedBytes        int64            `json:"distributed_bytes"`
	CompressionSavingsBytes int64            `json:"compression_savings_bytes"`
	PhaseMilliseconds       map[string]int64 `json:"phase_milliseconds"`
	TotalMilliseconds       int64            `json:"total_milliseconds"`
}

type Service struct {
	manager FileManager
	mu      sync.Mutex
	jobs    map[string]*Job
	maxKeep int
	closing bool
	wg      sync.WaitGroup
}

func New(manager FileManager) (*Service, error) {
	if manager == nil {
		return nil, errors.New("managed-file service required")
	}
	return &Service{manager: manager, jobs: map[string]*Job{}, maxKeep: 200}, nil
}

func cloneJob(j *Job) Job {
	if j == nil {
		return Job{}
	}
	c := *j
	if j.UploadReport != nil {
		report := *j.UploadReport
		report.PhaseMilliseconds = make(map[string]int64, len(j.UploadReport.PhaseMilliseconds))
		for phase, elapsed := range j.UploadReport.PhaseMilliseconds {
			report.PhaseMilliseconds[phase] = elapsed
		}
		c.UploadReport = &report
	}
	c.inputPath = ""
	c.outputPath = ""
	c.cancel = nil
	c.phaseStartedAt = time.Time{}
	return c
}

func (s *Service) pruneLocked() {
	if len(s.jobs) < s.maxKeep {
		return
	}
	type item struct {
		id string
		t  time.Time
	}
	var done []item
	for id, j := range s.jobs {
		if j.State == Completed || j.State == Failed || j.State == Canceled {
			done = append(done, item{id: id, t: j.FinishedAt})
		}
	}
	sort.Slice(done, func(i, j int) bool { return done[i].t.Before(done[j].t) })
	for len(s.jobs) >= s.maxKeep && len(done) > 0 {
		delete(s.jobs, done[0].id)
		done = done[1:]
	}
}

func newJobID() (string, error) { return cryptokit.RandomID(16) }

func (s *Service) StartUpload(path string) (Job, error) {
	path = filepath.Clean(strings.TrimSpace(path))
	if path == "." || path == "" {
		return Job{}, errors.New("input path required")
	}
	id, err := newJobID()
	if err != nil {
		return Job{}, err
	}
	s.mu.Lock()
	if s.closing {
		s.mu.Unlock()
		return Job{}, errors.New("VaultPool is shutting down; new transfers are not accepted")
	}
	ctx, cancel := context.WithCancel(context.Background())
	now := time.Now().UTC()
	j := &Job{ID: id, Kind: Upload, State: Queued, Phase: "queued", Label: filepath.Base(path), CreatedAt: now, inputPath: path, cancel: cancel}
	s.pruneLocked()
	s.jobs[id] = j
	s.wg.Add(1)
	out := cloneJob(j)
	s.mu.Unlock()
	go func() {
		defer s.wg.Done()
		s.runUpload(ctx, id)
	}()
	return out, nil
}

func (s *Service) StartRestore(fileID, outPath, label string) (Job, error) {
	fileID = strings.TrimSpace(fileID)
	outPath = filepath.Clean(strings.TrimSpace(outPath))
	if fileID == "" || outPath == "." || outPath == "" {
		return Job{}, errors.New("file id and output path required")
	}
	id, err := newJobID()
	if err != nil {
		return Job{}, err
	}
	if strings.TrimSpace(label) == "" {
		label = filepath.Base(outPath)
	}
	s.mu.Lock()
	if s.closing {
		s.mu.Unlock()
		return Job{}, errors.New("VaultPool is shutting down; new transfers are not accepted")
	}
	ctx, cancel := context.WithCancel(context.Background())
	now := time.Now().UTC()
	j := &Job{ID: id, Kind: Restore, State: Queued, Phase: "queued", Label: label, FileID: fileID, CreatedAt: now, outputPath: outPath, cancel: cancel}
	s.pruneLocked()
	s.jobs[id] = j
	s.wg.Add(1)
	out := cloneJob(j)
	s.mu.Unlock()
	go func() {
		defer s.wg.Done()
		s.runRestore(ctx, id)
	}()
	return out, nil
}

func (s *Service) start(id string) (input, output, fileID string, ok bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j, ok := s.jobs[id]
	if !ok {
		return "", "", "", false
	}
	if j.State == Canceling {
		j.State = Canceled
		j.Phase = "canceled"
		j.FinishedAt = time.Now().UTC()
		return "", "", "", false
	}
	j.State = Running
	j.StartedAt = time.Now().UTC()
	return j.inputPath, j.outputPath, j.FileID, true
}

func (s *Service) progress(id string, p core.TransferProgress) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j, ok := s.jobs[id]
	if !ok || j.State == Completed || j.State == Failed || j.State == Canceled {
		return
	}
	now := time.Now().UTC()
	if j.Kind == Upload {
		if j.UploadReport == nil {
			j.UploadReport = &UploadReport{PhaseMilliseconds: map[string]int64{}}
		}
		if !j.phaseStartedAt.IsZero() && j.Phase != p.Phase {
			j.recordPhaseElapsed(now)
		}
		if j.phaseStartedAt.IsZero() || j.Phase != p.Phase {
			j.phaseStartedAt = now
		}
		j.UploadReport.OriginalBytes = p.OriginalBytes
		j.UploadReport.StoredBytes = p.StoredBytes
		j.UploadReport.EncryptedBytes = p.EncryptedBytes
		j.UploadReport.DistributedBytes = p.DistributedBytes
		if p.OriginalBytes > p.StoredBytes {
			j.UploadReport.CompressionSavingsBytes = p.OriginalBytes - p.StoredBytes
		}
	}
	j.Phase = p.Phase
	j.BytesProcessed = p.BytesProcessed
	j.BytesTotal = p.BytesTotal
	j.BlocksDone = p.BlocksDone
	j.BlocksTotal = p.BlocksTotal
}

func reportableUploadPhase(phase string) bool {
	switch phase {
	case "packaging", "recovering", "preflight", "compressing", "encrypting", "fragmenting", "uploading", "finalizing":
		return true
	default:
		return false
	}
}

func (j *Job) recordPhaseElapsed(now time.Time) {
	if j.UploadReport == nil || j.phaseStartedAt.IsZero() || !reportableUploadPhase(j.Phase) {
		return
	}
	j.UploadReport.PhaseMilliseconds[j.Phase] += now.Sub(j.phaseStartedAt).Milliseconds()
}

func (s *Service) finish(id string, meta *managedfiles.Metadata, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j, ok := s.jobs[id]
	if !ok {
		return
	}
	now := time.Now().UTC()
	j.FinishedAt = now
	j.cancel = nil
	if j.Kind == Upload && j.UploadReport != nil {
		j.recordPhaseElapsed(now)
		j.phaseStartedAt = time.Time{}
		if !j.StartedAt.IsZero() {
			j.UploadReport.TotalMilliseconds = now.Sub(j.StartedAt).Milliseconds()
		}
	}
	if meta != nil {
		j.FileID = meta.FileID
		if strings.TrimSpace(meta.FileName) != "" {
			j.Label = meta.FileName
		}
	}
	// Successful storage state is authoritative. A cancel request that races
	// after the engine has already committed must not relabel durable data as
	// canceled.
	if err == nil {
		j.State = Completed
		j.Phase = "complete"
		j.Error = ""
		if j.BytesTotal > 0 {
			j.BytesProcessed = j.BytesTotal
		}
		return
	}
	if errors.Is(err, context.Canceled) || j.State == Canceling {
		j.State = Canceled
		j.Phase = "canceled"
		j.Error = ""
		return
	}
	j.State = Failed
	j.Phase = "failed"
	j.Error = err.Error()
	return

}

func (s *Service) runUpload(ctx context.Context, id string) {
	input, _, _, ok := s.start(id)
	if !ok {
		return
	}
	meta, err := s.manager.AddPath(ctx, input, func(p core.TransferProgress) { s.progress(id, p) })
	if err != nil {
		s.finish(id, nil, err)
		return
	}
	s.finish(id, &meta, nil)
}

func (s *Service) runRestore(ctx context.Context, id string) {
	_, out, fileID, ok := s.start(id)
	if !ok {
		return
	}
	err := s.manager.RestoreToPath(ctx, fileID, out, func(p core.TransferProgress) { s.progress(id, p) })
	s.finish(id, nil, err)
}

func (s *Service) Cancel(id string) (Job, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j, ok := s.jobs[id]
	if !ok {
		return Job{}, errors.New("transfer not found")
	}
	switch j.State {
	case Completed, Failed, Canceled:
		return cloneJob(j), errors.New("transfer is already finished")
	case Canceling:
		return cloneJob(j), nil
	}
	j.State = Canceling
	j.Phase = "canceling"
	if j.cancel != nil {
		j.cancel()
	}
	return cloneJob(j), nil
}

func (s *Service) Get(id string) (Job, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j, ok := s.jobs[id]
	if !ok {
		return Job{}, false
	}
	return cloneJob(j), true
}

func (s *Service) List() []Job {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]Job, 0, len(s.jobs))
	for _, j := range s.jobs {
		out = append(out, cloneJob(j))
	}
	sort.Slice(out, func(i, j int) bool { return out[i].CreatedAt.After(out[j].CreatedAt) })
	return out
}

// ClearFinished removes only terminal activity records. Managed files and
// their remote protection data are unaffected.
func (s *Service) ClearFinished() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	removed := 0
	for id, j := range s.jobs {
		if j.State != Completed && j.State != Failed && j.State != Canceled {
			continue
		}
		delete(s.jobs, id)
		removed++
	}
	return removed
}

func (s *Service) RemoveFinished(id string) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	j, ok := s.jobs[strings.TrimSpace(id)]
	if !ok {
		return false, errors.New("transfer not found")
	}
	if j.State != Completed && j.State != Failed && j.State != Canceled {
		return false, errors.New("active transfers cannot be removed")
	}
	delete(s.jobs, id)
	return true, nil
}

// BeginShutdown atomically closes the admission gate before cancellation. This
// prevents a transfer from slipping in between "start shutdown" and the pass
// that collects active jobs.
func (s *Service) BeginShutdown() {
	s.mu.Lock()
	s.closing = true
	s.mu.Unlock()
}

// Shutdown stops accepting transfers, cancels every active job, and waits for
// each worker to return from the managed-file layer. The latter is important:
// cancellation may trigger remote rollback/cleanup, so process teardown must
// not race that cleanup.
func (s *Service) Shutdown(ctx context.Context) error {
	s.mu.Lock()
	s.closing = true
	for _, j := range s.jobs {
		switch j.State {
		case Completed, Failed, Canceled:
			continue
		}
		j.State = Canceling
		j.Phase = "canceling"
		if j.cancel != nil {
			j.cancel()
		}
	}
	s.mu.Unlock()

	done := make(chan struct{})
	go func() {
		s.wg.Wait()
		close(done)
	}()
	select {
	case <-done:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (s *Service) Accepting() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return !s.closing
}
