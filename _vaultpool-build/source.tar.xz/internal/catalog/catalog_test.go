package catalog

import "testing"

func customWebDAVForTest() Provider {
	return Provider{
		ID: "custom-test", Name: "Custom Test", ShortName: "CT",
		Status: Allowed, StatusNote: "test", MaxAccounts: 0,
		AccountTypes: []string{"WebDAV"}, AuthStrategy: AuthDirectCredentials,
		OfficialURL: "https://example.com/", FailureDomain: "webdav:dav.example.com",
		GenericProtocol: "webdav", EndpointURL: "https://dav.example.com/root/",
	}
}

func TestGenericWebDAVGetsAndRequiresVaultPoolPolicy(t *testing.T) {
	c, err := New([]Provider{customWebDAVForTest()})
	if err != nil {
		t.Fatal(err)
	}
	p, ok := c.Get("custom-test")
	if !ok || p.PolicyVersion != GenericWebDAVPolicyVersion {
		t.Fatalf("generic WebDAV policy was not normalized: %+v %v", p, ok)
	}

	for name, mutate := range map[string]func(*Provider){
		"future policy":      func(p *Provider) { p.PolicyVersion = "vaultpool-generic-webdav-v2" },
		"non HTTPS endpoint": func(p *Provider) { p.EndpointURL = "http://dav.example.com/root/" },
		"artificial cap":     func(p *Provider) { p.MaxAccounts = 2 },
		"unsupported auth":   func(p *Provider) { p.AuthStrategy = AuthUnsupported },
	} {
		t.Run(name, func(t *testing.T) {
			p := customWebDAVForTest()
			mutate(&p)
			if _, err := New([]Provider{p}); err == nil {
				t.Fatal("unsafe generic provider was accepted")
			}
		})
	}
}

func TestGenericProtocolCannotBecomeAnArbitraryPlugin(t *testing.T) {
	p := customWebDAVForTest()
	p.GenericProtocol = "arbitrary-executable"
	if _, err := New([]Provider{p}); err == nil {
		t.Fatal("arbitrary provider protocol was accepted")
	}
}
