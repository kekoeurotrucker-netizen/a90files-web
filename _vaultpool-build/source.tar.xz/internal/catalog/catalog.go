package catalog

import (
	"fmt"
	"net/url"
	"sort"
	"strings"
	"sync"
)

type ComplianceStatus string

const (
	Allowed        ComplianceStatus = "allowed"
	ReviewRequired ComplianceStatus = "review_required"
	Disabled       ComplianceStatus = "disabled"
)

type AuthStrategy string

const (
	AuthSystemBrowserOAuth AuthStrategy = "system_browser_oauth"
	AuthEmbeddedWebView    AuthStrategy = "embedded_webview"
	AuthDeviceCode         AuthStrategy = "device_code"
	AuthDirectCredentials  AuthStrategy = "direct_credentials"
	AuthExternalSession    AuthStrategy = "external_session"
	AuthUnsupported        AuthStrategy = "unsupported"
)

// GenericWebDAVPolicyVersion identifies the fixed, local policy that governs
// user-added declarative WebDAV providers. It is deliberately versioned so a
// future policy change can fail closed instead of silently widening access.
const GenericWebDAVPolicyVersion = "vaultpool-generic-webdav-v1"

type Provider struct {
	ID                string           `json:"id"`
	Name              string           `json:"name"`
	ShortName         string           `json:"short_name"`
	Status            ComplianceStatus `json:"status"`
	StatusNote        string           `json:"status_note"`
	MaxAccounts       int              `json:"max_accounts"`
	AccountTypes      []string         `json:"account_types"`
	AuthStrategy      AuthStrategy     `json:"auth_strategy"`
	OAuthPKCE         bool             `json:"oauth_pkce"`
	CaptchaManualOnly bool             `json:"captcha_manual_only"`
	OfficialURL       string           `json:"official_url"`
	LastReviewed      string           `json:"last_reviewed"`
	FailureDomain     string           `json:"failure_domain"`
	IconURL           string           `json:"icon_url,omitempty"`
	GenericProtocol   string           `json:"generic_protocol,omitempty"`
	EndpointURL       string           `json:"endpoint_url,omitempty"`
	PolicyVersion     string           `json:"policy_version,omitempty"`
}

// Builtin is intentionally conservative. "Allowed" means that both the
// provider-use policy and a safe desktop authentication direction have enough
// evidence for VaultPool to expose the account-add flow. A provider can remain
// visible while ReviewRequired without being connectable.
func Builtin() []Provider {
	return []Provider{
		{ID: "google-drive", Name: "Google Drive", ShortName: "GD", Status: Allowed, StatusNote: "Admite varias cuentas legítimas. OAuth oficial en navegador del sistema; cada cuenta conserva sesión y cuota independientes. Todas las cuentas de Google Drive siguen siendo un único dominio de fallo.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "Google One / pago", "Workspace"}, AuthStrategy: AuthSystemBrowserOAuth, OAuthPKCE: true, CaptchaManualOnly: true, OfficialURL: "https://drive.google.com/", LastReviewed: "2026-09-08", FailureDomain: "google-drive"},
		{ID: "onedrive", Name: "Microsoft OneDrive", ShortName: "OD", Status: Allowed, StatusNote: "Admite varias cuentas legítimas. Aplicación de escritorio con OAuth Authorization Code + PKCE; cada cuenta conserva sesión y cuota independientes. Todas las cuentas OneDrive siguen siendo un único dominio de fallo.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "Microsoft 365 / pago", "Empresa"}, AuthStrategy: AuthSystemBrowserOAuth, OAuthPKCE: true, CaptchaManualOnly: true, OfficialURL: "https://onedrive.live.com/", LastReviewed: "2026-09-08", FailureDomain: "onedrive"},

		// These providers remain gated until VaultPool has a reviewed native-safe
		// authentication design that does not require shipping a confidential
		// client secret or relying on undocumented login/session behavior.
		{ID: "pcloud", Name: "pCloud", ShortName: "PC", Status: Allowed, StatusNote: "OAuth 2.0 oficial. El usuario introduce Client ID y Client Secret de su propia app pCloud; VaultPool los guarda cifrados localmente y permite varias cuentas, conservando el hostname regional (US/EU) por cuenta.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "Premium / pago"}, AuthStrategy: AuthSystemBrowserOAuth, OAuthPKCE: false, CaptchaManualOnly: true, OfficialURL: "https://www.pcloud.com/", LastReviewed: "2026-09-17", FailureDomain: "pcloud"},
		{ID: "proton-drive", Name: "Proton Drive", ShortName: "PD", Status: ReviewRequired, StatusNote: "El SDK oficial de Drive aún no incluye autenticación, login ni gestión de sesión para integraciones independientes. Se mantiene bloqueado hasta disponer de vía soportada.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "Drive Plus / pago", "Proton Unlimited / pago"}, AuthStrategy: AuthUnsupported, CaptchaManualOnly: true, OfficialURL: "https://proton.me/drive", LastReviewed: "2026-09-05", FailureDomain: "proton-drive"},
		{ID: "box", Name: "Box", ShortName: "BX", Status: ReviewRequired, StatusNote: "OAuth oficial disponible, pero el intercambio documentado usa client_secret. Pendiente de validar un patrón seguro para cliente nativo distribuido antes de habilitarlo.", MaxAccounts: 0, AccountTypes: []string{"Individual", "Personal Pro / pago", "Business / pago"}, AuthStrategy: AuthUnsupported, CaptchaManualOnly: true, OfficialURL: "https://www.box.com/", LastReviewed: "2026-09-05", FailureDomain: "box"},
		{ID: "mega", Name: "MEGA", ShortName: "ME", Status: Allowed, StatusNote: "Una cuenta por perfil. Integración mediante MEGAcmd oficial: el usuario inicia sesión de forma interactiva en la herramienta de MEGA y VaultPool reutiliza esa sesión sin recibir ni guardar la contraseña.", MaxAccounts: 1, AccountTypes: []string{"Gratis", "Pro / pago"}, AuthStrategy: AuthExternalSession, CaptchaManualOnly: true, OfficialURL: "https://mega.io/", LastReviewed: "2026-09-05", FailureDomain: "mega"},
		{ID: "filen", Name: "Filen", ShortName: "FI", Status: Allowed, StatusNote: "Admite varias cuentas legítimas. Conector directo mediante SDK oficial de Filen: email, contraseña y 2FA se usan solo para iniciar sesión localmente; cada cuenta conserva una sesión serializada independiente dentro de la bóveda cifrada.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "Starter / pago", "Pro / pago"}, AuthStrategy: AuthDirectCredentials, CaptchaManualOnly: true, OfficialURL: "https://filen.io/", LastReviewed: "2026-09-08", FailureDomain: "filen"},
		{ID: "dropbox", Name: "Dropbox", ShortName: "DB", Status: Allowed, StatusNote: "Admite varias cuentas legítimas. OAuth oficial en navegador del sistema con PKCE; VaultPool usa la carpeta de aplicación y guarda cada sesión por cuenta. Todas las cuentas Dropbox siguen siendo un único dominio de fallo.", MaxAccounts: 0, AccountTypes: []string{"Basic", "Plus", "Professional", "Business"}, AuthStrategy: AuthSystemBrowserOAuth, OAuthPKCE: true, CaptchaManualOnly: true, OfficialURL: "https://www.dropbox.com/", LastReviewed: "2026-09-08", FailureDomain: "dropbox"},
		{ID: "terabox", Name: "TeraBox", ShortName: "TB", Status: ReviewRequired, StatusNote: "Candidato visible, pero bloqueado hasta validar OAuth/API oficial compatible con archivos, cuota, subida, descarga y borrado. VaultPool no aceptará contraseñas, cookies, scraping ni automatización web no autorizada para conectar TeraBox.", MaxAccounts: 0, AccountTypes: []string{"Free 1 TB", "Premium / pago"}, AuthStrategy: AuthUnsupported, CaptchaManualOnly: true, OfficialURL: "https://www.terabox.com/", LastReviewed: "2026-09-06", FailureDomain: "terabox"},
		{ID: "icloud-drive", Name: "iCloud Drive", ShortName: "IC", Status: Disabled, StatusNote: "Desactivado hasta disponer de una vía oficial/autorizada suficientemente clara para la automatización requerida.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "iCloud+ / pago"}, AuthStrategy: AuthUnsupported, CaptchaManualOnly: true, OfficialURL: "https://www.icloud.com/", LastReviewed: "", FailureDomain: "icloud-drive"},
		{ID: "mediafire", Name: "MediaFire", ShortName: "MF", Status: Allowed, StatusNote: "API oficial MediaFire v1.5. Varias cuentas legítimas son posibles, cada una con sesión, cuota y espacio VaultPool independientes. Todas cuentan como un único dominio de fallo para la redundancia.", MaxAccounts: 0, AccountTypes: []string{"Basic", "Pro / pago"}, AuthStrategy: AuthDirectCredentials, CaptchaManualOnly: true, OfficialURL: "https://www.mediafire.com/developers/", LastReviewed: "2026-09-08", FailureDomain: "mediafire"},
		{ID: "idrive", Name: "IDrive", ShortName: "ID", Status: ReviewRequired, StatusNote: "Pendiente de distinguir condiciones/API entre IDrive Basic y servicios compatibles con S3.", MaxAccounts: 0, AccountTypes: []string{"Basic", "Personal / pago", "Business / pago"}, AuthStrategy: AuthUnsupported, CaptchaManualOnly: true, OfficialURL: "https://www.idrive.com/", LastReviewed: "", FailureDomain: "idrive"},
		{ID: "sync", Name: "Sync.com", ShortName: "SY", Status: ReviewRequired, StatusNote: "Pendiente de auditoría específica de API, automatización, autenticación y condiciones.", MaxAccounts: 0, AccountTypes: []string{"Gratis", "Solo / pago", "Teams / pago"}, AuthStrategy: AuthUnsupported, CaptchaManualOnly: true, OfficialURL: "https://www.sync.com/", LastReviewed: "", FailureDomain: "sync"},
	}
}

type Catalog struct {
	mu   sync.RWMutex
	byID map[string]Provider
}

func normalizeProvider(p Provider) (Provider, error) {
	p.ID = strings.TrimSpace(strings.ToLower(p.ID))
	p.Name = strings.TrimSpace(p.Name)
	p.FailureDomain = strings.TrimSpace(strings.ToLower(p.FailureDomain))
	p.GenericProtocol = strings.TrimSpace(strings.ToLower(p.GenericProtocol))
	p.EndpointURL = strings.TrimSpace(p.EndpointURL)
	p.IconURL = strings.TrimSpace(p.IconURL)
	if p.ID == "" || p.Name == "" || p.FailureDomain == "" {
		return Provider{}, fmt.Errorf("invalid provider catalog entry")
	}
	if p.Status == Allowed {
		if p.MaxAccounts < 0 {
			return Provider{}, fmt.Errorf("allowed provider %q has invalid max_accounts", p.ID)
		}
		if p.AuthStrategy == AuthUnsupported || p.AuthStrategy == "" {
			return Provider{}, fmt.Errorf("allowed provider %q needs approved auth strategy", p.ID)
		}
	}
	if p.GenericProtocol != "" && p.GenericProtocol != "webdav" {
		return Provider{}, fmt.Errorf("unsupported generic protocol %q", p.GenericProtocol)
	}
	if p.GenericProtocol == "webdav" {
		if p.PolicyVersion == "" {
			p.PolicyVersion = GenericWebDAVPolicyVersion
		}
		if p.PolicyVersion != GenericWebDAVPolicyVersion {
			return Provider{}, fmt.Errorf("unsupported WebDAV policy version %q", p.PolicyVersion)
		}
		if p.Status != Allowed || p.AuthStrategy != AuthDirectCredentials || p.MaxAccounts != 0 {
			return Provider{}, fmt.Errorf("custom WebDAV provider %q does not satisfy the VaultPool policy", p.ID)
		}
		u, err := url.Parse(p.EndpointURL)
		if err != nil || u.Scheme != "https" || u.Hostname() == "" || u.User != nil || u.RawQuery != "" {
			return Provider{}, fmt.Errorf("webdav provider %q needs a public HTTPS endpoint without credentials or query parameters", p.ID)
		}
	}
	return p, nil
}

func New(items []Provider) (*Catalog, error) {
	c := &Catalog{byID: map[string]Provider{}}
	for _, p := range items {
		var err error
		p, err = normalizeProvider(p)
		if err != nil {
			return nil, err
		}
		if _, ok := c.byID[p.ID]; ok {
			return nil, fmt.Errorf("duplicate provider %q", p.ID)
		}
		c.byID[p.ID] = p
	}
	return c, nil
}

// Add installs a provider after a successful runtime safety audit. It is used
// only for declarative/generic protocols that VaultPool already knows how to
// enforce; it never turns an arbitrary website into executable provider code.
func (c *Catalog) Add(p Provider) error {
	if c == nil {
		return fmt.Errorf("catalog required")
	}
	var err error
	p, err = normalizeProvider(p)
	if err != nil {
		return err
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, exists := c.byID[p.ID]; exists {
		return fmt.Errorf("duplicate provider %q", p.ID)
	}
	c.byID[p.ID] = p
	return nil
}

func MustBuiltin() *Catalog {
	c, err := New(Builtin())
	if err != nil {
		panic(err)
	}
	return c
}
func (c *Catalog) Get(id string) (Provider, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	p, ok := c.byID[strings.ToLower(strings.TrimSpace(id))]
	return p, ok
}
func (c *Catalog) All() []Provider {
	c.mu.RLock()
	defer c.mu.RUnlock()
	out := make([]Provider, 0, len(c.byID))
	for _, p := range c.byID {
		out = append(out, p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}
