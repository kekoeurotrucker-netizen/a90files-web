package filen

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"path"
	"sort"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

type Store struct {
	Connector        *Connector
	ExpectedTargetID string
}

func (s *Store) ProviderID() string { return ProviderID }

func (s *Store) session(ctx context.Context, accountID string) (Session, error) {
	if s == nil || s.Connector == nil {
		return nil, errors.New("Filen direct connector is not available")
	}
	session, err := s.Connector.loadSession(ctx, accountID)
	if err != nil {
		return nil, err
	}
	if strings.TrimSpace(s.ExpectedTargetID) == "" {
		return session, nil
	}
	snap, err := s.Connector.snapshot(ctx, accountID, session)
	if err != nil {
		return nil, err
	}
	current, err := connector.StableTargetID(ProviderID, snap.ProviderSubject)
	if err != nil || current != strings.TrimSpace(s.ExpectedTargetID) {
		return nil, errors.New("active Filen session belongs to a different account; transfer blocked")
	}
	return session, nil
}

func objectName(key string) (string, error) {
	if err := remoteobject.ValidateKey(key); err != nil {
		return "", err
	}
	var suffix [6]byte
	if _, err := rand.Read(suffix[:]); err != nil {
		return "", err
	}
	if strings.HasPrefix(key, "metadata/manifests/") {
		id, ok := manifestID(key)
		if !ok {
			return "", errors.New("invalid VaultPool manifest key")
		}
		return "vp-manifest-" + id + "-" + hex.EncodeToString(suffix[:]) + ".cpm", nil
	}
	if id, ok := recoveryID(key); ok {
		return "vp-filekey-" + id + "-" + hex.EncodeToString(suffix[:]) + ".vprk", nil
	}
	return "vp-" + remoteobject.SHA256Bytes([]byte(key)) + "-" + hex.EncodeToString(suffix[:]) + ".cps", nil
}

func manifestID(key string) (string, bool) {
	const prefix = "metadata/manifests/"
	if !strings.HasPrefix(key, prefix) {
		return "", false
	}
	parts := strings.Split(strings.TrimPrefix(key, prefix), "/")
	if len(parts) != 2 || len(parts[0]) != 32 || !strings.HasPrefix(parts[1], "generation-") || !strings.HasSuffix(parts[1], ".cpm") {
		return "", false
	}
	if _, err := hex.DecodeString(parts[0]); err != nil {
		return "", false
	}
	return strings.ToLower(parts[0]), true
}

func recoveryID(key string) (string, bool) {
	const prefix = "metadata/recovery/filekeys/"
	const suffix = ".vprk"
	if !strings.HasPrefix(key, prefix) || !strings.HasSuffix(key, suffix) {
		return "", false
	}
	id := strings.TrimSuffix(strings.TrimPrefix(key, prefix), suffix)
	if len(id) != 32 {
		return "", false
	}
	if _, err := hex.DecodeString(id); err != nil {
		return "", false
	}
	return strings.ToLower(id), true
}

func splitLocator(namespace, loc string) (string, error) {
	namespace, err := cleanNamespace(namespace)
	if err != nil {
		return "", err
	}
	clean := path.Clean(strings.TrimSpace(loc))
	if strings.HasPrefix(clean, "../") || clean == "." || clean == ".." || !strings.HasPrefix(clean, namespace+"/") {
		return "", errors.New("invalid Filen object locator")
	}
	name := path.Base(clean)
	if name == "." || name == "/" || strings.ContainsAny(name, "/\\\r\n\x00") {
		return "", errors.New("invalid Filen object locator")
	}
	return name, nil
}

func locator(namespace, name string) (string, error) {
	namespace, err := cleanNamespace(namespace)
	if err != nil {
		return "", err
	}
	if name == "" || strings.ContainsAny(name, "/\\\r\n\x00") || name == "." || name == ".." {
		return "", errors.New("unsafe Filen object name")
	}
	return namespace + "/" + name, nil
}

func (s *Store) PutVerified(ctx context.Context, accountID, key string, data []byte, expectedSHA string) (remoteobject.Object, error) {
	if err := remoteobject.ValidateKey(key); err != nil {
		return remoteobject.Object{}, err
	}
	if len(data) == 0 {
		return remoteobject.Object{}, errors.New("empty remote objects are not supported")
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(data), expectedSHA) {
		return remoteobject.Object{}, errors.New("local SHA-256 mismatch before Filen upload")
	}
	opCtx, cancel := withDefaultTimeout(ctx, transferTimeout(int64(len(data))*2))
	defer cancel()
	session, err := s.session(opCtx, accountID)
	if err != nil {
		return remoteobject.Object{}, err
	}
	if err := session.EnsureNamespace(opCtx, s.Connector.namespace()); err != nil {
		return remoteobject.Object{}, filenError(ErrNetwork, "No se pudo crear o localizar la carpeta VaultPool en Filen.", err)
	}
	name, err := objectName(key)
	if err != nil {
		return remoteobject.Object{}, err
	}
	loc, err := locator(s.Connector.namespace(), name)
	if err != nil {
		return remoteobject.Object{}, err
	}
	if _, err := session.Upload(opCtx, s.Connector.namespace(), name, data); err != nil {
		return remoteobject.Object{}, filenError(ErrNetwork, "Filen upload failed.", err)
	}
	remote, ok, err := session.FindFile(opCtx, s.Connector.namespace(), name)
	if err != nil {
		return remoteobject.Object{}, filenError(ErrNetwork, "No se pudo localizar el objeto subido en Filen.", err)
	}
	if !ok {
		return remoteobject.Object{}, errors.New("Filen upload did not create a locatable remote object")
	}
	if remote.Name != name {
		cleanup(opCtx, session, remote)
		return remoteobject.Object{}, errors.New("Filen upload returned an unexpected remote name")
	}
	obj := remoteobject.Object{ProviderID: ProviderID, AccountID: accountID, ID: loc, Key: key, Name: name, Size: int64(len(data)), SHA256: strings.ToLower(expectedSHA)}
	if remote.Size != obj.Size {
		cleanup(opCtx, session, remote)
		return remoteobject.Object{}, fmt.Errorf("Filen post-upload size mismatch: got %d want %d", remote.Size, obj.Size)
	}
	downloaded, err := session.Download(opCtx, remote)
	if err != nil {
		cleanup(opCtx, session, remote)
		return remoteobject.Object{}, fmt.Errorf("Filen post-upload download failed: %w", err)
	}
	if int64(len(downloaded)) != obj.Size {
		cleanup(opCtx, session, remote)
		zero(downloaded)
		return remoteobject.Object{}, fmt.Errorf("Filen post-upload size mismatch: got %d want %d", len(downloaded), obj.Size)
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(downloaded), obj.SHA256) {
		cleanup(opCtx, session, remote)
		zero(downloaded)
		return remoteobject.Object{}, errors.New("Filen post-upload SHA-256 mismatch")
	}
	zero(downloaded)
	return obj, nil
}

func (s *Store) GetVerified(ctx context.Context, accountID, loc string, expectedSize int64, expectedSHA string) ([]byte, error) {
	if expectedSize < 0 {
		return nil, errors.New("negative expected size")
	}
	name, err := splitLocator(s.Connector.namespace(), loc)
	if err != nil {
		return nil, err
	}
	opCtx, cancel := withDefaultTimeout(ctx, transferTimeout(expectedSize))
	defer cancel()
	session, err := s.session(opCtx, accountID)
	if err != nil {
		return nil, err
	}
	remote, ok, err := session.FindFile(opCtx, s.Connector.namespace(), name)
	if err != nil {
		return nil, filenError(ErrNetwork, "No se pudo localizar el objeto en Filen.", err)
	}
	if !ok {
		return nil, errors.New("Filen object not found")
	}
	if remote.Name != name {
		return nil, errors.New("Filen object name mismatch")
	}
	if remote.Size != expectedSize {
		return nil, fmt.Errorf("remote size mismatch: got %d want %d", remote.Size, expectedSize)
	}
	data, err := session.Download(opCtx, remote)
	if err != nil {
		return nil, filenError(ErrNetwork, "Filen download failed.", err)
	}
	if int64(len(data)) != expectedSize {
		zero(data)
		return nil, fmt.Errorf("remote size mismatch: got %d want %d", len(data), expectedSize)
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(data), expectedSHA) {
		zero(data)
		return nil, errors.New("remote SHA-256 mismatch")
	}
	return data, nil
}

func (s *Store) Delete(ctx context.Context, accountID, loc string) error {
	name, err := splitLocator(s.Connector.namespace(), loc)
	if err != nil {
		return err
	}
	opCtx, cancel := withDefaultTimeout(ctx, deleteTimeout)
	defer cancel()
	session, err := s.session(opCtx, accountID)
	if err != nil {
		return err
	}
	remote, ok, err := session.FindFile(opCtx, s.Connector.namespace(), name)
	if err != nil {
		return filenError(ErrNetwork, "No se pudo localizar el objeto en Filen para borrarlo.", err)
	}
	if !ok {
		return nil
	}
	if remote.Name != name {
		return errors.New("Filen object name mismatch during delete")
	}
	if err := session.Delete(opCtx, remote); err != nil {
		return filenError(ErrNetwork, "Filen delete failed.", err)
	}
	if _, exists, err := session.FindFile(opCtx, s.Connector.namespace(), name); err != nil {
		return filenError(ErrNetwork, "No se pudo verificar el borrado en Filen.", err)
	} else if exists {
		return errors.New("Filen object still exists after delete")
	}
	return nil
}

func cleanup(parent context.Context, session Session, remote FileRef) {
	ctx, cancel := context.WithTimeout(context.Background(), deleteTimeout)
	defer cancel()
	done := make(chan struct{})
	go func() {
		_ = session.Delete(ctx, remote)
		close(done)
	}()
	select {
	case <-done:
	case <-parent.Done():
	case <-ctx.Done():
	}
}

func (s *Store) listRecovery(ctx context.Context, accountID, prefix, suffix string) ([]FileRef, error) {
	opCtx, cancel := withDefaultTimeout(ctx, listTimeout)
	defer cancel()
	session, err := s.session(opCtx, accountID)
	if err != nil {
		return nil, err
	}
	if err := session.EnsureNamespace(opCtx, s.Connector.namespace()); err != nil {
		return nil, filenError(ErrNetwork, "No se pudo crear o localizar la carpeta VaultPool en Filen.", err)
	}
	files, err := session.ListFiles(opCtx, s.Connector.namespace())
	if err != nil {
		return nil, filenError(ErrNetwork, "No se pudo listar la carpeta VaultPool en Filen.", err)
	}
	out := make([]FileRef, 0, len(files))
	for _, f := range files {
		if f.Size <= 0 || strings.ContainsAny(f.Name, "/\\\r\n\x00") || !strings.HasPrefix(f.Name, prefix) || !strings.HasSuffix(f.Name, suffix) {
			continue
		}
		out = append(out, f)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out, nil
}

func recoveryNameID(name, prefix, suffix string) string {
	body := strings.TrimSuffix(strings.TrimPrefix(name, prefix), suffix)
	if len(body) >= 32 {
		return strings.ToLower(body[:32])
	}
	return ""
}

func (s *Store) ListManifestCandidates(ctx context.Context, accountID string) ([]remoteobject.ManifestCandidate, error) {
	files, err := s.listRecovery(ctx, accountID, "vp-manifest-", ".cpm")
	if err != nil {
		return nil, err
	}
	out := make([]remoteobject.ManifestCandidate, 0, len(files))
	for _, f := range files {
		loc, err := locator(s.Connector.namespace(), f.Name)
		if err != nil {
			continue
		}
		out = append(out, remoteobject.ManifestCandidate{Locator: loc, RecoveryID: recoveryNameID(f.Name, "vp-manifest-", ".cpm"), Size: f.Size})
	}
	return out, nil
}

func (s *Store) ReadManifestCandidate(ctx context.Context, accountID, loc string, maxBytes int64) ([]byte, error) {
	return s.readCandidate(ctx, accountID, loc, maxBytes)
}

func (s *Store) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]remoteobject.RecoveryRecordCandidate, error) {
	files, err := s.listRecovery(ctx, accountID, "vp-filekey-", ".vprk")
	if err != nil {
		return nil, err
	}
	out := make([]remoteobject.RecoveryRecordCandidate, 0, len(files))
	for _, f := range files {
		loc, err := locator(s.Connector.namespace(), f.Name)
		if err != nil {
			continue
		}
		out = append(out, remoteobject.RecoveryRecordCandidate{Locator: loc, RecoveryID: recoveryNameID(f.Name, "vp-filekey-", ".vprk"), Size: f.Size})
	}
	return out, nil
}

func (s *Store) ReadRecoveryRecordCandidate(ctx context.Context, accountID, loc string, maxBytes int64) ([]byte, error) {
	return s.readCandidate(ctx, accountID, loc, maxBytes)
}

func (s *Store) readCandidate(ctx context.Context, accountID, loc string, maxBytes int64) ([]byte, error) {
	if maxBytes <= 0 {
		return nil, errors.New("invalid recovery size cap")
	}
	name, err := splitLocator(s.Connector.namespace(), loc)
	if err != nil {
		return nil, err
	}
	opCtx, cancel := withDefaultTimeout(ctx, listTimeout)
	defer cancel()
	session, err := s.session(opCtx, accountID)
	if err != nil {
		return nil, err
	}
	remote, ok, err := session.FindFile(opCtx, s.Connector.namespace(), name)
	if err != nil {
		return nil, filenError(ErrNetwork, "No se pudo localizar el candidato de recuperación en Filen.", err)
	}
	if !ok {
		return nil, errors.New("Filen recovery candidate not found")
	}
	if remote.Size <= 0 || remote.Size > maxBytes {
		return nil, fmt.Errorf("Filen recovery candidate exceeds cap: %d > %d", remote.Size, maxBytes)
	}
	return session.Download(opCtx, remote)
}
