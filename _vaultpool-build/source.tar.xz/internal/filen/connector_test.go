package filen

import (
	"bytes"
	"context"
	"crypto/sha256"
	"errors"
	"io"
	"strings"
	"sync"
	"testing"
	"time"

	filensdk "github.com/FilenCloudDienste/filen-sdk-go/filen"
	filensdkcrypto "github.com/FilenCloudDienste/filen-sdk-go/filen/crypto"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type memorySecrets struct {
	mu     sync.Mutex
	values map[string][]byte
}

func newMemorySecrets() *memorySecrets { return &memorySecrets{values: map[string][]byte{}} }

func (m *memorySecrets) key(accountID string, kind secretvault.Kind) string {
	return accountID + "\x00" + string(kind)
}
func (m *memorySecrets) Get(accountID string, kind secretvault.Kind) ([]byte, bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	b, ok := m.values[m.key(accountID, kind)]
	return append([]byte(nil), b...), ok, nil
}
func (m *memorySecrets) Put(accountID string, kind secretvault.Kind, value []byte) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.values[m.key(accountID, kind)] = append([]byte(nil), value...)
	return nil
}
func (m *memorySecrets) Delete(accountID string, kind secretvault.Kind) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.values, m.key(accountID, kind))
	return nil
}

type fakeSession struct {
	mu          sync.Mutex
	info        UserInfo
	serialized  []byte
	files       map[string][]byte
	ensureCalls []string
	blockUser   bool
}

func newFakeSession(email string, id int64, base string) *fakeSession {
	return &fakeSession{
		info:       UserInfo{ID: id, Email: email, IsPremium: true, MaxStorage: 10_000, UsedStorage: 2_500, BaseFolderUUID: base},
		serialized: []byte("sdk-session-without-password"),
		files:      map[string][]byte{},
	}
}

func (s *fakeSession) SerializeTo(w io.Writer) error { _, err := w.Write(s.serialized); return err }
func (s *fakeSession) UserInfo(ctx context.Context) (UserInfo, error) {
	if s.blockUser {
		<-ctx.Done()
		return UserInfo{}, ctx.Err()
	}
	return s.info, nil
}
func (s *fakeSession) BaseFolderUUID() string { return s.info.BaseFolderUUID }
func (s *fakeSession) EnsureNamespace(_ context.Context, namespace string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.ensureCalls = append(s.ensureCalls, namespace)
	return nil
}
func (s *fakeSession) Upload(_ context.Context, _, name string, data []byte) (FileRef, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.files[name] = append([]byte(nil), data...)
	return FileRef{ID: "file-" + name, Name: name, Size: int64(len(data)), handle: name}, nil
}
func (s *fakeSession) FindFile(_ context.Context, _, name string) (FileRef, bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	data, ok := s.files[name]
	if !ok {
		return FileRef{}, false, nil
	}
	return FileRef{ID: "file-" + name, Name: name, Size: int64(len(data)), handle: name}, true, nil
}
func (s *fakeSession) ListFiles(_ context.Context, _ string) ([]FileRef, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]FileRef, 0, len(s.files))
	for name, data := range s.files {
		out = append(out, FileRef{ID: "file-" + name, Name: name, Size: int64(len(data)), handle: name})
	}
	return out, nil
}
func (s *fakeSession) Download(_ context.Context, ref FileRef) ([]byte, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	name, ok := ref.handle.(string)
	if !ok {
		name = ref.Name
	}
	data, ok := s.files[name]
	if !ok {
		return nil, errors.New("missing fake file")
	}
	return append([]byte(nil), data...), nil
}
func (s *fakeSession) Delete(_ context.Context, ref FileRef) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	name, ok := ref.handle.(string)
	if !ok {
		name = ref.Name
	}
	delete(s.files, name)
	return nil
}

type fakeFactory struct {
	loginErr   error
	session    *fakeSession
	serialized []byte
}

func (f *fakeFactory) Login(_ context.Context, _, _, code string) (Session, error) {
	if f.loginErr != nil {
		return nil, f.loginErr
	}
	return f.session, nil
}
func (f *fakeFactory) Deserialize(raw []byte) (Session, error) {
	if !bytes.Equal(raw, f.serialized) {
		return nil, errors.New("serialized session mismatch")
	}
	return f.session, nil
}

func validFilenConnector() (*Connector, *memorySecrets, *fakeSession) {
	secrets := newMemorySecrets()
	session := newFakeSession("person@example.com", 42, "base-folder")
	factory := &fakeFactory{session: session, serialized: session.serialized}
	return &Connector{Secrets: secrets, Factory: factory, Namespace: DefaultNamespace}, secrets, session
}

func TestLoginStoresOnlySerializedSessionAndProbeRestoresIt(t *testing.T) {
	c, secrets, session := validFilenConnector()
	snap, err := c.Login(context.Background(), "acct", "person@example.com", "correct-password", "")
	if err != nil {
		t.Fatal(err)
	}
	if snap.ProviderID != ProviderID || snap.Identity != "person@example.com" || snap.TotalBytes != 10_000 || snap.UsedBytes != 2_500 || snap.FreeBytes != 7_500 {
		t.Fatalf("unexpected snapshot: %+v", snap)
	}
	stored, ok, err := secrets.Get("acct", secretvault.FilenSession)
	if err != nil || !ok {
		t.Fatalf("session not stored: ok=%v err=%v", ok, err)
	}
	if !bytes.Equal(stored, session.serialized) || bytes.Contains(stored, []byte("correct-password")) {
		t.Fatalf("unexpected persisted session: %q", stored)
	}
	if len(session.ensureCalls) != 1 || session.ensureCalls[0] != DefaultNamespace {
		t.Fatalf("namespace was not ensured once: %v", session.ensureCalls)
	}

	probed, err := c.Probe(context.Background(), "acct")
	if err != nil {
		t.Fatal(err)
	}
	if probed.ProviderSubject != snap.ProviderSubject || probed.FreeBytes != 7_500 {
		t.Fatalf("restored probe changed identity/quota: %+v vs %+v", probed, snap)
	}
	if len(session.ensureCalls) != 2 {
		t.Fatalf("expected namespace reuse check on probe: %v", session.ensureCalls)
	}
}

func TestQuotaValidRejectsMissingAndInconsistentQuota(t *testing.T) {
	for _, tc := range []struct {
		name        string
		total, used int64
		want        bool
	}{
		{name: "valid", total: 10_000, used: 2_500, want: true},
		{name: "zero total", total: 0, used: 0, want: false},
		{name: "negative used", total: 10_000, used: -1, want: false},
		{name: "used over total", total: 10_000, used: 10_001, want: false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if got := quotaValid(tc.total, tc.used); got != tc.want {
				t.Fatalf("quotaValid(%d, %d)=%v want %v", tc.total, tc.used, got, tc.want)
			}
		})
	}
}

func TestSnapshotReportsConcreteQuotaFailure(t *testing.T) {
	c, _, session := validFilenConnector()
	session.info.MaxStorage = 0
	session.info.UsedStorage = 0
	_, err := c.snapshot(context.Background(), "acct", session)
	if Code(err) != ErrAccountInvalid || !strings.Contains(err.Error(), "cuota total") {
		t.Fatalf("expected concrete total-quota error, got code=%q err=%v", Code(err), err)
	}

	session.info.MaxStorage = 10_000
	session.info.UsedStorage = 10_001
	_, err = c.snapshot(context.Background(), "acct", session)
	if Code(err) != ErrAccountInvalid || !strings.Contains(err.Error(), "superior a la cuota total") {
		t.Fatalf("expected concrete used-over-total error, got code=%q err=%v", Code(err), err)
	}
}

func TestLoginErrorStatesAndTimeout(t *testing.T) {
	for _, tc := range []struct {
		name string
		err  error
		code ErrorCode
	}{
		{name: "invalid password", err: errors.New("unauthorized"), code: ErrInvalidCredentials},
		{name: "needs 2fa", err: errors.New("two factor required"), code: ErrTwoFactorRequired},
		{name: "invalid 2fa", err: errors.New("invalid otp"), code: ErrTwoFactorInvalid},
		{name: "rate limit", err: errors.New("HTTP 429 too many requests"), code: ErrRateLimited},
	} {
		t.Run(tc.name, func(t *testing.T) {
			c, _, _ := validFilenConnector()
			c.Factory = &fakeFactory{loginErr: tc.err, session: newFakeSession("person@example.com", 42, "base-folder")}
			code := ""
			if tc.code == ErrTwoFactorInvalid {
				code = "123456"
			}
			_, err := c.Login(context.Background(), "acct", "person@example.com", "password", code)
			if Code(err) != tc.code {
				t.Fatalf("code=%q err=%v", Code(err), err)
			}
		})
	}

	c, _, session := validFilenConnector()
	session.blockUser = true
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Millisecond)
	defer cancel()
	if _, err := c.Login(ctx, "acct", "person@example.com", "password", ""); Code(err) != ErrNetwork {
		t.Fatalf("expected network timeout, got code=%q err=%v", Code(err), err)
	}
}

func TestFilenStoreVerifiesUploadDownloadDeleteAndRecovery(t *testing.T) {
	c, secrets, session := validFilenConnector()
	if err := secrets.Put("acct", secretvault.FilenSession, session.serialized); err != nil {
		t.Fatal(err)
	}
	store := c.RemoteStoreFor("acct", stableTarget(t, session))
	data := []byte("disposable verified object")
	hash := remoteobject.SHA256Bytes(data)
	key := "metadata/manifests/0123456789abcdef0123456789abcdef/generation-1.cpm"
	obj, err := store.PutVerified(context.Background(), "acct", key, data, hash)
	if err != nil {
		t.Fatal(err)
	}
	if obj.ProviderID != ProviderID || obj.Size != int64(len(data)) || obj.SHA256 != hash || !strings.HasPrefix(obj.ID, DefaultNamespace+"/") {
		t.Fatalf("unexpected remote object: %+v", obj)
	}
	got, err := store.GetVerified(context.Background(), "acct", obj.ID, obj.Size, obj.SHA256)
	if err != nil || !bytes.Equal(got, data) {
		t.Fatalf("verified get: %v %q", err, got)
	}

	session.mu.Lock()
	session.files[obj.Name][0] ^= 1
	session.mu.Unlock()
	if _, err := store.GetVerified(context.Background(), "acct", obj.ID, obj.Size, obj.SHA256); err == nil {
		t.Fatal("corrupted object passed SHA-256 verification")
	}
	session.mu.Lock()
	session.files[obj.Name][0] ^= 1
	session.mu.Unlock()

	recoveryKey := "metadata/recovery/filekeys/abcdefabcdefabcdefabcdefabcdefab.vprk"
	recoveryData := []byte("encrypted recovery record")
	if _, err := store.PutVerified(context.Background(), "acct", recoveryKey, recoveryData, remoteobject.SHA256Bytes(recoveryData)); err != nil {
		t.Fatal(err)
	}
	manifestStore, ok := store.(remoteobject.ManifestRecoveryStore)
	if !ok {
		t.Fatal("Filen store does not expose manifest recovery")
	}
	manifests, err := manifestStore.ListManifestCandidates(context.Background(), "acct")
	if err != nil || len(manifests) != 1 || manifests[0].RecoveryID != "0123456789abcdef0123456789abcdef" {
		t.Fatalf("manifest recovery list: %+v err=%v", manifests, err)
	}
	recordStore, ok := store.(remoteobject.RecoveryRecordStore)
	if !ok {
		t.Fatal("Filen store does not expose recovery records")
	}
	records, err := recordStore.ListRecoveryRecordCandidates(context.Background(), "acct")
	if err != nil || len(records) != 1 || records[0].RecoveryID != "abcdefabcdefabcdefabcdefabcdefab" {
		t.Fatalf("record recovery list: %+v err=%v", records, err)
	}
	if err := store.Delete(context.Background(), "acct", obj.ID); err != nil {
		t.Fatal(err)
	}
	if _, ok, err := session.FindFile(context.Background(), DefaultNamespace, obj.Name); err != nil || ok {
		t.Fatalf("object remained after delete: ok=%v err=%v", ok, err)
	}
}

func TestFilenStoreRejectsDifferentIdentityAndCancellation(t *testing.T) {
	c, secrets, session := validFilenConnector()
	if err := secrets.Put("acct", secretvault.FilenSession, session.serialized); err != nil {
		t.Fatal(err)
	}
	other := newFakeSession("other@example.com", 99, "other-base")
	c.Factory = &fakeFactory{session: other, serialized: session.serialized}
	store := c.RemoteStoreFor("acct", stableTarget(t, session))
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := store.PutVerified(ctx, "acct", "objects/test", []byte("data"), remoteobject.SHA256Bytes([]byte("data")))
	if err == nil {
		t.Fatal("cancelled or mismatched session was accepted")
	}
	if !strings.Contains(err.Error(), "different account") && !errors.Is(err, context.Canceled) {
		t.Fatalf("unexpected identity/cancellation error: %v", err)
	}
}

func TestLogoutDeletesSessionAndIdentity(t *testing.T) {
	c, secrets, _ := validFilenConnector()
	if err := secrets.Put("acct", secretvault.FilenSession, []byte("session")); err != nil {
		t.Fatal(err)
	}
	if err := secrets.Put("acct", secretvault.AccountIdentity, []byte("person@example.com")); err != nil {
		t.Fatal(err)
	}
	if err := c.Logout("acct"); err != nil {
		t.Fatal(err)
	}
	for _, kind := range []secretvault.Kind{secretvault.FilenSession, secretvault.AccountIdentity} {
		if got, ok, err := secrets.Get("acct", kind); err != nil || ok || got != nil {
			t.Fatalf("secret %s remained: ok=%v value=%q err=%v", kind, ok, got, err)
		}
	}
}

func TestNormalizeSDKVersionsForAllAuthVersions(t *testing.T) {
	for _, version := range []int{1, 2, 3} {
		api := &filensdk.Filen{AuthVersion: filensdkcrypto.AuthVersion(version)}
		normalizeSDKVersions(api)
		if api.FileEncryptionVersion == 0 || api.MetadataEncryptionVersion == 0 {
			t.Fatalf("auth version %d did not restore encryption versions", version)
		}
	}
}

func stableTarget(t *testing.T, session *fakeSession) string {
	t.Helper()
	id, err := connector.StableTargetID(ProviderID, stableSubject(session.info))
	if err != nil {
		t.Fatal(err)
	}
	return id
}

func TestStableSubjectIsNotEmailOnlyWhenProviderIDExists(t *testing.T) {
	a := stableSubject(UserInfo{ID: 1, Email: "same@example.com", BaseFolderUUID: "base-a"})
	b := stableSubject(UserInfo{ID: 1, Email: "same@example.com", BaseFolderUUID: "base-b"})
	if a == b || !strings.Contains(a, "user:1") {
		t.Fatalf("stable subject did not bind base folder: %q %q", a, b)
	}

	first := sha256.Sum256([]byte(a))
	second := sha256.Sum256([]byte(b))
	if first == second {
		t.Fatal("identity subjects unexpectedly hashed equally")
	}
}
