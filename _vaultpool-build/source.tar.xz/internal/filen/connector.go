package filen

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"path"
	"strings"
	"time"

	filensdk "github.com/FilenCloudDienste/filen-sdk-go/filen"
	filenclient "github.com/FilenCloudDienste/filen-sdk-go/filen/client"
	filencrypto "github.com/FilenCloudDienste/filen-sdk-go/filen/crypto"
	filentypes "github.com/FilenCloudDienste/filen-sdk-go/filen/types"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

const (
	ProviderID       = "filen"
	DefaultNamespace = "VaultPool"

	loginTimeout  = 75 * time.Second
	probeTimeout  = 25 * time.Second
	listTimeout   = 35 * time.Second
	deleteTimeout = 45 * time.Second
)

type ErrorCode string

const (
	ErrInvalidCredentials ErrorCode = "invalid_credentials"
	ErrTwoFactorRequired  ErrorCode = "two_factor_required"
	ErrTwoFactorInvalid   ErrorCode = "two_factor_invalid"
	ErrSessionInvalid     ErrorCode = "session_invalid"
	ErrNetwork            ErrorCode = "network_error"
	ErrRateLimited        ErrorCode = "rate_limited"
	ErrAccountInvalid     ErrorCode = "account_invalid"
)

type Error struct {
	Code    ErrorCode
	Message string
	Cause   error
}

func (e *Error) Error() string {
	if e == nil {
		return ""
	}
	return e.Message
}

func (e *Error) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Cause
}

func filenError(code ErrorCode, message string, cause error) error {
	return &Error{Code: code, Message: message, Cause: cause}
}

func Code(err error) ErrorCode {
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return ""
}

type SecretStore interface {
	Get(string, secretvault.Kind) ([]byte, bool, error)
	Put(string, secretvault.Kind, []byte) error
	Delete(string, secretvault.Kind) error
}

type UserInfo struct {
	ID             int64
	Email          string
	IsPremium      bool
	MaxStorage     int64
	UsedStorage    int64
	BaseFolderUUID string
}

type FileRef struct {
	ID   string
	Name string
	Size int64

	handle any
}

type Session interface {
	SerializeTo(io.Writer) error
	UserInfo(context.Context) (UserInfo, error)
	BaseFolderUUID() string
	EnsureNamespace(context.Context, string) error
	Upload(context.Context, string, string, []byte) (FileRef, error)
	FindFile(context.Context, string, string) (FileRef, bool, error)
	ListFiles(context.Context, string) ([]FileRef, error)
	Download(context.Context, FileRef) ([]byte, error)
	Delete(context.Context, FileRef) error
}

type Factory interface {
	Login(context.Context, string, string, string) (Session, error)
	Deserialize([]byte) (Session, error)
}

type SDKFactory struct{}

func (SDKFactory) Login(ctx context.Context, email, password, twoFactorCode string) (Session, error) {
	code := strings.TrimSpace(twoFactorCode)
	if code == "" {
		code = "XXXXXX"
	}
	type result struct {
		api *filensdk.Filen
		err error
	}
	resultCh := make(chan result, 1)
	go func() {
		var r result
		// The official SDK selects auth v1/v2/v3 from the account response. It
		// currently performs one legacy base-folder request with a background
		// context, so keep the potentially blocking constructor off the caller
		// goroutine and enforce the connector deadline here.
		defer func() {
			if recovered := recover(); recovered != nil {
				r.err = fmt.Errorf("Filen SDK authentication version is unsupported: %v", recovered)
			}
			resultCh <- r
		}()
		r.api, r.err = filensdk.New(ctx, email, password, code)
	}()
	var resultValue result
	select {
	case resultValue = <-resultCh:
	case <-ctx.Done():
		return nil, ctx.Err()
	}
	api, err := resultValue.api, resultValue.err
	if err != nil {
		return nil, err
	}
	normalizeSDKVersions(api)
	return sdkSession{api: api}, nil
}

func (SDKFactory) Deserialize(raw []byte) (Session, error) {
	api, err := filensdk.DeserializeFrom(bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	normalizeSDKVersions(api)
	return sdkSession{api: api}, nil
}

func normalizeSDKVersions(api *filensdk.Filen) {
	if api == nil {
		return
	}
	if api.FileEncryptionVersion != 0 && api.MetadataEncryptionVersion != 0 {
		return
	}
	if api.AuthVersion >= 3 {
		api.FileEncryptionVersion = filencrypto.FileEncryptionVersion(3)
		api.MetadataEncryptionVersion = filencrypto.MetadataEncryptionVersion(3)
		return
	}
	api.FileEncryptionVersion = filensdk.V2AccountFileEncryptionVersion
	api.MetadataEncryptionVersion = filensdk.V2AccountMetadataEncryptionVersion
}

type sdkSession struct {
	api *filensdk.Filen
}

func (s sdkSession) SerializeTo(w io.Writer) error {
	return s.api.SerializeTo(w)
}

type sdkAccountInfo struct {
	Email      string `json:"email"`
	IsPremium  int    `json:"isPremium"`
	MaxStorage int64  `json:"maxStorage"`
	Storage    int64  `json:"storage"`
}

func quotaValid(total, used int64) bool {
	return total > 0 && used >= 0 && used <= total
}

func (s sdkSession) UserInfo(ctx context.Context) (UserInfo, error) {
	if s.api == nil || s.api.Client == nil {
		return UserInfo{}, errors.New("Filen SDK session is not initialized")
	}

	// Seed identity from the authenticated SDK session itself. The Go SDK's
	// /v3/user/info wrapper is still work-in-progress, while Filen's first-party
	// clients use /v3/user/account as the authoritative source for storage usage.
	// Keep both paths so an API/schema change in either endpoint does not reject
	// an otherwise valid account.
	info := UserInfo{
		Email:          strings.TrimSpace(s.api.Email),
		BaseFolderUUID: s.BaseFolderUUID(),
	}

	var userInfoErr error
	if u, err := s.api.GetUserInfo(ctx); err == nil {
		info.ID = u.ID
		if email := strings.TrimSpace(u.Email); email != "" {
			info.Email = email
		}
		info.IsPremium = u.IsPremium != 0
		info.MaxStorage = u.MaxStorage
		info.UsedStorage = u.UsedStorage
		if base := strings.TrimSpace(u.BaseFolder); base != "" {
			info.BaseFolderUUID = base
		}
	} else {
		userInfoErr = err
	}

	// /v3/user/account is the endpoint used by Filen's current first-party web
	// client for maxStorage/storage. Prefer a valid quota from it, but keep the
	// /user/info values as a fallback so older accounts/API versions continue to
	// work. This also fixes accounts for which /user/info returns a zero or stale
	// quota even though the account itself is fully usable.
	var account sdkAccountInfo
	_, accountErr := s.api.Client.RequestData(ctx, "GET", filenclient.GatewayURL("/v3/user/account"), nil, &account)
	if accountErr == nil {
		if email := strings.TrimSpace(account.Email); email != "" {
			info.Email = email
		}
		info.IsPremium = info.IsPremium || account.IsPremium != 0
		if quotaValid(account.MaxStorage, account.Storage) {
			info.MaxStorage = account.MaxStorage
			info.UsedStorage = account.Storage
		}
	}

	if userInfoErr != nil && accountErr != nil {
		return UserInfo{}, errors.Join(userInfoErr, accountErr)
	}
	return info, nil
}

func (s sdkSession) BaseFolderUUID() string {
	if s.api == nil {
		return ""
	}
	return strings.TrimSpace(s.api.BaseFolder.GetUUID())
}

func cleanNamespace(namespace string) (string, error) {
	namespace = strings.Trim(strings.TrimSpace(namespace), "/")
	if namespace == "" {
		namespace = DefaultNamespace
	}
	for _, segment := range strings.Split(namespace, "/") {
		if segment == "" || segment == "." || segment == ".." || strings.ContainsAny(segment, "\\\r\n\x00") {
			return "", errors.New("invalid Filen namespace")
		}
	}
	return namespace, nil
}

func (s sdkSession) EnsureNamespace(ctx context.Context, namespace string) error {
	namespace, err := cleanNamespace(namespace)
	if err != nil {
		return err
	}
	_, err = s.api.FindDirectoryOrCreate(ctx, namespace)
	return err
}

func (s sdkSession) Upload(ctx context.Context, namespace, name string, data []byte) (FileRef, error) {
	namespace, err := cleanNamespace(namespace)
	if err != nil {
		return FileRef{}, err
	}
	dir, err := s.api.FindDirectoryOrCreate(ctx, namespace)
	if err != nil {
		return FileRef{}, err
	}
	now := time.Now().UTC()
	incomplete, err := filentypes.NewIncompleteFile(s.api.FileEncryptionVersion, name, "application/octet-stream", now, now, dir)
	if err != nil {
		return FileRef{}, err
	}
	uploaded, err := s.api.UploadFromReader(ctx, incomplete, bytes.NewReader(data))
	if err != nil {
		return FileRef{}, err
	}
	return fileRef(uploaded), nil
}

func (s sdkSession) FindFile(ctx context.Context, namespace, name string) (FileRef, bool, error) {
	namespace, err := cleanNamespace(namespace)
	if err != nil {
		return FileRef{}, false, err
	}
	f, err := s.api.FindFile(ctx, path.Join(namespace, name))
	if err != nil {
		return FileRef{}, false, err
	}
	if f == nil {
		return FileRef{}, false, nil
	}
	return fileRef(f), true, nil
}

func (s sdkSession) ListFiles(ctx context.Context, namespace string) ([]FileRef, error) {
	namespace, err := cleanNamespace(namespace)
	if err != nil {
		return nil, err
	}
	dir, err := s.api.FindDirectory(ctx, namespace)
	if err != nil {
		return nil, err
	}
	if dir == nil {
		return []FileRef{}, nil
	}
	files, _, err := s.api.ReadDirectory(ctx, dir)
	if err != nil {
		return nil, err
	}
	out := make([]FileRef, 0, len(files))
	for _, f := range files {
		out = append(out, fileRef(f))
	}
	return out, nil
}

func (s sdkSession) Download(ctx context.Context, ref FileRef) ([]byte, error) {
	f, ok := ref.handle.(*filentypes.File)
	if !ok || f == nil {
		return nil, errors.New("invalid Filen file reference")
	}
	reader := s.api.GetDownloadReader(ctx, f)
	b, err := io.ReadAll(io.LimitReader(reader, f.Size+1))
	if err != nil {
		_ = reader.Close()
		return nil, err
	}
	if int64(len(b)) != f.Size {
		_ = reader.Close()
		return nil, fmt.Errorf("Filen file size mismatch: got %d want %d", len(b), f.Size)
	}
	if err := reader.Close(); err != nil {
		return nil, err
	}
	return b, nil
}

func (s sdkSession) Delete(ctx context.Context, ref FileRef) error {
	f, ok := ref.handle.(*filentypes.File)
	if !ok || f == nil {
		return errors.New("invalid Filen file reference")
	}
	return s.api.Client.PostV3FileDeletePermanent(ctx, f.GetUUID())
}

func fileRef(f *filentypes.File) FileRef {
	if f == nil {
		return FileRef{}
	}
	return FileRef{ID: f.UUID, Name: f.Name, Size: f.Size, handle: f}
}

type Connector struct {
	Secrets   SecretStore
	Factory   Factory
	Namespace string
}

func New(secrets SecretStore) *Connector {
	return &Connector{Secrets: secrets, Factory: SDKFactory{}, Namespace: DefaultNamespace}
}

func (c *Connector) ProviderID() string { return ProviderID }

func (c *Connector) Ready() bool {
	return c != nil && c.Secrets != nil && c.factory() != nil
}

func (c *Connector) factory() Factory {
	if c == nil {
		return nil
	}
	if c.Factory == nil {
		return SDKFactory{}
	}
	return c.Factory
}

func (c *Connector) namespace() string {
	if c == nil || strings.TrimSpace(c.Namespace) == "" {
		return DefaultNamespace
	}
	return c.Namespace
}

func (c *Connector) Login(ctx context.Context, accountID, email, password, twoFactorCode string) (connector.Snapshot, error) {
	if !c.Ready() {
		return connector.Snapshot{}, errors.New("Filen direct connector is not available")
	}
	email = strings.TrimSpace(email)
	if email == "" || password == "" {
		return connector.Snapshot{}, filenError(ErrInvalidCredentials, "Introduce el email y la contraseña de Filen.", nil)
	}
	opCtx, cancel := withDefaultTimeout(ctx, loginTimeout)
	defer cancel()
	session, err := c.factory().Login(opCtx, email, password, strings.TrimSpace(twoFactorCode))
	if err != nil {
		return connector.Snapshot{}, classifyLoginError(err, strings.TrimSpace(twoFactorCode) != "")
	}
	snap, err := c.snapshot(opCtx, accountID, session)
	if err != nil {
		return connector.Snapshot{}, err
	}
	if err := session.EnsureNamespace(opCtx, c.namespace()); err != nil {
		return connector.Snapshot{}, filenError(ErrNetwork, "No se pudo crear o localizar la carpeta VaultPool en Filen.", err)
	}
	var buf bytes.Buffer
	if err := session.SerializeTo(&buf); err != nil {
		return connector.Snapshot{}, filenError(ErrSessionInvalid, "No se pudo preparar la sesión segura de Filen.", err)
	}
	serialized := buf.Bytes()
	raw := append([]byte(nil), serialized...)
	zero(serialized)
	defer zero(raw)
	if len(raw) == 0 {
		return connector.Snapshot{}, filenError(ErrSessionInvalid, "La sesión de Filen no devolvió estado serializado.", nil)
	}
	if err := c.Secrets.Put(accountID, secretvault.FilenSession, raw); err != nil {
		return connector.Snapshot{}, fmt.Errorf("guardar sesión cifrada de Filen: %w", err)
	}
	return snap, nil
}

func (c *Connector) Probe(ctx context.Context, accountID string) (connector.Snapshot, error) {
	if !c.Ready() {
		return connector.Snapshot{}, errors.New("Filen direct connector is not available")
	}
	opCtx, cancel := withDefaultTimeout(ctx, probeTimeout)
	defer cancel()
	session, err := c.loadSession(opCtx, accountID)
	if err != nil {
		return connector.Snapshot{}, err
	}
	snap, err := c.snapshot(opCtx, accountID, session)
	if err != nil {
		return connector.Snapshot{}, err
	}
	if err := session.EnsureNamespace(opCtx, c.namespace()); err != nil {
		return connector.Snapshot{}, filenError(ErrNetwork, "No se pudo comprobar la carpeta VaultPool en Filen.", err)
	}
	return snap, nil
}

func (c *Connector) RemoteStore() remoteobject.Store {
	return &Store{Connector: c}
}

func (c *Connector) RemoteStoreFor(_ string, stableTargetID string) remoteobject.Store {
	return &Store{Connector: c, ExpectedTargetID: strings.TrimSpace(stableTargetID)}
}

func (c *Connector) Logout(accountID string) error {
	if c == nil || c.Secrets == nil {
		return errors.New("Filen direct connector is not available")
	}
	var errs []error
	if err := c.Secrets.Delete(accountID, secretvault.FilenSession); err != nil {
		errs = append(errs, err)
	}
	if err := c.Secrets.Delete(accountID, secretvault.AccountIdentity); err != nil {
		errs = append(errs, err)
	}
	return errors.Join(errs...)
}

func (c *Connector) loadSession(ctx context.Context, accountID string) (Session, error) {
	raw, ok, err := c.Secrets.Get(accountID, secretvault.FilenSession)
	if err != nil {
		return nil, err
	}
	if !ok || len(raw) == 0 {
		return nil, filenError(ErrSessionInvalid, "No se pudo renovar la sesión de Filen. Inicia sesión de nuevo.", nil)
	}
	defer zero(raw)
	session, err := c.factory().Deserialize(raw)
	if err != nil {
		return nil, filenError(ErrSessionInvalid, "No se pudo renovar la sesión de Filen. Inicia sesión de nuevo.", err)
	}
	return session, nil
}

func (c *Connector) snapshot(ctx context.Context, accountID string, session Session) (connector.Snapshot, error) {
	info, err := session.UserInfo(ctx)
	if err != nil {
		return connector.Snapshot{}, classifySessionError(err)
	}
	if strings.TrimSpace(info.BaseFolderUUID) == "" {
		info.BaseFolderUUID = session.BaseFolderUUID()
	}
	if strings.TrimSpace(info.Email) == "" {
		return connector.Snapshot{}, filenError(ErrAccountInvalid, "Filen autenticó la cuenta, pero no devolvió una identidad de usuario válida.", nil)
	}
	if strings.TrimSpace(info.BaseFolderUUID) == "" {
		return connector.Snapshot{}, filenError(ErrAccountInvalid, "Filen autenticó la cuenta, pero no devolvió la carpeta raíz de almacenamiento.", nil)
	}
	if info.MaxStorage <= 0 {
		return connector.Snapshot{}, filenError(ErrAccountInvalid, "Filen autenticó la cuenta, pero no devolvió una cuota total de almacenamiento utilizable.", nil)
	}
	if info.UsedStorage < 0 {
		return connector.Snapshot{}, filenError(ErrAccountInvalid, "Filen devolvió un uso de almacenamiento no válido.", nil)
	}
	if info.UsedStorage > info.MaxStorage {
		return connector.Snapshot{}, filenError(ErrAccountInvalid, "Filen devolvió un uso de almacenamiento superior a la cuota total.", nil)
	}
	plan := "Filen"
	if info.IsPremium {
		plan = "Filen Premium"
	}
	snap := connector.Snapshot{
		ProviderID:      ProviderID,
		AccountID:       accountID,
		ProviderSubject: stableSubject(info),
		Identity:        strings.TrimSpace(info.Email),
		PlanName:        plan,
		Auth:            connector.Authenticated,
		Health:          connector.HealthOK,
		Transfer:        connector.TransferReady,
		TotalBytes:      info.MaxStorage,
		UsedBytes:       info.UsedStorage,
		FreeBytes:       info.MaxStorage - info.UsedStorage,
		Limits: connector.Limits{
			UploadLimitNote:   "Sujeto a la cuota y límites oficiales de la cuenta Filen.",
			DownloadLimitNote: "Sujeto a la cuota y límites oficiales de la cuenta Filen.",
			RateLimitNote:     "VaultPool respeta el rate limiting de Filen y no intenta eludirlo.",
		},
		LastChecked: time.Now().UTC().Format(time.RFC3339Nano),
		StatusNote:  "Sesión directa de Filen, identidad y cuota verificadas mediante SDK oficial.",
	}
	return snap, snap.Validate()
}

func stableSubject(info UserInfo) string {
	base := strings.TrimSpace(info.BaseFolderUUID)
	if info.ID > 0 {
		return fmt.Sprintf("user:%d\x00base:%s", info.ID, base)
	}
	return "email:" + strings.ToLower(strings.TrimSpace(info.Email)) + "\x00base:" + base
}

func classifyLoginError(err error, submittedTwoFactor bool) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled) {
		return filenError(ErrNetwork, "La conexión con Filen tardó demasiado y fue cancelada.", err)
	}
	msg := strings.ToLower(err.Error())
	switch {
	case strings.Contains(msg, "rate") || strings.Contains(msg, "too many") || strings.Contains(msg, "429"):
		return filenError(ErrRateLimited, "Filen limitó temporalmente el inicio de sesión. Espera y vuelve a intentarlo.", err)
	case strings.Contains(msg, "2fa") || strings.Contains(msg, "twofactor") || strings.Contains(msg, "two factor") || strings.Contains(msg, "otp") || strings.Contains(msg, "mfa"):
		if submittedTwoFactor {
			return filenError(ErrTwoFactorInvalid, "El código de verificación de Filen no es válido.", err)
		}
		return filenError(ErrTwoFactorRequired, "Introduce tu código de verificación de Filen.", err)
	case strings.Contains(msg, "auth") || strings.Contains(msg, "login") || strings.Contains(msg, "password") || strings.Contains(msg, "credential") || strings.Contains(msg, "unauthorized") || strings.Contains(msg, "forbidden"):
		return filenError(ErrInvalidCredentials, "Email o contraseña de Filen incorrectos.", err)
	default:
		return filenError(ErrNetwork, "No se pudo completar el inicio de sesión directo con Filen.", err)
	}
}

func classifySessionError(err error) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled) {
		return filenError(ErrNetwork, "La comprobación de Filen tardó demasiado y fue cancelada.", err)
	}
	msg := strings.ToLower(err.Error())
	if strings.Contains(msg, "unauthorized") || strings.Contains(msg, "forbidden") || strings.Contains(msg, "api key") || strings.Contains(msg, "auth") {
		return filenError(ErrSessionInvalid, "No se pudo renovar la sesión de Filen. Inicia sesión de nuevo.", err)
	}
	if strings.Contains(msg, "rate") || strings.Contains(msg, "too many") || strings.Contains(msg, "429") {
		return filenError(ErrRateLimited, "Filen limitó temporalmente la comprobación. Espera y vuelve a intentarlo.", err)
	}
	return filenError(ErrNetwork, "No se pudo consultar Filen.", err)
}

func withDefaultTimeout(ctx context.Context, timeout time.Duration) (context.Context, context.CancelFunc) {
	if ctx == nil {
		ctx = context.Background()
	}
	if _, ok := ctx.Deadline(); ok {
		return context.WithCancel(ctx)
	}
	return context.WithTimeout(ctx, timeout)
}

func transferTimeout(size int64) time.Duration {
	if size < 0 {
		size = 0
	}
	timeout := 2*time.Minute + time.Duration(size/(32<<20))*time.Minute
	if timeout > 30*time.Minute {
		return 30 * time.Minute
	}
	return timeout
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
