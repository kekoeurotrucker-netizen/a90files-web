//go:build windows

package player

import (
	"os/exec"
	"syscall"
)

const createNoWindow = 0x08000000

func hiddenProcAttr() *syscall.SysProcAttr {
	return &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
}

func openDefault(path string) error {
	cmd := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", path)
	cmd.SysProcAttr = hiddenProcAttr()
	return cmd.Start()
}
