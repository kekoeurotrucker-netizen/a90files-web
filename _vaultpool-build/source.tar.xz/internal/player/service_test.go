package player

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
)

type streamTestFiles struct {
	meta managedfiles.Metadata
	data []byte
}

func (f *streamTestFiles) Get(fileID string) (managedfiles.Metadata, bool, error) {
	if fileID != f.meta.FileID {
		return managedfiles.Metadata{}, false, nil
	}
	return f.meta, true, nil
}

func (f *streamTestFiles) ReadRange(_ context.Context, fileID string, offset int64, length int) ([]byte, error) {
	if fileID != f.meta.FileID || offset < 0 || offset >= int64(len(f.data)) || length < 0 {
		return nil, context.Canceled
	}
	end := offset + int64(length)
	if end > int64(len(f.data)) {
		end = int64(len(f.data))
	}
	return append([]byte(nil), f.data[offset:end]...), nil
}

func (f *streamTestFiles) RestoreToPath(context.Context, string, string, core.ProgressFunc) error {
	return context.Canceled
}

func TestParseByteRange(t *testing.T) {
	tests := []struct {
		name    string
		header  string
		start   int64
		length  int64
		partial bool
		wantErr bool
	}{
		{name: "full", header: "", start: 0, length: 1000},
		{name: "closed", header: "bytes=100-199", start: 100, length: 100, partial: true},
		{name: "open", header: "bytes=900-", start: 900, length: 100, partial: true},
		{name: "suffix", header: "bytes=-80", start: 920, length: 80, partial: true},
		{name: "clamped", header: "bytes=950-2000", start: 950, length: 50, partial: true},
		{name: "multiple", header: "bytes=0-10,20-30", wantErr: true},
		{name: "outside", header: "bytes=1000-", wantErr: true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			start, length, partial, err := parseByteRange(tc.header, 1000)
			if (err != nil) != tc.wantErr {
				t.Fatalf("error = %v, wantErr %v", err, tc.wantErr)
			}
			if err != nil {
				return
			}
			if start != tc.start || length != tc.length || partial != tc.partial {
				t.Fatalf("got start=%d length=%d partial=%v, want %d %d %v", start, length, partial, tc.start, tc.length, tc.partial)
			}
		})
	}
}

func TestStreamChunkCount(t *testing.T) {
	if got := streamChunkCount(0, defaultStreamChunkBytes); got != 0 {
		t.Fatalf("zero-size file has %d chunks", got)
	}
	if got := streamChunkCount(defaultStreamChunkBytes+1, defaultStreamChunkBytes); got != 2 {
		t.Fatalf("got %d chunks, want 2", got)
	}
}

func TestStreamChunkSizeUsesManifestGeometry(t *testing.T) {
	if got := streamChunkSize(managedfiles.Metadata{BlockSize: 1 << 20}); got != 1<<20 {
		t.Fatalf("got %d, want 1 MiB", got)
	}
	if got := streamChunkSize(managedfiles.Metadata{}); got != legacyStreamChunkBytes {
		t.Fatalf("got %d, want legacy chunk size %d", got, legacyStreamChunkBytes)
	}
}

func TestStreamServesRangeWithoutFullRestore(t *testing.T) {
	data := bytes.Repeat([]byte("vaultpool-stream"), 512)
	files := &streamTestFiles{
		meta: managedfiles.Metadata{FileID: "stream-test", FileName: "sample.mp4", OriginalSize: int64(len(data)), BlockSize: 1024},
		data: data,
	}
	svc, err := New(files, t.TempDir()+"/cache", t.TempDir()+"/plugins")
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodGet, "/api/player/stream-test/stream", nil)
	req.Header.Set("Range", "bytes=17-96")
	res := httptest.NewRecorder()
	if err := svc.Stream(res, req, "stream-test"); err != nil {
		t.Fatal(err)
	}
	if res.Code != http.StatusPartialContent {
		t.Fatalf("status = %d, want %d", res.Code, http.StatusPartialContent)
	}
	if got := res.Body.Bytes(); !bytes.Equal(got, data[17:97]) {
		t.Fatal("streamed bytes do not match requested range")
	}
	st, err := svc.Status("stream-test")
	if err != nil {
		t.Fatal(err)
	}
	if !st.Streaming || st.StartsAfterComplete {
		t.Fatalf("unexpected streaming status: %+v", st)
	}
}
