//go:build !windows

package player

import (
	"os/exec"
	"runtime"
	"syscall"
)

func hiddenProcAttr() *syscall.SysProcAttr { return nil }

func openDefault(path string) error {
	name := "xdg-open"
	if runtime.GOOS == "darwin" {
		name = "open"
	}
	cmd := exec.Command(name, path)
	return cmd.Start()
}
