package player

import (
	"archive/zip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
)

const (
	StateIdle      = "idle"
	StatePreparing = "preparing"
	StateReady     = "ready"
	StateFailed    = "failed"

	vlcID      = "vlc"
	vlcName    = "VLC portable"
	vlcVersion = "3.0.23"
	vlcURL     = "https://get.videolan.org/vlc/3.0.23/win64/vlc-3.0.23-win64.zip"
	vlcSHA256  = "26d556648d4a67e8938d6d4b4d99ba0359f1979bfef985c8f6710882c7ed5975"

	maxPluginDownloadBytes     = 140 << 20
	maxPluginUncompressedBytes = 520 << 20
	defaultStreamChunkBytes    = int64(1 << 20)
	legacyStreamChunkBytes     = int64(4 << 20)
	initialPrefetchChunks      = 1
	streamPrefetchChunks       = 3
)

type FileManager interface {
	Get(fileID string) (managedfiles.Metadata, bool, error)
	ReadRange(ctx context.Context, fileID string, offset int64, length int) ([]byte, error)
	RestoreToPath(ctx context.Context, fileID, out string, progress core.ProgressFunc) error
}

type Status struct {
	FileID              string       `json:"file_id"`
	FileName            string       `json:"file_name,omitempty"`
	Extension           string       `json:"extension,omitempty"`
	MIME                string       `json:"mime,omitempty"`
	State               string       `json:"state"`
	Phase               string       `json:"phase,omitempty"`
	Video               bool         `json:"video"`
	IntegratedCandidate bool         `json:"integrated_candidate"`
	ExternalRecommended bool         `json:"external_recommended"`
	BytesProcessed      int64        `json:"bytes_processed,omitempty"`
	BytesTotal          int64        `json:"bytes_total,omitempty"`
	ProgressPercent     float64      `json:"progress_percent,omitempty"`
	BytesPerSecond      float64      `json:"bytes_per_second,omitempty"`
	ETASeconds          int64        `json:"eta_seconds,omitempty"`
	ElapsedSeconds      int64        `json:"elapsed_seconds,omitempty"`
	BlocksDone          int          `json:"blocks_done,omitempty"`
	BlocksTotal         int          `json:"blocks_total,omitempty"`
	Streaming           bool         `json:"streaming"`
	CacheBytes          int64        `json:"cache_bytes,omitempty"`
	CacheChunks         int          `json:"cache_chunks,omitempty"`
	CacheChunksTotal    int64        `json:"cache_chunks_total,omitempty"`
	StartsAfterComplete bool         `json:"starts_after_complete"`
	StreamURL           string       `json:"stream_url,omitempty"`
	Error               string       `json:"error,omitempty"`
	Plugin              PluginStatus `json:"plugin"`
}

type PluginStatus struct {
	ID              string `json:"id"`
	Name            string `json:"name"`
	Version         string `json:"version"`
	SourceURL       string `json:"source_url"`
	SHA256          string `json:"sha256"`
	Installed       bool   `json:"installed"`
	Installing      bool   `json:"installing"`
	BytesDownloaded int64  `json:"bytes_downloaded,omitempty"`
	BytesTotal      int64  `json:"bytes_total,omitempty"`
	Error           string `json:"error,omitempty"`
}

type entry struct {
	meta           managedfiles.Metadata
	path           string
	extension      string
	mime           string
	state          string
	phase          string
	streaming      bool
	blocksDone     int
	blocksTotal    int
	bytesProcessed int64
	bytesTotal     int64
	chunkDir       string
	chunkBytes     int64
	cacheBytes     int64
	cacheChunks    int
	inflight       map[int64]*chunkFlight
	err            string
	cancel         context.CancelFunc
	startedAt      time.Time
	finishedAt     time.Time
}

type chunkFlight struct {
	done chan struct{}
	err  error
}

type pluginInstall struct {
	installing      bool
	bytesDownloaded int64
	bytesTotal      int64
	err             string
}

type Service struct {
	files      FileManager
	cacheRoot  string
	pluginRoot string
	client     *http.Client
	baseURL    string

	mu      sync.Mutex
	entries map[string]*entry
	plugin  pluginInstall
}

func (s *Service) SetBaseURL(base string) {
	s.mu.Lock()
	s.baseURL = strings.TrimRight(strings.TrimSpace(base), "/")
	s.mu.Unlock()
}

func New(files FileManager, cacheRoot, pluginRoot string) (*Service, error) {
	if files == nil {
		return nil, errors.New("managed file service required")
	}
	cacheRoot = filepath.Clean(strings.TrimSpace(cacheRoot))
	pluginRoot = filepath.Clean(strings.TrimSpace(pluginRoot))
	if err := safePrivateDir(cacheRoot); err != nil {
		return nil, fmt.Errorf("media cache: %w", err)
	}
	if err := safePrivateDir(pluginRoot); err != nil {
		return nil, fmt.Errorf("media plugins: %w", err)
	}
	if err := os.RemoveAll(cacheRoot); err != nil {
		return nil, err
	}
	if err := os.MkdirAll(cacheRoot, 0o700); err != nil {
		return nil, err
	}
	if err := os.MkdirAll(pluginRoot, 0o700); err != nil {
		return nil, err
	}
	return &Service{
		files:      files,
		cacheRoot:  cacheRoot,
		pluginRoot: pluginRoot,
		client:     &http.Client{Timeout: 10 * time.Minute},
		entries:    map[string]*entry{},
	}, nil
}

func safePrivateDir(path string) error {
	if path == "" || path == "." {
		return errors.New("path required")
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return err
	}
	vol := filepath.VolumeName(abs)
	root := vol + string(os.PathSeparator)
	if runtime.GOOS != "windows" && vol == "" {
		root = string(os.PathSeparator)
	}
	if abs == root || filepath.Dir(abs) == abs {
		return fmt.Errorf("refusing unsafe root path %q", abs)
	}
	return nil
}

func IsVideo(name string) bool {
	_, ok := videoMIME(filepath.Ext(name))
	return ok
}

func IntegratedCandidate(name string) bool {
	return integratedExt(filepath.Ext(name))
}

func videoMIME(ext string) (string, bool) {
	ext = strings.ToLower(strings.TrimSpace(ext))
	switch ext {
	case ".mp4", ".m4v":
		return "video/mp4", true
	case ".mov":
		return "video/quicktime", true
	case ".webm":
		return "video/webm", true
	case ".avi":
		return "video/x-msvideo", true
	case ".mpg", ".mpeg":
		return "video/mpeg", true
	case ".ogv", ".ogg":
		return "video/ogg", true
	case ".3gp":
		return "video/3gpp", true
	case ".3g2":
		return "video/3gpp2", true
	case ".ts", ".m2ts", ".mts":
		return "video/mp2t", true
	case ".mkv":
		return "video/x-matroska", true
	case ".wmv":
		return "video/x-ms-wmv", true
	case ".flv":
		return "video/x-flv", true
	default:
		if mt := mime.TypeByExtension(ext); strings.HasPrefix(mt, "video/") {
			return strings.Split(mt, ";")[0], true
		}
		return "", false
	}
}

func integratedExt(ext string) bool {
	switch strings.ToLower(strings.TrimSpace(ext)) {
	case ".mp4", ".m4v", ".mov", ".webm", ".avi", ".mpg", ".mpeg", ".ogv", ".ogg", ".3gp", ".3g2", ".ts":
		return true
	default:
		return false
	}
}

func cleanExt(name string) string {
	ext := strings.ToLower(filepath.Ext(strings.TrimSpace(name)))
	if len(ext) > 16 || strings.ContainsAny(ext, `\/:`) {
		return ".bin"
	}
	if ext == "" {
		return ".bin"
	}
	return ext
}

func (s *Service) cachePath(fileID, ext string) string {
	return filepath.Join(s.cacheRoot, fileID+cleanExt(ext))
}

func (s *Service) chunkDir(fileID string) string {
	return filepath.Join(s.cacheRoot, "chunks", fileID)
}

func (s *Service) chunkPath(fileID string, index int64) string {
	return filepath.Join(s.chunkDir(fileID), fmt.Sprintf("%08d.part", index))
}

func streamChunkSize(meta managedfiles.Metadata) int64 {
	if meta.BlockSize > 0 {
		return int64(meta.BlockSize)
	}
	// Catalogs created before block size was recorded used the 4 MiB default.
	return legacyStreamChunkBytes
}

func streamChunkCount(size, chunkBytes int64) int64 {
	if size <= 0 || chunkBytes <= 0 {
		return 0
	}
	return (size + chunkBytes - 1) / chunkBytes
}

func (s *Service) Prepare(fileID string) (Status, error) {
	fileID = strings.TrimSpace(fileID)
	meta, ok, err := s.files.Get(fileID)
	if err != nil {
		return Status{}, err
	}
	if !ok {
		return Status{}, errors.New("managed file not found")
	}
	mimeType, video := videoMIME(filepath.Ext(meta.FileName))
	if !video {
		return Status{}, errors.New("este archivo no parece ser un vídeo compatible")
	}
	ext := cleanExt(meta.FileName)
	path := s.cachePath(meta.FileID, ext)

	s.mu.Lock()
	if e := s.entries[meta.FileID]; e != nil {
		out := s.statusLocked(e)
		s.mu.Unlock()
		return out, nil
	}
	if st, statErr := os.Stat(path); statErr == nil && !st.IsDir() && st.Size() == meta.OriginalSize && meta.OriginalSize > 0 {
		e := &entry{meta: meta, path: path, extension: ext, mime: mimeType, state: StateReady, bytesProcessed: st.Size(), bytesTotal: meta.OriginalSize, finishedAt: time.Now().UTC(), inflight: map[int64]*chunkFlight{}}
		s.entries[meta.FileID] = e
		out := s.statusLocked(e)
		s.mu.Unlock()
		return out, nil
	}
	if integratedExt(ext) && meta.OriginalSize > 0 {
		chunkDir := s.chunkDir(meta.FileID)
		if err := os.MkdirAll(chunkDir, 0o700); err != nil {
			s.mu.Unlock()
			return Status{}, err
		}
		e := &entry{
			meta:       meta,
			path:       path,
			extension:  ext,
			mime:       mimeType,
			state:      StateReady,
			phase:      "streaming",
			streaming:  true,
			bytesTotal: meta.OriginalSize,
			chunkDir:   chunkDir,
			chunkBytes: streamChunkSize(meta),
			inflight:   map[int64]*chunkFlight{},
			startedAt:  time.Now().UTC(),
		}
		s.entries[meta.FileID] = e
		out := s.statusLocked(e)
		s.mu.Unlock()
		go s.prefetchFrom(meta.FileID, 0, initialPrefetchChunks)
		return out, nil
	}
	ctx, cancel := context.WithCancel(context.Background())
	e := &entry{meta: meta, path: path, extension: ext, mime: mimeType, state: StatePreparing, phase: "queued", bytesTotal: meta.OriginalSize, cancel: cancel, startedAt: time.Now().UTC()}
	s.entries[meta.FileID] = e
	out := s.statusLocked(e)
	s.mu.Unlock()

	go s.restoreToCache(ctx, meta.FileID)
	return out, nil
}

func (s *Service) restoreToCache(ctx context.Context, fileID string) {
	s.mu.Lock()
	e := s.entries[fileID]
	if e == nil {
		s.mu.Unlock()
		return
	}
	path := e.path
	s.mu.Unlock()

	err := s.files.RestoreToPath(ctx, fileID, path, func(p core.TransferProgress) {
		s.mu.Lock()
		defer s.mu.Unlock()
		e := s.entries[fileID]
		if e == nil || e.state != StatePreparing {
			return
		}
		if strings.TrimSpace(p.Phase) != "" {
			e.phase = p.Phase
		}
		if p.BlocksDone > 0 {
			e.blocksDone = p.BlocksDone
		}
		if p.BlocksTotal > 0 {
			e.blocksTotal = p.BlocksTotal
		}
		if p.BytesProcessed > 0 {
			e.bytesProcessed = p.BytesProcessed
		}
		if p.BytesTotal > 0 {
			e.bytesTotal = p.BytesTotal
		}
	})

	s.mu.Lock()
	defer s.mu.Unlock()
	e = s.entries[fileID]
	if e == nil {
		return
	}
	e.cancel = nil
	e.finishedAt = time.Now().UTC()
	if err != nil {
		e.state = StateFailed
		e.phase = "failed"
		e.err = err.Error()
		_ = os.Remove(path)
		return
	}
	if st, statErr := os.Stat(path); statErr == nil {
		e.bytesProcessed = st.Size()
		if e.bytesTotal == 0 {
			e.bytesTotal = st.Size()
		}
	}
	e.state = StateReady
	e.phase = "ready"
	e.err = ""
}

func (s *Service) Status(fileID string) (Status, error) {
	fileID = strings.TrimSpace(fileID)
	s.mu.Lock()
	if e := s.entries[fileID]; e != nil {
		out := s.statusLocked(e)
		s.mu.Unlock()
		return out, nil
	}
	s.mu.Unlock()

	meta, ok, err := s.files.Get(fileID)
	if err != nil {
		return Status{}, err
	}
	if !ok {
		return Status{}, errors.New("managed file not found")
	}
	mimeType, video := videoMIME(filepath.Ext(meta.FileName))
	ext := cleanExt(meta.FileName)
	st := Status{
		FileID:              meta.FileID,
		FileName:            meta.FileName,
		Extension:           ext,
		MIME:                mimeType,
		State:               StateIdle,
		Video:               video,
		IntegratedCandidate: video && integratedExt(ext),
		ExternalRecommended: video && !integratedExt(ext),
		BytesTotal:          meta.OriginalSize,
		StartsAfterComplete: !(video && integratedExt(ext)),
		Plugin:              s.PluginStatus(vlcID),
	}
	if video {
		path := s.cachePath(meta.FileID, ext)
		if file, statErr := os.Stat(path); statErr == nil && !file.IsDir() && file.Size() == meta.OriginalSize {
			st.State = StateReady
			st.BytesProcessed = file.Size()
			fillProgressStats(&st, time.Time{}, time.Time{})
			st.StreamURL = "/api/player/" + meta.FileID + "/stream"
		}
	}
	return st, nil
}

func (s *Service) statusLocked(e *entry) Status {
	st := Status{
		FileID:              e.meta.FileID,
		FileName:            e.meta.FileName,
		Extension:           e.extension,
		MIME:                e.mime,
		State:               e.state,
		Phase:               e.phase,
		Video:               true,
		IntegratedCandidate: integratedExt(e.extension),
		ExternalRecommended: !integratedExt(e.extension),
		BytesProcessed:      e.bytesProcessed,
		BytesTotal:          e.bytesTotal,
		BlocksDone:          e.blocksDone,
		BlocksTotal:         e.blocksTotal,
		Streaming:           e.streaming,
		CacheBytes:          e.cacheBytes,
		CacheChunks:         e.cacheChunks,
		CacheChunksTotal:    streamChunkCount(e.meta.OriginalSize, e.chunkBytes),
		StartsAfterComplete: !e.streaming,
		Error:               e.err,
		Plugin:              s.PluginStatusLocked(),
	}
	fillProgressStats(&st, e.startedAt, e.finishedAt)
	if e.state == StateReady {
		st.StreamURL = "/api/player/" + e.meta.FileID + "/stream"
	}
	return st
}

func fillProgressStats(st *Status, startedAt, finishedAt time.Time) {
	if st.BytesTotal > 0 && st.BytesProcessed > 0 {
		st.ProgressPercent = float64(st.BytesProcessed) / float64(st.BytesTotal) * 100
		if st.ProgressPercent > 100 {
			st.ProgressPercent = 100
		}
	}
	if startedAt.IsZero() {
		return
	}
	until := time.Now().UTC()
	if !finishedAt.IsZero() {
		until = finishedAt
	}
	elapsed := until.Sub(startedAt)
	if elapsed <= 0 {
		return
	}
	st.ElapsedSeconds = int64(elapsed.Round(time.Second).Seconds())
	if st.BytesProcessed <= 0 {
		return
	}
	st.BytesPerSecond = float64(st.BytesProcessed) / elapsed.Seconds()
	if st.State == StatePreparing && st.BytesTotal > st.BytesProcessed && st.BytesPerSecond > 0 {
		st.ETASeconds = int64((float64(st.BytesTotal-st.BytesProcessed) / st.BytesPerSecond) + 0.5)
	}
}

func parseByteRange(value string, total int64) (start, length int64, partial bool, err error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return 0, total, false, nil
	}
	if total <= 0 || !strings.HasPrefix(strings.ToLower(value), "bytes=") {
		return 0, 0, false, errors.New("rango HTTP no válido")
	}
	spec := strings.TrimSpace(value[len("bytes="):])
	if strings.Contains(spec, ",") {
		return 0, 0, false, errors.New("solo se admite un rango HTTP")
	}
	parts := strings.SplitN(spec, "-", 2)
	if len(parts) != 2 {
		return 0, 0, false, errors.New("rango HTTP no válido")
	}
	left, right := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
	if left == "" {
		suffix, parseErr := strconv.ParseInt(right, 10, 64)
		if parseErr != nil || suffix <= 0 {
			return 0, 0, false, errors.New("rango HTTP no válido")
		}
		if suffix > total {
			suffix = total
		}
		return total - suffix, suffix, true, nil
	}
	start, parseErr := strconv.ParseInt(left, 10, 64)
	if parseErr != nil || start < 0 || start >= total {
		return 0, 0, false, errors.New("rango HTTP fuera de límites")
	}
	end := total - 1
	if right != "" {
		end, parseErr = strconv.ParseInt(right, 10, 64)
		if parseErr != nil || end < start {
			return 0, 0, false, errors.New("rango HTTP no válido")
		}
		if end >= total {
			end = total - 1
		}
	}
	return start, end - start + 1, true, nil
}

func (s *Service) Stream(w http.ResponseWriter, r *http.Request, fileID string) error {
	fileID = strings.TrimSpace(fileID)
	st, err := s.Prepare(fileID)
	if err != nil {
		return err
	}
	if !st.Video || st.BytesTotal <= 0 {
		return errors.New("vídeo no disponible para streaming")
	}
	start, length, partial, err := parseByteRange(r.Header.Get("Range"), st.BytesTotal)
	if err != nil {
		w.Header().Set("Content-Range", fmt.Sprintf("bytes */%d", st.BytesTotal))
		w.WriteHeader(http.StatusRequestedRangeNotSatisfiable)
		return err
	}
	end := start + length - 1
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Pragma", "no-cache")
	w.Header().Set("Accept-Ranges", "bytes")
	w.Header().Set("Content-Type", st.MIME)
	w.Header().Set("Content-Disposition", mime.FormatMediaType("inline", map[string]string{"filename": st.FileName}))
	w.Header().Set("Content-Length", strconv.FormatInt(length, 10))
	if partial {
		w.Header().Set("Content-Range", fmt.Sprintf("bytes %d-%d/%d", start, end, st.BytesTotal))
		w.WriteHeader(http.StatusPartialContent)
	}
	if r.Method == http.MethodHead {
		return nil
	}
	return s.writeStreamRange(r.Context(), w, fileID, start, length)
}

func (s *Service) writeStreamRange(ctx context.Context, w http.ResponseWriter, fileID string, start, length int64) error {
	s.mu.Lock()
	e := s.entries[fileID]
	chunkBytes := defaultStreamChunkBytes
	if e != nil && e.chunkBytes > 0 {
		chunkBytes = e.chunkBytes
	}
	s.mu.Unlock()
	firstChunk := start / chunkBytes
	go s.prefetchFrom(fileID, firstChunk+1, streamPrefetchChunks)
	end := start + length
	position := start
	for position < end {
		index := position / chunkBytes
		data, err := s.getChunk(ctx, fileID, index)
		if err != nil {
			return err
		}
		chunkStart := index * chunkBytes
		from := position - chunkStart
		to := int64(len(data))
		if chunkStart+to > end {
			to = end - chunkStart
		}
		if from < 0 || from >= to || to > int64(len(data)) {
			wipeBytes(data)
			return errors.New("bloque de streaming fuera de límites")
		}
		_, writeErr := w.Write(data[from:to])
		wipeBytes(data)
		if writeErr != nil {
			return writeErr
		}
		position = chunkStart + to
		if flusher, ok := w.(http.Flusher); ok {
			flusher.Flush()
		}
	}
	return nil
}

func (s *Service) getChunk(ctx context.Context, fileID string, index int64) ([]byte, error) {
	if index < 0 {
		return nil, errors.New("índice de bloque inválido")
	}
	s.mu.Lock()
	e := s.entries[fileID]
	if e == nil || !e.streaming {
		s.mu.Unlock()
		return nil, errors.New("streaming no preparado")
	}
	total := e.meta.OriginalSize
	chunkDir := e.chunkDir
	chunkBytes := e.chunkBytes
	flight := e.inflight[index]
	s.mu.Unlock()
	if chunkBytes <= 0 {
		chunkBytes = defaultStreamChunkBytes
	}
	count := streamChunkCount(total, chunkBytes)
	if index >= count {
		return nil, errors.New("bloque de streaming fuera de límites")
	}
	expected := chunkBytes
	if remaining := total - index*chunkBytes; remaining < expected {
		expected = remaining
	}
	path := filepath.Join(chunkDir, fmt.Sprintf("%08d.part", index))
	if data, ok := readExactChunk(path, expected); ok {
		return data, nil
	}
	if flight != nil {
		select {
		case <-flight.done:
			if flight.err != nil {
				return nil, flight.err
			}
			return s.getChunk(ctx, fileID, index)
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}

	s.mu.Lock()
	e = s.entries[fileID]
	if e == nil || !e.streaming {
		s.mu.Unlock()
		return nil, errors.New("streaming no preparado")
	}
	if existing := e.inflight[index]; existing != nil {
		s.mu.Unlock()
		select {
		case <-existing.done:
			if existing.err != nil {
				return nil, existing.err
			}
			return s.getChunk(ctx, fileID, index)
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}
	flight = &chunkFlight{done: make(chan struct{})}
	e.inflight[index] = flight
	s.mu.Unlock()

	data, fetchErr := s.files.ReadRange(ctx, fileID, index*chunkBytes, int(expected))
	if fetchErr == nil && int64(len(data)) != expected {
		fetchErr = fmt.Errorf("el proveedor devolvió %d bytes; se esperaban %d", len(data), expected)
	}
	if fetchErr == nil {
		if err := os.MkdirAll(chunkDir, 0o700); err != nil {
			fetchErr = err
		} else {
			tmp := path + ".tmp"
			if err := os.WriteFile(tmp, data, 0o600); err != nil {
				fetchErr = err
			} else if err := os.Rename(tmp, path); err != nil {
				_ = os.Remove(tmp)
				fetchErr = err
			}
		}
	}

	s.mu.Lock()
	if current := s.entries[fileID]; current != nil {
		if fetchErr == nil {
			current.cacheBytes += int64(len(data))
			current.cacheChunks++
			current.bytesProcessed = current.cacheBytes
		}
		if currentFlight := current.inflight[index]; currentFlight == flight {
			flight.err = fetchErr
			delete(current.inflight, index)
			close(flight.done)
		}
	} else {
		flight.err = fetchErr
		close(flight.done)
	}
	s.mu.Unlock()
	if fetchErr != nil {
		wipeBytes(data)
		return nil, fetchErr
	}
	return data, nil
}

func readExactChunk(path string, expected int64) ([]byte, bool) {
	st, err := os.Stat(path)
	if err != nil || st.IsDir() || st.Size() != expected {
		return nil, false
	}
	data, err := os.ReadFile(path)
	if err != nil || int64(len(data)) != expected {
		wipeBytes(data)
		return nil, false
	}
	return data, true
}

func (s *Service) prefetchFrom(fileID string, first int64, wanted int64) {
	if first < 0 {
		first = 0
	}
	if wanted <= 0 {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	s.mu.Lock()
	e := s.entries[fileID]
	if e == nil || !e.streaming {
		s.mu.Unlock()
		return
	}
	count := streamChunkCount(e.meta.OriginalSize, e.chunkBytes)
	s.mu.Unlock()
	last := first + wanted
	if last > count {
		last = count
	}
	var wg sync.WaitGroup
	for index := first; index < last; index++ {
		index := index
		wg.Add(1)
		go func() {
			defer wg.Done()
			data, err := s.getChunk(ctx, fileID, index)
			if err == nil {
				wipeBytes(data)
			}
		}()
	}
	wg.Wait()
}

func wipeBytes(data []byte) {
	for i := range data {
		data[i] = 0
	}
}

func (s *Service) Open(fileID string) (*os.File, Status, error) {
	fileID = strings.TrimSpace(fileID)
	s.mu.Lock()
	e := s.entries[fileID]
	if e == nil {
		s.mu.Unlock()
		st, err := s.Status(fileID)
		if err != nil {
			return nil, Status{}, err
		}
		return nil, st, errors.New("video cache is not prepared")
	}
	st := s.statusLocked(e)
	path := e.path
	streaming := e.streaming
	s.mu.Unlock()
	if st.State != StateReady {
		return nil, st, errors.New("video cache is not ready")
	}
	if streaming {
		return nil, st, errors.New("este vídeo se reproduce por streaming; no necesita una copia completa")
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, st, err
	}
	return f, st, nil
}

func (s *Service) Clear(fileID string) error {
	fileID = strings.TrimSpace(fileID)
	s.mu.Lock()
	e := s.entries[fileID]
	if e != nil && e.cancel != nil {
		e.cancel()
	}
	delete(s.entries, fileID)
	s.mu.Unlock()
	if fileID != "" {
		matches, _ := filepath.Glob(filepath.Join(s.cacheRoot, fileID+".*"))
		for _, p := range matches {
			_ = os.Remove(p)
		}
		_ = os.RemoveAll(filepath.Join(s.cacheRoot, "chunks", fileID))
	}
	return nil
}

func (s *Service) ClearAll() error {
	s.mu.Lock()
	for _, e := range s.entries {
		if e.cancel != nil {
			e.cancel()
		}
	}
	s.entries = map[string]*entry{}
	s.mu.Unlock()
	if err := os.RemoveAll(s.cacheRoot); err != nil {
		return err
	}
	return os.MkdirAll(s.cacheRoot, 0o700)
}

func (s *Service) OpenDefault(fileID string) error {
	path, err := s.readyPath(fileID)
	if err != nil {
		return err
	}
	return openDefault(path)
}

func (s *Service) OpenVLC(fileID string) error {
	exePath := s.vlcExe()
	if exePath == "" {
		return errors.New("VLC portable no está instalado en VaultPool")
	}
	s.mu.Lock()
	e := s.entries[strings.TrimSpace(fileID)]
	streaming, state, baseURL := false, "", s.baseURL
	if e != nil {
		streaming, state = e.streaming, e.state
	}
	s.mu.Unlock()
	if streaming {
		if state != StateReady {
			return errors.New("el vídeo todavía se está preparando")
		}
		if baseURL == "" {
			return errors.New("el servidor local de streaming todavía no está listo")
		}
		streamURL := baseURL + "/api/player/" + url.PathEscape(strings.TrimSpace(fileID)) + "/stream"
		cmd := exec.Command(exePath, streamURL)
		cmd.SysProcAttr = hiddenProcAttr()
		return cmd.Start()
	}
	path, err := s.readyPath(fileID)
	if err != nil {
		return err
	}
	cmd := exec.Command(exePath, path)
	cmd.SysProcAttr = hiddenProcAttr()
	return cmd.Start()
}

func (s *Service) readyPath(fileID string) (string, error) {
	fileID = strings.TrimSpace(fileID)
	s.mu.Lock()
	e := s.entries[fileID]
	if e == nil {
		s.mu.Unlock()
		return "", errors.New("prepara primero la reproducción")
	}
	path, state, streaming := e.path, e.state, e.streaming
	s.mu.Unlock()
	if state != StateReady {
		return "", errors.New("el vídeo todavía se está preparando")
	}
	if streaming {
		return "", errors.New("este vídeo usa streaming por rangos")
	}
	return path, nil
}

func (s *Service) PluginStatus(id string) PluginStatus {
	st := PluginStatus{ID: vlcID, Name: vlcName, Version: vlcVersion, SourceURL: vlcURL, SHA256: vlcSHA256}
	if strings.TrimSpace(id) != "" && id != vlcID {
		st.Error = "plugin multimedia desconocido"
		return st
	}
	st.Installed = s.vlcExe() != ""
	s.mu.Lock()
	st.Installing = s.plugin.installing
	st.BytesDownloaded = s.plugin.bytesDownloaded
	st.BytesTotal = s.plugin.bytesTotal
	st.Error = s.plugin.err
	s.mu.Unlock()
	return st
}

func (s *Service) StartInstallPlugin(id string) (PluginStatus, error) {
	if strings.TrimSpace(id) != vlcID {
		return PluginStatus{}, errors.New("plugin multimedia desconocido")
	}
	if runtime.GOOS != "windows" {
		return PluginStatus{}, errors.New("la descarga automática de VLC portable está preparada para Windows")
	}
	if s.vlcExe() != "" {
		return s.PluginStatus(vlcID), nil
	}
	s.mu.Lock()
	if s.plugin.installing {
		st := s.PluginStatusLocked()
		s.mu.Unlock()
		return st, nil
	}
	s.plugin = pluginInstall{installing: true}
	s.mu.Unlock()
	go s.installVLC(context.Background())
	return s.PluginStatus(vlcID), nil
}

func (s *Service) PluginStatusLocked() PluginStatus {
	return PluginStatus{
		ID:              vlcID,
		Name:            vlcName,
		Version:         vlcVersion,
		SourceURL:       vlcURL,
		SHA256:          vlcSHA256,
		Installed:       s.vlcExe() != "",
		Installing:      s.plugin.installing,
		BytesDownloaded: s.plugin.bytesDownloaded,
		BytesTotal:      s.plugin.bytesTotal,
		Error:           s.plugin.err,
	}
}

func (s *Service) installVLC(ctx context.Context) {
	err := s.downloadAndExtractVLC(ctx)
	s.mu.Lock()
	s.plugin.installing = false
	if err != nil {
		s.plugin.err = err.Error()
	} else {
		s.plugin.err = ""
	}
	s.mu.Unlock()
}

func (s *Service) downloadAndExtractVLC(ctx context.Context) error {
	downloads := filepath.Join(s.pluginRoot, "downloads")
	if err := os.MkdirAll(downloads, 0o700); err != nil {
		return err
	}
	tmp := filepath.Join(downloads, "vlc-"+vlcVersion+"-win64.zip.part")
	_ = os.Remove(tmp)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, vlcURL, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "VaultPool/"+vlcVersion+" local media plugin installer")
	res, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return fmt.Errorf("descarga VLC HTTP %d", res.StatusCode)
	}
	if res.ContentLength > maxPluginDownloadBytes {
		return errors.New("descarga VLC supera el límite de seguridad")
	}
	out, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o600)
	if err != nil {
		return err
	}
	hash := sha256.New()
	var read int64
	buf := make([]byte, 128*1024)
	for {
		n, readErr := res.Body.Read(buf)
		if n > 0 {
			read += int64(n)
			if read > maxPluginDownloadBytes {
				_ = out.Close()
				_ = os.Remove(tmp)
				return errors.New("descarga VLC supera el límite de seguridad")
			}
			if _, err := hash.Write(buf[:n]); err != nil {
				_ = out.Close()
				return err
			}
			if _, err := out.Write(buf[:n]); err != nil {
				_ = out.Close()
				return err
			}
			s.mu.Lock()
			s.plugin.bytesDownloaded = read
			s.plugin.bytesTotal = res.ContentLength
			s.mu.Unlock()
		}
		if errors.Is(readErr, io.EOF) {
			break
		}
		if readErr != nil {
			_ = out.Close()
			return readErr
		}
	}
	if err := out.Close(); err != nil {
		return err
	}
	got := hex.EncodeToString(hash.Sum(nil))
	if !strings.EqualFold(got, vlcSHA256) {
		_ = os.Remove(tmp)
		return fmt.Errorf("hash VLC no coincide: %s", got)
	}
	stage := filepath.Join(s.pluginRoot, "vlc-stage")
	final := filepath.Join(s.pluginRoot, "vlc")
	if err := os.RemoveAll(stage); err != nil {
		return err
	}
	if err := os.MkdirAll(stage, 0o700); err != nil {
		return err
	}
	if err := extractZipSafe(tmp, stage); err != nil {
		_ = os.RemoveAll(stage)
		return err
	}
	if findExecutable(stage, "vlc.exe") == "" {
		_ = os.RemoveAll(stage)
		return errors.New("la descarga verificada no contiene vlc.exe")
	}
	if err := os.RemoveAll(final); err != nil {
		return err
	}
	if err := os.Rename(stage, final); err != nil {
		return err
	}
	_ = os.Remove(tmp)
	return nil
}

func extractZipSafe(src, dst string) error {
	r, err := zip.OpenReader(src)
	if err != nil {
		return err
	}
	defer r.Close()
	dstAbs, err := filepath.Abs(dst)
	if err != nil {
		return err
	}
	var total uint64
	for _, f := range r.File {
		if f.FileInfo().Mode()&os.ModeSymlink != 0 {
			return errors.New("zip VLC contiene enlaces simbólicos")
		}
		name := filepath.Clean(filepath.FromSlash(f.Name))
		if name == "." || filepath.IsAbs(name) || strings.HasPrefix(name, ".."+string(os.PathSeparator)) || name == ".." {
			return fmt.Errorf("ruta insegura dentro del zip VLC: %s", f.Name)
		}
		total += f.UncompressedSize64
		if total > maxPluginUncompressedBytes {
			return errors.New("VLC descomprimido supera el límite de seguridad")
		}
		target := filepath.Join(dstAbs, name)
		rel, err := filepath.Rel(dstAbs, target)
		if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
			return fmt.Errorf("ruta insegura dentro del zip VLC: %s", f.Name)
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o700); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o700); err != nil {
			return err
		}
		in, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o600)
		if err != nil {
			_ = in.Close()
			return err
		}
		_, copyErr := io.Copy(out, in)
		closeErr := errors.Join(out.Close(), in.Close())
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func (s *Service) vlcExe() string {
	return findExecutable(filepath.Join(s.pluginRoot, "vlc"), "vlc.exe")
}

func findExecutable(root, name string) string {
	root = filepath.Clean(root)
	var found string
	_ = filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil || found != "" || d.IsDir() {
			return nil
		}
		if strings.EqualFold(d.Name(), name) {
			found = path
		}
		return nil
	})
	return found
}
