package recoverycenter

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/safefile"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

const (
	MaxRecoveryPackageBytes int64 = 64 << 20
	pendingRestoreVersion         = 1
	pendingRestoreTTL             = 24 * time.Hour
)

var (
	ErrUnavailable           = errors.New("recovery center unavailable")
	ErrAlreadyConfigured     = errors.New("portable recovery is already configured; safe rotation is not implemented yet")
	ErrConfirmationRequired  = errors.New("confirm that both recovery package and recovery code were saved")
	ErrRestoreExpired        = errors.New("staged recovery request expired")
	ErrRestoreAlreadyPending = errors.New("a recovery restore is already staged; cancel or apply it before staging another")
)

type Status struct {
	Available                  bool   `json:"available"`
	Configured                 bool   `json:"configured"`
	Pending                    bool   `json:"pending"`
	PackageReady               bool   `json:"package_ready"`
	PackageName                string `json:"package_name,omitempty"`
	UpdatedAt                  string `json:"updated_at,omitempty"`
	RestorePending             bool   `json:"restore_pending"`
	RestartRequired            bool   `json:"restart_required"`
	CredentialRevision         uint64 `json:"credential_revision"`
	ExternalCredentialRevision uint64 `json:"external_credential_revision"`
	CredentialsRefreshRequired bool   `json:"credentials_refresh_required"`
	ExternalConfirmedAt        string `json:"external_confirmed_at,omitempty"`
}

type pendingRestore struct {
	Version       int    `json:"version"`
	PackageSHA256 string `json:"package_sha256"`
	ProtectedCode string `json:"protected_code"`
	CreatedAt     string `json:"created_at"`
	ExpiresAt     string `json:"expires_at"`
}

type Service struct {
	mu                         sync.Mutex
	vault                      *secretvault.Vault
	vaultPath                  string
	packagePath                string
	pendingPackagePath         string
	pendingRequestPath         string
	protector                  secretvault.Protector
	lastExportedCredentialRev  uint64
	lastExportedCredentialSeen bool
}

func New(vault *secretvault.Vault, vaultPath, packagePath string, protector secretvault.Protector) (*Service, error) {
	if vault == nil || protector == nil || strings.TrimSpace(vaultPath) == "" || strings.TrimSpace(packagePath) == "" {
		return nil, errors.New("vault, vault path, package path and protector are required")
	}
	return &Service{
		vault:              vault,
		vaultPath:          filepath.Clean(vaultPath),
		packagePath:        filepath.Clean(packagePath),
		pendingPackagePath: filepath.Clean(packagePath) + ".pending-restore",
		pendingRequestPath: filepath.Clean(vaultPath) + ".pending-restore.json",
		protector:          protector,
	}, nil
}

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && st.Mode().IsRegular()
}

func readFileLimited(path string, max int64) ([]byte, error) {
	st, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if !st.Mode().IsRegular() {
		return nil, errors.New("recovery path is not a regular file")
	}
	if st.Size() < 1 || st.Size() > max {
		return nil, errors.New("recovery file exceeds safety limit")
	}
	return os.ReadFile(path)
}

func uniqueBackupPath(path string) string {
	base := path + ".pre-recovery.bak"
	if !fileExists(base) {
		return base
	}
	for i := 1; i < 10000; i++ {
		candidate := fmt.Sprintf("%s.pre-recovery.%d.bak", path, i)
		if !fileExists(candidate) {
			return candidate
		}
	}
	return fmt.Sprintf("%s.pre-recovery.%d.bak", path, time.Now().UTC().UnixNano())
}

func tempRestorePath(dir, pattern string) (string, error) {
	f, err := os.CreateTemp(dir, pattern)
	if err != nil {
		return "", err
	}
	name := f.Name()
	_ = f.Chmod(0o600)
	if err := f.Close(); err != nil {
		_ = os.Remove(name)
		return "", err
	}
	if err := os.Remove(name); err != nil {
		return "", err
	}
	return name, nil
}

func (s *Service) Status() Status {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.vault.PortableRecoveryStatus()
	return Status{
		Available:                  true,
		Configured:                 st.Configured,
		Pending:                    st.Pending,
		PackageReady:               st.Path != "" && fileExists(st.Path),
		PackageName:                filepath.Base(st.Path),
		UpdatedAt:                  st.UpdatedAt,
		RestorePending:             fileExists(s.pendingRequestPath) && fileExists(s.pendingPackagePath),
		RestartRequired:            fileExists(s.pendingRequestPath) && fileExists(s.pendingPackagePath),
		CredentialRevision:         st.CredentialRevision,
		ExternalCredentialRevision: st.ExternalCredentialRevision,
		CredentialsRefreshRequired: st.CredentialsRefreshRequired,
		ExternalConfirmedAt:        st.ExternalConfirmedAt,
	}
}

// Begin creates or regenerates an unconfirmed recovery kit. A confirmed kit is
// never replaced here: rotating it safely requires a separate two-phase flow so
// the old external recovery remains valid until the new kit is confirmed.
func (s *Service) Begin() (string, Status, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	current := s.vault.PortableRecoveryStatus()
	if current.Configured {
		return "", Status{}, ErrAlreadyConfigured
	}
	code, err := s.vault.ConfigurePortableRecovery(s.packagePath)
	if err != nil {
		return "", Status{}, err
	}
	return code, s.statusLocked(), nil
}

func (s *Service) Confirm(savedPackage, savedCode bool) (Status, error) {
	if !savedPackage || !savedCode {
		return Status{}, ErrConfirmationRequired
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.vault.ConfirmPortableRecovery(); err != nil {
		return Status{}, err
	}
	return s.statusLocked(), nil
}

func (s *Service) statusLocked() Status {
	st := s.vault.PortableRecoveryStatus()
	return Status{
		Available:                  true,
		Configured:                 st.Configured,
		Pending:                    st.Pending,
		PackageReady:               st.Path != "" && fileExists(st.Path),
		PackageName:                filepath.Base(st.Path),
		UpdatedAt:                  st.UpdatedAt,
		RestorePending:             fileExists(s.pendingRequestPath) && fileExists(s.pendingPackagePath),
		RestartRequired:            fileExists(s.pendingRequestPath) && fileExists(s.pendingPackagePath),
		CredentialRevision:         st.CredentialRevision,
		ExternalCredentialRevision: st.ExternalCredentialRevision,
		CredentialsRefreshRequired: st.CredentialsRefreshRequired,
		ExternalConfirmedAt:        st.ExternalConfirmedAt,
	}
}

// ConfirmCredentialRefresh acknowledges that the user saved the current
// portable package outside this machine after a recoverable credential change.
// The recovery code/root is unchanged; this is a snapshot refresh, not a kit
// rotation.
func (s *Service) ConfirmCredentialRefresh(savedPackage bool) (Status, error) {
	if !savedPackage {
		return Status{}, errors.New("confirm that the refreshed recovery package was saved outside this machine")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.vault.PortableRecoveryStatus()
	if !st.Configured {
		return Status{}, secretvault.ErrPortableRecoveryRequired
	}
	if !st.CredentialsRefreshRequired {
		return s.statusLocked(), nil
	}
	// Do not let the UI acknowledge a revision that was never exported, or an
	// older package downloaded before another credential change.
	if !s.lastExportedCredentialSeen || s.lastExportedCredentialRev != st.CredentialRevision {
		return Status{}, errors.New("download the current recovery package before confirming the credential snapshot")
	}
	if err := s.vault.ConfirmExternalCredentialSnapshot(); err != nil {
		return Status{}, err
	}
	s.lastExportedCredentialSeen = false
	return s.statusLocked(), nil
}

func (s *Service) CancelStagedRestore() (Status, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var first error
	for _, path := range []string{s.pendingRequestPath, s.pendingPackagePath} {
		if err := os.Remove(path); err != nil && !os.IsNotExist(err) && first == nil {
			first = err
		}
	}
	if first != nil {
		return Status{}, first
	}
	return s.statusLocked(), nil
}

func (s *Service) ExportPackage() ([]byte, string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st := s.vault.PortableRecoveryStatus()
	if st.Path == "" || (!st.Pending && !st.Configured) {
		return nil, "", secretvault.ErrPortableRecoveryRequired
	}
	b, err := readFileLimited(st.Path, MaxRecoveryPackageBytes)
	if err != nil {
		return nil, "", err
	}
	s.lastExportedCredentialRev = st.CredentialRevision
	s.lastExportedCredentialSeen = true
	return b, filepath.Base(st.Path), nil
}

// StageRestore validates the package and recovery code without touching the
// active vault. If valid, it stores only the encrypted package plus an OS-
// protected one-time recovery code. The actual vault replacement happens on
// the next process start, before the normal vault is opened.
func (s *Service) StageRestore(packageBytes []byte, recoveryCode string, replaceCurrent bool) (Status, error) {
	if !replaceCurrent {
		return Status{}, errors.New("explicit confirmation to replace current local vault is required")
	}
	if len(packageBytes) == 0 || int64(len(packageBytes)) > MaxRecoveryPackageBytes {
		return Status{}, errors.New("invalid recovery package size")
	}
	if strings.TrimSpace(recoveryCode) == "" {
		return Status{}, errors.New("recovery code required")
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	if fileExists(s.pendingRequestPath) || fileExists(s.pendingPackagePath) {
		return Status{}, ErrRestoreAlreadyPending
	}

	// Validate using private temporary files first. RestoreFromRecovery performs
	// AES-GCM authentication of the package and re-wraps the vault master key
	// with this machine's protector. Neither temp file becomes authoritative.
	dir := filepath.Dir(s.vaultPath)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return Status{}, err
	}
	pkgTmp, err := os.CreateTemp(dir, ".vaultpool-validate-recovery-*.vpr")
	if err != nil {
		return Status{}, err
	}
	pkgTmpPath := pkgTmp.Name()
	_ = pkgTmp.Chmod(0o600)
	if _, err := pkgTmp.Write(packageBytes); err != nil {
		_ = pkgTmp.Close()
		_ = os.Remove(pkgTmpPath)
		return Status{}, err
	}
	if err := pkgTmp.Sync(); err != nil {
		_ = pkgTmp.Close()
		_ = os.Remove(pkgTmpPath)
		return Status{}, err
	}
	if err := pkgTmp.Close(); err != nil {
		_ = os.Remove(pkgTmpPath)
		return Status{}, err
	}
	defer os.Remove(pkgTmpPath)

	validationVault, err := tempRestorePath(dir, ".vaultpool-validate-restored-*.vpv")
	if err != nil {
		return Status{}, err
	}
	v, err := secretvault.RestoreFromRecovery(pkgTmpPath, recoveryCode, validationVault, s.protector)
	if err != nil {
		_ = os.Remove(validationVault)
		return Status{}, err
	}
	v.Close()
	_ = os.Remove(validationVault)

	protectedCode, err := s.protector.Protect([]byte(recoveryCode))
	if err != nil {
		return Status{}, fmt.Errorf("protect staged recovery code: %w", err)
	}
	defer zero(protectedCode)
	if err := safefile.WriteAtomic(s.pendingPackagePath, packageBytes, 0o600); err != nil {
		return Status{}, err
	}
	h := sha256.Sum256(packageBytes)
	now := time.Now().UTC()
	req := pendingRestore{
		Version:       pendingRestoreVersion,
		PackageSHA256: hex.EncodeToString(h[:]),
		ProtectedCode: base64.RawStdEncoding.EncodeToString(protectedCode),
		CreatedAt:     now.Format(time.RFC3339Nano),
		ExpiresAt:     now.Add(pendingRestoreTTL).Format(time.RFC3339Nano),
	}
	raw, err := json.MarshalIndent(req, "", "  ")
	if err != nil {
		return Status{}, err
	}
	if err := safefile.WriteAtomic(s.pendingRequestPath, raw, 0o600); err != nil {
		_ = os.Remove(s.pendingPackagePath)
		return Status{}, err
	}
	return s.statusLocked(), nil
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func pendingPaths(vaultPath, packagePath string) (string, string) {
	return filepath.Clean(vaultPath) + ".pending-restore.json", filepath.Clean(packagePath) + ".pending-restore"
}

func copyPrivate(path, backup string) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return safefile.WriteAtomic(backup, b, 0o600)
}

// ApplyPendingRestore is called before the ordinary vault is opened. It makes
// an encrypted backup of the previous local vault, restores into a temporary
// vault, atomically replaces the active vault, then relocates the portable
// package to its canonical path. A crash after vault replacement is still
// recoverable because the pending encrypted package is retained until the final
// relocation succeeds.
func ApplyPendingRestore(vaultPath, packagePath string, p secretvault.Protector) (bool, error) {
	if p == nil {
		return false, errors.New("secret protector required")
	}
	reqPath, pendingPackage := pendingPaths(vaultPath, packagePath)
	raw, err := readFileLimited(reqPath, 64<<10)
	if err != nil {
		if os.IsNotExist(err) {
			return false, nil
		}
		return false, err
	}
	var req pendingRestore
	if err := json.Unmarshal(raw, &req); err != nil || req.Version != pendingRestoreVersion {
		return false, errors.New("invalid pending recovery request")
	}
	expires, err := time.Parse(time.RFC3339Nano, req.ExpiresAt)
	if err != nil {
		return false, errors.New("invalid pending recovery expiry")
	}
	if time.Now().UTC().After(expires) {
		_ = os.Remove(reqPath)
		_ = os.Remove(pendingPackage)
		return false, ErrRestoreExpired
	}
	pkg, err := readFileLimited(pendingPackage, MaxRecoveryPackageBytes)
	if err != nil {
		return false, err
	}
	h := sha256.Sum256(pkg)
	if !strings.EqualFold(hex.EncodeToString(h[:]), req.PackageSHA256) {
		return false, errors.New("pending recovery package hash mismatch")
	}
	wrapped, err := base64.RawStdEncoding.DecodeString(req.ProtectedCode)
	if err != nil {
		return false, errors.New("invalid protected recovery code")
	}
	codeBytes, err := p.Unprotect(wrapped)
	zero(wrapped)
	if err != nil {
		return false, fmt.Errorf("unlock staged recovery code: %w", err)
	}
	code := string(codeBytes)
	zero(codeBytes)

	dir := filepath.Dir(vaultPath)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return false, err
	}
	stagedVault, err := tempRestorePath(dir, ".vaultpool-restored-next-*.vpv")
	if err != nil {
		return false, err
	}
	restored, err := secretvault.RestoreFromRecovery(pendingPackage, code, stagedVault, p)
	code = ""
	if err != nil {
		_ = os.Remove(stagedVault)
		return false, err
	}
	restored.Close()

	if fileExists(vaultPath) {
		if err := copyPrivate(vaultPath, uniqueBackupPath(vaultPath)); err != nil {
			_ = os.Remove(stagedVault)
			return false, fmt.Errorf("backup current vault: %w", err)
		}
	}
	if fileExists(packagePath) {
		if err := copyPrivate(packagePath, uniqueBackupPath(packagePath)); err != nil {
			_ = os.Remove(stagedVault)
			return false, fmt.Errorf("backup current recovery package: %w", err)
		}
	}
	if err := safefile.CommitTemp(stagedVault, vaultPath); err != nil {
		return false, fmt.Errorf("activate restored vault: %w", err)
	}

	active, err := secretvault.Open(vaultPath, p)
	if err != nil {
		return false, fmt.Errorf("open activated restored vault: %w", err)
	}
	if err := active.RelocatePortableRecovery(packagePath); err != nil {
		active.Close()
		// Do not remove pending files. The restored vault still points at the
		// pending package and can be retried/recovered on the next start.
		return false, fmt.Errorf("relocate restored recovery package: %w", err)
	}
	active.Close()
	_ = os.Remove(reqPath)
	_ = os.Remove(pendingPackage)
	return true, nil
}
