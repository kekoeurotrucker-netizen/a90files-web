package recoverycenter

import (
	"bytes"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/safefile"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type testProtector byte

func (p testProtector) Name() string { return "recovery-test" }
func (p testProtector) Protect(in []byte) ([]byte, error) {
	out := append([]byte(nil), in...)
	for i := range out {
		out[i] ^= byte(p)
	}
	return out, nil
}
func (p testProtector) Unprotect(in []byte) ([]byte, error) { return p.Protect(in) }

func makeRecoverySource(t *testing.T, dir string, p secretvault.Protector) (vaultPath, packagePath, code string) {
	t.Helper()
	vaultPath = filepath.Join(dir, "source.vpv")
	packagePath = filepath.Join(dir, "source-recovery.vpr")
	v, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	code, err = v.ConfigurePortableRecovery(packagePath)
	if err != nil {
		v.Close()
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		v.Close()
		t.Fatal(err)
	}
	if err := v.Put("account-a", secretvault.RecoverableUsername, []byte("person@example.com")); err != nil {
		v.Close()
		t.Fatal(err)
	}
	if err := v.Put("file-a", secretvault.FileDataKey, bytes.Repeat([]byte{0x42}, 32)); err != nil {
		v.Close()
		t.Fatal(err)
	}
	v.Close()
	return
}

func TestRecoveryKitRequiresExplicitConfirmation(t *testing.T) {
	dir := t.TempDir()
	p := testProtector(0x33)
	vaultPath := filepath.Join(dir, "secrets.vpv")
	packagePath := filepath.Join(dir, "VaultPool-Recovery.vpr")
	v, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	s, err := New(v, vaultPath, packagePath, p)
	if err != nil {
		t.Fatal(err)
	}
	code, st, err := s.Begin()
	if err != nil || len(code) < 40 {
		t.Fatalf("begin: code=%q err=%v", code, err)
	}
	if !st.Pending || st.Configured || !st.PackageReady {
		t.Fatalf("unexpected pending status: %+v", st)
	}
	if _, err := s.Confirm(true, false); !errors.Is(err, ErrConfirmationRequired) {
		t.Fatalf("confirmation should require both acknowledgements: %v", err)
	}
	st, err = s.Confirm(true, true)
	if err != nil {
		t.Fatal(err)
	}
	if !st.Configured || st.Pending {
		t.Fatalf("expected confirmed status: %+v", st)
	}
	if _, _, err := s.Begin(); !errors.Is(err, ErrAlreadyConfigured) {
		t.Fatalf("confirmed kit must not rotate implicitly: %v", err)
	}
}

func TestStageRestoreWrongCodeDoesNotCreatePendingState(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, _ := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, err := os.ReadFile(sourcePackage)
	if err != nil {
		t.Fatal(err)
	}
	targetDir := filepath.Join(dir, "target")
	vaultPath := filepath.Join(targetDir, "secrets.vpv")
	packagePath := filepath.Join(targetDir, "VaultPool-Recovery.vpr")
	p := testProtector(0x22)
	v, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	s, _ := New(v, vaultPath, packagePath, p)
	if _, err := s.StageRestore(pkg, "not-a-valid-code", true); err == nil {
		t.Fatal("wrong recovery code accepted")
	}
	req, pending := pendingPaths(vaultPath, packagePath)
	if fileExists(req) || fileExists(pending) {
		t.Fatal("failed validation left pending recovery state")
	}
}

func TestStageAndApplyRestoreIsTransactional(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, code := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, err := os.ReadFile(sourcePackage)
	if err != nil {
		t.Fatal(err)
	}
	targetDir := filepath.Join(dir, "target")
	vaultPath := filepath.Join(targetDir, "secrets.vpv")
	packagePath := filepath.Join(targetDir, "VaultPool-Recovery.vpr")
	p := testProtector(0x22)
	old, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	if err := old.Put("old-account", secretvault.ProviderSession, []byte("old-local-session")); err != nil {
		t.Fatal(err)
	}
	s, _ := New(old, vaultPath, packagePath, p)
	st, err := s.StageRestore(pkg, code, true)
	if err != nil {
		t.Fatal(err)
	}
	if !st.RestorePending || !st.RestartRequired {
		t.Fatalf("restore not staged: %+v", st)
	}
	old.Close()

	applied, err := ApplyPendingRestore(vaultPath, packagePath, p)
	if err != nil || !applied {
		t.Fatalf("apply: applied=%v err=%v", applied, err)
	}
	restored, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	defer restored.Close()
	got, ok, err := restored.Get("account-a", secretvault.RecoverableUsername)
	if err != nil || !ok || string(got) != "person@example.com" {
		t.Fatalf("restored secret mismatch: %q ok=%v err=%v", got, ok, err)
	}
	for i := range got {
		got[i] = 0
	}
	if ready, path := restored.RecoveryConfigured(); !ready || filepath.Clean(path) != filepath.Clean(packagePath) {
		t.Fatalf("restored recovery config wrong: ready=%v path=%q", ready, path)
	}
	if !fileExists(packagePath) {
		t.Fatal("canonical recovery package missing after apply")
	}
	if !fileExists(vaultPath + ".pre-recovery.bak") {
		t.Fatal("previous vault backup missing")
	}
	backup, err := secretvault.Open(vaultPath+".pre-recovery.bak", p)
	if err != nil {
		t.Fatal(err)
	}
	oldSecret, ok, err := backup.Get("old-account", secretvault.ProviderSession)
	backup.Close()
	if err != nil || !ok || string(oldSecret) != "old-local-session" {
		t.Fatalf("pre-recovery backup not usable: %q ok=%v err=%v", oldSecret, ok, err)
	}
	req, pending := pendingPaths(vaultPath, packagePath)
	if fileExists(req) || fileExists(pending) {
		t.Fatal("pending restore files not cleaned after successful apply")
	}
}

func TestTamperedStagedPackageCannotReplaceActiveVault(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, code := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, _ := os.ReadFile(sourcePackage)
	targetDir := filepath.Join(dir, "target")
	vaultPath := filepath.Join(targetDir, "secrets.vpv")
	packagePath := filepath.Join(targetDir, "VaultPool-Recovery.vpr")
	p := testProtector(0x22)
	v, _ := secretvault.Open(vaultPath, p)
	if err := v.Put("old", secretvault.ProviderSession, []byte("keep-me")); err != nil {
		t.Fatal(err)
	}
	s, _ := New(v, vaultPath, packagePath, p)
	if _, err := s.StageRestore(pkg, code, true); err != nil {
		t.Fatal(err)
	}
	v.Close()
	_, pending := pendingPaths(vaultPath, packagePath)
	b, _ := os.ReadFile(pending)
	b[len(b)/2] ^= 0x80
	if err := safefile.WriteAtomic(pending, b, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := ApplyPendingRestore(vaultPath, packagePath, p); err == nil {
		t.Fatal("tampered staged package was accepted")
	}
	active, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	defer active.Close()
	got, ok, err := active.Get("old", secretvault.ProviderSession)
	if err != nil || !ok || string(got) != "keep-me" {
		t.Fatalf("active vault changed after failed recovery: %q ok=%v err=%v", got, ok, err)
	}
}

func TestExpiredPendingRestoreIsRemovedWithoutReplacement(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, code := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, _ := os.ReadFile(sourcePackage)
	targetDir := filepath.Join(dir, "target")
	vaultPath := filepath.Join(targetDir, "secrets.vpv")
	packagePath := filepath.Join(targetDir, "VaultPool-Recovery.vpr")
	p := testProtector(0x22)
	v, _ := secretvault.Open(vaultPath, p)
	s, _ := New(v, vaultPath, packagePath, p)
	if _, err := s.StageRestore(pkg, code, true); err != nil {
		t.Fatal(err)
	}
	v.Close()
	reqPath, pending := pendingPaths(vaultPath, packagePath)
	raw, _ := os.ReadFile(reqPath)
	var req pendingRestore
	if err := json.Unmarshal(raw, &req); err != nil {
		t.Fatal(err)
	}
	req.ExpiresAt = time.Now().UTC().Add(-time.Minute).Format(time.RFC3339Nano)
	raw, _ = json.Marshal(req)
	if err := safefile.WriteAtomic(reqPath, raw, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := ApplyPendingRestore(vaultPath, packagePath, p); !errors.Is(err, ErrRestoreExpired) {
		t.Fatalf("want expiry error, got %v", err)
	}
	if fileExists(reqPath) || fileExists(pending) {
		t.Fatal("expired recovery state not cleaned")
	}
}

func TestCancelStagedRestore(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, code := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, _ := os.ReadFile(sourcePackage)
	vaultPath := filepath.Join(dir, "target", "secrets.vpv")
	packagePath := filepath.Join(dir, "target", "VaultPool-Recovery.vpr")
	p := testProtector(0x22)
	v, _ := secretvault.Open(vaultPath, p)
	defer v.Close()
	s, _ := New(v, vaultPath, packagePath, p)
	if _, err := s.StageRestore(pkg, code, true); err != nil {
		t.Fatal(err)
	}
	st, err := s.CancelStagedRestore()
	if err != nil {
		t.Fatal(err)
	}
	if st.RestorePending || st.RestartRequired {
		t.Fatalf("cancel did not clear pending state: %+v", st)
	}
}

func TestSecondStageCannotReplacePendingRestore(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, code := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, _ := os.ReadFile(sourcePackage)
	vaultPath := filepath.Join(dir, "target", "secrets.vpv")
	packagePath := filepath.Join(dir, "target", "VaultPool-Recovery.vpr")
	p := testProtector(0x22)
	v, _ := secretvault.Open(vaultPath, p)
	defer v.Close()
	s, _ := New(v, vaultPath, packagePath, p)
	if _, err := s.StageRestore(pkg, code, true); err != nil {
		t.Fatal(err)
	}
	_, pending := pendingPaths(vaultPath, packagePath)
	before, _ := os.ReadFile(pending)
	if _, err := s.StageRestore(pkg, code, true); !errors.Is(err, ErrRestoreAlreadyPending) {
		t.Fatalf("second stage should be blocked, got %v", err)
	}
	after, _ := os.ReadFile(pending)
	if !bytes.Equal(before, after) {
		t.Fatal("existing pending recovery package was replaced")
	}
}

func TestFailedRelocationLeavesPendingPackageRetryable(t *testing.T) {
	dir := t.TempDir()
	_, sourcePackage, code := makeRecoverySource(t, filepath.Join(dir, "source"), testProtector(0x11))
	pkg, _ := os.ReadFile(sourcePackage)
	targetDir := filepath.Join(dir, "target")
	vaultPath := filepath.Join(targetDir, "secrets.vpv")
	// Deliberately use an existing directory as the canonical recovery "file"
	// so relocation fails only after the restored vault is atomically activated.
	packagePath := filepath.Join(targetDir, "blocked-recovery-target")
	if err := os.MkdirAll(packagePath, 0o700); err != nil {
		t.Fatal(err)
	}
	p := testProtector(0x22)
	v, _ := secretvault.Open(vaultPath, p)
	s, _ := New(v, vaultPath, packagePath, p)
	if _, err := s.StageRestore(pkg, code, true); err != nil {
		t.Fatal(err)
	}
	v.Close()
	_, pending := pendingPaths(vaultPath, packagePath)
	before, err := os.ReadFile(pending)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := ApplyPendingRestore(vaultPath, packagePath, p); err == nil {
		t.Fatal("relocation unexpectedly succeeded")
	}
	afterFirst, err := os.ReadFile(pending)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(before, afterFirst) {
		t.Fatal("failed restore mutated pending source package")
	}
	if _, err := ApplyPendingRestore(vaultPath, packagePath, p); err == nil || strings.Contains(err.Error(), "hash mismatch") {
		t.Fatalf("retry should reach relocation again without hash mismatch, got %v", err)
	}
}

func TestUniqueBackupPathNeverOverwritesExistingBackup(t *testing.T) {
	dir := t.TempDir()
	base := filepath.Join(dir, "secrets.vpv")
	first := uniqueBackupPath(base)
	if first != base+".pre-recovery.bak" {
		t.Fatalf("unexpected first backup %q", first)
	}
	if err := os.WriteFile(first, []byte("old-backup"), 0o600); err != nil {
		t.Fatal(err)
	}
	second := uniqueBackupPath(base)
	if second == first {
		t.Fatal("existing recovery backup would be overwritten")
	}
}

func TestCredentialRefreshRequiresCurrentPackageExport(t *testing.T) {
	dir := t.TempDir()
	p := testProtector(0x41)
	vaultPath := filepath.Join(dir, "secrets.vpv")
	packagePath := filepath.Join(dir, "VaultPool-Recovery.vpr")
	v, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	s, err := New(v, vaultPath, packagePath, p)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := s.Begin(); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Confirm(true, true); err != nil {
		t.Fatal(err)
	}
	if err := v.Put("acct", secretvault.RecoverableUsername, []byte("one@example.com")); err != nil {
		t.Fatal(err)
	}
	if !s.Status().CredentialsRefreshRequired {
		t.Fatal("credential change did not mark external package stale")
	}
	if _, err := s.ConfirmCredentialRefresh(true); err == nil {
		t.Fatal("credential refresh confirmed without exporting the current package")
	}
	if _, _, err := s.ExportPackage(); err != nil {
		t.Fatal(err)
	}
	st, err := s.ConfirmCredentialRefresh(true)
	if err != nil {
		t.Fatal(err)
	}
	if st.CredentialsRefreshRequired || st.ExternalCredentialRevision != st.CredentialRevision {
		t.Fatalf("refresh confirmation did not advance external revision: %+v", st)
	}
}

func TestCredentialRefreshRejectsPackageExportedBeforeLaterCredentialChange(t *testing.T) {
	dir := t.TempDir()
	p := testProtector(0x52)
	vaultPath := filepath.Join(dir, "secrets.vpv")
	packagePath := filepath.Join(dir, "VaultPool-Recovery.vpr")
	v, err := secretvault.Open(vaultPath, p)
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	s, _ := New(v, vaultPath, packagePath, p)
	if _, _, err := s.Begin(); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Confirm(true, true); err != nil {
		t.Fatal(err)
	}
	if err := v.Put("acct", secretvault.RecoverableUsername, []byte("one@example.com")); err != nil {
		t.Fatal(err)
	}
	if _, _, err := s.ExportPackage(); err != nil {
		t.Fatal(err)
	}
	// The downloaded package is immediately stale after a second change.
	if err := v.Put("acct", secretvault.RecoverablePassword, []byte("second-change")); err != nil {
		t.Fatal(err)
	}
	if _, err := s.ConfirmCredentialRefresh(true); err == nil {
		t.Fatal("stale exported package was accepted for a newer credential revision")
	}
	if _, _, err := s.ExportPackage(); err != nil {
		t.Fatal(err)
	}
	if _, err := s.ConfirmCredentialRefresh(true); err != nil {
		t.Fatal(err)
	}
}
