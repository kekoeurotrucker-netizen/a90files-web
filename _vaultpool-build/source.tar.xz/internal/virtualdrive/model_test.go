package virtualdrive

import (
	"bytes"
	"context"
	"errors"
	"testing"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
)

type fakeSource struct {
	items []managedfiles.Metadata
	data  map[string][]byte
}

func (f *fakeSource) List() ([]managedfiles.Metadata, error) {
	return append([]managedfiles.Metadata(nil), f.items...), nil
}
func (f *fakeSource) ReadRange(_ context.Context, id string, off int64, n int) ([]byte, error) {
	b, ok := f.data[id]
	if !ok {
		return nil, errors.New("missing")
	}
	if off >= int64(len(b)) {
		return []byte{}, nil
	}
	end := off + int64(n)
	if end > int64(len(b)) {
		end = int64(len(b))
	}
	return append([]byte(nil), b[off:end]...), nil
}
func meta(id, name string, size int64, at time.Time) managedfiles.Metadata {
	return managedfiles.Metadata{FileID: id, FileName: name, OriginalSize: size, OriginalSHA256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", Generation: 1, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1, CreatedAt: at, RegisteredAt: at}
}
func TestModelSanitizesAndDisambiguatesWindowsNames(t *testing.T) {
	now := time.Now().UTC()
	f := &fakeSource{items: []managedfiles.Metadata{
		meta("00112233445566778899aabbccddeeff", "movie.mkv", 10, now),
		meta("ffeeddccbbaa99887766554433221100", "movie.mkv", 11, now.Add(time.Second)),
		meta("11112222333344445555666677778888", "CON.txt", 12, now.Add(2*time.Second)),
	}}
	m, _ := NewModel(f, nil)
	got, err := m.ListRoot()
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 3 {
		t.Fatalf("entries=%d", len(got))
	}
	seen := map[string]bool{}
	for _, e := range got {
		if seen[e.Name] {
			t.Fatalf("duplicate name %q", e.Name)
		}
		seen[e.Name] = true
	}
	if !seen["movie.mkv"] || !seen["movie [ffeeddcc].mkv"] || !seen["_CON.txt"] {
		t.Fatalf("names=%v", seen)
	}
}
func TestModelReadUsesFileID(t *testing.T) {
	id := "00112233445566778899aabbccddeeff"
	f := &fakeSource{items: []managedfiles.Metadata{meta(id, "a.bin", 10, time.Now())}, data: map[string][]byte{id: []byte("0123456789")}}
	m, _ := NewModel(f, nil)
	b, err := m.Read(context.Background(), `\a.bin`, 3, 4)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(b, []byte("3456")) {
		t.Fatalf("got=%q", b)
	}
}
func TestModelCapacityCallback(t *testing.T) {
	m, _ := NewModel(&fakeSource{}, func() (uint64, uint64) { return 100, 40 })
	total, free := m.Capacity()
	if total != 100 || free != 40 {
		t.Fatalf("%d/%d", total, free)
	}
}
