package virtualdrive

import (
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
)

type FileSource interface {
	List() ([]managedfiles.Metadata, error)
	ReadRange(context.Context, string, int64, int) ([]byte, error)
}

type CapacityFunc func() (total, free uint64)

type Entry struct {
	Name       string    `json:"name"`
	FileID     string    `json:"file_id"`
	Size       int64     `json:"size"`
	CreatedAt  time.Time `json:"created_at"`
	Registered time.Time `json:"registered_at"`
}

type Model struct {
	source   FileSource
	capacity CapacityFunc
	mu       sync.RWMutex
	entries  []Entry
	byName   map[string]Entry
	loadedAt time.Time
	ttl      time.Duration
}

func NewModel(source FileSource, capacity CapacityFunc) (*Model, error) {
	if source == nil {
		return nil, errors.New("virtual drive file source required")
	}
	return &Model{source: source, capacity: capacity, ttl: 2 * time.Second}, nil
}

func normalizeVirtualPath(p string) string {
	p = strings.TrimSpace(strings.ReplaceAll(p, "/", `\`))
	if p == "" || p == `\` {
		return ""
	}
	p = strings.TrimPrefix(p, `\`)
	p = strings.TrimSuffix(p, `\`)
	return p
}

func reservedDOSName(base string) bool {
	base = strings.TrimSpace(strings.TrimSuffix(base, filepath.Ext(base)))
	base = strings.ToUpper(strings.TrimRight(base, ". "))
	switch base {
	case "CON", "PRN", "AUX", "NUL":
		return true
	}
	if len(base) == 4 && (strings.HasPrefix(base, "COM") || strings.HasPrefix(base, "LPT")) && base[3] >= '1' && base[3] <= '9' {
		return true
	}
	return false
}

func sanitizeName(name string) string {
	name = filepath.Base(strings.TrimSpace(name))
	if name == "" || name == "." || name == ".." {
		name = "archivo"
	}
	var b strings.Builder
	for _, r := range name {
		if r < 32 || strings.ContainsRune(`<>:"/\|?*`, r) {
			b.WriteRune('_')
		} else {
			b.WriteRune(r)
		}
	}
	name = strings.TrimRight(b.String(), ". ")
	if name == "" {
		name = "archivo"
	}
	if reservedDOSName(name) {
		name = "_" + name
	}
	// Leave room for Explorer/Win32 path prefixes and collision suffixes.
	const max = 220
	if len([]rune(name)) > max {
		r := []rune(name)
		ext := filepath.Ext(name)
		if ext != "" && len([]rune(ext)) < 40 {
			er := []rune(ext)
			keep := max - len(er)
			name = string(r[:keep]) + string(er)
		} else {
			name = string(r[:max])
		}
	}
	return name
}

func withIDSuffix(name, id string) string {
	ext := filepath.Ext(name)
	stem := strings.TrimSuffix(name, ext)
	short := id
	if len(short) > 8 {
		short = short[:8]
	}
	return fmt.Sprintf("%s [%s]%s", stem, short, ext)
}

func buildEntries(items []managedfiles.Metadata) ([]Entry, map[string]Entry) {
	sort.Slice(items, func(i, j int) bool {
		if items[i].RegisteredAt.Equal(items[j].RegisteredAt) {
			return items[i].FileID < items[j].FileID
		}
		return items[i].RegisteredAt.Before(items[j].RegisteredAt)
	})
	used := map[string]bool{}
	out := make([]Entry, 0, len(items))
	byName := make(map[string]Entry, len(items))
	for _, meta := range items {
		name := sanitizeName(meta.FileName)
		key := strings.ToLower(name)
		if used[key] {
			name = withIDSuffix(name, meta.FileID)
			key = strings.ToLower(name)
			for used[key] {
				name = "_" + name
				key = strings.ToLower(name)
			}
		}
		used[key] = true
		e := Entry{Name: name, FileID: meta.FileID, Size: meta.OriginalSize, CreatedAt: meta.CreatedAt, Registered: meta.RegisteredAt}
		out = append(out, e)
		byName[key] = e
	}
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name) })
	return out, byName
}

func (m *Model) Refresh() error {
	items, err := m.source.List()
	if err != nil {
		return err
	}
	entries, byName := buildEntries(items)
	m.mu.Lock()
	m.entries, m.byName, m.loadedAt = entries, byName, time.Now()
	m.mu.Unlock()
	return nil
}

func (m *Model) ensureFresh() error {
	m.mu.RLock()
	fresh := len(m.byName) > 0 && time.Since(m.loadedAt) < m.ttl
	loaded := !m.loadedAt.IsZero() && time.Since(m.loadedAt) < m.ttl
	m.mu.RUnlock()
	if fresh || loaded {
		return nil
	}
	return m.Refresh()
}

func (m *Model) ListRoot() ([]Entry, error) {
	if err := m.ensureFresh(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := append([]Entry(nil), m.entries...)
	return out, nil
}

func (m *Model) Lookup(path string) (Entry, bool, error) {
	name := normalizeVirtualPath(path)
	if name == "" || strings.Contains(name, `\`) {
		return Entry{}, false, nil
	}
	if err := m.ensureFresh(); err != nil {
		return Entry{}, false, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	e, ok := m.byName[strings.ToLower(name)]
	return e, ok, nil
}

func (m *Model) Read(ctx context.Context, path string, offset int64, length int) ([]byte, error) {
	e, ok, err := m.Lookup(path)
	if err != nil {
		return nil, err
	}
	if !ok {
		return nil, errors.New("virtual file not found")
	}
	return m.source.ReadRange(ctx, e.FileID, offset, length)
}

func (m *Model) Capacity() (total, free uint64) {
	if m.capacity == nil {
		entries, err := m.ListRoot()
		if err != nil {
			return 0, 0
		}
		for _, e := range entries {
			total += uint64(e.Size)
		}
		return total, 0
	}
	return m.capacity()
}
