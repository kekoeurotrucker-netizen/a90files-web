package health

import "testing"

func assess104(valid int) Assessment {
	return Assess(Input{DataShards: 10, ParityShards: 4, ValidShards: valid, ProviderFailureMargin: 1, RequiredProviderMargin: 1})
}

func TestTenPlusFourWarningSequence(t *testing.T) {
	cases := []struct {
		valid int
		want  Level
	}{
		{14, VeryLow},
		{13, Low},
		{12, Reduced},
		{11, High},
		{10, Critical},
		{9, Unrecoverable},
	}
	for _, tc := range cases {
		got := assess104(tc.valid)
		if got.Level != tc.want {
			t.Fatalf("valid=%d level=%s want %s", tc.valid, got.Level, tc.want)
		}
	}
}

func TestProviderConcentrationEscalatesRisk(t *testing.T) {
	got := Assess(Input{DataShards: 10, ParityShards: 4, ValidShards: 14, ProviderFailureMargin: 0, RequiredProviderMargin: 1})
	if got.Level != High {
		t.Fatalf("level=%s want HIGH", got.Level)
	}
	if got.ProviderSafetySatisfied {
		t.Fatal("provider safety must be false")
	}
}

func TestMissingOneDoesNotHideProviderRisk(t *testing.T) {
	got := Assess(Input{DataShards: 10, ParityShards: 4, ValidShards: 13, ProviderFailureMargin: 0, RequiredProviderMargin: 1})
	if got.Level != High {
		t.Fatalf("level=%s want HIGH", got.Level)
	}
}
