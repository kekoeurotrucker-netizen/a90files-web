package health

import "fmt"

type Level string

const (
	VeryLow       Level = "VERY_LOW"
	Low           Level = "LOW"
	Reduced       Level = "REDUCED"
	High          Level = "HIGH"
	Critical      Level = "CRITICAL"
	Unrecoverable Level = "UNRECOVERABLE"
)

type Input struct {
	DataShards             int
	ParityShards           int
	ValidShards            int
	ProviderFailureMargin  int
	RequiredProviderMargin int
}

type Assessment struct {
	Level                   Level
	TotalShards             int
	ValidShards             int
	MissingOrCorrupt        int
	RecoveryMargin          int
	ProviderFailureMargin   int
	ProviderSafetySatisfied bool
	Summary                 string
	RecommendedAction       string
}

func severity(l Level) int {
	switch l {
	case VeryLow:
		return 0
	case Low:
		return 1
	case Reduced:
		return 2
	case High:
		return 3
	case Critical:
		return 4
	case Unrecoverable:
		return 5
	default:
		return 99
	}
}

func Worse(a, b Assessment) Assessment {
	if severity(b.Level) > severity(a.Level) {
		return b
	}
	return a
}

func Assess(in Input) Assessment {
	total := in.DataShards + in.ParityShards
	missing := total - in.ValidShards
	margin := in.ValidShards - in.DataShards
	providerSafe := in.ProviderFailureMargin >= in.RequiredProviderMargin

	a := Assessment{
		TotalShards:             total,
		ValidShards:             in.ValidShards,
		MissingOrCorrupt:        missing,
		RecoveryMargin:          margin,
		ProviderFailureMargin:   in.ProviderFailureMargin,
		ProviderSafetySatisfied: providerSafe,
	}

	switch {
	case in.ValidShards < in.DataShards:
		a.Level = Unrecoverable
		a.Summary = fmt.Sprintf("Only %d/%d verified shards remain; at least %d are required.", in.ValidShards, total, in.DataShards)
		a.RecommendedAction = "Do not delete or move any remaining data. Reconnect missing providers or restore external backups; reconstruction is not possible from the currently verified shards."
		return a
	case missing == 0:
		a.Level = VeryLow
		a.Summary = fmt.Sprintf("%d/%d shards verified with full configured redundancy.", in.ValidShards, total)
		a.RecommendedAction = "No repair is required. Continue normal integrity audits."
	case margin == 0:
		a.Level = Critical
		a.Summary = fmt.Sprintf("%d/%d verified shards remain. The file is recoverable, but no shard-loss margin remains.", in.ValidShards, total)
		a.RecommendedAction = "Repair protection now to rebuild the missing/corrupt shards before any additional loss occurs."
	case margin == 1:
		a.Level = High
		a.Summary = fmt.Sprintf("%d/%d verified shards remain. Only one additional shard may be lost.", in.ValidShards, total)
		a.RecommendedAction = "Repair protection now. Reconnect or add an independent provider if needed, then rebuild missing/corrupt shards."
	case missing == 1:
		a.Level = Low
		a.Summary = fmt.Sprintf("%d/%d verified shards remain. Redundancy is reduced but recovery margin is %d shards.", in.ValidShards, total, margin)
		a.RecommendedAction = "Repair protection when convenient to return to full redundancy."
	default:
		a.Level = Reduced
		a.Summary = fmt.Sprintf("%d/%d verified shards remain. Recovery margin is %d shards.", in.ValidShards, total, margin)
		a.RecommendedAction = "Repair protection soon to rebuild missing/corrupt shards and restore full redundancy."
	}

	// Provider concentration is an independent risk. Escalate if loss of the
	// currently worst remaining provider would violate the configured safety
	// margin. Never downgrade a more severe shard-loss condition.
	if !providerSafe {
		providerLevel := Reduced
		providerAction := "Rebalance or repair onto additional independent providers to restore provider-failure protection."
		if in.ProviderFailureMargin <= 0 {
			providerLevel = High
			providerAction = "Add/reconnect an independent provider and repair or rebalance protection; another provider outage could make the file unrecoverable."
		}
		if severity(providerLevel) > severity(a.Level) {
			a.Level = providerLevel
			a.RecommendedAction = providerAction
		}
	}
	return a
}
