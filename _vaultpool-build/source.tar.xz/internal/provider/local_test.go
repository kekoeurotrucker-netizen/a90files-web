package provider

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLocalProviderRejectsTraversalAndAbsolutePaths(t *testing.T) {
	root := t.TempDir()
	p := Local{Name: "mock", Root: root}
	bad := []string{"../escape", "a/../../escape", "/absolute", `a\\windows-escape`}
	for _, object := range bad {
		if err := p.PutVerified(object, []byte("x"), HashBytes([]byte("x"))); err == nil {
			t.Fatalf("expected unsafe object %q to be rejected", object)
		}
	}
	if _, err := os.Stat(filepath.Join(filepath.Dir(root), "escape")); !os.IsNotExist(err) {
		t.Fatalf("path traversal created an external file: %v", err)
	}
}
