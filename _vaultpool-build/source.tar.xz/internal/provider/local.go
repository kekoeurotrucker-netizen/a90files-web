package provider

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/safefile"
)

type Local struct{ Name, Root string }

func Discover(pool string) ([]Local, error) {
	entries, err := os.ReadDir(pool)
	if err != nil {
		return nil, err
	}
	var out []Local
	for _, e := range entries {
		if e.IsDir() {
			out = append(out, Local{Name: e.Name(), Root: filepath.Join(pool, e.Name())})
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no providers in %s", pool)
	}
	return out, nil
}

func validateObjectName(object string) error {
	if object == "" || strings.Contains(object, `\`) {
		return fmt.Errorf("invalid provider object name %q", object)
	}
	for _, part := range strings.Split(object, "/") {
		if part == "" || part == "." || part == ".." {
			return fmt.Errorf("unsafe provider object name %q", object)
		}
	}
	if filepath.IsAbs(filepath.FromSlash(object)) {
		return fmt.Errorf("absolute provider object name %q", object)
	}
	return nil
}

func (p Local) path(object string) (string, error) {
	if err := validateObjectName(object); err != nil {
		return "", err
	}
	root, err := filepath.Abs(p.Root)
	if err != nil {
		return "", err
	}
	path := filepath.Join(root, filepath.FromSlash(object))
	rel, err := filepath.Rel(root, path)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return "", fmt.Errorf("provider object escapes root: %q", object)
	}
	return path, nil
}

func (p Local) PutVerified(object string, data []byte, expected string) error {
	path, err := p.path(object)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".vaultpool-upload-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	committed := false
	defer func() {
		tmp.Close()
		if !committed {
			_ = os.Remove(tmpName)
		}
	}()
	h := sha256.New()
	w := io.MultiWriter(tmp, h)
	if _, err := w.Write(data); err != nil {
		return err
	}
	if err := tmp.Sync(); err != nil {
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	got := hex.EncodeToString(h.Sum(nil))
	if got != expected {
		return fmt.Errorf("write hash mismatch: got %s want %s", got, expected)
	}
	check, err := HashFile(tmpName)
	if err != nil {
		return err
	}
	if check != expected {
		return fmt.Errorf("post-write verification mismatch")
	}
	if err := safefile.CommitTemp(tmpName, path); err != nil {
		return err
	}
	committed = true
	return nil
}

func (p Local) Get(object string) ([]byte, error) {
	path, err := p.path(object)
	if err != nil {
		return nil, err
	}
	return os.ReadFile(path)
}
func (p Local) Delete(object string) error {
	path, err := p.path(object)
	if err != nil {
		return err
	}
	return os.Remove(path)
}
func (p Local) Exists(object string) bool {
	path, err := p.path(object)
	if err != nil {
		return false
	}
	_, err = os.Stat(path)
	return err == nil
}
func (p Local) Hash(object string) (string, error) {
	path, err := p.path(object)
	if err != nil {
		return "", err
	}
	return HashFile(path)
}

func HashBytes(b []byte) string { s := sha256.Sum256(b); return hex.EncodeToString(s[:]) }
func HashFile(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// List returns provider-relative object names below prefix. The local mock uses
// it to simulate provider object listing for recovery discovery.
func (p Local) List(prefix string) ([]string, error) {
	base, err := p.path(prefix)
	if err != nil {
		return nil, err
	}
	var out []string
	if _, err := os.Stat(base); err != nil {
		if os.IsNotExist(err) {
			return out, nil
		}
		return nil, err
	}
	err = filepath.WalkDir(base, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			return nil
		}
		rel, err := filepath.Rel(p.Root, path)
		if err != nil {
			return err
		}
		out = append(out, filepath.ToSlash(rel))
		return nil
	})
	if err != nil {
		return nil, err
	}
	return out, nil
}
