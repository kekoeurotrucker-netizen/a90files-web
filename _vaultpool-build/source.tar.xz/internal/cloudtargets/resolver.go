package cloudtargets

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type tokenProvider interface {
	AccessToken(context.Context, string) (string, error)
}

type remoteStoreConnector interface {
	RemoteStore() remoteobject.Store
}

type boundRemoteStoreConnector interface {
	RemoteStoreFor(accountID, stableTargetID string) remoteobject.Store
}

// unavailableStore is attached to a known target when its connector is not
// currently usable. The target is disabled, so normal core code will classify
// its shards as temporarily unavailable rather than permanently missing.
type unavailableStore struct{ providerID string }

func (s unavailableStore) ProviderID() string { return s.providerID }
func (s unavailableStore) PutVerified(context.Context, string, string, []byte, string) (remoteobject.Object, error) {
	return remoteobject.Object{}, errors.New("storage target unavailable")
}
func (s unavailableStore) GetVerified(context.Context, string, string, int64, string) ([]byte, error) {
	return nil, errors.New("storage target unavailable")
}
func (s unavailableStore) Delete(context.Context, string, string) error {
	return errors.New("storage target unavailable")
}

type Resolver struct {
	Store      *appstate.Store
	Connectors *connector.Registry
}

func New(store *appstate.Store, connectors *connector.Registry) (*Resolver, error) {
	if store == nil || connectors == nil {
		return nil, errors.New("app state and connector registry required")
	}
	return &Resolver{Store: store, Connectors: connectors}, nil
}

func (r *Resolver) Resolve(_ context.Context) ([]storage.Target, error) {
	d := r.Store.Snapshot()
	out := make([]storage.Target, 0, len(d.Accounts))
	for _, a := range d.Accounts {
		if a.StableTargetID == "" {
			continue
		} // never verified, therefore cannot be referenced by a committed manifest
		var rs remoteobject.Store = unavailableStore{providerID: a.ProviderID}
		enabled := false
		if c, ok := r.Connectors.Get(a.ProviderID); ok && r.Connectors.Ready(a.ProviderID) {
			if sp, ok := c.(boundRemoteStoreConnector); ok {
				rs = sp.RemoteStoreFor(a.ID, a.StableTargetID)
				enabled = true
			} else if sp, ok := c.(remoteStoreConnector); ok {
				rs = sp.RemoteStore()
				enabled = true
			} else if tp, ok := c.(tokenProvider); ok {
				switch a.ProviderID {
				case "google-drive":
					rs = &remoteobject.GoogleDrive{Tokens: tp}
					enabled = true
				case "onedrive":
					rs = &remoteobject.OneDrive{Tokens: tp}
					enabled = true
				case "dropbox":
					rs = &remoteobject.Dropbox{Tokens: tp}
					enabled = true
				case "pcloud":
					if hp, ok := c.(remoteobject.PCloudHostProvider); ok {
						rs = &remoteobject.PCloud{Tokens: tp, Hosts: hp}
						enabled = true
					}
				}
			}
		}
		// A stale quota snapshot may remain useful for display, but writes/audits
		// must not call a provider when auth/health explicitly says unavailable.
		if a.State != "connected" || a.Health == string(connector.HealthUnavailable) {
			enabled = false
		}
		failureDomain := a.ProviderID
		if p, ok := r.Store.Provider(a.ProviderID); ok && strings.TrimSpace(p.FailureDomain) != "" {
			failureDomain = p.FailureDomain
		}
		t := storage.Target{
			ID:                  a.StableTargetID,
			FailureDomain:       failureDomain,
			AccountID:           a.ID,
			Store:               rs,
			FreeBytes:           a.FreeBytes,
			MaxObjectBytes:      a.MaxObjectBytes,
			UploadBytesPerSec:   a.UploadBytesPerSec,
			DownloadBytesPerSec: a.DownloadBytesPerSec,
			Enabled:             enabled,
		}
		if err := t.Validate(); err != nil {
			return nil, fmt.Errorf("account %s target: %w", a.ID, err)
		}
		out = append(out, t)
	}
	if len(out) == 0 {
		return nil, errors.New("no previously verified storage accounts are available in this VaultPool profile")
	}
	return storage.Sorted(out), nil
}
