package cloudtargets

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/connector"
)

type readyTokenConnector struct{ id string }

func (c readyTokenConnector) ProviderID() string { return c.id }
func (c readyTokenConnector) Ready() bool        { return true }
func (c readyTokenConnector) AccessToken(context.Context, string) (string, error) {
	return "token", nil
}
func (c readyTokenConnector) Probe(context.Context, string) (connector.Snapshot, error) {
	panic("not used")
}

func TestResolveKeepsKnownReauthTargetAsUnavailable(t *testing.T) {
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	_, err = st.ApplySnapshot(connector.Snapshot{ProviderID: "google-drive", AccountID: a.ID, ProviderSubject: "stable-subject", Identity: "x@example.com", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: 1000, UsedBytes: 100, FreeBytes: 900})
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	if err := reg.Register(readyTokenConnector{id: "google-drive"}); err != nil {
		t.Fatal(err)
	}
	r, err := New(st, reg)
	if err != nil {
		t.Fatal(err)
	}
	targets, err := r.Resolve(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(targets) != 1 || !targets[0].Enabled {
		t.Fatalf("unexpected enabled targets: %+v", targets)
	}
	// A later provider snapshot can require reauthentication while keeping the
	// stable target id from the previously verified account.
	_, err = st.ApplySnapshot(connector.Snapshot{ProviderID: "google-drive", AccountID: a.ID, ProviderSubject: "stable-subject", Identity: "x@example.com", Auth: connector.ReauthRequired, Health: connector.HealthUnavailable, Transfer: connector.TransferPaused, TotalBytes: 1000, UsedBytes: 100, FreeBytes: 900})
	if err != nil {
		t.Fatal(err)
	}
	targets, err = r.Resolve(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(targets) != 1 || targets[0].Enabled {
		t.Fatalf("reauth target must remain known but disabled: %+v", targets)
	}
}
