package library

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"

	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

const storageID = "vaultpool-library-v1"
const stateVersion = 1

type SecretStore interface {
	Get(string, secretvault.Kind) ([]byte, bool, error)
	Put(string, secretvault.Kind, []byte) error
}

type Folder struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type State struct {
	Version     int               `json:"version"`
	Folders     []Folder          `json:"folders"`
	Assignments map[string]string `json:"assignments"`
}

type Category struct {
	ID    string `json:"id"`
	Label string `json:"label"`
	Icon  string `json:"icon"`
}

var categories = []Category{
	{ID: "video", Label: "Vídeos", Icon: "▶"},
	{ID: "image", Label: "Imágenes", Icon: "▧"},
	{ID: "document", Label: "Documentos", Icon: "▤"},
	{ID: "audio", Label: "Audio", Icon: "♪"},
	{ID: "archive", Label: "Comprimidos", Icon: "▦"},
	{ID: "code", Label: "Código", Icon: "</>"},
	{ID: "application", Label: "Aplicaciones", Icon: "◇"},
	{ID: "other", Label: "Otros", Icon: "▱"},
}

var extensionCategory = buildExtensionMap()

func buildExtensionMap() map[string]string {
	groups := map[string][]string{
		"video":       {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm", ".m4v", ".mpg", ".mpeg", ".m2ts", ".mts", ".3gp", ".flv"},
		"image":       {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif", ".avif", ".svg", ".raw", ".cr2", ".cr3", ".nef", ".arw", ".dng"},
		"document":    {".pdf", ".doc", ".docx", ".odt", ".rtf", ".txt", ".md", ".xls", ".xlsx", ".ods", ".csv", ".ppt", ".pptx", ".odp", ".epub", ".mobi", ".pages", ".numbers", ".key"},
		"audio":       {".mp3", ".wav", ".flac", ".aac", ".m4a", ".ogg", ".opus", ".wma", ".aiff", ".aif", ".alac", ".mid", ".midi"},
		"archive":     {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2", ".xz", ".zst", ".tgz", ".tbz", ".tbz2", ".txz"},
		"code":        {".go", ".py", ".js", ".mjs", ".cjs", ".ts", ".jsx", ".tsx", ".html", ".htm", ".css", ".scss", ".sass", ".less", ".json", ".yaml", ".yml", ".xml", ".sql", ".sh", ".ps1", ".bat", ".cmd", ".c", ".cc", ".cpp", ".h", ".hpp", ".java", ".rs", ".php", ".rb", ".swift", ".kt", ".kts", ".lua", ".vue", ".svelte"},
		"application": {".exe", ".msi", ".msix", ".appx", ".apk", ".ipa", ".dmg", ".pkg", ".deb", ".rpm", ".appimage", ".jar"},
	}
	out := map[string]string{}
	for id, exts := range groups {
		for _, ext := range exts {
			out[ext] = id
		}
	}
	return out
}

func Categories() []Category {
	out := make([]Category, len(categories))
	copy(out, categories)
	return out
}

func CategoryFor(name string) Category {
	ext := strings.ToLower(filepath.Ext(strings.TrimSpace(name)))
	id := extensionCategory[ext]
	if id == "" {
		id = "other"
	}
	for _, c := range categories {
		if c.ID == id {
			return c
		}
	}
	return categories[len(categories)-1]
}

func Extension(name string) string {
	return strings.ToLower(filepath.Ext(strings.TrimSpace(name)))
}

type Service struct {
	vault SecretStore
	mu    sync.Mutex
}

func New(vault SecretStore) (*Service, error) {
	if vault == nil {
		return nil, errors.New("secret vault required")
	}
	return &Service{vault: vault}, nil
}

func defaultState() State {
	return State{Version: stateVersion, Folders: []Folder{}, Assignments: map[string]string{}}
}

func (s *Service) loadLocked() (State, error) {
	b, ok, err := s.vault.Get(storageID, secretvault.LibraryMetadata)
	if err != nil {
		return State{}, err
	}
	if !ok {
		return defaultState(), nil
	}
	defer zero(b)
	var st State
	if err := json.Unmarshal(b, &st); err != nil {
		return State{}, errors.New("encrypted library metadata is invalid")
	}
	if st.Version != stateVersion {
		return State{}, errors.New("unsupported library metadata version")
	}
	if st.Assignments == nil {
		st.Assignments = map[string]string{}
	}
	if err := validateState(st); err != nil {
		return State{}, err
	}
	return st, nil
}

func validateState(st State) error {
	if len(st.Folders) > 5000 || len(st.Assignments) > 2_000_000 {
		return errors.New("library metadata exceeds safety limits")
	}
	ids := map[string]bool{}
	names := map[string]bool{}
	for _, f := range st.Folders {
		if !validFolderID(f.ID) {
			return errors.New("invalid library folder id")
		}
		if err := validateFolderName(f.Name); err != nil {
			return err
		}
		key := strings.ToLower(strings.TrimSpace(f.Name))
		if ids[f.ID] || names[key] {
			return errors.New("duplicate library folder")
		}
		ids[f.ID] = true
		names[key] = true
	}
	for fileID, folderID := range st.Assignments {
		if !validFileID(fileID) || !ids[folderID] {
			return errors.New("invalid library file assignment")
		}
	}
	return nil
}

func (s *Service) saveLocked(st State) error {
	st.Version = stateVersion
	if st.Assignments == nil {
		st.Assignments = map[string]string{}
	}
	if err := validateState(st); err != nil {
		return err
	}
	b, err := json.Marshal(st)
	if err != nil {
		return err
	}
	defer zero(b)
	return s.vault.Put(storageID, secretvault.LibraryMetadata, b)
}

func (s *Service) Snapshot() (State, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st, err := s.loadLocked()
	if err != nil {
		return State{}, err
	}
	sort.Slice(st.Folders, func(i, j int) bool {
		a, b := strings.ToLower(st.Folders[i].Name), strings.ToLower(st.Folders[j].Name)
		if a == b {
			return st.Folders[i].ID < st.Folders[j].ID
		}
		return a < b
	})
	return st, nil
}

func (s *Service) CreateFolder(name string) (Folder, error) {
	name = normalizeFolderName(name)
	if err := validateFolderName(name); err != nil {
		return Folder{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	st, err := s.loadLocked()
	if err != nil {
		return Folder{}, err
	}
	for _, f := range st.Folders {
		if strings.EqualFold(f.Name, name) {
			return Folder{}, errors.New("ya existe una carpeta con ese nombre")
		}
	}
	id, err := randomID(8)
	if err != nil {
		return Folder{}, err
	}
	now := time.Now().UTC()
	f := Folder{ID: id, Name: name, CreatedAt: now, UpdatedAt: now}
	st.Folders = append(st.Folders, f)
	if err := s.saveLocked(st); err != nil {
		return Folder{}, err
	}
	return f, nil
}

func (s *Service) RenameFolder(id, name string) (Folder, error) {
	if !validFolderID(id) {
		return Folder{}, errors.New("invalid library folder id")
	}
	name = normalizeFolderName(name)
	if err := validateFolderName(name); err != nil {
		return Folder{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	st, err := s.loadLocked()
	if err != nil {
		return Folder{}, err
	}
	idx := -1
	for i, f := range st.Folders {
		if f.ID == id {
			idx = i
		} else if strings.EqualFold(f.Name, name) {
			return Folder{}, errors.New("ya existe una carpeta con ese nombre")
		}
	}
	if idx < 0 {
		return Folder{}, errors.New("carpeta no encontrada")
	}
	st.Folders[idx].Name = name
	st.Folders[idx].UpdatedAt = time.Now().UTC()
	if err := s.saveLocked(st); err != nil {
		return Folder{}, err
	}
	return st.Folders[idx], nil
}

func (s *Service) DeleteFolder(id string) error {
	if !validFolderID(id) {
		return errors.New("invalid library folder id")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	st, err := s.loadLocked()
	if err != nil {
		return err
	}
	found := false
	out := st.Folders[:0]
	for _, f := range st.Folders {
		if f.ID == id {
			found = true
			continue
		}
		out = append(out, f)
	}
	if !found {
		return errors.New("carpeta no encontrada")
	}
	st.Folders = out
	for fileID, folderID := range st.Assignments {
		if folderID == id {
			delete(st.Assignments, fileID)
		}
	}
	return s.saveLocked(st)
}

func (s *Service) Assign(fileID, folderID string) error {
	if !validFileID(fileID) {
		return errors.New("invalid file id")
	}
	if folderID != "" && !validFolderID(folderID) {
		return errors.New("invalid library folder id")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	st, err := s.loadLocked()
	if err != nil {
		return err
	}
	if folderID == "" {
		delete(st.Assignments, fileID)
		return s.saveLocked(st)
	}
	found := false
	for _, f := range st.Folders {
		if f.ID == folderID {
			found = true
			break
		}
	}
	if !found {
		return errors.New("carpeta no encontrada")
	}
	st.Assignments[fileID] = folderID
	return s.saveLocked(st)
}

func normalizeFolderName(name string) string {
	return strings.Join(strings.Fields(strings.TrimSpace(name)), " ")
}

func validateFolderName(name string) error {
	if name == "" {
		return errors.New("el nombre de la carpeta es obligatorio")
	}
	if len([]rune(name)) > 80 {
		return errors.New("el nombre de la carpeta es demasiado largo")
	}
	if strings.ContainsAny(name, "/\\") || name == "." || name == ".." {
		return errors.New("el nombre de la carpeta contiene caracteres no permitidos")
	}
	for _, r := range name {
		if unicode.IsControl(r) {
			return errors.New("el nombre de la carpeta contiene caracteres no permitidos")
		}
	}
	return nil
}

func validFolderID(id string) bool {
	if len(id) != 16 {
		return false
	}
	_, err := hex.DecodeString(id)
	return err == nil
}

func validFileID(id string) bool {
	if len(id) != 32 {
		return false
	}
	_, err := hex.DecodeString(id)
	return err == nil
}

func randomID(bytes int) (string, error) {
	b := make([]byte, bytes)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	defer zero(b)
	return hex.EncodeToString(b), nil
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
