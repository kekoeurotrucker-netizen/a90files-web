package library

import (
	"errors"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type memoryVault struct{ values map[string][]byte }

func (m *memoryVault) key(id string, kind secretvault.Kind) string { return id + "\x00" + string(kind) }
func (m *memoryVault) Get(id string, kind secretvault.Kind) ([]byte, bool, error) {
	b, ok := m.values[m.key(id, kind)]
	return append([]byte(nil), b...), ok, nil
}
func (m *memoryVault) Put(id string, kind secretvault.Kind, b []byte) error {
	if len(b) == 0 {
		return errors.New("empty")
	}
	m.values[m.key(id, kind)] = append([]byte(nil), b...)
	return nil
}

func TestClassify(t *testing.T) {
	cases := map[string]string{"movie.MKV": "video", "foto.HEIC": "image", "factura.pdf": "document", "tema.flac": "audio", "backup.7z": "archive", "main.go": "code", "setup.exe": "application", "script.ts": "code", "captura.mts": "video", "sinextension": "other"}
	for name, want := range cases {
		if got := CategoryFor(name).ID; got != want {
			t.Fatalf("%s: got %s want %s", name, got, want)
		}
	}
}

func TestFolderLifecycleAndAssignments(t *testing.T) {
	v := &memoryVault{values: map[string][]byte{}}
	s, err := New(v)
	if err != nil {
		t.Fatal(err)
	}
	f, err := s.CreateFolder(" Trabajo  2026 ")
	if err != nil {
		t.Fatal(err)
	}
	if f.Name != "Trabajo 2026" {
		t.Fatalf("normalized name %q", f.Name)
	}
	if _, err := s.CreateFolder("trabajo 2026"); err == nil {
		t.Fatal("duplicate folder accepted")
	}
	id := "00112233445566778899aabbccddeeff"
	if err := s.Assign(id, f.ID); err != nil {
		t.Fatal(err)
	}
	st, err := s.Snapshot()
	if err != nil {
		t.Fatal(err)
	}
	if st.Assignments[id] != f.ID {
		t.Fatal("assignment missing")
	}
	renamed, err := s.RenameFolder(f.ID, "Facturas")
	if err != nil {
		t.Fatal(err)
	}
	if renamed.Name != "Facturas" {
		t.Fatal("rename failed")
	}
	if err := s.DeleteFolder(f.ID); err != nil {
		t.Fatal(err)
	}
	st, err = s.Snapshot()
	if err != nil {
		t.Fatal(err)
	}
	if len(st.Folders) != 0 || len(st.Assignments) != 0 {
		t.Fatalf("delete did not clean state: %+v", st)
	}
}

func TestRejectsUnsafeFolderNames(t *testing.T) {
	v := &memoryVault{values: map[string][]byte{}}
	s, _ := New(v)
	for _, name := range []string{"", "..", "a/b", "a\\b"} {
		if _, err := s.CreateFolder(name); err == nil {
			t.Fatalf("accepted %q", name)
		}
	}
}
