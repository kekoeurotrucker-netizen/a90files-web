package remoteobject

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestDropboxPermissionError(t *testing.T) {
	for _, tc := range []struct {
		name, body, scope string
		status            int
	}{
		{"app console", `{"error":{".tag":"other"},"user_message":{"text":"Error in call to API function files/upload: Your app is not permitted because it does not have the required scope 'files.content.write'. sensitive-value"}}`, "files.content.write", 400},
		{"token scope", `{"error":{".tag":"missing_scope","required_scope":"files.metadata.read"}}`, "files.metadata.read", 401},
		{"download scope", `{"error":{".tag":"missing_scope","required_scope":"files.content.read"}}`, "files.content.read", 401},
		{"account scope", `{"error":{".tag":"missing_scope","required_scope":"account_info.read"}}`, "account_info.read", 403},
		{"unknown scope", `{"error":{".tag":"missing_scope","required_scope":"sensitive-value"}}`, "", 401},
		{"arbitrary text", `{"error":{"code":"sensitive-value","message":"sensitive-value"},"user_message":{"text":"sensitive-value"}}`, "", 400},
		{"not permission", `{"error":{".tag":"other"},"user_message":{"text":"sensitive-value"}}`, "", 400},
		{"malformed", `sensitive-value`, "", 400},
		{"transient", `{"error":{".tag":"missing_scope","required_scope":"files.content.write"}}`, "", 503},
	} {
		t.Run(tc.name, func(t *testing.T) {
			resp := &http.Response{StatusCode: tc.status, Status: http.StatusText(tc.status), Header: http.Header{"Retry-After": {"5"}}, Body: io.NopCloser(strings.NewReader(tc.body))}
			err := dropboxProviderError(resp)
			var apiErr *APIError
			if !errors.As(err, &apiErr) || apiErr.StatusCode != tc.status || apiErr.RetryAfter != 5*time.Second {
				t.Fatalf("lost API classification: %v", err)
			}
			if strings.Contains(err.Error(), "sensitive-value") {
				t.Fatalf("raw error text leaked: %v", err)
			}
			if tc.scope != "" {
				if apiErr.Code != "missing_scope" || !strings.Contains(err.Error(), tc.scope) || !strings.Contains(err.Error(), "Submit") {
					t.Fatalf("missing actionable permission error: %v", err)
				}
			} else if apiErr.Code != "" || apiErr.Message != "" {
				t.Fatalf("unrecognized text exposed: %v", err)
			}
		})
	}
}

func TestDropboxOperationsReportMissingScope(t *testing.T) {
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusBadRequest)
		_, _ = io.WriteString(w, `{"error":{".tag":"missing_scope","required_scope":"files.content.write"}}`)
	}))
	defer server.Close()
	s := &Dropbox{Tokens: staticTokens{"test-token"}, HTTP: server.Client(), APIBase: server.URL, FilesBase: server.URL}
	ctx := context.Background()
	data := []byte("encrypted-test-payload")
	operations := map[string]func() error{
		"upload": func() error {
			_, err := s.PutVerified(ctx, "acct", "objects/f/b/s", data, SHA256Bytes(data))
			return err
		},
		"download": func() error {
			_, err := s.GetVerified(ctx, "acct", "id:object", int64(len(data)), SHA256Bytes(data))
			return err
		},
		"delete":         func() error { return s.Delete(ctx, "acct", "id:object") },
		"list manifests": func() error { _, err := s.ListManifestCandidates(ctx, "acct"); return err },
		"read manifest":  func() error { _, err := s.ReadManifestCandidate(ctx, "acct", "id:object", 1024); return err },
		"list recovery":  func() error { _, err := s.ListRecoveryRecordCandidates(ctx, "acct"); return err },
		"read recovery":  func() error { _, err := s.ReadRecoveryRecordCandidate(ctx, "acct", "id:object", 1024); return err },
	}
	for name, operation := range operations {
		t.Run(name, func(t *testing.T) {
			err := operation()
			var apiErr *APIError
			if !errors.As(err, &apiErr) || apiErr.Code != "missing_scope" {
				t.Fatalf("missing scoped error: %v", err)
			}
		})
	}
}
