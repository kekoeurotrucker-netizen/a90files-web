package remoteobject

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
)

type Dropbox struct {
	Tokens    TokenProvider
	HTTP      *http.Client
	APIBase   string
	FilesBase string
}

func (s *Dropbox) ProviderID() string { return "dropbox" }
func (s *Dropbox) apiBase() string {
	b := strings.TrimRight(s.APIBase, "/")
	if b == "" {
		b = "https://api.dropboxapi.com/2"
	}
	return b
}
func (s *Dropbox) filesBase() string {
	b := strings.TrimRight(s.FilesBase, "/")
	if b == "" {
		b = "https://content.dropboxapi.com/2"
	}
	return b
}
func (s *Dropbox) client() *http.Client {
	if s.HTTP != nil {
		return s.HTTP
	}
	return &http.Client{}
}
func dropboxObjectPath(key string) (string, error) {
	if err := ValidateKey(key); err != nil {
		return "", err
	}
	name, err := oneDriveObjectName(key)
	if err != nil {
		return "", err
	}
	return "/" + name, nil
}
func dropboxAPIArg(v any) (string, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return "", err
	}
	return string(b), nil
}
func (s *Dropbox) token(ctx context.Context, accountID string) (string, error) {
	if s.Tokens == nil {
		return "", errors.New("Dropbox token provider missing")
	}
	return s.Tokens.AccessToken(ctx, accountID)
}
func (s *Dropbox) contentRequest(ctx context.Context, endpoint, token string, arg any, body io.Reader) (*http.Response, error) {
	rawArg, err := dropboxAPIArg(arg)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, s.filesBase()+endpoint, body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Dropbox-API-Arg", rawArg)
	if body != nil {
		req.Header.Set("Content-Type", "application/octet-stream")
	}
	return noRedirectClient(s.client()).Do(req)
}
func (s *Dropbox) rpcRequest(ctx context.Context, endpoint, token string, arg any, dst any) error {
	rawArg, err := dropboxAPIArg(arg)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, s.apiBase()+endpoint, strings.NewReader(rawArg))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return dropboxProviderError(resp)
	}
	if dst == nil {
		_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 1<<20))
		return nil
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 2<<20)).Decode(dst); err != nil {
		return errors.New("invalid Dropbox API response")
	}
	return nil
}

func (s *Dropbox) PutVerified(ctx context.Context, accountID, key string, data []byte, expectedSHA string) (Object, error) {
	if len(data) == 0 {
		return Object{}, errors.New("empty remote objects are not supported")
	}
	if len(data) > 150*1000*1000 {
		return Object{}, errors.New("Dropbox single-upload object exceeds 150 MB")
	}
	if err := validateExpected(data, expectedSHA); err != nil {
		return Object{}, err
	}
	path, err := dropboxObjectPath(key)
	if err != nil {
		return Object{}, err
	}
	token, err := s.token(ctx, accountID)
	if err != nil {
		return Object{}, err
	}
	arg := map[string]any{"path": path, "mode": "add", "autorename": false, "mute": true, "strict_conflict": true}
	resp, err := s.contentRequest(ctx, "/files/upload", token, arg, bytes.NewReader(data))
	if err != nil {
		return Object{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return Object{}, dropboxProviderError(resp)
	}
	var meta struct {
		ID   string `json:"id"`
		Name string `json:"name"`
		Size int64  `json:"size"`
		Rev  string `json:"rev"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&meta); err != nil || meta.ID == "" {
		return Object{}, errors.New("Dropbox upload did not return object id")
	}
	if meta.Size != 0 && meta.Size != int64(len(data)) {
		_ = s.Delete(ctx, accountID, meta.ID)
		return Object{}, fmt.Errorf("Dropbox upload size mismatch: got %d want %d", meta.Size, len(data))
	}
	obj := Object{ProviderID: s.ProviderID(), AccountID: accountID, ID: meta.ID, Key: key, Name: meta.Name, Size: int64(len(data)), SHA256: strings.ToLower(expectedSHA), ETag: meta.Rev}
	if _, err := s.GetVerified(ctx, accountID, obj.ID, obj.Size, obj.SHA256); err != nil {
		_ = s.Delete(ctx, accountID, obj.ID)
		return Object{}, fmt.Errorf("Dropbox post-upload verification failed: %w", err)
	}
	return obj, nil
}

func (s *Dropbox) GetVerified(ctx context.Context, accountID, objectID string, expectedSize int64, expectedSHA string) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("Dropbox object id required")
	}
	token, err := s.token(ctx, accountID)
	if err != nil {
		return nil, err
	}
	resp, err := s.contentRequest(ctx, "/files/download", token, map[string]any{"path": objectID}, nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, dropboxProviderError(resp)
	}
	b, err := readExpected(resp, expectedSize)
	if err != nil {
		return nil, err
	}
	if err := validateExpected(b, expectedSHA); err != nil {
		return nil, err
	}
	return b, nil
}

func (s *Dropbox) Delete(ctx context.Context, accountID, objectID string) error {
	if objectID == "" {
		return errors.New("Dropbox object id required")
	}
	token, err := s.token(ctx, accountID)
	if err != nil {
		return err
	}
	err = s.rpcRequest(ctx, "/files/delete_v2", token, map[string]any{"path": objectID}, nil)
	if apiErr, ok := err.(*APIError); ok && apiErr.StatusCode == http.StatusConflict {
		return nil
	}
	return err
}

type dropboxListEntry struct {
	Tag  string `json:".tag"`
	ID   string `json:"id"`
	Name string `json:"name"`
	Size int64  `json:"size"`
}

type dropboxListPage struct {
	Entries []dropboxListEntry `json:"entries"`
	Cursor  string             `json:"cursor"`
	HasMore bool               `json:"has_more"`
}

func (s *Dropbox) listRoot(ctx context.Context, accountID string) ([]dropboxListEntry, error) {
	token, err := s.token(ctx, accountID)
	if err != nil {
		return nil, err
	}
	arg := map[string]any{"path": "", "recursive": false, "include_deleted": false, "include_non_downloadable_files": false, "limit": 200}
	var page dropboxListPage
	if err := s.rpcRequest(ctx, "/files/list_folder", token, arg, &page); err != nil {
		return nil, err
	}
	out := append([]dropboxListEntry(nil), page.Entries...)
	for page.HasMore {
		cursor := page.Cursor
		if cursor == "" {
			return nil, errors.New("Dropbox pagination cursor missing")
		}
		page = dropboxListPage{}
		if err := s.rpcRequest(ctx, "/files/list_folder/continue", token, map[string]any{"cursor": cursor}, &page); err != nil {
			return nil, err
		}
		out = append(out, page.Entries...)
	}
	return out, nil
}

func (s *Dropbox) ListManifestCandidates(ctx context.Context, accountID string) ([]ManifestCandidate, error) {
	entries, err := s.listRoot(ctx, accountID)
	if err != nil {
		return nil, err
	}
	var out []ManifestCandidate
	seen := map[string]bool{}
	for _, e := range entries {
		if e.ID == "" || seen[e.ID] || e.Size <= 0 || !strings.HasPrefix(e.Name, "vp-manifest-") || !strings.HasSuffix(e.Name, ".cpm") {
			continue
		}
		seen[e.ID] = true
		fileID, _ := manifestFileIDFromOneDriveName(e.Name)
		out = append(out, ManifestCandidate{Locator: e.ID, RecoveryID: fileID, Size: e.Size})
	}
	return out, nil
}

func (s *Dropbox) ReadManifestCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("Dropbox manifest object id required")
	}
	if maxBytes <= 0 {
		return nil, errors.New("manifest recovery size cap required")
	}
	token, err := s.token(ctx, accountID)
	if err != nil {
		return nil, err
	}
	resp, err := s.contentRequest(ctx, "/files/download", token, map[string]any{"path": objectID}, nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, dropboxProviderError(resp)
	}
	return readBounded(resp, maxBytes)
}

func (s *Dropbox) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]RecoveryRecordCandidate, error) {
	entries, err := s.listRoot(ctx, accountID)
	if err != nil {
		return nil, err
	}
	var out []RecoveryRecordCandidate
	seen := map[string]bool{}
	for _, e := range entries {
		if e.ID == "" || seen[e.ID] || e.Size <= 0 {
			continue
		}
		rid, ok := recoveryIDFromOneDriveName(e.Name)
		if !ok {
			continue
		}
		seen[e.ID] = true
		out = append(out, RecoveryRecordCandidate{Locator: e.ID, RecoveryID: rid, Size: e.Size})
	}
	return out, nil
}

func (s *Dropbox) ReadRecoveryRecordCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("Dropbox recovery-record object id required")
	}
	if maxBytes <= 0 {
		return nil, errors.New("recovery-record size cap required")
	}
	token, err := s.token(ctx, accountID)
	if err != nil {
		return nil, err
	}
	resp, err := s.contentRequest(ctx, "/files/download", token, map[string]any{"path": objectID}, nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, dropboxProviderError(resp)
	}
	return readBounded(resp, maxBytes)
}

func dropboxProviderError(resp *http.Response) error {
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	copyResp := *resp
	copyResp.Body = io.NopCloser(bytes.NewReader(body))
	apiErr := providerError(&copyResp).(*APIError)
	// Dropbox can include request data in error text. Expose only known causes.
	apiErr.Code, apiErr.Message = "", ""
	var envelope struct {
		Error struct {
			Tag           string `json:".tag"`
			RequiredScope string `json:"required_scope"`
		} `json:"error"`
		UserMessage struct {
			Text string `json:"text"`
		} `json:"user_message"`
	}
	if json.Unmarshal(body, &envelope) != nil {
		return apiErr
	}
	if resp.StatusCode != http.StatusBadRequest && resp.StatusCode != http.StatusUnauthorized && resp.StatusCode != http.StatusForbidden {
		return apiErr
	}
	for _, scope := range []string{"account_info.read", "files.metadata.read", "files.content.read", "files.content.write"} {
		structured := envelope.Error.Tag == "missing_scope" && envelope.Error.RequiredScope == scope
		appPermission := envelope.Error.Tag == "other" && strings.Contains(envelope.UserMessage.Text, "does not have the required scope '"+scope+"'")
		if structured || appPermission {
			apiErr.Code = "missing_scope"
			apiErr.Message = "Dropbox: falta el permiso " + scope + ". Activalo en App Console > Permissions, guarda con Submit y vuelve a autorizar la cuenta en VaultPool."
			return apiErr
		}
	}
	return apiErr
}
