package remoteobject

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

type GoogleDrive struct {
	Tokens     TokenProvider
	HTTP       *http.Client
	APIBase    string
	UploadBase string
}

func (s *GoogleDrive) ProviderID() string { return "google-drive" }
func (s *GoogleDrive) bases() (string, string) {
	api := strings.TrimRight(s.APIBase, "/")
	if api == "" {
		api = "https://www.googleapis.com/drive/v3"
	}
	upload := strings.TrimRight(s.UploadBase, "/")
	if upload == "" {
		upload = "https://www.googleapis.com/upload/drive/v3"
	}
	return api, upload
}
func (s *GoogleDrive) client() *http.Client {
	if s.HTTP != nil {
		return s.HTTP
	}
	// No global transfer deadline: VaultPool must not invent its own bandwidth
	// or duration limit. Callers/scheduler may cancel via context, while future
	// stall detection can distinguish a stuck transfer from a merely slow one.
	return &http.Client{}
}
func (s *GoogleDrive) authRequest(ctx context.Context, method, raw, token string, body io.Reader) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, raw, body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	return noRedirectClient(s.client()).Do(req)
}

func (s *GoogleDrive) ensureRoot(ctx context.Context, token string) (string, error) {
	api, _ := s.bases()
	u, _ := url.Parse(api + "/files")
	q := u.Query()
	q.Set("q", "mimeType='application/vnd.google-apps.folder' and trashed=false and appProperties has { key='vaultpool_root' and value='1' }")
	q.Set("spaces", "drive")
	q.Set("pageSize", "10")
	q.Set("fields", "files(id,name,appProperties)")
	u.RawQuery = q.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", providerError(resp)
	}
	var list struct {
		Files []struct {
			ID string `json:"id"`
		} `json:"files"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&list); err != nil {
		return "", errors.New("invalid Google Drive folder response")
	}
	if len(list.Files) > 0 && list.Files[0].ID != "" {
		return list.Files[0].ID, nil
	}
	meta, _ := json.Marshal(map[string]any{
		"name":          "VaultPool",
		"mimeType":      "application/vnd.google-apps.folder",
		"appProperties": map[string]string{"vaultpool_root": "1"},
	})
	u, _ = url.Parse(api + "/files")
	q = u.Query()
	q.Set("fields", "id,name")
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, u.String(), bytes.NewReader(meta))
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err = noRedirectClient(s.client()).Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", providerError(resp)
	}
	var created struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&created); err != nil || created.ID == "" {
		return "", errors.New("Google Drive did not return VaultPool folder id")
	}
	return created.ID, nil
}

func objectKind(key string) string {
	if strings.HasPrefix(key, "metadata/manifests/") {
		return "manifest"
	}
	if _, ok := recoveryRecordIDFromKey(key); ok {
		return "recovery_file_key"
	}
	return "data"
}

func (s *GoogleDrive) PutVerified(ctx context.Context, accountID, key string, data []byte, expectedSHA string) (Object, error) {
	if s.Tokens == nil {
		return Object{}, errors.New("Google Drive token provider missing")
	}
	if err := ValidateKey(key); err != nil {
		return Object{}, err
	}
	if len(data) == 0 {
		return Object{}, errors.New("empty remote objects are not supported")
	}
	if err := validateExpected(data, expectedSHA); err != nil {
		return Object{}, err
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return Object{}, err
	}
	rootID, err := s.ensureRoot(ctx, token)
	if err != nil {
		return Object{}, fmt.Errorf("ensure VaultPool Drive folder: %w", err)
	}
	name, err := objectName(key)
	if err != nil {
		return Object{}, err
	}
	keyHash := SHA256Bytes([]byte(key))
	props := map[string]string{
		"vaultpool_object": keyHash,
		"vaultpool_sha256": strings.ToLower(expectedSHA),
		"vaultpool_kind":   objectKind(key),
	}
	if fileID, ok := manifestFileIDFromKey(key); ok {
		props["vaultpool_file_id"] = fileID
	}
	if recoveryID, ok := recoveryRecordIDFromKey(key); ok {
		props["vaultpool_recovery_id"] = recoveryID
	}
	meta, _ := json.Marshal(map[string]any{
		"name":          name,
		"mimeType":      "application/octet-stream",
		"parents":       []string{rootID},
		"appProperties": props,
	})
	_, uploadBase := s.bases()
	u, _ := url.Parse(uploadBase + "/files")
	q := u.Query()
	q.Set("uploadType", "resumable")
	q.Set("fields", "id,name,size,md5Checksum")
	u.RawQuery = q.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, u.String(), bytes.NewReader(meta))
	if err != nil {
		return Object{}, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json; charset=UTF-8")
	req.Header.Set("X-Upload-Content-Type", "application/octet-stream")
	req.Header.Set("X-Upload-Content-Length", strconv.Itoa(len(data)))
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return Object{}, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return Object{}, providerError(resp)
	}
	location := resp.Header.Get("Location")
	_ = resp.Body.Close()
	if location == "" {
		return Object{}, errors.New("Google Drive resumable upload missing Location")
	}
	if err := sameHTTPSOrigin(location, uploadBase); err != nil {
		return Object{}, err
	}
	put, err := http.NewRequestWithContext(ctx, http.MethodPut, location, bytes.NewReader(data))
	if err != nil {
		return Object{}, err
	}
	put.Header.Set("Authorization", "Bearer "+token)
	put.Header.Set("Content-Type", "application/octet-stream")
	put.Header.Set("Content-Length", strconv.Itoa(len(data)))
	resp, err = noRedirectClient(s.client()).Do(put)
	if err != nil {
		return Object{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return Object{}, providerError(resp)
	}
	var created struct {
		ID   string `json:"id"`
		Name string `json:"name"`
		Size string `json:"size"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&created); err != nil || created.ID == "" {
		return Object{}, errors.New("Google Drive upload did not return object id")
	}
	obj := Object{ProviderID: s.ProviderID(), AccountID: accountID, ID: created.ID, Key: key, Name: name, Size: int64(len(data)), SHA256: strings.ToLower(expectedSHA)}
	if _, err := s.GetVerified(ctx, accountID, obj.ID, obj.Size, obj.SHA256); err != nil {
		_ = s.Delete(ctx, accountID, obj.ID)
		return Object{}, fmt.Errorf("Google Drive post-upload verification failed: %w", err)
	}
	return obj, nil
}

func (s *GoogleDrive) GetVerified(ctx context.Context, accountID, objectID string, expectedSize int64, expectedSHA string) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("Google Drive object id required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	api, _ := s.bases()
	u, _ := url.Parse(api + "/files/" + url.PathEscape(objectID))
	q := u.Query()
	q.Set("alt", "media")
	u.RawQuery = q.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	b, err := readExpected(resp, expectedSize)
	if err != nil {
		return nil, err
	}
	if err := validateExpected(b, expectedSHA); err != nil {
		return nil, err
	}
	return b, nil
}

func (s *GoogleDrive) Delete(ctx context.Context, accountID, objectID string) error {
	if objectID == "" {
		return errors.New("Google Drive object id required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return err
	}
	api, _ := s.bases()
	resp, err := s.authRequest(ctx, http.MethodDelete, api+"/files/"+url.PathEscape(objectID), token, nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound {
		return nil
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return providerError(resp)
	}
	return nil
}

func (s *GoogleDrive) ListManifestCandidates(ctx context.Context, accountID string) ([]ManifestCandidate, error) {
	if s.Tokens == nil {
		return nil, errors.New("Google Drive token provider missing")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	api, _ := s.bases()
	// Scan every VaultPool root marker. Concurrent historical clients could have
	// created more than one; recovery must not silently ignore any of them.
	u, _ := url.Parse(api + "/files")
	q := u.Query()
	q.Set("q", "mimeType='application/vnd.google-apps.folder' and trashed=false and appProperties has { key='vaultpool_root' and value='1' }")
	q.Set("spaces", "drive")
	q.Set("pageSize", "100")
	q.Set("fields", "nextPageToken,files(id)")
	u.RawQuery = q.Encode()
	var roots []string
	for next := u.String(); next != ""; {
		resp, err := s.authRequest(ctx, http.MethodGet, next, token, nil)
		if err != nil {
			return nil, err
		}
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			err := providerError(resp)
			_ = resp.Body.Close()
			return nil, err
		}
		var page struct {
			Next  string `json:"nextPageToken"`
			Files []struct {
				ID string `json:"id"`
			} `json:"files"`
		}
		if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&page); err != nil {
			_ = resp.Body.Close()
			return nil, errors.New("invalid Google Drive root listing")
		}
		_ = resp.Body.Close()
		for _, f := range page.Files {
			if f.ID != "" {
				roots = append(roots, f.ID)
			}
		}
		if page.Next == "" {
			break
		}
		nu, _ := url.Parse(api + "/files")
		nq := nu.Query()
		nq.Set("q", q.Get("q"))
		nq.Set("spaces", "drive")
		nq.Set("pageSize", "100")
		nq.Set("fields", "nextPageToken,files(id)")
		nq.Set("pageToken", page.Next)
		nu.RawQuery = nq.Encode()
		next = nu.String()
	}
	seen := map[string]bool{}
	var out []ManifestCandidate
	for _, rootID := range roots {
		u, _ := url.Parse(api + "/files")
		q := u.Query()
		rootLit := strings.ReplaceAll(rootID, "'", "\\'")
		q.Set("q", fmt.Sprintf("'%s' in parents and trashed=false and appProperties has { key='vaultpool_kind' and value='manifest' }", rootLit))
		q.Set("spaces", "drive")
		q.Set("pageSize", "100")
		q.Set("fields", "nextPageToken,files(id,size,appProperties)")
		u.RawQuery = q.Encode()
		baseQuery := q.Get("q")
		for next := u.String(); next != ""; {
			resp, err := s.authRequest(ctx, http.MethodGet, next, token, nil)
			if err != nil {
				return nil, err
			}
			if resp.StatusCode < 200 || resp.StatusCode >= 300 {
				err := providerError(resp)
				_ = resp.Body.Close()
				return nil, err
			}
			var page struct {
				Next  string `json:"nextPageToken"`
				Files []struct {
					ID            string            `json:"id"`
					Size          string            `json:"size"`
					AppProperties map[string]string `json:"appProperties"`
				} `json:"files"`
			}
			if err := json.NewDecoder(io.LimitReader(resp.Body, 2<<20)).Decode(&page); err != nil {
				_ = resp.Body.Close()
				return nil, errors.New("invalid Google Drive manifest listing")
			}
			_ = resp.Body.Close()
			for _, f := range page.Files {
				if f.ID == "" || seen[f.ID] {
					continue
				}
				n, err := strconv.ParseInt(f.Size, 10, 64)
				if err != nil || n <= 0 {
					continue
				}
				seen[f.ID] = true
				fileID := strings.ToLower(strings.TrimSpace(f.AppProperties["vaultpool_file_id"]))
				if len(fileID) != 32 {
					fileID = ""
				} else if _, err := hex.DecodeString(fileID); err != nil {
					fileID = ""
				}
				out = append(out, ManifestCandidate{Locator: f.ID, RecoveryID: fileID, Size: n})
			}
			if page.Next == "" {
				break
			}
			nu, _ := url.Parse(api + "/files")
			nq := nu.Query()
			nq.Set("q", baseQuery)
			nq.Set("spaces", "drive")
			nq.Set("pageSize", "100")
			nq.Set("fields", "nextPageToken,files(id,size,appProperties)")
			nq.Set("pageToken", page.Next)
			nu.RawQuery = nq.Encode()
			next = nu.String()
		}
	}
	return out, nil
}

func (s *GoogleDrive) ReadManifestCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("Google Drive manifest object id required")
	}
	if maxBytes <= 0 {
		return nil, errors.New("manifest recovery size cap required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	api, _ := s.bases()
	metaURL, _ := url.Parse(api + "/files/" + url.PathEscape(objectID))
	mq := metaURL.Query()
	mq.Set("fields", "id,size,appProperties")
	metaURL.RawQuery = mq.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, metaURL.String(), token, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, providerError(resp)
	}
	var meta struct {
		ID            string            `json:"id"`
		Size          string            `json:"size"`
		AppProperties map[string]string `json:"appProperties"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&meta); err != nil {
		_ = resp.Body.Close()
		return nil, errors.New("invalid Google Drive manifest metadata")
	}
	_ = resp.Body.Close()
	if meta.ID == "" || meta.AppProperties["vaultpool_kind"] != "manifest" {
		return nil, errors.New("Google Drive object is not a VaultPool manifest replica")
	}
	n, err := strconv.ParseInt(meta.Size, 10, 64)
	if err != nil || n <= 0 || n > maxBytes {
		return nil, errors.New("Google Drive manifest size is invalid or exceeds recovery cap")
	}
	u, _ := url.Parse(api + "/files/" + url.PathEscape(objectID))
	q := u.Query()
	q.Set("alt", "media")
	u.RawQuery = q.Encode()
	resp, err = s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	return readBounded(resp, maxBytes)
}

func (s *GoogleDrive) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]RecoveryRecordCandidate, error) {
	if s.Tokens == nil {
		return nil, errors.New("Google Drive token provider missing")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	api, _ := s.bases()
	rootsURL, _ := url.Parse(api + "/files")
	rq := rootsURL.Query()
	rq.Set("q", "mimeType='application/vnd.google-apps.folder' and trashed=false and appProperties has { key='vaultpool_root' and value='1' }")
	rq.Set("spaces", "drive")
	rq.Set("pageSize", "100")
	rq.Set("fields", "nextPageToken,files(id)")
	rootsURL.RawQuery = rq.Encode()
	var roots []string
	for next := rootsURL.String(); next != ""; {
		resp, err := s.authRequest(ctx, http.MethodGet, next, token, nil)
		if err != nil {
			return nil, err
		}
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			e := providerError(resp)
			_ = resp.Body.Close()
			return nil, e
		}
		var page struct {
			Next  string `json:"nextPageToken"`
			Files []struct {
				ID string `json:"id"`
			} `json:"files"`
		}
		if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&page); err != nil {
			_ = resp.Body.Close()
			return nil, errors.New("invalid Google Drive root listing")
		}
		_ = resp.Body.Close()
		for _, f := range page.Files {
			if f.ID != "" {
				roots = append(roots, f.ID)
			}
		}
		if page.Next == "" {
			break
		}
		nu, _ := url.Parse(api + "/files")
		nq := nu.Query()
		nq.Set("q", rq.Get("q"))
		nq.Set("spaces", "drive")
		nq.Set("pageSize", "100")
		nq.Set("fields", "nextPageToken,files(id)")
		nq.Set("pageToken", page.Next)
		nu.RawQuery = nq.Encode()
		next = nu.String()
	}
	seen := map[string]bool{}
	var out []RecoveryRecordCandidate
	for _, rootID := range roots {
		u, _ := url.Parse(api + "/files")
		q := u.Query()
		rootLit := strings.ReplaceAll(rootID, "'", "\\'")
		baseQuery := fmt.Sprintf("'%s' in parents and trashed=false and appProperties has { key='vaultpool_kind' and value='recovery_file_key' }", rootLit)
		q.Set("q", baseQuery)
		q.Set("spaces", "drive")
		q.Set("pageSize", "100")
		q.Set("fields", "nextPageToken,files(id,size,appProperties)")
		u.RawQuery = q.Encode()
		for next := u.String(); next != ""; {
			resp, err := s.authRequest(ctx, http.MethodGet, next, token, nil)
			if err != nil {
				return nil, err
			}
			if resp.StatusCode < 200 || resp.StatusCode >= 300 {
				e := providerError(resp)
				_ = resp.Body.Close()
				return nil, e
			}
			var page struct {
				Next  string `json:"nextPageToken"`
				Files []struct {
					ID            string            `json:"id"`
					Size          string            `json:"size"`
					AppProperties map[string]string `json:"appProperties"`
				} `json:"files"`
			}
			if err := json.NewDecoder(io.LimitReader(resp.Body, 2<<20)).Decode(&page); err != nil {
				_ = resp.Body.Close()
				return nil, errors.New("invalid Google Drive recovery-record listing")
			}
			_ = resp.Body.Close()
			for _, f := range page.Files {
				if f.ID == "" || seen[f.ID] {
					continue
				}
				rid := strings.ToLower(f.AppProperties["vaultpool_recovery_id"])
				if len(rid) != 32 {
					continue
				}
				if _, err := hex.DecodeString(rid); err != nil {
					continue
				}
				n, err := strconv.ParseInt(f.Size, 10, 64)
				if err != nil || n <= 0 {
					continue
				}
				seen[f.ID] = true
				out = append(out, RecoveryRecordCandidate{Locator: f.ID, RecoveryID: rid, Size: n})
			}
			if page.Next == "" {
				break
			}
			nu, _ := url.Parse(api + "/files")
			nq := nu.Query()
			nq.Set("q", baseQuery)
			nq.Set("spaces", "drive")
			nq.Set("pageSize", "100")
			nq.Set("fields", "nextPageToken,files(id,size,appProperties)")
			nq.Set("pageToken", page.Next)
			nu.RawQuery = nq.Encode()
			next = nu.String()
		}
	}
	return out, nil
}

func (s *GoogleDrive) ReadRecoveryRecordCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("Google Drive recovery-record object id required")
	}
	if maxBytes <= 0 {
		return nil, errors.New("recovery-record size cap required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	api, _ := s.bases()
	metaURL, _ := url.Parse(api + "/files/" + url.PathEscape(objectID))
	mq := metaURL.Query()
	mq.Set("fields", "id,size,appProperties")
	metaURL.RawQuery = mq.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, metaURL.String(), token, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, providerError(resp)
	}
	var meta struct {
		ID            string            `json:"id"`
		Size          string            `json:"size"`
		AppProperties map[string]string `json:"appProperties"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&meta); err != nil {
		_ = resp.Body.Close()
		return nil, errors.New("invalid Google Drive recovery-record metadata")
	}
	_ = resp.Body.Close()
	if meta.ID == "" || meta.AppProperties["vaultpool_kind"] != "recovery_file_key" {
		return nil, errors.New("Google Drive object is not a VaultPool recovery record")
	}
	n, err := strconv.ParseInt(meta.Size, 10, 64)
	if err != nil || n <= 0 || n > maxBytes {
		return nil, errors.New("Google Drive recovery-record size is invalid or exceeds cap")
	}
	u, _ := url.Parse(api + "/files/" + url.PathEscape(objectID))
	q := u.Query()
	q.Set("alt", "media")
	u.RawQuery = q.Encode()
	resp, err = s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	return readBounded(resp, maxBytes)
}
