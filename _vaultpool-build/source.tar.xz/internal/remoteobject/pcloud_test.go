package remoteobject

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

type pcToken string

func (t pcToken) AccessToken(context.Context, string) (string, error) { return string(t), nil }

type pcHost string

func (h pcHost) PCloudAPIHost(string) (string, error) { return string(h), nil }

func TestPCloudPutGetDeleteVerified(t *testing.T) {
	data := []byte("vaultpool-pcloud-object")
	sha := SHA256Bytes(data)
	var deleted bool
	var host string
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer token" && !strings.HasPrefix(r.URL.Path, "/content/") {
			t.Fatalf("missing bearer on %s", r.URL.Path)
		}
		switch r.URL.Path {
		case "/uploadfile":
			if err := r.ParseMultipartForm(1 << 20); err != nil {
				t.Fatal(err)
			}
			_, hdr, err := r.FormFile("file")
			if err != nil {
				t.Fatal(err)
			}
			_ = hdr
			json.NewEncoder(w).Encode(map[string]any{"result": 0, "fileids": []int64{101}, "metadata": []map[string]any{{"fileid": 101, "name": "x", "size": len(data)}}})
		case "/getfilelink":
			json.NewEncoder(w).Encode(map[string]any{"result": 0, "hosts": []string{host}, "path": "/content/101"})
		case "/content/101":
			w.Write(data)
		case "/deletefile":
			deleted = true
			json.NewEncoder(w).Encode(map[string]any{"result": 0})
		default:
			t.Fatalf("unexpected path %s", r.URL.Path)
		}
	}))
	defer ts.Close()
	u, _ := url.Parse(ts.URL)
	host = u.Host
	s := &PCloud{Tokens: pcToken("token"), Hosts: pcHost(host), HTTP: ts.Client()}
	obj, err := s.PutVerified(context.Background(), "acct", "data/abc", data, sha)
	if err != nil {
		t.Fatal(err)
	}
	if obj.ID != "101" {
		t.Fatalf("id=%s", obj.ID)
	}
	got, err := s.GetVerified(context.Background(), "acct", obj.ID, int64(len(data)), sha)
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != string(data) {
		t.Fatalf("got %q", got)
	}
	if err := s.Delete(context.Background(), "acct", obj.ID); err != nil {
		t.Fatal(err)
	}
	if !deleted {
		t.Fatal("delete not called")
	}
}

func TestPCloudRejectsBadHost(t *testing.T) {
	s := &PCloud{Tokens: pcToken("token"), Hosts: pcHost("evil.example")}
	_, _, err := s.tokenHost(context.Background(), "acct")
	if err == nil {
		t.Fatal("expected host validation error")
	}
	_ = fmt.Sprint(err)
}
