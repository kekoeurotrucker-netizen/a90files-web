package remoteobject

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

type PCloudHostProvider interface {
	PCloudAPIHost(accountID string) (string, error)
}

type PCloud struct {
	Tokens TokenProvider
	Hosts  PCloudHostProvider
	HTTP   *http.Client
}

func (s *PCloud) ProviderID() string { return "pcloud" }
func (s *PCloud) client() *http.Client {
	if s.HTTP != nil {
		return s.HTTP
	}
	return &http.Client{}
}
func (s *PCloud) tokenHost(ctx context.Context, accountID string) (string, string, error) {
	if s.Tokens == nil || s.Hosts == nil {
		return "", "", errors.New("pCloud token/host provider missing")
	}
	t, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return "", "", err
	}
	h, err := s.Hosts.PCloudAPIHost(accountID)
	if err != nil {
		return "", "", err
	}
	h = strings.ToLower(strings.TrimSpace(h))
	if h != "api.pcloud.com" && h != "eapi.pcloud.com" && !strings.HasPrefix(h, "127.0.0.1:") && !strings.HasPrefix(h, "localhost:") {
		return "", "", errors.New("invalid pCloud API hostname")
	}
	return t, h, nil
}
func (s *PCloud) apiURL(host, method string, q url.Values) string {
	scheme := "https"
	if strings.HasPrefix(host, "127.0.0.1:") || strings.HasPrefix(host, "localhost:") {
		scheme = "http"
	}
	u := url.URL{Scheme: scheme, Host: host, Path: "/" + method, RawQuery: q.Encode()}
	return u.String()
}

type pcloudEnvelope struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

func pcloudResultError(body []byte) error {
	var e pcloudEnvelope
	if json.Unmarshal(body, &e) != nil {
		return errors.New("invalid pCloud API response")
	}
	if e.Result != 0 {
		return fmt.Errorf("pCloud API result %d", e.Result)
	}
	return nil
}
func (s *PCloud) jsonCall(ctx context.Context, accountID, method string, q url.Values, dst any) error {
	token, host, err := s.tokenHost(ctx, accountID)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, s.apiURL(host, method, q), nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Accept", "application/json")
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return providerError(resp)
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	if err != nil {
		return err
	}
	if err := pcloudResultError(body); err != nil {
		return err
	}
	if dst != nil && json.Unmarshal(body, dst) != nil {
		return errors.New("invalid pCloud API response")
	}
	return nil
}

func (s *PCloud) PutVerified(ctx context.Context, accountID, key string, data []byte, expectedSHA string) (Object, error) {
	if len(data) == 0 {
		return Object{}, errors.New("empty remote objects are not supported")
	}
	if err := validateExpected(data, expectedSHA); err != nil {
		return Object{}, err
	}
	name, err := oneDriveObjectName(key)
	if err != nil {
		return Object{}, err
	}
	token, host, err := s.tokenHost(ctx, accountID)
	if err != nil {
		return Object{}, err
	}
	var body bytes.Buffer
	mw := multipart.NewWriter(&body)
	_ = mw.WriteField("nopartial", "1")
	_ = mw.WriteField("renameifexists", "1")
	part, err := mw.CreateFormFile("file", name)
	if err != nil {
		return Object{}, err
	}
	if _, err := part.Write(data); err != nil {
		return Object{}, err
	}
	if err := mw.Close(); err != nil {
		return Object{}, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, s.apiURL(host, "uploadfile", nil), &body)
	if err != nil {
		return Object{}, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", mw.FormDataContentType())
	req.Header.Set("Accept", "application/json")
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return Object{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return Object{}, providerError(resp)
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	if err != nil {
		return Object{}, err
	}
	if err := pcloudResultError(b); err != nil {
		return Object{}, err
	}
	var r struct {
		FileIDs  []int64 `json:"fileids"`
		Metadata []struct {
			FileID int64  `json:"fileid"`
			Name   string `json:"name"`
			Size   int64  `json:"size"`
		} `json:"metadata"`
	}
	if json.Unmarshal(b, &r) != nil || len(r.FileIDs) != 1 {
		return Object{}, errors.New("pCloud upload did not return exactly one file id")
	}
	id := r.FileIDs[0]
	if id <= 0 {
		return Object{}, errors.New("pCloud upload returned invalid file id")
	}
	sz := int64(len(data))
	if len(r.Metadata) > 0 && r.Metadata[0].Size != 0 && r.Metadata[0].Size != sz {
		_ = s.Delete(ctx, accountID, strconv.FormatInt(id, 10))
		return Object{}, errors.New("pCloud upload size mismatch")
	}
	obj := Object{ProviderID: s.ProviderID(), AccountID: accountID, ID: strconv.FormatInt(id, 10), Key: key, Name: name, Size: sz, SHA256: strings.ToLower(expectedSHA)}
	if _, err := s.GetVerified(ctx, accountID, obj.ID, obj.Size, obj.SHA256); err != nil {
		_ = s.Delete(ctx, accountID, obj.ID)
		return Object{}, fmt.Errorf("pCloud post-upload verification failed: %w", err)
	}
	return obj, nil
}

func (s *PCloud) GetVerified(ctx context.Context, accountID, objectID string, expectedSize int64, expectedSHA string) ([]byte, error) {
	if _, err := strconv.ParseInt(objectID, 10, 64); err != nil {
		return nil, errors.New("pCloud file id required")
	}
	var link struct {
		Hosts []string `json:"hosts"`
		Path  string   `json:"path"`
	}
	if err := s.jsonCall(ctx, accountID, "getfilelink", url.Values{"fileid": {objectID}, "forcedownload": {"1"}}, &link); err != nil {
		return nil, err
	}
	if len(link.Hosts) == 0 || link.Path == "" {
		return nil, errors.New("pCloud download link missing")
	}
	raw := "https://" + link.Hosts[0] + link.Path
	if strings.HasPrefix(link.Hosts[0], "127.0.0.1:") || strings.HasPrefix(link.Hosts[0], "localhost:") {
		raw = "http://" + link.Hosts[0] + link.Path
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, raw, nil)
	if err != nil {
		return nil, err
	}
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	b, err := readExpected(resp, expectedSize)
	if err != nil {
		return nil, err
	}
	if err := validateExpected(b, expectedSHA); err != nil {
		return nil, err
	}
	return b, nil
}

func (s *PCloud) Delete(ctx context.Context, accountID, objectID string) error {
	if _, err := strconv.ParseInt(objectID, 10, 64); err != nil {
		return errors.New("pCloud file id required")
	}
	err := s.jsonCall(ctx, accountID, "deletefile", url.Values{"fileid": {objectID}}, nil)
	if err != nil && strings.Contains(err.Error(), "2009") {
		return nil
	}
	return err
}

type pcloudEntry struct {
	FileID    int64  `json:"fileid"`
	Name      string `json:"name"`
	Size      int64  `json:"size"`
	IsFolder  bool   `json:"isfolder"`
	IsDeleted bool   `json:"isdeleted"`
}

func (s *PCloud) listRoot(ctx context.Context, accountID string) ([]pcloudEntry, error) {
	var r struct {
		Metadata struct {
			Contents []pcloudEntry `json:"contents"`
		} `json:"metadata"`
	}
	if err := s.jsonCall(ctx, accountID, "listfolder", url.Values{"folderid": {"0"}, "showdeleted": {"0"}}, &r); err != nil {
		return nil, err
	}
	return r.Metadata.Contents, nil
}
func (s *PCloud) ListManifestCandidates(ctx context.Context, accountID string) ([]ManifestCandidate, error) {
	entries, err := s.listRoot(ctx, accountID)
	if err != nil {
		return nil, err
	}
	out := []ManifestCandidate{}
	for _, e := range entries {
		if e.FileID <= 0 || e.Size <= 0 || e.IsFolder || e.IsDeleted {
			continue
		}
		fid, ok := manifestFileIDFromOneDriveName(e.Name)
		if !ok {
			continue
		}
		out = append(out, ManifestCandidate{Locator: strconv.FormatInt(e.FileID, 10), RecoveryID: fid, Size: e.Size})
	}
	return out, nil
}
func (s *PCloud) ReadManifestCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if maxBytes <= 0 {
		return nil, errors.New("manifest recovery size cap required")
	}
	return s.readCandidate(ctx, accountID, objectID, maxBytes)
}
func (s *PCloud) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]RecoveryRecordCandidate, error) {
	entries, err := s.listRoot(ctx, accountID)
	if err != nil {
		return nil, err
	}
	out := []RecoveryRecordCandidate{}
	for _, e := range entries {
		if e.FileID <= 0 || e.Size <= 0 || e.IsFolder || e.IsDeleted {
			continue
		}
		rid, ok := recoveryIDFromOneDriveName(e.Name)
		if !ok {
			continue
		}
		out = append(out, RecoveryRecordCandidate{Locator: strconv.FormatInt(e.FileID, 10), RecoveryID: rid, Size: e.Size})
	}
	return out, nil
}
func (s *PCloud) ReadRecoveryRecordCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if maxBytes <= 0 {
		return nil, errors.New("recovery-record size cap required")
	}
	return s.readCandidate(ctx, accountID, objectID, maxBytes)
}
func (s *PCloud) readCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	var link struct {
		Hosts []string `json:"hosts"`
		Path  string   `json:"path"`
	}
	if err := s.jsonCall(ctx, accountID, "getfilelink", url.Values{"fileid": {objectID}, "forcedownload": {"1"}}, &link); err != nil {
		return nil, err
	}
	if len(link.Hosts) == 0 || link.Path == "" {
		return nil, errors.New("pCloud download link missing")
	}
	raw := "https://" + link.Hosts[0] + link.Path
	if strings.HasPrefix(link.Hosts[0], "127.0.0.1:") || strings.HasPrefix(link.Hosts[0], "localhost:") {
		raw = "http://" + link.Hosts[0] + link.Path
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, raw, nil)
	if err != nil {
		return nil, err
	}
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	return readBounded(resp, maxBytes)
}
