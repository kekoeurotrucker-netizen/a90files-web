package remoteobject

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestOneDriveDownloadWithoutAnnotation(t *testing.T) {
	payload := []byte("ciphertext from OneDrive")
	for _, direct := range []bool{false, true} {
		t.Run(map[bool]string{false: "redirect", true: "direct"}[direct], func(t *testing.T) {
			var server *httptest.Server
			contentCalls, fileCalls := 0, 0
			server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.URL.Path == "/download" {
					fileCalls++
					if r.Header.Get("Authorization") != "" {
						t.Error("bearer leaked to download host")
					}
					_, _ = w.Write(payload)
					return
				}
				if r.Header.Get("Authorization") != "Bearer tok" {
					t.Error("Graph request missing bearer")
				}
				if strings.HasSuffix(r.URL.Path, "/content") {
					contentCalls++
					if direct {
						_, _ = w.Write(payload)
					} else {
						http.Redirect(w, r, server.URL+"/download", http.StatusFound)
					}
					return
				}
				name := "vp-data.cps"
				if strings.HasSuffix(r.URL.Path, "/manifest") {
					name = "vp-manifest-0123456789abcdef0123456789abcdef-1234567890abcdef.cpm"
				}
				if strings.HasSuffix(r.URL.Path, "/recovery") {
					var err error
					name, err = oneDriveObjectName("metadata/recovery/filekeys/0123456789abcdef0123456789abcdef.vprk")
					if err != nil {
						t.Error(err)
					}
				}
				_ = json.NewEncoder(w).Encode(map[string]any{"id": "item", "name": name, "size": len(payload)})
			}))
			defer server.Close()
			s := &OneDrive{Tokens: staticTokens{"tok"}, HTTP: server.Client(), GraphBase: server.URL}
			ctx := context.Background()
			got, err := s.GetVerified(ctx, "acct", "item", int64(len(payload)), SHA256Bytes(payload))
			if err != nil || !bytes.Equal(got, payload) {
				t.Fatalf("verified download: %v", err)
			}
			got, err = s.ReadManifestCandidate(ctx, "acct", "manifest", 1024)
			if err != nil || !bytes.Equal(got, payload) {
				t.Fatalf("manifest download: %v", err)
			}
			got, err = s.ReadRecoveryRecordCandidate(ctx, "acct", "recovery", 1024)
			if err != nil || !bytes.Equal(got, payload) {
				t.Fatalf("recovery download: %v", err)
			}
			if _, err = s.GetVerified(ctx, "acct", "item", int64(len(payload)), SHA256Bytes([]byte("corrupt"))); err == nil {
				t.Fatal("corrupt ciphertext accepted")
			}
			before := contentCalls
			if _, err = s.GetVerified(ctx, "acct", "item", 1, SHA256Bytes(payload)); err == nil {
				t.Fatal("wrong metadata size accepted")
			}
			if _, err = s.ReadManifestCandidate(ctx, "acct", "manifest", 1); err == nil {
				t.Fatal("manifest cap bypassed")
			}
			if _, err = s.ReadRecoveryRecordCandidate(ctx, "acct", "recovery", 1); err == nil {
				t.Fatal("recovery cap bypassed")
			}
			if contentCalls != before || contentCalls != 4 || (!direct && fileCalls != 4) {
				t.Fatalf("unexpected fetches: content=%d download=%d", contentCalls, fileCalls)
			}
		})
	}
}

type oneDriveDownloadTransport func(*http.Request) (*http.Response, error)

func (f oneDriveDownloadTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestOneDriveContentRejectsUnsafeRedirect(t *testing.T) {
	for _, location := range []string{"", "http://example.com/file", "https://127.0.0.1/file", "https://localhost/file", "https://user:pass@example.com/file"} {
		t.Run(location, func(t *testing.T) {
			calls := 0
			s := &OneDrive{HTTP: &http.Client{Transport: oneDriveDownloadTransport(func(r *http.Request) (*http.Response, error) {
				calls++
				return &http.Response{StatusCode: http.StatusFound, Header: http.Header{"Location": {location}}, Body: io.NopCloser(strings.NewReader("")), Request: r}, nil
			})}}
			if _, err := s.downloadContent(context.Background(), "item", "tok", ""); err == nil {
				t.Fatal("unsafe redirect accepted")
			}
			if calls != 1 {
				t.Fatal("followed unsafe redirect")
			}
		})
	}
}
