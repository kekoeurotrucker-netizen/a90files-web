package remoteobject

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

type staticTokens struct{ token string }

func (s staticTokens) AccessToken(context.Context, string) (string, error) { return s.token, nil }

func TestValidateKey(t *testing.T) {
	for _, good := range []string{"objects/file/block/shard", "manifests/abc.cpm"} {
		if err := ValidateKey(good); err != nil {
			t.Fatalf("good key %q: %v", good, err)
		}
	}
	for _, bad := range []string{"", "../x", "/root", "a//b", "a/./b", `a\\b`, "a\x00b"} {
		if err := ValidateKey(bad); err == nil {
			t.Fatalf("bad key accepted: %q", bad)
		}
	}
}

func TestGoogleDrivePutReadbackVerifyAndDelete(t *testing.T) {
	var mu sync.Mutex
	var stored []byte
	deleted := false
	folderCreated := false
	var server *httptest.Server
	server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/drive/v3/") || strings.HasPrefix(r.URL.Path, "/upload/drive/v3/") {
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("missing bearer on Google API %s: %q", r.URL.Path, r.Header.Get("Authorization"))
			}
		}
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files":
			_ = json.NewEncoder(w).Encode(map[string]any{"files": []any{}})
		case r.Method == http.MethodPost && r.URL.Path == "/drive/v3/files":
			folderCreated = true
			w.WriteHeader(http.StatusOK)
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "root1", "name": "VaultPool"})
		case r.Method == http.MethodPost && r.URL.Path == "/upload/drive/v3/files":
			if !folderCreated {
				t.Error("upload started before root folder")
			}
			w.Header().Set("Location", server.URL+"/google-upload-session")
			w.WriteHeader(http.StatusOK)
		case r.Method == http.MethodPut && r.URL.Path == "/google-upload-session":
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("Google resumable upload missing bearer")
			}
			b, _ := io.ReadAll(r.Body)
			mu.Lock()
			stored = append([]byte(nil), b...)
			mu.Unlock()
			w.WriteHeader(http.StatusOK)
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "g1", "name": "obj", "size": strconv.Itoa(len(b))})
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files/g1" && r.URL.Query().Get("alt") == "media":
			mu.Lock()
			b := append([]byte(nil), stored...)
			mu.Unlock()
			w.Header().Set("Content-Length", strconv.Itoa(len(b)))
			_, _ = w.Write(b)
		case r.Method == http.MethodDelete && r.URL.Path == "/drive/v3/files/g1":
			deleted = true
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	s := &GoogleDrive{Tokens: staticTokens{"tok"}, HTTP: server.Client(), APIBase: server.URL + "/drive/v3", UploadBase: server.URL + "/upload/drive/v3"}
	data := bytes.Repeat([]byte("vaultpool"), 1000)
	h := SHA256Bytes(data)
	obj, err := s.PutVerified(context.Background(), "acct", "objects/f/b/s", data, h)
	if err != nil {
		t.Fatal(err)
	}
	if obj.ID != "g1" || obj.Size != int64(len(data)) || obj.SHA256 != h {
		t.Fatalf("bad object: %+v", obj)
	}
	got, err := s.GetVerified(context.Background(), "acct", obj.ID, obj.Size, obj.SHA256)
	if err != nil || !bytes.Equal(got, data) {
		t.Fatalf("get verified err=%v equal=%v", err, bytes.Equal(got, data))
	}
	if err := s.Delete(context.Background(), "acct", obj.ID); err != nil {
		t.Fatal(err)
	}
	if !deleted {
		t.Fatal("Google object was not deleted")
	}
}

func TestGoogleDriveVerificationFailureDeletesUntrustedUpload(t *testing.T) {
	deleted := false
	var server *httptest.Server
	server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files":
			_ = json.NewEncoder(w).Encode(map[string]any{"files": []map[string]string{{"id": "root1"}}})
		case r.Method == http.MethodPost && r.URL.Path == "/upload/drive/v3/files":
			w.Header().Set("Location", server.URL+"/session")
		case r.Method == http.MethodPut && r.URL.Path == "/session":
			b, _ := io.ReadAll(r.Body)
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "g1", "size": strconv.Itoa(len(b))})
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files/g1":
			b := []byte("corrupt")
			w.Header().Set("Content-Length", strconv.Itoa(len(b)))
			_, _ = w.Write(b)
		case r.Method == http.MethodDelete && r.URL.Path == "/drive/v3/files/g1":
			deleted = true
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()
	s := &GoogleDrive{Tokens: staticTokens{"tok"}, HTTP: server.Client(), APIBase: server.URL + "/drive/v3", UploadBase: server.URL + "/upload/drive/v3"}
	data := []byte("trusted")
	if _, err := s.PutVerified(context.Background(), "acct", "objects/x", data, SHA256Bytes(data)); err == nil {
		t.Fatal("expected readback verification failure")
	}
	if !deleted {
		t.Fatal("untrusted Google upload was not cleaned up")
	}
}

func TestOneDriveChunkedUploadNoBearerOnPreauthURLsAndDelete(t *testing.T) {
	var mu sync.Mutex
	var stored []byte
	deleted := false
	var server *httptest.Server
	server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && strings.Contains(r.URL.Path, "createUploadSession"):
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("Graph create session missing bearer")
			}
			_ = json.NewEncoder(w).Encode(map[string]string{"uploadUrl": server.URL + "/od-upload"})
		case r.Method == http.MethodPut && r.URL.Path == "/od-upload":
			if r.Header.Get("Authorization") != "" {
				t.Errorf("bearer leaked to preauthenticated upload URL: %q", r.Header.Get("Authorization"))
			}
			part, _ := io.ReadAll(r.Body)
			mu.Lock()
			stored = append(stored, part...)
			current := len(stored)
			mu.Unlock()
			rng := r.Header.Get("Content-Range")
			var start, end, total int
			if _, err := fmt.Sscanf(rng, "bytes %d-%d/%d", &start, &end, &total); err != nil {
				t.Errorf("bad range %q: %v", rng, err)
			}
			if current < total {
				w.WriteHeader(http.StatusAccepted)
				_ = json.NewEncoder(w).Encode(map[string]any{"nextExpectedRanges": []string{fmt.Sprintf("%d-", current)}})
				return
			}
			w.WriteHeader(http.StatusCreated)
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "od1", "name": "obj", "size": total, "eTag": "etag1"})
		case r.Method == http.MethodGet && r.URL.Path == "/v1.0/me/drive/items/od1":
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("metadata missing bearer")
			}
			mu.Lock()
			n := len(stored)
			mu.Unlock()
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "od1", "size": n, "@microsoft.graph.downloadUrl": server.URL + "/od-download"})
		case r.Method == http.MethodGet && r.URL.Path == "/od-download":
			if r.Header.Get("Authorization") != "" {
				t.Errorf("bearer leaked to preauthenticated download URL: %q", r.Header.Get("Authorization"))
			}
			mu.Lock()
			b := append([]byte(nil), stored...)
			mu.Unlock()
			w.Header().Set("Content-Length", strconv.Itoa(len(b)))
			_, _ = w.Write(b)
		case r.Method == http.MethodDelete && r.URL.Path == "/v1.0/me/drive/items/od1":
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("delete missing bearer")
			}
			deleted = true
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	s := &OneDrive{Tokens: staticTokens{"tok"}, HTTP: server.Client(), GraphBase: server.URL + "/v1.0"}
	data := bytes.Repeat([]byte("x"), oneDriveChunkSize+12345)
	h := SHA256Bytes(data)
	obj, err := s.PutVerified(context.Background(), "acct", "objects/f/b/s", data, h)
	if err != nil {
		t.Fatal(err)
	}
	if obj.ID != "od1" || obj.Size != int64(len(data)) {
		t.Fatalf("bad object: %+v", obj)
	}
	got, err := s.GetVerified(context.Background(), "acct", obj.ID, obj.Size, obj.SHA256)
	if err != nil || !bytes.Equal(got, data) {
		t.Fatalf("get err=%v equal=%v", err, bytes.Equal(got, data))
	}
	if err := s.Delete(context.Background(), "acct", obj.ID); err != nil {
		t.Fatal(err)
	}
	if !deleted {
		t.Fatal("OneDrive object was not deleted")
	}
}

func TestOneDriveRejectsPrivatePreauthenticatedURLInProduction(t *testing.T) {
	if err := validatePreauthenticatedURL("https://127.0.0.1/upload", "https://graph.microsoft.com/v1.0"); err == nil {
		t.Fatal("private preauthenticated URL accepted")
	}
	if err := validatePreauthenticatedURL("https://localhost/upload", "https://graph.microsoft.com/v1.0"); err == nil {
		t.Fatal("localhost preauthenticated URL accepted")
	}
}

func TestProviderErrorClassifiesRateLimitAndQuota(t *testing.T) {
	r := httptest.NewRecorder()
	r.Header().Set("Retry-After", "120")
	r.WriteHeader(http.StatusTooManyRequests)
	_, _ = r.WriteString(`{"error":{"code":"rateLimitExceeded","message":"try later"}}`)
	resp := r.Result()
	err := providerError(resp)
	var apiErr *APIError
	if !errors.As(err, &apiErr) {
		t.Fatalf("not APIError: %T", err)
	}
	if !apiErr.RateLimited() || !apiErr.Temporary() || apiErr.RetryAfter != 120*time.Second {
		t.Fatalf("classification=%+v", apiErr)
	}

	r = httptest.NewRecorder()
	r.WriteHeader(http.StatusInsufficientStorage)
	_, _ = r.WriteString(`{"error":{"code":"quotaExceeded","message":"insufficient storage"}}`)
	resp = r.Result()
	err = providerError(resp)
	if !errors.As(err, &apiErr) || !apiErr.QuotaOrCapacity() {
		t.Fatalf("quota classification failed: %v", err)
	}
}

func TestGoogleManifestRecoveryIsNarrowAndBounded(t *testing.T) {
	payload := []byte("sealed-manifest-bytes")
	var server *httptest.Server
	server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer tok" {
			t.Errorf("missing bearer: %q", r.Header.Get("Authorization"))
		}
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files" && strings.Contains(r.URL.Query().Get("q"), "vaultpool_root"):
			_ = json.NewEncoder(w).Encode(map[string]any{"files": []any{map[string]any{"id": "root1"}}})
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files" && strings.Contains(r.URL.Query().Get("q"), "vaultpool_kind"):
			_ = json.NewEncoder(w).Encode(map[string]any{"files": []any{map[string]any{"id": "m1", "size": strconv.Itoa(len(payload))}}})
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files/m1" && r.URL.Query().Get("alt") == "":
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "m1", "size": strconv.Itoa(len(payload)), "appProperties": map[string]string{"vaultpool_kind": "manifest"}})
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files/m1" && r.URL.Query().Get("alt") == "media":
			w.Header().Set("Content-Length", strconv.Itoa(len(payload)))
			_, _ = w.Write(payload)
		case r.Method == http.MethodGet && r.URL.Path == "/drive/v3/files/d1":
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "d1", "size": "4", "appProperties": map[string]string{"vaultpool_kind": "data"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()
	s := &GoogleDrive{Tokens: staticTokens{"tok"}, HTTP: server.Client(), APIBase: server.URL + "/drive/v3", UploadBase: server.URL + "/upload/drive/v3"}
	c, err := s.ListManifestCandidates(context.Background(), "acct")
	if err != nil || len(c) != 1 || c[0].Locator != "m1" {
		t.Fatalf("candidates=%+v err=%v", c, err)
	}
	got, err := s.ReadManifestCandidate(context.Background(), "acct", "m1", 1024)
	if err != nil || !bytes.Equal(got, payload) {
		t.Fatalf("read=%q err=%v", got, err)
	}
	if _, err := s.ReadManifestCandidate(context.Background(), "acct", "d1", 1024); err == nil {
		t.Fatal("data object accepted by manifest-only recovery reader")
	}
	if _, err := s.ReadManifestCandidate(context.Background(), "acct", "m1", 4); err == nil {
		t.Fatal("manifest size cap not enforced")
	}
}

func TestOneDriveManifestRecoveryIsNarrowAndBearerFreeOnDownload(t *testing.T) {
	payload := []byte("sealed-od-manifest")
	var server *httptest.Server
	server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/v1.0/me/drive/special/approot/children":
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("list missing bearer")
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"value": []any{
				map[string]any{"id": "m1", "name": "vp-manifest-0123456789abcdef0123456789abcdef-1234567890abcdef.cpm", "size": len(payload)},
				map[string]any{"id": "d1", "name": "vp-deadbeef.cps", "size": 4},
			}})
		case r.Method == http.MethodGet && r.URL.Path == "/v1.0/me/drive/items/m1":
			if r.Header.Get("Authorization") != "Bearer tok" {
				t.Errorf("metadata missing bearer")
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "m1", "name": "vp-manifest-0123456789abcdef0123456789abcdef-1234567890abcdef.cpm", "size": len(payload), "@microsoft.graph.downloadUrl": server.URL + "/manifest-download"})
		case r.Method == http.MethodGet && r.URL.Path == "/manifest-download":
			if r.Header.Get("Authorization") != "" {
				t.Fatalf("bearer leaked to manifest download")
			}
			w.Header().Set("Content-Length", strconv.Itoa(len(payload)))
			_, _ = w.Write(payload)
		case r.Method == http.MethodGet && r.URL.Path == "/v1.0/me/drive/items/d1":
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "d1", "name": "vp-data.cps", "size": 4, "@microsoft.graph.downloadUrl": server.URL + "/data-download"})
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()
	s := &OneDrive{Tokens: staticTokens{"tok"}, HTTP: server.Client(), GraphBase: server.URL + "/v1.0"}
	c, err := s.ListManifestCandidates(context.Background(), "acct")
	if err != nil || len(c) != 1 || c[0].Locator != "m1" {
		t.Fatalf("candidates=%+v err=%v", c, err)
	}
	got, err := s.ReadManifestCandidate(context.Background(), "acct", "m1", 1024)
	if err != nil || !bytes.Equal(got, payload) {
		t.Fatalf("read=%q err=%v", got, err)
	}
	if _, err := s.ReadManifestCandidate(context.Background(), "acct", "d1", 1024); err == nil {
		t.Fatal("data object accepted by OneDrive manifest-only reader")
	}
}

func TestOneDriveManifestObjectNameIsDeterministicAndSeparated(t *testing.T) {
	a, err := oneDriveObjectName("metadata/manifests/0123456789abcdef0123456789abcdef/generation-00000000000000000001.cpm")
	if err != nil {
		t.Fatal(err)
	}
	b, _ := oneDriveObjectName("metadata/manifests/0123456789abcdef0123456789abcdef/generation-00000000000000000001.cpm")
	if a != b || !strings.HasPrefix(a, "vp-manifest-") || !strings.HasSuffix(a, ".cpm") {
		t.Fatalf("manifest name=%q second=%q", a, b)
	}
	d, err := oneDriveObjectName("objects/file/block/shard")
	if err != nil {
		t.Fatal(err)
	}
	if strings.HasPrefix(d, "vp-manifest-") {
		t.Fatalf("data object received manifest namespace: %q", d)
	}
}
