package remoteobject

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

const oneDriveChunkSize = 20 * 320 * 1024 // 6.25 MiB; required multiple of 320 KiB.

type OneDrive struct {
	Tokens    TokenProvider
	HTTP      *http.Client
	GraphBase string
}

func (s *OneDrive) ProviderID() string { return "onedrive" }
func (s *OneDrive) base() string {
	b := strings.TrimRight(s.GraphBase, "/")
	if b == "" {
		b = "https://graph.microsoft.com/v1.0"
	}
	return b
}
func (s *OneDrive) client() *http.Client {
	if s.HTTP != nil {
		return s.HTTP
	}
	return &http.Client{}
}
func (s *OneDrive) authRequest(ctx context.Context, method, raw, token string, body io.Reader) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, raw, body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	return noRedirectClient(s.client()).Do(req)
}

func oneDriveObjectName(key string) (string, error) {
	if err := ValidateKey(key); err != nil {
		return "", err
	}
	if strings.HasPrefix(key, "metadata/manifests/") {
		if fileID, ok := manifestFileIDFromKey(key); ok {
			return "vp-manifest-" + fileID + "-" + SHA256Bytes([]byte(key))[:16] + ".cpm", nil
		}
		return "", errors.New("invalid VaultPool manifest key")
	}
	if _, ok := recoveryRecordIDFromKey(key); ok {
		return recoveryRecordObjectName(key)
	}
	return objectName(key)
}

func (s *OneDrive) PutVerified(ctx context.Context, accountID, key string, data []byte, expectedSHA string) (Object, error) {
	if s.Tokens == nil {
		return Object{}, errors.New("OneDrive token provider missing")
	}
	if err := ValidateKey(key); err != nil {
		return Object{}, err
	}
	if len(data) == 0 {
		return Object{}, errors.New("empty remote objects are not supported")
	}
	if err := validateExpected(data, expectedSHA); err != nil {
		return Object{}, err
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return Object{}, err
	}
	name, err := oneDriveObjectName(key)
	if err != nil {
		return Object{}, err
	}
	base := s.base()
	endpoint := base + "/me/drive/special/approot:/" + url.PathEscape(name) + ":/createUploadSession"
	body, _ := json.Marshal(map[string]any{"item": map[string]any{"@microsoft.graph.conflictBehavior": "fail", "name": name}})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
	if err != nil {
		return Object{}, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := noRedirectClient(s.client()).Do(req)
	if err != nil {
		return Object{}, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return Object{}, providerError(resp)
	}
	var session struct {
		UploadURL string `json:"uploadUrl"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&session); err != nil {
		_ = resp.Body.Close()
		return Object{}, errors.New("invalid OneDrive upload session response")
	}
	_ = resp.Body.Close()
	if session.UploadURL == "" {
		return Object{}, errors.New("OneDrive upload session missing URL")
	}
	if err := validatePreauthenticatedURL(session.UploadURL, base); err != nil {
		return Object{}, err
	}

	var created struct {
		ID   string `json:"id"`
		Name string `json:"name"`
		Size int64  `json:"size"`
		ETag string `json:"eTag"`
	}
	for off := 0; off < len(data); {
		end := off + oneDriveChunkSize
		if end > len(data) {
			end = len(data)
		}
		part := data[off:end]
		put, err := http.NewRequestWithContext(ctx, http.MethodPut, session.UploadURL, bytes.NewReader(part))
		if err != nil {
			return Object{}, err
		}
		// uploadUrl is preauthenticated. Never attach the user's bearer token.
		put.Header.Set("Content-Length", strconv.Itoa(len(part)))
		put.Header.Set("Content-Range", fmt.Sprintf("bytes %d-%d/%d", off, end-1, len(data)))
		resp, err := preauthenticatedClient(s.client(), base).Do(put)
		if err != nil {
			return Object{}, err
		}
		isFinal := end == len(data)
		if !isFinal {
			if resp.StatusCode != http.StatusAccepted {
				defer resp.Body.Close()
				return Object{}, providerError(resp)
			}
			_ = resp.Body.Close()
			off = end
			continue
		}
		if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusCreated {
			defer resp.Body.Close()
			return Object{}, providerError(resp)
		}
		if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&created); err != nil {
			_ = resp.Body.Close()
			return Object{}, errors.New("invalid OneDrive completed upload response")
		}
		_ = resp.Body.Close()
		off = end
	}
	if created.ID == "" {
		return Object{}, errors.New("OneDrive upload did not return object id")
	}
	if created.Size != 0 && created.Size != int64(len(data)) {
		_ = s.Delete(ctx, accountID, created.ID)
		return Object{}, fmt.Errorf("OneDrive upload size mismatch: got %d want %d", created.Size, len(data))
	}
	obj := Object{ProviderID: s.ProviderID(), AccountID: accountID, ID: created.ID, Key: key, Name: name, Size: int64(len(data)), SHA256: strings.ToLower(expectedSHA), ETag: created.ETag}
	if _, err := s.GetVerified(ctx, accountID, obj.ID, obj.Size, obj.SHA256); err != nil {
		_ = s.Delete(ctx, accountID, obj.ID)
		return Object{}, fmt.Errorf("OneDrive post-upload verification failed: %w", err)
	}
	return obj, nil
}

func (s *OneDrive) GetVerified(ctx context.Context, accountID, objectID string, expectedSize int64, expectedSHA string) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("OneDrive object id required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	base := s.base()
	u, _ := url.Parse(base + "/me/drive/items/" + url.PathEscape(objectID))
	q := u.Query()
	q.Set("$select", "id,name,size,@microsoft.graph.downloadUrl")
	u.RawQuery = q.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, providerError(resp)
	}
	var meta struct {
		ID          string `json:"id"`
		Size        int64  `json:"size"`
		DownloadURL string `json:"@microsoft.graph.downloadUrl"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&meta); err != nil {
		_ = resp.Body.Close()
		return nil, errors.New("invalid OneDrive item metadata")
	}
	_ = resp.Body.Close()
	if meta.ID == "" {
		return nil, errors.New("OneDrive item missing id")
	}
	if meta.Size != expectedSize {
		return nil, fmt.Errorf("remote size mismatch: got %d want %d", meta.Size, expectedSize)
	}
	resp, err = s.downloadContent(ctx, objectID, token, meta.DownloadURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	b, err := readExpected(resp, expectedSize)
	if err != nil {
		return nil, err
	}
	if err := validateExpected(b, expectedSHA); err != nil {
		return nil, err
	}
	return b, nil
}

func (s *OneDrive) Delete(ctx context.Context, accountID, objectID string) error {
	if objectID == "" {
		return errors.New("OneDrive object id required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return err
	}
	resp, err := s.authRequest(ctx, http.MethodDelete, s.base()+"/me/drive/items/"+url.PathEscape(objectID), token, nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound {
		return nil
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return providerError(resp)
	}
	return nil
}

func (s *OneDrive) ListManifestCandidates(ctx context.Context, accountID string) ([]ManifestCandidate, error) {
	if s.Tokens == nil {
		return nil, errors.New("OneDrive token provider missing")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	base := s.base()
	u, _ := url.Parse(base + "/me/drive/special/approot/children")
	q := u.Query()
	q.Set("$select", "id,name,size")
	q.Set("$top", "200")
	u.RawQuery = q.Encode()
	next := u.String()
	seen := map[string]bool{}
	var out []ManifestCandidate
	for next != "" {
		if next != u.String() {
			if err := sameHTTPSOrigin(next, base); err != nil {
				return nil, fmt.Errorf("unsafe OneDrive pagination URL: %w", err)
			}
		}
		resp, err := s.authRequest(ctx, http.MethodGet, next, token, nil)
		if err != nil {
			return nil, err
		}
		if resp.StatusCode == http.StatusNotFound {
			_ = resp.Body.Close()
			return out, nil
		}
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			err := providerError(resp)
			_ = resp.Body.Close()
			return nil, err
		}
		var page struct {
			Value []struct {
				ID   string `json:"id"`
				Name string `json:"name"`
				Size int64  `json:"size"`
			} `json:"value"`
			Next string `json:"@odata.nextLink"`
		}
		if err := json.NewDecoder(io.LimitReader(resp.Body, 4<<20)).Decode(&page); err != nil {
			_ = resp.Body.Close()
			return nil, errors.New("invalid OneDrive app-root listing")
		}
		_ = resp.Body.Close()
		for _, item := range page.Value {
			if item.ID == "" || seen[item.ID] || item.Size <= 0 || !strings.HasPrefix(item.Name, "vp-manifest-") || !strings.HasSuffix(item.Name, ".cpm") {
				continue
			}
			seen[item.ID] = true
			fileID, _ := manifestFileIDFromOneDriveName(item.Name)
			out = append(out, ManifestCandidate{Locator: item.ID, RecoveryID: fileID, Size: item.Size})
		}
		next = page.Next
	}
	return out, nil
}

func (s *OneDrive) ReadManifestCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("OneDrive manifest object id required")
	}
	if maxBytes <= 0 {
		return nil, errors.New("manifest recovery size cap required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	base := s.base()
	u, _ := url.Parse(base + "/me/drive/items/" + url.PathEscape(objectID))
	q := u.Query()
	q.Set("$select", "id,name,size,@microsoft.graph.downloadUrl")
	u.RawQuery = q.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, providerError(resp)
	}
	var meta struct {
		ID          string `json:"id"`
		Name        string `json:"name"`
		Size        int64  `json:"size"`
		DownloadURL string `json:"@microsoft.graph.downloadUrl"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&meta); err != nil {
		_ = resp.Body.Close()
		return nil, errors.New("invalid OneDrive manifest metadata")
	}
	_ = resp.Body.Close()
	if meta.ID == "" || !strings.HasPrefix(meta.Name, "vp-manifest-") || !strings.HasSuffix(meta.Name, ".cpm") {
		return nil, errors.New("OneDrive object is not a VaultPool manifest replica")
	}
	if meta.Size <= 0 || meta.Size > maxBytes {
		return nil, errors.New("OneDrive manifest size/download metadata invalid or exceeds recovery cap")
	}
	resp, err = s.downloadContent(ctx, objectID, token, meta.DownloadURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	return readBounded(resp, maxBytes)
}

func (s *OneDrive) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]RecoveryRecordCandidate, error) {
	if s.Tokens == nil {
		return nil, errors.New("OneDrive token provider missing")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	base := s.base()
	u, _ := url.Parse(base + "/me/drive/special/approot/children")
	q := u.Query()
	q.Set("$select", "id,name,size")
	q.Set("$top", "200")
	u.RawQuery = q.Encode()
	next := u.String()
	seen := map[string]bool{}
	var out []RecoveryRecordCandidate
	for next != "" {
		if next != u.String() {
			if err := sameHTTPSOrigin(next, base); err != nil {
				return nil, fmt.Errorf("unsafe OneDrive pagination URL: %w", err)
			}
		}
		resp, err := s.authRequest(ctx, http.MethodGet, next, token, nil)
		if err != nil {
			return nil, err
		}
		if resp.StatusCode == http.StatusNotFound {
			_ = resp.Body.Close()
			return out, nil
		}
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			e := providerError(resp)
			_ = resp.Body.Close()
			return nil, e
		}
		var page struct {
			Value []struct {
				ID   string `json:"id"`
				Name string `json:"name"`
				Size int64  `json:"size"`
			} `json:"value"`
			Next string `json:"@odata.nextLink"`
		}
		if err := json.NewDecoder(io.LimitReader(resp.Body, 4<<20)).Decode(&page); err != nil {
			_ = resp.Body.Close()
			return nil, errors.New("invalid OneDrive app-root recovery listing")
		}
		_ = resp.Body.Close()
		for _, item := range page.Value {
			if item.ID == "" || seen[item.ID] || item.Size <= 0 {
				continue
			}
			rid, ok := recoveryIDFromOneDriveName(item.Name)
			if !ok {
				continue
			}
			seen[item.ID] = true
			out = append(out, RecoveryRecordCandidate{Locator: item.ID, RecoveryID: rid, Size: item.Size})
		}
		next = page.Next
	}
	return out, nil
}

func (s *OneDrive) ReadRecoveryRecordCandidate(ctx context.Context, accountID, objectID string, maxBytes int64) ([]byte, error) {
	if objectID == "" {
		return nil, errors.New("OneDrive recovery-record object id required")
	}
	if maxBytes <= 0 {
		return nil, errors.New("recovery-record size cap required")
	}
	token, err := s.Tokens.AccessToken(ctx, accountID)
	if err != nil {
		return nil, err
	}
	base := s.base()
	u, _ := url.Parse(base + "/me/drive/items/" + url.PathEscape(objectID))
	q := u.Query()
	q.Set("$select", "id,name,size,@microsoft.graph.downloadUrl")
	u.RawQuery = q.Encode()
	resp, err := s.authRequest(ctx, http.MethodGet, u.String(), token, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, providerError(resp)
	}
	var meta struct {
		ID          string `json:"id"`
		Name        string `json:"name"`
		Size        int64  `json:"size"`
		DownloadURL string `json:"@microsoft.graph.downloadUrl"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&meta); err != nil {
		_ = resp.Body.Close()
		return nil, errors.New("invalid OneDrive recovery-record metadata")
	}
	_ = resp.Body.Close()
	if meta.ID == "" {
		return nil, errors.New("OneDrive recovery record missing id")
	}
	if _, ok := recoveryIDFromOneDriveName(meta.Name); !ok {
		return nil, errors.New("OneDrive object is not a VaultPool recovery record")
	}
	if meta.Size <= 0 || meta.Size > maxBytes {
		return nil, errors.New("OneDrive recovery-record size/download metadata invalid or exceeds cap")
	}
	resp, err = s.downloadContent(ctx, objectID, token, meta.DownloadURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, providerError(resp)
	}
	return readBounded(resp, maxBytes)
}

func (s *OneDrive) downloadContent(ctx context.Context, objectID, token, downloadURL string) (*http.Response, error) {
	base := s.base()
	if downloadURL == "" {
		// Some Graph item responses omit downloadUrl. Resolve it via /content,
		// stopping before the redirect so the bearer cannot reach the file host.
		resp, err := s.authRequest(ctx, http.MethodGet, base+"/me/drive/items/"+url.PathEscape(objectID)+"/content", token, nil)
		if err != nil {
			return nil, err
		}
		switch resp.StatusCode {
		case http.StatusFound, http.StatusSeeOther, http.StatusTemporaryRedirect, http.StatusPermanentRedirect:
			downloadURL = resp.Header.Get("Location")
			_ = resp.Body.Close()
			if downloadURL == "" {
				return nil, errors.New("OneDrive content redirect missing location")
			}
		default:
			return resp, nil
		}
	}
	if err := validatePreauthenticatedURL(downloadURL, base); err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, downloadURL, nil)
	if err != nil {
		return nil, err
	}
	return preauthenticatedClient(s.client(), base).Do(req)
}
