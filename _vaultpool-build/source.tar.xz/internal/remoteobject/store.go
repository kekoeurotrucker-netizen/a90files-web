package remoteobject

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// TokenProvider deliberately returns tokens only in-memory. Remote stores must
// not persist or log them; the encrypted secret vault remains the sole owner.
type TokenProvider interface {
	AccessToken(context.Context, string) (string, error)
}

type Object struct {
	ProviderID string `json:"provider_id"`
	AccountID  string `json:"account_id"`
	ID         string `json:"id"`
	Key        string `json:"key"`
	Name       string `json:"name"`
	Size       int64  `json:"size"`
	SHA256     string `json:"sha256"`
	ETag       string `json:"etag,omitempty"`
}

type Store interface {
	ProviderID() string
	PutVerified(context.Context, string, string, []byte, string) (Object, error)
	GetVerified(context.Context, string, string, int64, string) ([]byte, error)
	Delete(context.Context, string, string) error
}

type ManifestCandidate struct {
	Locator    string `json:"locator"`
	RecoveryID string `json:"recovery_id,omitempty"`
	Size       int64  `json:"size"`
}

// ManifestRecoveryStore is deliberately narrower than Store. It may enumerate
// and bounded-read only VaultPool manifest replicas. It must never provide a
// generic unauthenticated read primitive for data shards. Candidate bytes are
// authenticated later by manifest.Open (AES-GCM).
type ManifestRecoveryStore interface {
	ListManifestCandidates(context.Context, string) ([]ManifestCandidate, error)
	ReadManifestCandidate(context.Context, string, string, int64) ([]byte, error)
}

// RecoveryRecordCandidate is a small encrypted recovery record (currently a
// per-file data key) discoverable after reinstall without trusting ordinary
// provider filenames or exposing a generic unauthenticated read primitive.
type RecoveryRecordCandidate struct {
	Locator    string `json:"locator"`
	RecoveryID string `json:"recovery_id"`
	Size       int64  `json:"size"`
}

// RecoveryRecordStore is deliberately scoped to VaultPool's reserved recovery
// namespace. Candidate bytes are authenticated later with SecretVault's
// recovery root and a FileID-bound AEAD label.
type RecoveryRecordStore interface {
	ListRecoveryRecordCandidates(context.Context, string) ([]RecoveryRecordCandidate, error)
	ReadRecoveryRecordCandidate(context.Context, string, string, int64) ([]byte, error)
}

type IntegrityError struct {
	Reason string
}

func (e *IntegrityError) Error() string { return "remote integrity verification failed: " + e.Reason }

func integrityErrorf(format string, args ...any) error {
	return &IntegrityError{Reason: fmt.Sprintf(format, args...)}
}

type APIError struct {
	StatusCode int
	Status     string
	Code       string
	Message    string
	RetryAfter time.Duration
}

func (e *APIError) Error() string {
	switch {
	case e.Code != "" && e.Message != "":
		return fmt.Sprintf("provider API %s (%s): %s", e.Status, e.Code, e.Message)
	case e.Code != "":
		return fmt.Sprintf("provider API %s (%s)", e.Status, e.Code)
	default:
		return fmt.Sprintf("provider API %s", e.Status)
	}
}
func (e *APIError) RateLimited() bool { return e.StatusCode == http.StatusTooManyRequests }
func (e *APIError) Authentication() bool {
	return e.StatusCode == http.StatusUnauthorized
}
func (e *APIError) QuotaOrCapacity() bool {
	if e.StatusCode == http.StatusInsufficientStorage {
		return true
	}
	s := strings.ToLower(e.Code + " " + e.Message)
	return strings.Contains(s, "quota") || strings.Contains(s, "storage limit") || strings.Contains(s, "insufficient storage")
}
func (e *APIError) Temporary() bool {
	return e.RateLimited() || e.StatusCode == http.StatusRequestTimeout || e.StatusCode == http.StatusBadGateway || e.StatusCode == http.StatusServiceUnavailable || e.StatusCode == http.StatusGatewayTimeout
}

func ValidateKey(key string) error {
	key = strings.TrimSpace(key)
	if key == "" || len(key) > 1024 {
		return errors.New("remote object key must be 1..1024 bytes")
	}
	if strings.Contains(key, `\\`) || strings.HasPrefix(key, "/") {
		return errors.New("unsafe remote object key")
	}
	for _, part := range strings.Split(key, "/") {
		if part == "" || part == "." || part == ".." {
			return errors.New("unsafe remote object key")
		}
		for _, r := range part {
			if r < 0x20 || r == 0x7f {
				return errors.New("remote object key contains control characters")
			}
		}
	}
	return nil
}

func SHA256Bytes(b []byte) string {
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:])
}

func recoveryRecordIDFromKey(key string) (string, bool) {
	const prefix = "metadata/recovery/filekeys/"
	const suffix = ".vprk"
	if !strings.HasPrefix(key, prefix) || !strings.HasSuffix(key, suffix) {
		return "", false
	}
	id := strings.TrimSuffix(strings.TrimPrefix(key, prefix), suffix)
	if len(id) != 32 {
		return "", false
	}
	if _, err := hex.DecodeString(id); err != nil {
		return "", false
	}
	return strings.ToLower(id), true
}

func manifestFileIDFromKey(key string) (string, bool) {
	const prefix = "metadata/manifests/"
	if !strings.HasPrefix(key, prefix) {
		return "", false
	}
	rest := strings.TrimPrefix(key, prefix)
	parts := strings.Split(rest, "/")
	if len(parts) != 2 || len(parts[0]) != 32 || !strings.HasPrefix(parts[1], "generation-") || !strings.HasSuffix(parts[1], ".cpm") {
		return "", false
	}
	if _, err := hex.DecodeString(parts[0]); err != nil {
		return "", false
	}
	return strings.ToLower(parts[0]), true
}

func manifestFileIDFromOneDriveName(name string) (string, bool) {
	const prefix = "vp-manifest-"
	const suffix = ".cpm"
	if !strings.HasPrefix(name, prefix) || !strings.HasSuffix(name, suffix) {
		return "", false
	}
	body := strings.TrimSuffix(strings.TrimPrefix(name, prefix), suffix)
	if len(body) < 32+1 || body[32] != '-' {
		return "", false
	}
	id := body[:32]
	if _, err := hex.DecodeString(id); err != nil {
		return "", false
	}
	return strings.ToLower(id), true
}

func recoveryRecordObjectName(key string) (string, error) {
	id, ok := recoveryRecordIDFromKey(key)
	if !ok {
		return "", errors.New("invalid VaultPool recovery-record key")
	}
	var suffix [6]byte
	if _, err := rand.Read(suffix[:]); err != nil {
		return "", err
	}
	return "vp-filekey-" + id + "-" + hex.EncodeToString(suffix[:]) + ".vprk", nil
}

func recoveryIDFromOneDriveName(name string) (string, bool) {
	const prefix = "vp-filekey-"
	const suffix = ".vprk"
	if !strings.HasPrefix(name, prefix) || !strings.HasSuffix(name, suffix) {
		return "", false
	}
	body := strings.TrimSuffix(strings.TrimPrefix(name, prefix), suffix)
	if len(body) != 32+1+12 || body[32] != '-' {
		return "", false
	}
	id, rnd := body[:32], body[33:]
	if _, err := hex.DecodeString(id); err != nil {
		return "", false
	}
	if _, err := hex.DecodeString(rnd); err != nil {
		return "", false
	}
	return strings.ToLower(id), true
}

func validateExpected(data []byte, expected string) error {
	if len(expected) != 64 {
		return errors.New("expected SHA-256 must be 64 hexadecimal characters")
	}
	if _, err := hex.DecodeString(expected); err != nil {
		return errors.New("expected SHA-256 is not hexadecimal")
	}
	if got := SHA256Bytes(data); !strings.EqualFold(got, expected) {
		return integrityErrorf("SHA-256 mismatch: got %s want %s", got, expected)
	}
	return nil
}

func objectName(key string) (string, error) {
	if err := ValidateKey(key); err != nil {
		return "", err
	}
	h := sha256.Sum256([]byte(key))
	var suffix [6]byte
	if _, err := rand.Read(suffix[:]); err != nil {
		return "", err
	}
	return "vp-" + hex.EncodeToString(h[:]) + "-" + hex.EncodeToString(suffix[:]) + ".cps", nil
}

func readBounded(resp *http.Response, maxBytes int64) ([]byte, error) {
	if maxBytes <= 0 {
		return nil, errors.New("max bytes must be positive")
	}
	if resp.ContentLength > maxBytes {
		return nil, fmt.Errorf("remote object exceeds recovery size cap: %d > %d", resp.ContentLength, maxBytes)
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, maxBytes+1))
	if err != nil {
		return nil, err
	}
	if int64(len(b)) > maxBytes {
		return nil, fmt.Errorf("remote object exceeds recovery size cap: > %d", maxBytes)
	}
	return b, nil
}

func readExpected(resp *http.Response, expectedSize int64) ([]byte, error) {
	if expectedSize < 0 {
		return nil, errors.New("negative expected size")
	}
	if resp.ContentLength >= 0 && resp.ContentLength != expectedSize {
		return nil, integrityErrorf("remote size mismatch: got %d want %d", resp.ContentLength, expectedSize)
	}
	// The limit is derived from trusted manifest metadata, not from provider
	// input, and prevents a malicious/error response from exhausting memory.
	limited := io.LimitReader(resp.Body, expectedSize+1)
	b, err := io.ReadAll(limited)
	if err != nil {
		return nil, err
	}
	if int64(len(b)) != expectedSize {
		return nil, integrityErrorf("remote size mismatch: got %d want %d", len(b), expectedSize)
	}
	return b, nil
}

func noRedirectClient(base *http.Client) *http.Client {
	if base == nil {
		base = &http.Client{}
	}
	c := *base
	c.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	return &c
}

func preauthenticatedClient(base *http.Client, configuredBase string) *http.Client {
	if base == nil {
		base = &http.Client{}
	}
	c := *base
	c.CheckRedirect = func(req *http.Request, _ []*http.Request) error {
		if err := validatePreauthenticatedURL(req.URL.String(), configuredBase); err != nil {
			return err
		}
		return nil
	}
	return &c
}

func providerError(resp *http.Response) error {
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	var envelope struct {
		Error json.RawMessage `json:"error"`
	}
	code, message := "", ""
	if json.Unmarshal(body, &envelope) == nil && len(envelope.Error) > 0 {
		var obj struct {
			Code    any    `json:"code"`
			Message string `json:"message"`
		}
		if json.Unmarshal(envelope.Error, &obj) == nil {
			if obj.Code != nil {
				code = fmt.Sprint(obj.Code)
			}
			message = obj.Message
		} else {
			var simple string
			if json.Unmarshal(envelope.Error, &simple) == nil {
				code = simple
			}
		}
	}
	if len(message) > 240 {
		message = message[:240]
	}
	retryAfter := time.Duration(0)
	if raw := strings.TrimSpace(resp.Header.Get("Retry-After")); raw != "" {
		if secs, err := time.ParseDuration(raw + "s"); err == nil {
			retryAfter = secs
		} else if when, err := http.ParseTime(raw); err == nil {
			if d := time.Until(when); d > 0 {
				retryAfter = d
			}
		}
	}
	return &APIError{StatusCode: resp.StatusCode, Status: resp.Status, Code: code, Message: message, RetryAfter: retryAfter}
}

func parseHTTPS(raw string) (*url.URL, error) {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "https" || u.Hostname() == "" || u.User != nil {
		return nil, errors.New("provider returned an invalid HTTPS URL")
	}
	return u, nil
}

func sameHTTPSOrigin(raw, base string) error {
	u, err := parseHTTPS(raw)
	if err != nil {
		return err
	}
	b, err := parseHTTPS(base)
	if err != nil {
		return err
	}
	if !strings.EqualFold(u.Hostname(), b.Hostname()) || u.Port() != b.Port() {
		return errors.New("provider returned upload URL on an unexpected host")
	}
	return nil
}

func isLoopbackBase(raw string) bool {
	u, err := url.Parse(raw)
	if err != nil {
		return false
	}
	h := u.Hostname()
	if strings.EqualFold(h, "localhost") {
		return true
	}
	ip := net.ParseIP(h)
	return ip != nil && ip.IsLoopback()
}

// validatePreauthenticatedURL accepts arbitrary public HTTPS hosts because
// OneDrive upload/download session URLs intentionally live on different hosts.
// In production it rejects IP literals, loopback/private/link-local targets to
// avoid turning a provider response into an SSRF primitive. Loopback is allowed
// only when the configured Graph base is itself loopback (tests).
func validatePreauthenticatedURL(raw, configuredBase string) error {
	u, err := parseHTTPS(raw)
	if err != nil {
		return err
	}
	if isLoopbackBase(configuredBase) {
		return nil
	}
	if ip := net.ParseIP(u.Hostname()); ip != nil {
		if ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() || ip.IsUnspecified() {
			return errors.New("provider returned a non-public preauthenticated URL")
		}
		return errors.New("provider returned an IP-literal preauthenticated URL")
	}
	if strings.EqualFold(u.Hostname(), "localhost") || strings.HasSuffix(strings.ToLower(u.Hostname()), ".localhost") {
		return errors.New("provider returned a local preauthenticated URL")
	}
	return nil
}
