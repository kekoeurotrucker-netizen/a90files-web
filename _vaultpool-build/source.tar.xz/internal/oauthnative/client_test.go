package oauthnative

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

func TestAuthorizationURLUsesPKCEAndNoSecret(t *testing.T) {
	c, err := New(Config{ProviderID: "x", ClientID: "public-id", AuthorizeURL: "https://auth.example/authorize", TokenURL: "https://auth.example/token", Scopes: []string{"files"}}, nil)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := c.AuthorizationURL("http://127.0.0.1:8742/oauth/callback", "state", "challenge")
	if err != nil {
		t.Fatal(err)
	}
	u, _ := url.Parse(raw)
	q := u.Query()
	if q.Get("client_id") != "public-id" || q.Get("code_challenge_method") != "S256" || q.Get("code_challenge") != "challenge" {
		t.Fatalf("query=%v", q)
	}
	if strings.Contains(raw, "client_secret") {
		t.Fatal("client secret leaked into auth URL")
	}
}

func TestDropboxAuthorizationRequestsStorageScopes(t *testing.T) {
	c, err := Dropbox("public-key", nil)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := c.AuthorizationURL("http://127.0.0.1:8742/oauth/callback", "state", "challenge")
	if err != nil {
		t.Fatal(err)
	}
	u, err := url.Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	q := u.Query()
	want := "account_info.read files.metadata.read files.content.read files.content.write"
	if q.Get("scope") != want || q.Get("token_access_type") != "offline" || q.Get("code_challenge_method") != "S256" {
		t.Fatalf("Dropbox authorization missing required storage scopes or PKCE: %v", q)
	}
}
func TestTokenExchangeNeverSendsClientSecret(t *testing.T) {
	var got url.Values
	ts := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = r.ParseForm()
		got = r.PostForm
		_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "a", "refresh_token": "r", "token_type": "Bearer", "expires_in": 3600})
	}))
	defer ts.Close()
	c, err := New(Config{ProviderID: "x", ClientID: "public", AuthorizeURL: "https://auth.example/a", TokenURL: ts.URL}, ts.Client())
	if err != nil {
		t.Fatal(err)
	}
	tok, err := c.ExchangeCode(context.Background(), "code", "verifier", "http://127.0.0.1:8742/oauth/callback")
	if err != nil {
		t.Fatal(err)
	}
	if tok.RefreshToken != "r" {
		t.Fatalf("got %+v", tok)
	}
	if got.Get("client_secret") != "" {
		t.Fatal("client_secret must not be sent")
	}
	if got.Get("code_verifier") != "verifier" {
		t.Fatal("missing verifier")
	}
}

func TestTokenExchangeSendsConfiguredDesktopSecretOnlyToTokenEndpoint(t *testing.T) {
	var got url.Values
	ts := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = r.ParseForm()
		got = r.PostForm
		_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "a", "refresh_token": "r", "token_type": "Bearer", "expires_in": 3600})
	}))
	defer ts.Close()
	c, err := New(Config{ProviderID: "google-drive", ClientID: "public", ClientSecret: "desktop-secret", AuthorizeURL: "https://auth.example/a", TokenURL: ts.URL}, ts.Client())
	if err != nil {
		t.Fatal(err)
	}
	raw, err := c.AuthorizationURL("http://127.0.0.1:8742/oauth/callback", "state", "challenge")
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(raw, "desktop-secret") || strings.Contains(raw, "client_secret") {
		t.Fatal("client secret leaked into authorization URL")
	}
	if _, err := c.ExchangeCode(context.Background(), "code", "verifier", "http://127.0.0.1:8742/oauth/callback"); err != nil {
		t.Fatal(err)
	}
	if got.Get("client_secret") != "desktop-secret" {
		t.Fatalf("desktop secret missing from token exchange: %v", got)
	}
	if got.Get("code_verifier") != "verifier" {
		t.Fatal("missing verifier")
	}
}

func TestRejectsNonLoopbackRedirect(t *testing.T) {
	c, _ := New(Config{ProviderID: "x", ClientID: "c", AuthorizeURL: "https://a.example/a", TokenURL: "https://a.example/t"}, nil)
	if _, err := c.AuthorizationURL("https://evil.example/cb", "s", "c"); err == nil {
		t.Fatal("expected rejection")
	}
}

func TestTokenEndpointRedirectIsNotFollowed(t *testing.T) {
	hit := false
	evil := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hit = true
		w.WriteHeader(http.StatusOK)
	}))
	defer evil.Close()
	var token *httptest.Server
	token = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, evil.URL, http.StatusTemporaryRedirect)
	}))
	defer token.Close()
	c, err := New(Config{ProviderID: "x", ClientID: "public", AuthorizeURL: "https://auth.example/a", TokenURL: token.URL}, token.Client())
	if err != nil {
		t.Fatal(err)
	}
	if _, err := c.ExchangeCode(context.Background(), "code", "verifier", "http://127.0.0.1:8742/oauth/callback"); err == nil {
		t.Fatal("redirected token endpoint unexpectedly succeeded")
	}
	if hit {
		t.Fatal("authorization code/PKCE request followed a token endpoint redirect")
	}
}
