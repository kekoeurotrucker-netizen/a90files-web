package oauthnative

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type Config struct {
	ProviderID string
	ClientID   string
	// ClientSecret is optional. It is never sent in the browser authorization URL.
	// Some desktop providers, notably Google desktop OAuth clients, still return
	// a client_secret alongside the public client_id and may require it at the
	// token endpoint. Desktop binaries cannot keep that value secret from a
	// determined local user, so VaultPool treats it as connector bootstrap
	// material, stores runtime-entered values only in the OS-protected vault, and
	// never logs or displays it.
	ClientSecret string
	AuthorizeURL string
	TokenURL     string
	Scopes       []string
	ExtraAuth    map[string]string
}

type Client struct {
	cfg  Config
	http *http.Client
}

type Token struct {
	AccessToken      string `json:"access_token"`
	RefreshToken     string `json:"refresh_token,omitempty"`
	TokenType        string `json:"token_type"`
	ExpiresIn        int64  `json:"expires_in,omitempty"`
	Scope            string `json:"scope,omitempty"`
	IDToken          string `json:"id_token,omitempty"`
	UID              int64  `json:"uid,omitempty"`
	PCloudHostname   string `json:"pcloud_hostname,omitempty"`
	PCloudLocationID int    `json:"pcloud_location_id,omitempty"`
	ObtainedAt       string `json:"obtained_at"`
}

func New(cfg Config, hc *http.Client) (*Client, error) {
	if strings.TrimSpace(cfg.ProviderID) == "" || strings.TrimSpace(cfg.ClientID) == "" {
		return nil, errors.New("provider_id and client_id required")
	}
	for _, raw := range []string{cfg.AuthorizeURL, cfg.TokenURL} {
		u, err := url.Parse(raw)
		if err != nil || u.Scheme != "https" || u.Hostname() == "" {
			return nil, errors.New("OAuth endpoints must be absolute HTTPS URLs")
		}
	}
	if hc == nil {
		hc = &http.Client{Timeout: 20 * time.Second}
	}
	return &Client{cfg: cfg, http: hc}, nil
}
func (c *Client) ProviderID() string { return c.cfg.ProviderID }

func (c *Client) AuthorizationURL(redirectURI, state, challenge string) (string, error) {
	if state == "" || redirectURI == "" {
		return "", errors.New("redirect URI and state required")
	}
	if c.cfg.ProviderID != "pcloud" && challenge == "" {
		return "", errors.New("PKCE challenge required")
	}
	r, err := url.Parse(redirectURI)
	if err != nil || r.Scheme != "http" || !isLoopback(r.Hostname()) {
		return "", errors.New("native OAuth redirect must use loopback HTTP")
	}
	u, _ := url.Parse(c.cfg.AuthorizeURL)
	q := u.Query()
	q.Set("client_id", c.cfg.ClientID)
	q.Set("response_type", "code")
	q.Set("redirect_uri", redirectURI)
	q.Set("state", state)
	if c.cfg.ProviderID != "pcloud" {
		q.Set("code_challenge", challenge)
		q.Set("code_challenge_method", "S256")
	}
	if len(c.cfg.Scopes) > 0 {
		q.Set("scope", strings.Join(c.cfg.Scopes, " "))
	}
	for k, v := range c.cfg.ExtraAuth {
		q.Set(k, v)
	}
	u.RawQuery = q.Encode()
	return u.String(), nil
}
func isLoopback(host string) bool {
	return host == "127.0.0.1" || host == "::1" || strings.EqualFold(host, "localhost")
}

func (c *Client) ExchangeCode(ctx context.Context, code, verifier, redirectURI string) (Token, error) {
	return c.ExchangeCodeAtHost(ctx, code, verifier, redirectURI, "")
}
func (c *Client) ExchangeCodeAtHost(ctx context.Context, code, verifier, redirectURI, hostname string) (Token, error) {
	if code == "" {
		return Token{}, errors.New("authorization code required")
	}
	var v url.Values
	if c.cfg.ProviderID == "pcloud" {
		v = url.Values{"client_id": {c.cfg.ClientID}, "code": {code}}
	} else {
		if verifier == "" {
			return Token{}, errors.New("authorization code and verifier required")
		}
		v = url.Values{"grant_type": {"authorization_code"}, "client_id": {c.cfg.ClientID}, "code": {code}, "code_verifier": {verifier}, "redirect_uri": {redirectURI}}
	}
	c.addOptionalClientSecret(v)
	if c.cfg.ProviderID == "pcloud" && hostname != "" {
		if hostname != "api.pcloud.com" && hostname != "eapi.pcloud.com" {
			return Token{}, errors.New("invalid pCloud API hostname")
		}
		return c.tokenRequestURL(ctx, "https://"+hostname+"/oauth2_token", v)
	}
	return c.tokenRequest(ctx, v)
}
func (c *Client) Refresh(ctx context.Context, refreshToken string) (Token, error) {
	if refreshToken == "" {
		return Token{}, errors.New("refresh token required")
	}
	v := url.Values{"grant_type": {"refresh_token"}, "client_id": {c.cfg.ClientID}, "refresh_token": {refreshToken}}
	c.addOptionalClientSecret(v)
	return c.tokenRequest(ctx, v)
}
func (c *Client) addOptionalClientSecret(v url.Values) {
	if secret := strings.TrimSpace(c.cfg.ClientSecret); secret != "" {
		v.Set("client_secret", secret)
	}
}
func (c *Client) tokenRequest(ctx context.Context, v url.Values) (Token, error) {
	return c.tokenRequestURL(ctx, c.cfg.TokenURL, v)
}
func (c *Client) tokenRequestURL(ctx context.Context, tokenURL string, v url.Values) (Token, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, tokenURL, strings.NewReader(v.Encode()))
	if err != nil {
		return Token{}, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")
	hc := *c.http
	// Authorization codes, PKCE verifiers and refresh tokens are secrets. Token
	// endpoints are fixed HTTPS origins from the audited provider catalog and a
	// redirect must never carry those values to a different endpoint.
	hc.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	resp, err := hc.Do(req)
	if err != nil {
		return Token{}, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	if err != nil {
		return Token{}, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		var oe struct {
			Error       string `json:"error"`
			Description string `json:"error_description"`
		}
		_ = json.Unmarshal(body, &oe)
		msg := oe.Error
		if oe.Description != "" {
			msg += ": " + oe.Description
		}
		if msg == "" {
			msg = resp.Status
		}
		return Token{}, fmt.Errorf("oauth token exchange failed: %s", msg)
	}
	var t Token
	if err := json.Unmarshal(body, &t); err != nil {
		return Token{}, errors.New("invalid OAuth token response")
	}
	if t.AccessToken == "" || !strings.EqualFold(t.TokenType, "bearer") {
		return Token{}, errors.New("OAuth response missing bearer access token")
	}
	t.ObtainedAt = time.Now().UTC().Format(time.RFC3339Nano)
	return t, nil
}

func Google(clientID string, hc *http.Client) (*Client, error) {
	return GoogleWithSecret(clientID, "", hc)
}
func GoogleWithSecret(clientID, clientSecret string, hc *http.Client) (*Client, error) {
	return New(Config{ProviderID: "google-drive", ClientID: clientID, ClientSecret: clientSecret, AuthorizeURL: "https://accounts.google.com/o/oauth2/v2/auth", TokenURL: "https://oauth2.googleapis.com/token", Scopes: []string{"openid", "email", "https://www.googleapis.com/auth/drive.file"}, ExtraAuth: map[string]string{"access_type": "offline", "include_granted_scopes": "true", "prompt": "consent"}}, hc)
}
func Microsoft(clientID string, hc *http.Client) (*Client, error) {
	return New(Config{ProviderID: "onedrive", ClientID: clientID, AuthorizeURL: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize", TokenURL: "https://login.microsoftonline.com/common/oauth2/v2.0/token", Scopes: []string{"offline_access", "Files.ReadWrite", "User.Read"}}, hc)
}

func Dropbox(clientID string, hc *http.Client) (*Client, error) {
	return New(Config{ProviderID: "dropbox", ClientID: clientID, AuthorizeURL: "https://www.dropbox.com/oauth2/authorize", TokenURL: "https://api.dropboxapi.com/oauth2/token", Scopes: []string{"account_info.read", "files.metadata.read", "files.content.read", "files.content.write"}, ExtraAuth: map[string]string{"token_access_type": "offline"}}, hc)
}

func PCloud(clientID, clientSecret string, hc *http.Client) (*Client, error) {
	if strings.TrimSpace(clientSecret) == "" {
		return nil, errors.New("pCloud client secret required")
	}
	return New(Config{ProviderID: "pcloud", ClientID: clientID, ClientSecret: clientSecret, AuthorizeURL: "https://my.pcloud.com/oauth2/authorize", TokenURL: "https://api.pcloud.com/oauth2_token"}, hc)
}
