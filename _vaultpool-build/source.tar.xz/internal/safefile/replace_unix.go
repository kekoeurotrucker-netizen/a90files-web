//go:build !windows

package safefile

import "os"

func replaceFile(src, dst string) error { return os.Rename(src, dst) }

func syncParent(dir string) error {
	f, err := os.Open(dir)
	if err != nil {
		return err
	}
	defer f.Close()
	return f.Sync()
}
