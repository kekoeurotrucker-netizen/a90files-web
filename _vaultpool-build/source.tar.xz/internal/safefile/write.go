package safefile

import (
	"fmt"
	"os"
	"path/filepath"
)

// CommitTemp atomically replaces path with an already fully-written temporary
// file in the same directory. The caller must fsync and close the temp file
// before calling CommitTemp. On Windows this uses MoveFileExW with
// REPLACE_EXISTING|WRITE_THROUGH; on Unix it uses rename(2).
//
// Once the replace succeeds, path is authoritative. Parent-directory syncing
// is best-effort because reporting an error after the destination changed can
// make callers roll back metadata against the already-committed file.
func CommitTemp(tempPath, path string) error {
	if tempPath == "" || path == "" {
		return fmt.Errorf("temp and destination paths are required")
	}
	if filepath.Clean(filepath.Dir(tempPath)) != filepath.Clean(filepath.Dir(path)) {
		return fmt.Errorf("atomic replace requires temp file in destination directory")
	}
	if err := replaceFile(tempPath, path); err != nil {
		return fmt.Errorf("atomic replace: %w", err)
	}
	_ = syncParent(filepath.Dir(path))
	return nil
}

// WriteAtomic writes data to a temporary file in the destination directory,
// fsyncs it, and atomically replaces the destination where the OS supports it.
// The platform replace implementation preserves the previous destination if
// replacement fails.
func WriteAtomic(path string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".vaultpool-atomic-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	committed := false
	defer func() {
		_ = tmp.Close()
		if !committed {
			_ = os.Remove(tmpName)
		}
	}()
	if err := tmp.Chmod(perm); err != nil {
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		return err
	}
	if err := tmp.Sync(); err != nil {
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := CommitTemp(tmpName, path); err != nil {
		return err
	}
	committed = true
	return nil
}
