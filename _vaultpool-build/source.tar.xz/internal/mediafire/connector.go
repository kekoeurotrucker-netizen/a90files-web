// Package mediafire uses only the documented MediaFire Core API over HTTPS.
package mediafire

import (
	"context"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

const ProviderID = "mediafire"
const apiBase = "https://www.mediafire.com/api/1.5/"

type SecretStore interface {
	Get(string, secretvault.Kind) ([]byte, bool, error)
	Put(string, secretvault.Kind, []byte) error
	Delete(string, secretvault.Kind) error
}
type Session struct {
	ApplicationID string `json:"application_id"`
	Token         string `json:"session_token"`
	SecretKey     uint64 `json:"secret_key"`
	Time          string `json:"time"`
}

func (s Session) valid() bool {
	return s.ApplicationID != "" && s.Token != "" && s.SecretKey > 0 && s.Time != ""
}

type Connector struct {
	Secrets SecretStore
	Client  *http.Client
	mu      sync.Mutex
}

func New(secrets SecretStore) *Connector {
	return &Connector{Secrets: secrets, Client: &http.Client{Timeout: 25 * time.Second}}
}
func (c *Connector) ProviderID() string { return ProviderID }

// Login uses credentials for this single HTTPS request only. The serialized v2
// session is stored in SecretVault; the password is never serialized or logged.
func (c *Connector) Login(ctx context.Context, accountID, applicationID, email, password string) (connector.Snapshot, error) {
	if c == nil || c.Secrets == nil {
		return connector.Snapshot{}, errors.New("bóveda segura de Windows no disponible")
	}
	if strings.TrimSpace(applicationID) == "" || strings.TrimSpace(email) == "" || password == "" {
		return connector.Snapshot{}, errors.New("Application ID, email y contraseña son obligatorios")
	}
	ctx, cancel := timeout(ctx, 75*time.Second)
	defer cancel()
	values := url.Values{"application_id": {strings.TrimSpace(applicationID)}, "email": {strings.TrimSpace(email)}, "password": {password}, "token_version": {"2"}, "response_format": {"json"}}
	var r response
	err := c.post(ctx, "user/get_session_token", values, &r)
	password = ""
	if err != nil {
		return connector.Snapshot{}, friendly(err)
	}
	s := Session{ApplicationID: strings.TrimSpace(applicationID), Token: r.String("session_token"), SecretKey: r.Uint("secret_key"), Time: r.String("time")}
	if !s.valid() {
		return connector.Snapshot{}, errors.New("MediaFire no devolvió una sesión v2 completa")
	}
	snap, s, err := c.snapshot(ctx, accountID, s)
	if err != nil {
		return connector.Snapshot{}, err
	}
	if err := c.save(accountID, s); err != nil {
		return connector.Snapshot{}, err
	}
	return snap, nil
}
func (c *Connector) Probe(ctx context.Context, accountID string) (connector.Snapshot, error) {
	s, err := c.load(accountID)
	if err != nil {
		return connector.Snapshot{}, err
	}
	ctx, cancel := timeout(ctx, 25*time.Second)
	defer cancel()
	snap, s, err := c.snapshot(ctx, accountID, s)
	if err != nil {
		return connector.Snapshot{}, err
	}
	return snap, c.save(accountID, s)
}
func (c *Connector) Logout(accountID string) error {
	if c == nil || c.Secrets == nil {
		return nil
	}
	return c.Secrets.Delete(accountID, secretvault.MediaFireSession)
}
func (c *Connector) load(accountID string) (Session, error) {
	raw, ok, err := c.Secrets.Get(accountID, secretvault.MediaFireSession)
	if err != nil {
		return Session{}, err
	}
	defer wipe(raw)
	var s Session
	if !ok || json.Unmarshal(raw, &s) != nil || !s.valid() {
		return Session{}, errors.New("La sesión de MediaFire no está disponible. Inicia sesión de nuevo.")
	}
	return s, nil
}
func (c *Connector) save(accountID string, s Session) error {
	raw, err := json.Marshal(s)
	if err != nil {
		return err
	}
	defer wipe(raw)
	return c.Secrets.Put(accountID, secretvault.MediaFireSession, raw)
}
func (c *Connector) snapshot(ctx context.Context, accountID string, s Session) (connector.Snapshot, Session, error) {
	info, s, err := c.call(ctx, s, "user/get_info", nil)
	if err != nil {
		return connector.Snapshot{}, s, friendly(err)
	}
	limits, s, err := c.call(ctx, s, "user/get_limits", nil)
	if err != nil {
		return connector.Snapshot{}, s, friendly(err)
	}
	email := first(info.String("email"), info.String("user_email"))
	subject := first(info.String("user_id"), info.String("id"), strings.ToLower(email))
	total := firstUint(limits.Uint("storage_limit"), info.Uint("storage_limit"))
	used := firstUint(limits.Uint("storage_used"), info.Uint("storage_used"))
	if email == "" || subject == "" || total == 0 || used > total {
		return connector.Snapshot{}, s, errors.New("MediaFire no devolvió identidad o cuota verificables")
	}
	snap := connector.Snapshot{ProviderID: ProviderID, AccountID: accountID, ProviderSubject: "user:" + subject, Identity: email, PlanName: first(info.String("plan_name"), "MediaFire"), Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: int64(total), UsedBytes: int64(used), FreeBytes: int64(total - used), Limits: connector.Limits{UploadLimitNote: "Cuota y límites oficiales de MediaFire.", DownloadLimitNote: "Cuota y límites oficiales de MediaFire.", RateLimitNote: "VaultPool respeta los límites oficiales de MediaFire."}, LastChecked: time.Now().UTC().Format(time.RFC3339Nano), StatusNote: "Sesión MediaFire v2, identidad y cuota verificadas mediante API oficial."}
	return snap, s, snap.Validate()
}
func (c *Connector) call(ctx context.Context, s Session, action string, params url.Values) (response, Session, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if params == nil {
		params = url.Values{}
	} else {
		cloned := make(url.Values, len(params))
		for key, values := range params {
			cloned[key] = append([]string(nil), values...)
		}
		params = cloned
	}
	params.Set("session_token", s.Token)
	params.Set("response_format", "json")
	uri := "/api/1.5/" + action + ".php?" + params.Encode()
	digest := md5.Sum([]byte(strconv.FormatUint(s.SecretKey%256, 10) + s.Time + uri))
	params.Set("signature", hex.EncodeToString(digest[:]))
	var r response
	if err := c.post(ctx, action, params, &r); err != nil {
		return r, s, err
	}
	if r.String("new_key") == "yes" {
		s.SecretKey = (s.SecretKey * 16807) % 2147483647
		if s.SecretKey == 0 {
			return r, s, errors.New("rotación de sesión MediaFire inválida")
		}
	}
	return r, s, nil
}
func (c *Connector) post(ctx context.Context, action string, v url.Values, out *response) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, apiBase+action+".php?"+v.Encode(), nil)
	if err != nil {
		return err
	}
	client := c.Client
	if client == nil {
		client = &http.Client{Timeout: 25 * time.Second}
	}
	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	body, err := io.ReadAll(io.LimitReader(res.Body, 2<<20))
	if err != nil {
		return err
	}
	if err = json.Unmarshal(body, out); err != nil {
		return errors.New("respuesta MediaFire no válida")
	}
	if out.Result != "Success" {
		return fmt.Errorf("MediaFire: %s", first(out.Message, "operación rechazada"))
	}
	if res.StatusCode < 200 || res.StatusCode > 299 {
		return fmt.Errorf("MediaFire respondió HTTP %d", res.StatusCode)
	}
	return nil
}

type response struct {
	Result  string `json:"result"`
	Message string `json:"message"`
	Values  map[string]json.RawMessage
}

func (r *response) UnmarshalJSON(b []byte) error {
	var root map[string]json.RawMessage
	if err := json.Unmarshal(b, &root); err != nil {
		return err
	}
	if nested, ok := root["response"]; ok {
		return json.Unmarshal(nested, r)
	}
	r.Values = root
	_ = json.Unmarshal(root["result"], &r.Result)
	_ = json.Unmarshal(root["message"], &r.Message)
	return nil
}
func (r response) String(k string) string {
	var v any
	if json.Unmarshal(r.Values[k], &v) != nil {
		return ""
	}
	switch x := v.(type) {
	case string:
		return strings.TrimSpace(x)
	case float64:
		return strconv.FormatInt(int64(x), 10)
	}
	return ""
}
func (r response) Uint(k string) uint64 { n, _ := strconv.ParseUint(r.String(k), 10, 64); return n }
func first(v ...string) string {
	for _, x := range v {
		if strings.TrimSpace(x) != "" {
			return strings.TrimSpace(x)
		}
	}
	return ""
}
func firstUint(v ...uint64) uint64 {
	for _, x := range v {
		if x > 0 {
			return x
		}
	}
	return 0
}
func timeout(ctx context.Context, d time.Duration) (context.Context, context.CancelFunc) {
	if ctx == nil {
		ctx = context.Background()
	}
	if _, ok := ctx.Deadline(); ok {
		return context.WithCancel(ctx)
	}
	return context.WithTimeout(ctx, d)
}
func wipe(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
func friendly(err error) error {
	if errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled) {
		return errors.New("La operación de MediaFire tardó demasiado y fue cancelada.")
	}
	return err
}
