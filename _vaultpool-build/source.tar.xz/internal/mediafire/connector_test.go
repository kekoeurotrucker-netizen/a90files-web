package mediafire

import (
	"bytes"
	"context"
	"io"
	"net/http"
	"strings"
	"sync"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type memoryVault struct {
	mu      sync.Mutex
	entries map[string][]byte
}

func (m *memoryVault) key(a string, k secretvault.Kind) string { return a + "/" + string(k) }
func (m *memoryVault) Get(a string, k secretvault.Kind) ([]byte, bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	v, ok := m.entries[m.key(a, k)]
	return append([]byte(nil), v...), ok, nil
}
func (m *memoryVault) Put(a string, k secretvault.Kind, v []byte) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.entries[m.key(a, k)] = append([]byte(nil), v...)
	return nil
}
func (m *memoryVault) Delete(a string, k secretvault.Kind) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.entries, m.key(a, k))
	return nil
}

type roundTrip func(*http.Request) (*http.Response, error)

func (f roundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func jsonReply(body string) *http.Response {
	return &http.Response{StatusCode: 200, Header: make(http.Header), Body: io.NopCloser(strings.NewReader(body))}
}

func TestLoginPersistsV2SessionAndProbeRestoresIt(t *testing.T) {
	vault := &memoryVault{entries: map[string][]byte{}}
	var calls []string
	c := New(vault)
	c.Client = &http.Client{Transport: roundTrip(func(r *http.Request) (*http.Response, error) {
		calls = append(calls, r.URL.Path+"?"+r.URL.RawQuery)
		if got := r.URL.Query().Get("password"); got != "" && got != "correct horse" {
			t.Fatalf("unexpected password value")
		}
		switch {
		case strings.Contains(r.URL.Path, "get_session_token"):
			return jsonReply(`{"response":{"result":"Success","session_token":"token-a","secret_key":"9316931","time":"1359061000.8125"}}`), nil
		case strings.Contains(r.URL.Path, "get_info"):
			if r.URL.Query().Get("signature") == "" {
				t.Fatal("missing v2 signature")
			}
			return jsonReply(`{"response":{"result":"Success","new_key":"yes","email":"person@example.test","user_id":"42","plan_name":"Basic"}}`), nil
		case strings.Contains(r.URL.Path, "get_limits"):
			if r.URL.Query().Get("signature") == "" {
				t.Fatal("missing rotated v2 signature")
			}
			return jsonReply(`{"response":{"result":"Success","storage_limit":"1000","storage_used":"250"}}`), nil
		default:
			return jsonReply(`{"response":{"result":"Error","message":"unexpected"}}`), nil
		}
	})}
	snap, err := c.Login(context.Background(), "acct", "app-42", "person@example.test", "correct horse")
	if err != nil {
		t.Fatal(err)
	}
	if snap.Identity != "person@example.test" || snap.FreeBytes != 750 {
		t.Fatalf("bad snapshot %#v", snap)
	}
	raw, ok, err := vault.Get("acct", secretvault.MediaFireSession)
	if err != nil || !ok || bytes.Contains(raw, []byte("correct horse")) {
		t.Fatalf("session secret unsafe: ok=%v err=%v raw=%q", ok, err, raw)
	}
	if _, err := c.Probe(context.Background(), "acct"); err != nil {
		t.Fatal(err)
	}
	if len(calls) != 5 {
		t.Fatalf("want login plus two probes, got %d", len(calls))
	}
}
