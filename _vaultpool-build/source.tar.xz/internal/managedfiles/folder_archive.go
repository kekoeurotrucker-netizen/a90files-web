package managedfiles

import (
	"archive/zip"
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/core"
)

const folderArchiveSuffix = ".vaultpool-folder.zip"

func (m *Manager) stageFolderArchive(ctx context.Context, root string, progress core.ProgressFunc) (string, os.FileInfo, func(), error) {
	if progress != nil {
		progress(core.TransferProgress{Phase: "packaging"})
	}
	absRoot, err := filepath.Abs(root)
	if err != nil {
		return "", nil, nil, err
	}
	stagingRoot := filepath.Join(m.root, "staging")
	if err := os.MkdirAll(stagingRoot, 0o700); err != nil {
		return "", nil, nil, err
	}
	stageDir, err := os.MkdirTemp(stagingRoot, "folder-*")
	if err != nil {
		return "", nil, nil, err
	}
	cleanup := func() { _ = os.RemoveAll(stageDir) }
	archivePath := filepath.Join(stageDir, folderArchiveName(filepath.Base(absRoot)))
	file, err := os.OpenFile(archivePath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
	if err != nil {
		cleanup()
		return "", nil, nil, err
	}
	zipper := zip.NewWriter(file)
	entries := 0
	walkErr := filepath.WalkDir(absRoot, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if path == absRoot {
			return nil
		}
		if entry.Type()&os.ModeSymlink != 0 {
			return fmt.Errorf("folder contains a symbolic link: %s", safeRelativeName(absRoot, path))
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		if !entry.IsDir() && !info.Mode().IsRegular() {
			return nil
		}
		name, err := zipEntryName(absRoot, path, entry.IsDir())
		if err != nil {
			return err
		}
		header, err := zip.FileInfoHeader(info)
		if err != nil {
			return err
		}
		header.Name = name
		if entry.IsDir() {
			header.Method = zip.Store
			_, err = zipper.CreateHeader(header)
			if err == nil {
				entries++
			}
			return err
		}
		header.Method = zip.Deflate
		writer, err := zipper.CreateHeader(header)
		if err != nil {
			return err
		}
		in, err := os.Open(path)
		if err != nil {
			return err
		}
		_, copyErr := io.Copy(writer, in)
		closeErr := in.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		entries++
		return nil
	})
	closeZipErr := zipper.Close()
	closeFileErr := file.Close()
	if walkErr != nil || closeZipErr != nil || closeFileErr != nil {
		cleanup()
		return "", nil, nil, errors.Join(walkErr, closeZipErr, closeFileErr)
	}
	if entries == 0 {
		cleanup()
		return "", nil, nil, errors.New("folder contains no files or subfolders")
	}
	info, err := os.Stat(archivePath)
	if err != nil {
		cleanup()
		return "", nil, nil, err
	}
	return archivePath, info, cleanup, nil
}

func folderArchiveName(name string) string {
	name = strings.Trim(strings.TrimSpace(name), ". ")
	if name == "" || name == string(os.PathSeparator) {
		name = "carpeta"
	}
	var b strings.Builder
	for _, r := range name {
		switch {
		case r < 32 || strings.ContainsRune(`<>:"/\|?*`, r):
			b.WriteRune('_')
		default:
			b.WriteRune(r)
		}
	}
	clean := strings.Trim(b.String(), ". ")
	if clean == "" {
		clean = "carpeta"
	}
	if len([]rune(clean)) > 120 {
		clean = string([]rune(clean)[:120])
	}
	return clean + folderArchiveSuffix
}

func zipEntryName(root, path string, isDir bool) (string, error) {
	rel, err := filepath.Rel(root, path)
	if err != nil {
		return "", err
	}
	name := filepath.ToSlash(rel)
	name = strings.TrimPrefix(name, "./")
	if name == "" || name == "." || strings.HasPrefix(name, "../") || strings.Contains(name, "/../") || filepath.IsAbs(name) {
		return "", fmt.Errorf("unsafe folder entry path: %s", rel)
	}
	if isDir && !strings.HasSuffix(name, "/") {
		name += "/"
	}
	return name, nil
}

func safeRelativeName(root, path string) string {
	rel, err := filepath.Rel(root, path)
	if err != nil {
		return filepath.Base(path)
	}
	return filepath.ToSlash(rel)
}

func cleanupStaleFolderArchives(stagingRoot string, olderThan time.Duration) {
	entries, err := os.ReadDir(stagingRoot)
	if err != nil {
		return
	}
	cutoff := time.Now().Add(-olderThan)
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		info, err := entry.Info()
		if err != nil || info.ModTime().After(cutoff) {
			continue
		}
		_ = os.RemoveAll(filepath.Join(stagingRoot, entry.Name()))
	}
}
