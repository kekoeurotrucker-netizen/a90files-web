package managedfiles

import (
	"archive/zip"
	"bytes"
	"context"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/recoveryrecords"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type testProtector struct{ k byte }

func (p testProtector) Name() string { return "managedfiles-test" }
func (p testProtector) Protect(in []byte) ([]byte, error) {
	out := append([]byte(nil), in...)
	for i := range out {
		out[i] ^= p.k
	}
	return out, nil
}
func (p testProtector) Unprotect(in []byte) ([]byte, error) { return p.Protect(in) }

type failMetadataStore struct {
	base *secretvault.Vault
	fail bool
}

func (s *failMetadataStore) Get(id string, kind secretvault.Kind) ([]byte, bool, error) {
	return s.base.Get(id, kind)
}
func (s *failMetadataStore) Put(id string, kind secretvault.Kind, value []byte) error {
	if s.fail && kind == secretvault.FileMetadata {
		s.fail = false
		return errors.New("injected metadata write failure")
	}
	return s.base.Put(id, kind, value)
}
func (s *failMetadataStore) Delete(id string, kind secretvault.Kind) error {
	return s.base.Delete(id, kind)
}
func (s *failMetadataStore) ListMetadata() ([]secretvault.Metadata, error) {
	return s.base.ListMetadata()
}
func (s *failMetadataStore) RecoveryConfigured() (bool, string) { return s.base.RecoveryConfigured() }

func makeTargets(t *testing.T, pool string, n int) []storage.Target {
	t.Helper()
	for i := 0; i < n; i++ {
		if err := os.MkdirAll(filepath.Join(pool, "provider-"+string(rune('a'+i))), 0700); err != nil {
			t.Fatal(err)
		}
	}
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	return targets
}

func setupManaged(t *testing.T, withRecovery bool) (*Manager, *secretvault.Vault, *core.Engine, []storage.Target, string, []byte) {
	t.Helper()
	dir := t.TempDir()
	pool := filepath.Join(dir, "pool")
	targets := makeTargets(t, pool, 6)
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), testProtector{0x5a})
	if err != nil {
		t.Fatal(err)
	}
	if withRecovery {
		if _, err := v.ConfigurePortableRecovery(filepath.Join(dir, "VaultPool-Recovery.vpr")); err != nil {
			t.Fatal(err)
		}
		if err := v.ConfirmPortableRecovery(); err != nil {
			t.Fatal(err)
		}
	}
	e, err := core.New(core.DefaultConfig())
	if err != nil {
		t.Fatal(err)
	}
	mutable := targets
	rr, err := recoveryrecords.New(v, 2)
	if err != nil {
		t.Fatal(err)
	}
	mgr, err := New(filepath.Join(dir, "managed"), v, e, func(context.Context) ([]storage.Target, error) { return append([]storage.Target(nil), mutable...), nil }, rr)
	if err != nil {
		t.Fatal(err)
	}
	_ = mgr
	input := filepath.Join(dir, "sample.bin")
	data := bytes.Repeat([]byte("VaultPool-managed-files-test\n"), 600000)
	if err := os.WriteFile(input, data, 0600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(dir, "source.vpm")
	if err := e.PackTargets(context.Background(), input, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	return mgr, v, e, targets, mf, key
}

func TestRegistrationRequiresPortableRecoveryAndKeepsMetadataEncrypted(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, false)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	if _, err := mgr.RegisterCommitted(mf, key); err != secretvault.ErrPortableRecoveryRequired {
		t.Fatalf("expected recovery gate, got %v", err)
	}
	if _, err := v.ConfigurePortableRecovery(filepath.Join(filepath.Dir(mf), "recovery.vpr")); err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	items, err := mgr.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 1 || items[0].FileID != meta.FileID {
		t.Fatalf("unexpected catalog: %+v", items)
	}
	raw, err := os.ReadFile(filepath.Join(filepath.Dir(mf), "secrets.vpv"))
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(raw, []byte(meta.FileName)) || bytes.Contains(raw, []byte(meta.OriginalSHA256)) {
		t.Fatal("private file catalog leaked to plaintext secret-vault file")
	}
}

func TestAuditDetectsCorruptionAndRepairRestoresProtection(t *testing.T) {
	mgr, v, e, targets, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	h, err := mgr.Audit(context.Background(), meta.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if h.ValidShards != h.TotalShards || h.RepairAllowed {
		t.Fatalf("healthy audit unexpected: %+v", h)
	}
	managedPath, _ := mgr.manifestPath(meta.FileID)
	m, err := manifest.Load(managedPath, key)
	if err != nil {
		t.Fatal(err)
	}
	s := m.Blocks[0].Shards[0]
	var root string
	for _, tg := range targets {
		if tg.ID == s.Provider {
			root = tg.Store.(*storage.LocalStore).Local.Root
		}
	}
	if root == "" {
		t.Fatal("target root not found")
	}
	p := filepath.Join(root, filepath.FromSlash(s.Object))
	if err := os.WriteFile(p, bytes.Repeat([]byte{0xCC}, m.Blocks[0].ShardSize), 0600); err != nil {
		t.Fatal(err)
	}
	h, err = mgr.Audit(context.Background(), meta.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if h.CorruptShards < 1 || !h.RepairAllowed {
		t.Fatalf("corruption not actionable: %+v", h)
	}
	r, err := mgr.Repair(context.Background(), meta.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if r.Report.RepairedShards < 1 || r.Health.ValidShards != r.Health.TotalShards || r.Health.RepairAllowed {
		t.Fatalf("repair result unexpected: %+v", r)
	}
}

func TestTemporaryOutageDoesNotEnableRepair(t *testing.T) {
	mgr, v, e, targets, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	// Replace resolver with an otherwise complete target list where the account
	// holding the first shard is disabled. Audit must call it unavailable, not lost.
	managedPath, _ := mgr.manifestPath(meta.FileID)
	m, err := manifest.Load(managedPath, key)
	if err != nil {
		t.Fatal(err)
	}
	badID := m.Blocks[0].Shards[0].Provider
	mgr.targets = func(context.Context) ([]storage.Target, error) {
		cp := append([]storage.Target(nil), targets...)
		for i := range cp {
			if cp[i].ID == badID {
				cp[i].Enabled = false
			}
		}
		return cp, nil
	}
	h, err := mgr.Audit(context.Background(), meta.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if h.UnavailableShards < 1 || h.MissingShards != 0 || h.CorruptShards != 0 || h.RepairAllowed {
		t.Fatalf("temporary outage misclassified: %+v", h)
	}
	if _, err := mgr.Repair(context.Background(), meta.FileID); err == nil {
		t.Fatal("repair must be blocked for outage-only condition")
	}
}

func TestRegisterRefusesSameFileIDDifferentMetadata(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	managedPath, _ := mgr.manifestPath(meta.FileID)
	m, err := manifest.Load(managedPath, key)
	if err != nil {
		t.Fatal(err)
	}
	m.FileName = "different-name.bin"
	sealed, err := manifest.Seal(m, key)
	if err != nil {
		t.Fatal(err)
	}
	altered := filepath.Join(t.TempDir(), "altered.vpm")
	if err := os.WriteFile(altered, sealed, 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := mgr.RegisterCommitted(altered, key); err == nil {
		t.Fatal("same FileID with different file metadata must be rejected")
	}
}

func TestRegisterRollbackPreservesExistingRecoveryState(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	managedPath, _ := mgr.manifestPath(meta.FileID)
	beforeManifest, err := os.ReadFile(managedPath)
	if err != nil {
		t.Fatal(err)
	}
	beforeKey, ok, err := v.Get(meta.FileID, secretvault.FileDataKey)
	if err != nil || !ok {
		t.Fatalf("read old key: ok=%v err=%v", ok, err)
	}
	defer zero(beforeKey)
	beforeMeta, ok, err := v.Get(meta.FileID, secretvault.FileMetadata)
	if err != nil || !ok {
		t.Fatalf("read old metadata: ok=%v err=%v", ok, err)
	}
	defer zero(beforeMeta)

	flaky := &failMetadataStore{base: v, fail: true}
	mgr.vault = flaky
	if _, err := mgr.RegisterCommitted(mf, key); err == nil {
		t.Fatal("expected injected registration failure")
	}
	afterManifest, err := os.ReadFile(managedPath)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(beforeManifest, afterManifest) {
		t.Fatal("failed registration changed authoritative local manifest")
	}
	afterKey, ok, err := v.Get(meta.FileID, secretvault.FileDataKey)
	if err != nil || !ok {
		t.Fatalf("read restored key: ok=%v err=%v", ok, err)
	}
	defer zero(afterKey)
	if !bytes.Equal(beforeKey, afterKey) {
		t.Fatal("failed registration did not restore previous file key")
	}
	afterMeta, ok, err := v.Get(meta.FileID, secretvault.FileMetadata)
	if err != nil || !ok {
		t.Fatalf("read restored metadata: ok=%v err=%v", ok, err)
	}
	defer zero(afterMeta)
	if !bytes.Equal(beforeMeta, afterMeta) {
		t.Fatal("failed registration did not restore previous encrypted metadata")
	}
}

func TestRegistrationRefusesRecoveryOnOnlyOneProviderDomain(t *testing.T) {
	mgr, v, e, targets, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	// Six accounts that all fail together are still only one provider domain.
	mgr.targets = func(context.Context) ([]storage.Target, error) {
		cp := append([]storage.Target(nil), targets...)
		for i := range cp {
			cp[i].FailureDomain = "same-provider"
		}
		return cp, nil
	}
	if _, err := mgr.RegisterCommitted(mf, key); err == nil {
		t.Fatal("file registered without durable recovery across independent providers")
	}
	items, err := mgr.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 0 {
		t.Fatalf("failed durable-recovery registration leaked into catalog: %+v", items)
	}
}

func TestImportRecoveredManifestRebuildsCatalogWithoutFreshReplicaWrite(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)

	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	sealed, err := os.ReadFile(mf)
	if err != nil {
		t.Fatal(err)
	}
	// Simulate M0.14 having already restored the authenticated FileDataKey but
	// local catalog metadata/manifests being absent after reinstall.
	if err := v.Put(m.FileID, secretvault.FileDataKey, key); err != nil {
		t.Fatal(err)
	}
	if err := v.Delete(m.FileID, secretvault.FileMetadata); err != nil {
		t.Fatal(err)
	}
	localManifest, err := mgr.manifestPath(m.FileID)
	if err != nil {
		t.Fatal(err)
	}
	_ = os.Remove(localManifest)
	// Recovery import must not depend on writing fresh remote recovery replicas.
	mgr.targets = func(context.Context) ([]storage.Target, error) {
		return nil, errors.New("all but one provider temporarily unavailable")
	}
	meta, err := mgr.ImportRecoveredManifestBytesContext(context.Background(), sealed, key)
	if err != nil {
		t.Fatal(err)
	}
	if meta.FileID != m.FileID || meta.Generation != m.Generation {
		t.Fatalf("recovered metadata=%+v manifest=%+v", meta, m)
	}
	items, err := mgr.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 1 || items[0].FileID != m.FileID {
		t.Fatalf("catalog not rebuilt: %+v", items)
	}
	if _, err := os.Stat(localManifest); err != nil {
		t.Fatalf("recovered local encrypted manifest missing: %v", err)
	}
}

func TestImportRecoveredManifestRejectsMissingOrDifferentVaultKey(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	sealed, err := os.ReadFile(mf)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := mgr.ImportRecoveredManifestBytesContext(context.Background(), sealed, key); err == nil {
		t.Fatal("recovery import accepted manifest before FileDataKey restoration")
	}
	wrong, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	defer zero(wrong)
	if err := v.Put(m.FileID, secretvault.FileDataKey, wrong); err != nil {
		t.Fatal(err)
	}
	if _, err := mgr.ImportRecoveredManifestBytesContext(context.Background(), sealed, key); err == nil {
		t.Fatal("recovery import accepted a manifest whose key disagreed with SecretVault")
	}
}

func TestAddPathAndRestoreToPathRoundTrip(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	input := filepath.Join(filepath.Dir(mf), "sample.bin")
	original, err := os.ReadFile(input)
	if err != nil {
		t.Fatal(err)
	}
	var seenProgress bool
	meta, err := mgr.AddPath(context.Background(), input, func(p core.TransferProgress) {
		if p.Phase == "uploading" && p.BytesProcessed > 0 {
			seenProgress = true
		}
	})
	if err != nil {
		t.Fatal(err)
	}
	if !seenProgress || meta.FileID == "" || meta.FileName != "sample.bin" {
		t.Fatalf("unexpected ingest result: progress=%v meta=%+v", seenProgress, meta)
	}
	out := filepath.Join(filepath.Dir(mf), "restored", "sample.bin")
	var restoreProgress bool
	if err := mgr.RestoreToPath(context.Background(), meta.FileID, out, func(p core.TransferProgress) {
		if p.Phase == "restoring" && p.BytesProcessed > 0 {
			restoreProgress = true
		}
	}); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !restoreProgress || !bytes.Equal(got, original) {
		t.Fatal("managed upload/restore was not byte-identical")
	}
}

func TestAddPathPackagesDirectoryWithoutAbsolutePaths(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	root := filepath.Join(filepath.Dir(mf), "Proyecto Privado")
	if err := os.MkdirAll(filepath.Join(root, "nested", "empty"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "nested", "note.txt"), []byte("contenido privado"), 0o600); err != nil {
		t.Fatal(err)
	}
	var sawPackaging bool
	meta, err := mgr.AddPath(context.Background(), root, func(p core.TransferProgress) {
		if p.Phase == "packaging" {
			sawPackaging = true
		}
	})
	if err != nil {
		t.Fatal(err)
	}
	if !sawPackaging || meta.FileName != "Proyecto Privado.vaultpool-folder.zip" {
		t.Fatalf("unexpected folder metadata: packaging=%v meta=%+v", sawPackaging, meta)
	}
	out := filepath.Join(filepath.Dir(mf), "restored-folder.zip")
	if err := mgr.RestoreToPath(context.Background(), meta.FileID, out, nil); err != nil {
		t.Fatal(err)
	}
	zr, err := zip.OpenReader(out)
	if err != nil {
		t.Fatal(err)
	}
	defer zr.Close()
	entries := map[string]bool{}
	for _, f := range zr.File {
		if strings.Contains(f.Name, `\`) || strings.Contains(f.Name, ":") || strings.HasPrefix(f.Name, "/") || strings.Contains(f.Name, "../") {
			t.Fatalf("unsafe zip entry leaked from folder package: %q", f.Name)
		}
		entries[f.Name] = true
		if f.Name != "nested/note.txt" {
			continue
		}
		r, err := f.Open()
		if err != nil {
			t.Fatal(err)
		}
		buf, readErr := io.ReadAll(r)
		closeErr := r.Close()
		if readErr != nil {
			t.Fatal(readErr)
		}
		if closeErr != nil {
			t.Fatal(closeErr)
		}
		if string(buf) != "contenido privado" {
			t.Fatalf("unexpected restored folder file contents: %q", buf)
		}
	}
	for _, want := range []string{"nested/", "nested/empty/", "nested/note.txt"} {
		if !entries[want] {
			t.Fatalf("missing zip entry %q in %#v", want, entries)
		}
	}
	staged, err := os.ReadDir(filepath.Join(mgr.root, "staging"))
	if err != nil {
		t.Fatal(err)
	}
	if len(staged) != 0 {
		t.Fatalf("folder staging data was not cleaned: %v", staged)
	}
}

func TestAddPathRejectsSymlink(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	target := filepath.Join(filepath.Dir(mf), "sample.bin")
	link := filepath.Join(filepath.Dir(mf), "sample-link.bin")
	if err := os.Symlink(target, link); err != nil {
		t.Skipf("symlink unavailable: %v", err)
	}
	if _, err := mgr.AddPath(context.Background(), link, nil); err == nil {
		t.Fatal("symlink input should be rejected")
	}
}

func TestRestoreRefusesManagedInternalDestination(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	input := filepath.Join(filepath.Dir(mf), "sample.bin")
	meta, err := mgr.AddPath(context.Background(), input, nil)
	if err != nil {
		t.Fatal(err)
	}
	bad := filepath.Join(mgr.root, "manifests", "overwrite.vpm")
	if err := mgr.RestoreToPath(context.Background(), meta.FileID, bad, nil); err == nil {
		t.Fatal("restore into internal managed-file root should be blocked")
	}
}

func TestDistributionSummarizesAuthenticatedManifestPlacement(t *testing.T) {
	mgr, v, e, _, mf, key := setupManaged(t, true)
	defer v.Close()
	defer e.Close()
	defer zero(key)
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	report, err := mgr.Distribution(meta.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if report.FileID != meta.FileID || report.Blocks == 0 {
		t.Fatalf("unexpected distribution report: %+v", report)
	}
	wantFragments := report.Blocks * (meta.DataShards + meta.ParityShards)
	if report.Fragments != wantFragments || report.Bytes <= 0 {
		t.Fatalf("unexpected fragment totals: %+v", report)
	}
	counted := 0
	for _, provider := range report.Providers {
		if provider.TargetID == "" || provider.ProviderID == "" || provider.Fragments == 0 || provider.Bytes <= 0 {
			t.Fatalf("invalid provider distribution: %+v", provider)
		}
		counted += provider.Fragments
	}
	if counted != report.Fragments {
		t.Fatalf("provider fragment count=%d want %d", counted, report.Fragments)
	}
}
