package managedfiles

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/contentprofile"
	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/health"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/recoveryrecords"
	"github.com/vaultpool-project/vaultpool/internal/safefile"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

// Metadata is user-private file catalog data. It is deliberately stored inside
// SecretVault (FileMetadata), never in ui-state.json or plaintext SQLite/JSON.
type Metadata struct {
	FileID                   string    `json:"file_id"`
	FileName                 string    `json:"file_name"`
	OriginalSize             int64     `json:"original_size"`
	OriginalSHA256           string    `json:"original_sha256"`
	Generation               uint64    `json:"generation"`
	BlockSize                int       `json:"block_size,omitempty"`
	DataShards               int       `json:"data_shards"`
	ParityShards             int       `json:"parity_shards"`
	MinProviderFailureMargin int       `json:"min_provider_failure_margin"`
	CreatedAt                time.Time `json:"created_at"`
	RegisteredAt             time.Time `json:"registered_at"`
}

// Distribution summarizes where a protected file's ciphertext fragments were
// placed. It deliberately omits remote object locators and all plaintext data.
type Distribution struct {
	FileID       string                 `json:"file_id"`
	DataShards   int                    `json:"data_shards"`
	ParityShards int                    `json:"parity_shards"`
	Blocks       int                    `json:"blocks"`
	Fragments    int                    `json:"fragments"`
	Bytes        int64                  `json:"bytes"`
	Providers    []ProviderDistribution `json:"providers"`
}

type ProviderDistribution struct {
	TargetID   string `json:"-"`
	ProviderID string `json:"provider_id"`
	Fragments  int    `json:"fragments"`
	Blocks     int    `json:"blocks"`
	Bytes      int64  `json:"bytes"`
}

func (m Metadata) Validate() error {
	if !validFileID(m.FileID) {
		return errors.New("invalid file id")
	}
	if strings.TrimSpace(m.FileName) == "" || filepath.Base(m.FileName) != m.FileName {
		return errors.New("invalid file name")
	}
	if m.OriginalSize < 0 || len(m.OriginalSHA256) != 64 {
		return errors.New("invalid file size/hash")
	}
	if _, err := hex.DecodeString(m.OriginalSHA256); err != nil {
		return errors.New("invalid file SHA-256")
	}
	if m.Generation < 1 || m.BlockSize < 0 || m.DataShards < 1 || m.ParityShards < 1 {
		return errors.New("invalid file erasure metadata")
	}
	if m.MinProviderFailureMargin < 0 || m.MinProviderFailureMargin >= m.ParityShards {
		return errors.New("invalid provider failure margin")
	}
	return nil
}

func metadataFromManifest(m *manifest.Manifest) Metadata {
	return Metadata{
		FileID: m.FileID, FileName: m.FileName, OriginalSize: m.OriginalSize,
		OriginalSHA256: m.OriginalSHA256, Generation: m.Generation, BlockSize: m.BlockSize,
		DataShards: m.DataShards, ParityShards: m.ParityShards,
		MinProviderFailureMargin: m.MinProviderFailureMargin,
		CreatedAt:                m.CreatedAt, RegisteredAt: time.Now().UTC(),
	}
}

func validFileID(id string) bool {
	if len(id) != 32 {
		return false
	}
	_, err := hex.DecodeString(id)
	return err == nil
}

type TargetResolver func(context.Context) ([]storage.Target, error)

type SecretStore interface {
	Get(string, secretvault.Kind) ([]byte, bool, error)
	Put(string, secretvault.Kind, []byte) error
	Delete(string, secretvault.Kind) error
	ListMetadata() ([]secretvault.Metadata, error)
	RecoveryConfigured() (bool, string)
}

type RecoveryKeyReplicator interface {
	ReplicateFileKey(context.Context, string, []byte, []storage.Target) (recoveryrecords.ReplicationReport, error)
}

type Manager struct {
	root         string
	vault        SecretStore
	engine       *core.Engine
	targets      TargetResolver
	recoveryKeys RecoveryKeyReplicator
}

func New(root string, vault SecretStore, engine *core.Engine, resolver TargetResolver, recoveryKeys RecoveryKeyReplicator) (*Manager, error) {
	if strings.TrimSpace(root) == "" || vault == nil || engine == nil {
		return nil, errors.New("managed file root, secret vault and engine are required")
	}
	if resolver == nil {
		return nil, errors.New("storage target resolver required")
	}
	if recoveryKeys == nil {
		return nil, errors.New("durable recovery-key replicator required")
	}
	if err := os.MkdirAll(filepath.Join(root, "manifests"), 0o700); err != nil {
		return nil, err
	}
	if err := os.MkdirAll(filepath.Join(root, "staging"), 0o700); err != nil {
		return nil, err
	}
	cleanupStaleFolderArchives(filepath.Join(root, "staging"), 24*time.Hour)
	return &Manager{root: root, vault: vault, engine: engine, targets: resolver, recoveryKeys: recoveryKeys}, nil
}

func (m *Manager) manifestPath(fileID string) (string, error) {
	if !validFileID(fileID) {
		return "", errors.New("invalid file id")
	}
	return filepath.Join(m.root, "manifests", fileID+".vpm"), nil
}

func writeAtomic(path string, data []byte) error {
	return safefile.WriteAtomic(path, data, 0o600)
}

// RegisterCommitted imports an already committed authenticated manifest into
// the private VaultPool catalog. The data key and catalog metadata are recovery
// critical, so SecretVault refuses this operation until portable recovery is
// configured. The local manifest itself remains AES-GCM sealed.
// AddPath safely ingests a local file or folder into VaultPool. Regular files
// stream directly; folders are first packaged in a private local staging area
// and that temporary package is removed when the protected upload finishes. The
// recovery record is durably replicated before any file shard is uploaded, so a
// later crash can leave at worst tiny orphan recovery metadata -- never
// committed ciphertext whose key disappears.
func (m *Manager) AddPath(ctx context.Context, input string, progress core.ProgressFunc) (Metadata, error) {
	configured, _ := m.vault.RecoveryConfigured()
	if !configured {
		return Metadata{}, secretvault.ErrPortableRecoveryRequired
	}
	input = filepath.Clean(strings.TrimSpace(input))
	if input == "." || input == "" {
		return Metadata{}, errors.New("input path required")
	}
	if !filepath.IsAbs(input) {
		return Metadata{}, errors.New("input path must be absolute")
	}
	st, err := os.Lstat(input)
	if err != nil {
		return Metadata{}, err
	}
	if st.Mode()&os.ModeSymlink != 0 {
		return Metadata{}, errors.New("symbolic-link inputs are not accepted; select the real file or folder")
	}
	uploadInput := input
	cleanupStagedInput := func() {}
	if st.IsDir() {
		uploadInput, st, cleanupStagedInput, err = m.stageFolderArchive(ctx, input, progress)
		if err != nil {
			return Metadata{}, err
		}
		defer cleanupStagedInput()
	} else if !st.Mode().IsRegular() {
		return Metadata{}, errors.New("input must be a regular file or folder")
	}
	if st.Size() == 0 {
		return Metadata{}, errors.New("empty files are not supported yet")
	}
	profile := contentprofile.ForPath(uploadInput)
	engine := m.engine
	if profile.BlockSize != core.DefaultConfig().BlockSize || profile.SkipCompression {
		cfg := core.DefaultConfig()
		cfg.BlockSize = profile.BlockSize
		cfg.SkipCompression = profile.SkipCompression
		engine, err = core.New(cfg)
		if err != nil {
			return Metadata{}, fmt.Errorf("create content profile engine: %w", err)
		}
		defer engine.Close()
	}
	fileID, err := cryptokit.RandomID(16)
	if err != nil {
		return Metadata{}, err
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		return Metadata{}, err
	}
	defer zero(key)
	targets, err := m.targets(ctx)
	if err != nil {
		return Metadata{}, fmt.Errorf("resolve storage targets: %w", err)
	}
	if progress != nil {
		progress(core.TransferProgress{Phase: "recovering"})
	}
	recoveryReport, err := m.recoveryKeys.ReplicateFileKey(ctx, fileID, key, targets)
	if err != nil {
		return Metadata{}, fmt.Errorf("establish durable file-key recovery before upload: %w", err)
	}
	// The planner received the quota snapshot from before the recovery record was
	// written. Reserve those verified bytes explicitly so boundary-capacity plans
	// cannot overcommit by even a small metadata object.
	usedByRecovery := map[string]bool{}
	for _, id := range recoveryReport.SuccessfulTargetID {
		usedByRecovery[id] = true
	}
	for i := range targets {
		if usedByRecovery[targets[i].ID] {
			if targets[i].FreeBytes < recoveryReport.RecordBytes {
				return Metadata{}, errors.New("provider quota changed while establishing durable recovery")
			}
			targets[i].FreeBytes -= recoveryReport.RecordBytes
		}
	}
	manifestPath, err := m.manifestPath(fileID)
	if err != nil {
		return Metadata{}, err
	}
	if err := engine.PackTargetsWithIDObserved(ctx, uploadInput, manifestPath, key, targets, fileID, progress); err != nil {
		return Metadata{}, err
	}
	sealed, err := os.ReadFile(manifestPath)
	if err != nil {
		return Metadata{}, fmt.Errorf("read committed local manifest: %w", err)
	}
	defer zero(sealed)
	mf, err := manifest.Open(sealed, key)
	if err != nil {
		return Metadata{}, fmt.Errorf("authenticate committed manifest: %w", err)
	}
	// The key replicas were already verified before data upload; do not create a
	// second recovery transaction here.
	return m.registerAuthenticatedManifest(ctx, sealed, key, mf, false)
}

// RestoreToPath reconstructs one managed file directly into a verified atomic
// destination. Existing destinations are replaced only after final SHA-256
// verification succeeds.
func (m *Manager) RestoreToPath(ctx context.Context, fileID, out string, progress core.ProgressFunc) error {
	meta, ok, err := m.Get(fileID)
	if err != nil {
		return err
	}
	if !ok {
		return errors.New("managed file not found")
	}
	out = filepath.Clean(strings.TrimSpace(out))
	if out == "." || out == "" {
		return errors.New("output path required")
	}
	if !filepath.IsAbs(out) {
		return errors.New("output path must be absolute")
	}
	absRoot, err := filepath.Abs(m.root)
	if err != nil {
		return err
	}
	absOut, err := filepath.Abs(out)
	if err != nil {
		return err
	}
	if rel, err := filepath.Rel(absRoot, absOut); err == nil && rel != ".." && !strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
		return errors.New("refusing to restore over VaultPool internal managed-file data")
	}
	key, err := m.key(fileID)
	if err != nil {
		return err
	}
	defer zero(key)
	manifestPath, err := m.manifestPath(meta.FileID)
	if err != nil {
		return err
	}
	targets, err := m.targets(ctx)
	if err != nil {
		return fmt.Errorf("resolve storage targets: %w", err)
	}
	return m.engine.RestoreTargetsObserved(ctx, manifestPath, absOut, key, targets, progress)
}

func (m *Manager) RegisterCommitted(manifestPath string, key []byte) (Metadata, error) {
	return m.RegisterCommittedContext(context.Background(), manifestPath, key)
}

func (m *Manager) RegisterCommittedContext(ctx context.Context, manifestPath string, key []byte) (Metadata, error) {
	if len(key) != cryptokit.KeySize {
		return Metadata{}, errors.New("invalid file data key length")
	}
	configured, _ := m.vault.RecoveryConfigured()
	if !configured {
		return Metadata{}, secretvault.ErrPortableRecoveryRequired
	}
	sealed, err := os.ReadFile(manifestPath)
	if err != nil {
		return Metadata{}, err
	}
	defer zero(sealed)
	mf, err := manifest.Open(sealed, key)
	if err != nil {
		return Metadata{}, fmt.Errorf("authenticate manifest before registration: %w", err)
	}
	return m.registerAuthenticatedManifest(ctx, sealed, key, mf, true)
}

// ImportRecoveredManifestBytesContext rebuilds the private local catalog from
// an already authenticated remote manifest after reinstall/recovery. Unlike a
// normal registration it does not require a fresh write of the recovery record:
// the matching FileDataKey must already have been recovered and authenticated
// through M0.14. Temporary provider outages must not prevent reconstructing the
// local catalog from the surviving replicas.
func (m *Manager) ImportRecoveredManifestBytesContext(ctx context.Context, sealed, key []byte) (Metadata, error) {
	if len(key) != cryptokit.KeySize {
		return Metadata{}, errors.New("invalid file data key length")
	}
	configured, _ := m.vault.RecoveryConfigured()
	if !configured {
		return Metadata{}, secretvault.ErrPortableRecoveryRequired
	}
	mf, err := manifest.Open(sealed, key)
	if err != nil {
		return Metadata{}, fmt.Errorf("authenticate recovered manifest: %w", err)
	}
	storedKey, ok, err := m.vault.Get(mf.FileID, secretvault.FileDataKey)
	if err != nil {
		return Metadata{}, err
	}
	if !ok {
		return Metadata{}, errors.New("recovered manifest has no authenticated file key in the secure vault")
	}
	same := bytes.Equal(storedKey, key)
	zero(storedKey)
	if !same {
		return Metadata{}, errors.New("recovered manifest key does not match the authenticated vault key")
	}
	return m.registerAuthenticatedManifest(ctx, sealed, key, mf, false)
}

func (m *Manager) registerAuthenticatedManifest(ctx context.Context, sealed, key []byte, mf *manifest.Manifest, establishRecoveryReplicas bool) (Metadata, error) {
	meta := metadataFromManifest(mf)
	if err := meta.Validate(); err != nil {
		return Metadata{}, err
	}
	if existing, ok, err := m.Get(meta.FileID); err != nil {
		return Metadata{}, err
	} else if ok {
		if existing.OriginalSHA256 != meta.OriginalSHA256 || existing.FileName != meta.FileName || existing.OriginalSize != meta.OriginalSize {
			return Metadata{}, errors.New("refusing to replace an existing FileID with different file metadata")
		}
		if existing.Generation > meta.Generation {
			return Metadata{}, fmt.Errorf("refusing stale manifest generation %d; catalog already knows generation %d", meta.Generation, existing.Generation)
		}
		storedKey, present, err := m.vault.Get(meta.FileID, secretvault.FileDataKey)
		if err != nil {
			return Metadata{}, err
		}
		if present {
			same := bytes.Equal(storedKey, key)
			zero(storedKey)
			if !same {
				return Metadata{}, errors.New("refusing to replace an existing FileID with a different encryption key")
			}
		}
		meta.RegisteredAt = existing.RegisteredAt
	}

	if establishRecoveryReplicas {
		// A normal local registration is never committed until its data key has
		// at least two independently verified provider-domain recovery replicas.
		targets, err := m.targets(ctx)
		if err != nil {
			return Metadata{}, fmt.Errorf("resolve targets for durable key recovery: %w", err)
		}
		if _, err := m.recoveryKeys.ReplicateFileKey(ctx, meta.FileID, key, targets); err != nil {
			return Metadata{}, fmt.Errorf("durable file-key recovery not established: %w", err)
		}
	}

	metadataBytes, err := json.Marshal(meta)
	if err != nil {
		return Metadata{}, err
	}
	defer zero(metadataBytes)

	// Snapshot both recovery-critical values before touching either. Registering
	// a newer manifest is a logical transaction: a failure must not destroy the
	// previous key/catalog entry.
	oldKey, hadOldKey, err := m.vault.Get(meta.FileID, secretvault.FileDataKey)
	if err != nil {
		return Metadata{}, err
	}
	defer zero(oldKey)
	oldMeta, hadOldMeta, err := m.vault.Get(meta.FileID, secretvault.FileMetadata)
	if err != nil {
		return Metadata{}, err
	}
	defer zero(oldMeta)

	restore := func() error {
		var errs []error
		if hadOldKey {
			if err := m.vault.Put(meta.FileID, secretvault.FileDataKey, oldKey); err != nil {
				errs = append(errs, fmt.Errorf("restore previous file key: %w", err))
			}
		} else if err := m.vault.Delete(meta.FileID, secretvault.FileDataKey); err != nil {
			errs = append(errs, fmt.Errorf("remove uncommitted file key: %w", err))
		}
		if hadOldMeta {
			if err := m.vault.Put(meta.FileID, secretvault.FileMetadata, oldMeta); err != nil {
				errs = append(errs, fmt.Errorf("restore previous file metadata: %w", err))
			}
		} else if err := m.vault.Delete(meta.FileID, secretvault.FileMetadata); err != nil {
			errs = append(errs, fmt.Errorf("remove uncommitted file metadata: %w", err))
		}
		return errors.Join(errs...)
	}
	rollbackErr := func(cause error) error {
		if rb := restore(); rb != nil {
			return errors.Join(cause, fmt.Errorf("registration rollback incomplete: %w", rb))
		}
		return cause
	}

	if err := m.vault.Put(meta.FileID, secretvault.FileDataKey, key); err != nil {
		return Metadata{}, fmt.Errorf("store recovery-critical file key: %w", err)
	}
	if err := m.vault.Put(meta.FileID, secretvault.FileMetadata, metadataBytes); err != nil {
		return Metadata{}, rollbackErr(fmt.Errorf("store encrypted file metadata: %w", err))
	}

	dst, err := m.manifestPath(meta.FileID)
	if err != nil {
		return Metadata{}, rollbackErr(err)
	}
	if err := writeAtomic(dst, sealed); err != nil {
		return Metadata{}, rollbackErr(fmt.Errorf("store local encrypted manifest: %w", err))
	}
	return meta, nil
}

func (m *Manager) key(fileID string) ([]byte, error) {
	key, ok, err := m.vault.Get(fileID, secretvault.FileDataKey)
	if err != nil {
		return nil, err
	}
	if !ok {
		return nil, errors.New("file data key missing from secure vault")
	}
	if len(key) != cryptokit.KeySize {
		for i := range key {
			key[i] = 0
		}
		return nil, errors.New("invalid file data key in secure vault")
	}
	return key, nil
}

func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func (m *Manager) Get(fileID string) (Metadata, bool, error) {
	if !validFileID(fileID) {
		return Metadata{}, false, errors.New("invalid file id")
	}
	b, ok, err := m.vault.Get(fileID, secretvault.FileMetadata)
	if err != nil || !ok {
		return Metadata{}, ok, err
	}
	defer zero(b)
	var meta Metadata
	if err := json.Unmarshal(b, &meta); err != nil {
		return Metadata{}, false, errors.New("encrypted file metadata is invalid")
	}
	if err := meta.Validate(); err != nil {
		return Metadata{}, false, err
	}
	if meta.FileID != fileID {
		return Metadata{}, false, errors.New("file metadata id mismatch")
	}
	return meta, true, nil
}

func (m *Manager) RecoveryConfigured() (bool, string) {
	return m.vault.RecoveryConfigured()
}

func (m *Manager) List() ([]Metadata, error) {
	items, err := m.vault.ListMetadata()
	if err != nil {
		return nil, err
	}
	ids := map[string]bool{}
	for _, item := range items {
		if item.Kind == secretvault.FileMetadata && validFileID(item.AccountID) {
			ids[item.AccountID] = true
		}
	}
	out := make([]Metadata, 0, len(ids))
	for id := range ids {
		meta, ok, err := m.Get(id)
		if err != nil {
			return nil, err
		}
		if ok {
			out = append(out, meta)
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].RegisteredAt.Equal(out[j].RegisteredAt) {
			return out[i].FileID < out[j].FileID
		}
		return out[i].RegisteredAt.After(out[j].RegisteredAt)
	})
	return out, nil
}

// Distribution reads the authenticated local manifest and groups its shard
// placement by provider. The manifest itself remains encrypted at rest.
func (m *Manager) Distribution(fileID string) (Distribution, error) {
	if _, ok, err := m.Get(fileID); err != nil {
		return Distribution{}, err
	} else if !ok {
		return Distribution{}, errors.New("managed file not found")
	}
	key, err := m.key(fileID)
	if err != nil {
		return Distribution{}, err
	}
	defer zero(key)
	path, err := m.manifestPath(fileID)
	if err != nil {
		return Distribution{}, err
	}
	sealed, err := os.ReadFile(path)
	if err != nil {
		return Distribution{}, err
	}
	defer zero(sealed)
	mf, err := manifest.Open(sealed, key)
	if err != nil {
		return Distribution{}, fmt.Errorf("authenticate local manifest: %w", err)
	}
	report := Distribution{FileID: mf.FileID, DataShards: mf.DataShards, ParityShards: mf.ParityShards, Blocks: len(mf.Blocks)}
	byTarget := map[string]*ProviderDistribution{}
	for _, block := range mf.Blocks {
		seenInBlock := map[string]bool{}
		for _, shard := range block.Shards {
			entry := byTarget[shard.Provider]
			if entry == nil {
				providerID := shard.Provider
				if before, _, ok := strings.Cut(shard.Provider, ":"); ok && before != "" {
					providerID = before
				}
				entry = &ProviderDistribution{TargetID: shard.Provider, ProviderID: providerID}
				byTarget[shard.Provider] = entry
			}
			entry.Fragments++
			entry.Bytes += int64(block.ShardSize)
			report.Fragments++
			report.Bytes += int64(block.ShardSize)
			if !seenInBlock[shard.Provider] {
				entry.Blocks++
				seenInBlock[shard.Provider] = true
			}
		}
	}
	for _, entry := range byTarget {
		report.Providers = append(report.Providers, *entry)
	}
	sort.Slice(report.Providers, func(i, j int) bool {
		if report.Providers[i].ProviderID == report.Providers[j].ProviderID {
			return report.Providers[i].TargetID < report.Providers[j].TargetID
		}
		return report.Providers[i].ProviderID < report.Providers[j].ProviderID
	})
	return report, nil
}

type Health struct {
	FileID                  string            `json:"file_id"`
	FileName                string            `json:"file_name"`
	Level                   health.Level      `json:"level"`
	Summary                 string            `json:"summary"`
	RecommendedAction       string            `json:"recommended_action"`
	TotalShards             int               `json:"total_shards"`
	ValidShards             int               `json:"valid_shards"`
	MissingShards           int               `json:"missing_shards"`
	CorruptShards           int               `json:"corrupt_shards"`
	UnavailableShards       int               `json:"unavailable_shards"`
	RecoveryMargin          int               `json:"recovery_margin"`
	ProviderFailureMargin   int               `json:"provider_failure_margin"`
	ProviderSafetySatisfied bool              `json:"provider_safety_satisfied"`
	RepairAllowed           bool              `json:"repair_allowed"`
	RepairReason            string            `json:"repair_reason"`
	AuditedAt               time.Time         `json:"audited_at"`
	Blocks                  []core.AuditBlock `json:"blocks,omitempty"`
}

func healthView(meta Metadata, r core.AuditReport) Health {
	worst := core.AuditBlock{Total: meta.DataShards + meta.ParityShards, Valid: meta.DataShards + meta.ParityShards, Margin: meta.ParityShards, ProviderFailureMargin: meta.ParityShards}
	if len(r.Blocks) > 0 {
		worst = r.Blocks[0]
		for _, b := range r.Blocks[1:] {
			if b.Margin < worst.Margin || (b.Margin == worst.Margin && b.Missing+b.Corrupt+b.Unavailable > worst.Missing+worst.Corrupt+worst.Unavailable) {
				worst = b
			}
		}
	}
	h := Health{
		FileID: meta.FileID, FileName: meta.FileName, Level: r.Risk.Level,
		Summary: r.Risk.Summary, RecommendedAction: r.Risk.RecommendedAction,
		TotalShards: worst.Total, ValidShards: worst.Valid, MissingShards: worst.Missing,
		CorruptShards: worst.Corrupt, UnavailableShards: worst.Unavailable,
		RecoveryMargin: r.WorstMargin, ProviderFailureMargin: r.WorstProviderFailureMargin,
		ProviderSafetySatisfied: r.MeetsProviderSafety, AuditedAt: time.Now().UTC(), Blocks: r.Blocks,
	}
	confirmed := worst.Missing + worst.Corrupt
	switch {
	case r.Risk.Level == health.Unrecoverable:
		h.RepairReason = "No hay suficientes fragmentos verificados para reconstruir con seguridad."
	case confirmed == 0 && worst.Unavailable > 0:
		h.RepairReason = "Hay fragmentos temporalmente inaccesibles, pero no pérdida/corrupción confirmada. VaultPool no los moverá."
	case confirmed == 0:
		h.RepairReason = "La protección está completa; no hay fragmentos confirmados que reparar."
	case confirmed+worst.Unavailable > meta.ParityShards:
		h.RepairReason = "No hay suficientes fragmentos accesibles ahora para una reparación segura. Reconecta primero las cuentas inaccesibles."
	default:
		h.RepairAllowed = true
		h.RepairReason = "VaultPool puede reconstruir únicamente los fragmentos confirmados como perdidos o corruptos."
	}
	return h
}

func (m *Manager) Audit(ctx context.Context, fileID string) (Health, error) {
	meta, ok, err := m.Get(fileID)
	if err != nil {
		return Health{}, err
	}
	if !ok {
		return Health{}, errors.New("managed file not found")
	}
	key, err := m.key(fileID)
	if err != nil {
		return Health{}, err
	}
	defer zero(key)
	path, _ := m.manifestPath(fileID)
	targets, err := m.targets(ctx)
	if err != nil {
		return Health{}, fmt.Errorf("resolve storage targets: %w", err)
	}
	r, err := m.engine.AuditTargets(ctx, path, key, targets)
	if err != nil {
		return Health{}, err
	}
	return healthView(meta, r), nil
}

type RepairResult struct {
	Report   core.RepairReport `json:"report"`
	Health   Health            `json:"health"`
	Warnings []string          `json:"warnings,omitempty"`
}

func (m *Manager) Repair(ctx context.Context, fileID string) (RepairResult, error) {
	before, err := m.Audit(ctx, fileID)
	if err != nil {
		return RepairResult{}, err
	}
	if !before.RepairAllowed {
		return RepairResult{}, fmt.Errorf("repair blocked: %s", before.RepairReason)
	}
	key, err := m.key(fileID)
	if err != nil {
		return RepairResult{}, err
	}
	defer zero(key)
	path, _ := m.manifestPath(fileID)
	targets, err := m.targets(ctx)
	if err != nil {
		return RepairResult{}, err
	}
	r, err := m.engine.RepairTargets(ctx, path, key, targets)
	if err != nil {
		return RepairResult{}, err
	}
	// Refresh encrypted metadata only after the new authenticated manifest is
	// committed. This keeps generation display aligned with authoritative state.
	mf, err := manifest.Load(path, key)
	if err != nil {
		return RepairResult{}, err
	}
	meta := metadataFromManifest(mf)
	old, ok, err := m.Get(fileID)
	if err != nil {
		return RepairResult{}, err
	}
	if ok {
		meta.RegisteredAt = old.RegisteredAt
	}
	mb, _ := json.Marshal(meta)
	defer zero(mb)
	var warnings []string
	if err := m.vault.Put(fileID, secretvault.FileMetadata, mb); err != nil {
		warnings = append(warnings, "La reparación quedó confirmada, pero no se pudo actualizar el catálogo cifrado: "+err.Error())
	}
	after, err := m.Audit(ctx, fileID)
	if err != nil {
		warnings = append(warnings, "La reparación quedó confirmada, pero la auditoría posterior no pudo completarse: "+err.Error())
		return RepairResult{Report: r, Warnings: warnings}, nil
	}
	return RepairResult{Report: r, Health: after, Warnings: warnings}, nil
}

// ReadRange reconstructs and authenticates only the plaintext range requested
// by a virtual-filesystem reader. It never writes a plaintext cache file.
func (m *Manager) ReadRange(ctx context.Context, fileID string, offset int64, length int) ([]byte, error) {
	meta, ok, err := m.Get(fileID)
	if err != nil {
		return nil, err
	}
	if !ok {
		return nil, errors.New("managed file not found")
	}
	if offset < 0 || length < 0 {
		return nil, errors.New("invalid read range")
	}
	key, err := m.key(fileID)
	if err != nil {
		return nil, err
	}
	defer zero(key)
	manifestPath, err := m.manifestPath(meta.FileID)
	if err != nil {
		return nil, err
	}
	targets, err := m.targets(ctx)
	if err != nil {
		return nil, fmt.Errorf("resolve storage targets: %w", err)
	}
	return m.engine.ReadTargetsRange(ctx, manifestPath, key, targets, offset, length)
}

// DeleteResult is returned after an explicit user-confirmed deletion. It is
// intentionally limited to VaultPool-owned encrypted objects; arbitrary user
// files that predate VaultPool are outside this path.
type DeleteResult struct {
	FileID   string            `json:"file_id"`
	FileName string            `json:"file_name"`
	Report   core.DeleteReport `json:"report"`
}

// Delete removes one managed file from all connected cloud targets and then
// removes the local encrypted catalog/key/manifest. If remote deletion is only
// partially successful, local metadata is kept so the user can retry rather than
// leaving VaultPool blind to its own orphaned ciphertext.
func (m *Manager) Delete(ctx context.Context, fileID string) (DeleteResult, error) {
	meta, ok, err := m.Get(fileID)
	if err != nil {
		return DeleteResult{}, err
	}
	if !ok {
		return DeleteResult{}, errors.New("managed file not found")
	}
	key, err := m.key(fileID)
	if err != nil {
		return DeleteResult{}, err
	}
	defer zero(key)
	manifestPath, err := m.manifestPath(meta.FileID)
	if err != nil {
		return DeleteResult{}, err
	}
	targets, err := m.targets(ctx)
	if err != nil {
		return DeleteResult{}, fmt.Errorf("resolve storage targets: %w", err)
	}
	report, err := m.engine.DeleteTargets(ctx, manifestPath, key, targets)
	if err != nil {
		return DeleteResult{FileID: meta.FileID, FileName: meta.FileName, Report: report}, err
	}
	var localErrs []error
	if err := os.Remove(manifestPath); err != nil && !os.IsNotExist(err) {
		localErrs = append(localErrs, fmt.Errorf("remove local manifest: %w", err))
	}
	if err := m.vault.Delete(fileID, secretvault.FileDataKey); err != nil {
		localErrs = append(localErrs, fmt.Errorf("remove local file key: %w", err))
	}
	if err := m.vault.Delete(fileID, secretvault.FileMetadata); err != nil {
		localErrs = append(localErrs, fmt.Errorf("remove local file metadata: %w", err))
	}
	if len(localErrs) != 0 {
		return DeleteResult{FileID: meta.FileID, FileName: meta.FileName, Report: report}, errors.Join(localErrs...)
	}
	return DeleteResult{FileID: meta.FileID, FileName: meta.FileName, Report: report}, nil
}
