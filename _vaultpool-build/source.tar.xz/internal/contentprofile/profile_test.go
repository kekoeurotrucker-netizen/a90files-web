package contentprofile

import "testing"

func TestForPath(t *testing.T) {
	cases := []struct {
		name, class string
		skip, speed bool
	}{
		{"movie.MP4", "video", true, true}, {"song.flac", "audio", true, true},
		{"backup.7z", "archive", true, false}, {"scene.blend", "project", false, false},
		{"notes.txt", "general", false, false},
	}
	for _, tc := range cases {
		got := ForPath(tc.name)
		if got.Class != tc.class || got.SkipCompression != tc.skip || got.SpeedSensitive != tc.speed || got.BlockSize <= 0 {
			t.Fatalf("%s: %#v", tc.name, got)
		}
	}
}
