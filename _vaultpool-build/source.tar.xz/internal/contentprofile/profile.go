// Package contentprofile defines local, deterministic storage rules. It never
// inspects file contents remotely and does not weaken VaultPool redundancy.
package contentprofile

import (
	"path/filepath"
	"strings"
)

type Profile struct {
	Class           string
	BlockSize       int
	SkipCompression bool
	SpeedSensitive  bool
}

const (
	streamBlock  = 1 << 20
	compactBlock = 2 << 20
	archiveBlock = 4 << 20
)

// ForPath classifies by extension deliberately: it is predictable, local and
// does not expose filenames or contents to a provider.
func ForPath(name string) Profile {
	ext := strings.ToLower(filepath.Ext(strings.TrimSpace(name)))
	switch ext {
	case ".mp4", ".m4v", ".mov", ".webm", ".avi", ".mkv", ".mpeg", ".mpg", ".ts", ".m2ts":
		return Profile{Class: "video", BlockSize: streamBlock, SkipCompression: true, SpeedSensitive: true}
	case ".mp3", ".m4a", ".aac", ".ogg", ".opus", ".flac", ".wav", ".aiff":
		return Profile{Class: "audio", BlockSize: compactBlock, SkipCompression: true, SpeedSensitive: true}
	case ".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".avif", ".raw", ".cr2", ".nef":
		return Profile{Class: "image", BlockSize: compactBlock, SkipCompression: true}
	case ".zip", ".rar", ".7z", ".gz", ".bz2", ".xz", ".zst", ".iso", ".dmg", ".apk":
		return Profile{Class: "archive", BlockSize: archiveBlock, SkipCompression: true}
	case ".blend", ".prproj", ".aep", ".psd", ".ai", ".drp", ".kdenlive", ".fcpxml", ".aup3":
		return Profile{Class: "project", BlockSize: streamBlock}
	default:
		return Profile{Class: "general", BlockSize: compactBlock}
	}
}
