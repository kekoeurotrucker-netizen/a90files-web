package drivehost

import (
	"errors"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/virtualdrive"
)

type Status struct {
	Supported      bool   `json:"supported"`
	Installed      bool   `json:"installed"`
	Compatible     bool   `json:"compatible"`
	Running        bool   `json:"running"`
	ReadOnly       bool   `json:"read_only"`
	MountPoint     string `json:"mount_point,omitempty"`
	LibraryVersion uint32 `json:"library_version,omitempty"`
	DriverVersion  uint32 `json:"driver_version,omitempty"`
	Backend        string `json:"backend"`
	LastError      string `json:"last_error,omitempty"`
}

type Host interface {
	Status() Status
	Mount(string) error
	Unmount() error
}

func New(model *virtualdrive.Model) Host { return newPlatformHost(model) }

func NormalizeMountPoint(v string) (string, error) {
	v = strings.ToUpper(strings.TrimSpace(v))
	v = strings.TrimSuffix(v, `\`)
	if len(v) == 1 && v[0] >= 'A' && v[0] <= 'Z' {
		v += ":"
	}
	if len(v) != 2 || v[1] != ':' || v[0] < 'A' || v[0] > 'Z' {
		return "", errors.New("mount point must be a Windows drive letter such as P:")
	}
	return v + `\`, nil
}
