//go:build !windows

package drivehost

import (
	"errors"

	"github.com/vaultpool-project/vaultpool/internal/virtualdrive"
)

type unsupportedHost struct{}

func newPlatformHost(*virtualdrive.Model) Host { return &unsupportedHost{} }
func (h *unsupportedHost) Status() Status {
	return Status{Supported: false, Installed: false, Compatible: false, ReadOnly: true, Backend: "dokany2"}
}
func (h *unsupportedHost) Mount(string) error {
	return errors.New("VaultPool virtual drive is available only on Windows")
}
func (h *unsupportedHost) Unmount() error {
	return errors.New("VaultPool virtual drive is available only on Windows")
}
