package drivehost

import "testing"

func TestNormalizeMountPoint(t *testing.T) {
	for in, want := range map[string]string{"p": `P:\`, "P:": `P:\`, `p:\`: `P:\`} {
		got, err := NormalizeMountPoint(in)
		if err != nil || got != want {
			t.Fatalf("%q => %q,%v want %q", in, got, err, want)
		}
	}
	for _, bad := range []string{"", "PP:", "1:", `C:\folder`} {
		if _, err := NormalizeMountPoint(bad); err == nil {
			t.Fatalf("expected rejection for %q", bad)
		}
	}
}
