//go:build windows

package drivehost

import (
	"context"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"

	"github.com/vaultpool-project/vaultpool/internal/virtualdrive"
)

const (
	dokanVersion                    = 231
	volumeSecurityDescriptorMaxSize = 16 << 10

	dokanOptionWriteProtect   = 1 << 3
	dokanOptionCurrentSession = 1 << 7

	statusSuccess             = uint32(0x00000000)
	statusUnsuccessful        = uint32(0xC0000001)
	statusNotImplemented      = uint32(0xC0000002)
	statusInvalidParameter    = uint32(0xC000000D)
	statusAccessDenied        = uint32(0xC0000022)
	statusObjectNameNotFound  = uint32(0xC0000034)
	statusObjectPathNotFound  = uint32(0xC000003A)
	statusMediaWriteProtected = uint32(0xC00000A2)
	statusFileIsDirectory     = uint32(0xC00000BA)
	statusNotADirectory       = uint32(0xC0000103)

	fileAttributeReadOnly  = uint32(0x00000001)
	fileAttributeDirectory = uint32(0x00000010)
	fileAttributeArchive   = uint32(0x00000020)

	fileCasePreservedNames = uint32(0x00000002)
	fileUnicodeOnDisk      = uint32(0x00000004)
	fileReadOnlyVolume     = uint32(0x00080000)

	openExisting = uint32(3)
)

type dokanOptions struct {
	Version                        uint16
	SingleThread                   uint8
	_                              uint8
	Options                        uint32
	GlobalContext                  uint64
	MountPoint                     *uint16
	UNCName                        *uint16
	Timeout                        uint32
	AllocationUnitSize             uint32
	SectorSize                     uint32
	VolumeSecurityDescriptorLength uint32
	VolumeSecurityDescriptor       [volumeSecurityDescriptorMaxSize]byte
}

type dokanFileInfo struct {
	Context           uint64
	DokanContext      uint64
	DokanOptions      uintptr
	ProcessingContext uintptr
	ProcessID         uint32
	IsDirectory       uint8
	DeleteOnClose     uint8
	PagingIO          uint8
	SynchronousIO     uint8
	Nocache           uint8
	WriteToEndOfFile  uint8
	_                 [6]byte
}

type dokanOperations struct {
	ZwCreateFile         uintptr
	Cleanup              uintptr
	CloseFile            uintptr
	ReadFile             uintptr
	WriteFile            uintptr
	FlushFileBuffers     uintptr
	GetFileInformation   uintptr
	FindFiles            uintptr
	FindFilesWithPattern uintptr
	SetFileAttributes    uintptr
	SetFileTime          uintptr
	DeleteFile           uintptr
	DeleteDirectory      uintptr
	MoveFile             uintptr
	SetEndOfFile         uintptr
	SetAllocationSize    uintptr
	LockFile             uintptr
	UnlockFile           uintptr
	GetDiskFreeSpace     uintptr
	GetVolumeInformation uintptr
	Mounted              uintptr
	Unmounted            uintptr
	GetFileSecurity      uintptr
	SetFileSecurity      uintptr
	FindStreams          uintptr
}

type filetime struct{ LowDateTime, HighDateTime uint32 }
type byHandleFileInformation struct {
	FileAttributes     uint32
	CreationTime       filetime
	LastAccessTime     filetime
	LastWriteTime      filetime
	VolumeSerialNumber uint32
	FileSizeHigh       uint32
	FileSizeLow        uint32
	NumberOfLinks      uint32
	FileIndexHigh      uint32
	FileIndexLow       uint32
}
type win32FindDataW struct {
	FileAttributes    uint32
	CreationTime      filetime
	LastAccessTime    filetime
	LastWriteTime     filetime
	FileSizeHigh      uint32
	FileSizeLow       uint32
	Reserved0         uint32
	Reserved1         uint32
	FileName          [260]uint16
	AlternateFileName [14]uint16
}

// ABI guards. If Dokany changes these x64 layouts, the Windows build must
// fail instead of silently passing malformed callback structures to the driver.
var _ [16432 - int(unsafe.Sizeof(dokanOptions{}))]byte
var _ [int(unsafe.Sizeof(dokanOptions{})) - 16432]byte
var _ [48 - int(unsafe.Sizeof(dokanFileInfo{}))]byte
var _ [int(unsafe.Sizeof(dokanFileInfo{})) - 48]byte
var _ [200 - int(unsafe.Sizeof(dokanOperations{}))]byte
var _ [int(unsafe.Sizeof(dokanOperations{})) - 200]byte
var _ [52 - int(unsafe.Sizeof(byHandleFileInformation{}))]byte
var _ [int(unsafe.Sizeof(byHandleFileInformation{})) - 52]byte
var _ [592 - int(unsafe.Sizeof(win32FindDataW{}))]byte
var _ [int(unsafe.Sizeof(win32FindDataW{})) - 592]byte

type dokanAPI struct {
	dll         *syscall.DLL
	init        *syscall.Proc
	shutdown    *syscall.Proc
	main        *syscall.Proc
	removeMount *syscall.Proc
	version     *syscall.Proc
	driverVer   *syscall.Proc
}

func systemDirectory() (string, error) {
	kernel := syscall.NewLazyDLL("kernel32.dll")
	proc := kernel.NewProc("GetSystemDirectoryW")
	if err := proc.Find(); err != nil {
		return "", fmt.Errorf("GetSystemDirectoryW unavailable: %w", err)
	}
	buf := make([]uint16, 512)
	for attempts := 0; attempts < 2; attempts++ {
		r, _, callErr := proc.Call(uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		if r == 0 {
			if callErr != nil && callErr != syscall.Errno(0) {
				return "", fmt.Errorf("GetSystemDirectoryW: %w", callErr)
			}
			return "", errors.New("GetSystemDirectoryW returned an empty path")
		}
		if int(r) < len(buf) {
			return syscall.UTF16ToString(buf[:int(r)]), nil
		}
		buf = make([]uint16, int(r)+1)
	}
	return "", errors.New("system directory path changed while reading")
}

func findDokanProc(dll *syscall.DLL, name string) (*syscall.Proc, error) {
	p, err := dll.FindProc(name)
	if err != nil {
		return nil, fmt.Errorf("incompatible Dokany installation (%s): %w", name, err)
	}
	return p, nil
}

func loadDokan() (*dokanAPI, Status, error) {
	s := Status{Supported: true, ReadOnly: true, Backend: "dokany2"}
	systemDir, err := systemDirectory()
	if err != nil {
		return nil, s, err
	}
	dll, err := syscall.LoadDLL(filepath.Join(systemDir, "dokan2.dll"))
	if err != nil {
		return nil, s, fmt.Errorf("Dokany 2 is not installed: %w", err)
	}
	a := &dokanAPI{dll: dll}
	for name, dst := range map[string]**syscall.Proc{
		"DokanInit": &a.init, "DokanShutdown": &a.shutdown, "DokanMain": &a.main,
		"DokanRemoveMountPoint": &a.removeMount, "DokanVersion": &a.version, "DokanDriverVersion": &a.driverVer,
	} {
		p, findErr := findDokanProc(dll, name)
		if findErr != nil {
			_ = dll.Release()
			return nil, s, findErr
		}
		*dst = p
	}
	lib, _, _ := a.version.Call()
	drv, _, _ := a.driverVer.Call()
	s.LibraryVersion = uint32(lib)
	s.DriverVersion = uint32(drv)
	s.Installed = s.LibraryVersion != 0 && s.DriverVersion != 0
	s.Compatible = s.Installed && s.LibraryVersion == dokanVersion && s.DriverVersion == dokanVersion
	if !s.Installed {
		return a, s, errors.New("Dokany DLL is present but its signed driver is unavailable")
	}
	if !s.Compatible {
		return a, s, fmt.Errorf("unsupported Dokany version: library=%d driver=%d", s.LibraryVersion, s.DriverVersion)
	}
	return a, s, nil
}

func (a *dokanAPI) release() {
	if a != nil && a.dll != nil {
		_ = a.dll.Release()
	}
}

type windowsHost struct {
	model    *virtualdrive.Model
	mu       sync.Mutex
	state    Status
	starting bool
	api      *dokanAPI
	done     chan error
}

func newPlatformHost(model *virtualdrive.Model) Host {
	h := &windowsHost{model: model, state: Status{Supported: true, ReadOnly: true, Backend: "dokany2"}}
	a, s, err := loadDokan()
	if a != nil {
		a.release()
	}
	if err != nil {
		s.LastError = err.Error()
	}
	h.state = s
	return h
}

func (h *windowsHost) Status() Status {
	h.mu.Lock()
	defer h.mu.Unlock()
	if !h.state.Running && !h.starting {
		a, s, err := loadDokan()
		if a != nil {
			a.release()
		}
		if err != nil {
			s.LastError = err.Error()
		}
		if h.state.MountPoint != "" {
			s.MountPoint = h.state.MountPoint
		}
		h.state = s
	}
	return h.state
}

func (h *windowsHost) Mount(point string) error {
	if h.model == nil {
		return errors.New("virtual drive model unavailable")
	}
	mountPoint, err := NormalizeMountPoint(point)
	if err != nil {
		return err
	}
	api, s, err := loadDokan()
	if err != nil {
		return err
	}
	h.mu.Lock()
	if h.state.Running || h.starting {
		current := h.state.MountPoint
		h.mu.Unlock()
		return fmt.Errorf("VaultPool drive is already active at %s", current)
	}
	h.api = api
	h.state = s
	h.state.MountPoint = mountPoint
	h.starting = true
	mounted := make(chan struct{}, 1)
	done := make(chan error, 1)
	h.done = done
	h.mu.Unlock()
	go h.mountLoop(api, mountPoint, mounted, done)
	select {
	case <-mounted:
		return nil
	case err := <-done:
		if err == nil {
			err = errors.New("Dokany mount ended before becoming ready")
		}
		return err
	case <-time.After(20 * time.Second):
		_ = h.removeMount(api, mountPoint)
		return errors.New("timed out waiting for Dokany to mount VaultPool")
	}
}

func (h *windowsHost) Unmount() error {
	h.mu.Lock()
	point := h.state.MountPoint
	api := h.api
	running := h.state.Running || h.starting
	done := h.done
	h.mu.Unlock()
	if !running || point == "" {
		return errors.New("VaultPool drive is not mounted")
	}
	temporaryAPI := false
	if api == nil {
		var err error
		api, _, err = loadDokan()
		if err != nil {
			return err
		}
		temporaryAPI = true
	}
	if temporaryAPI {
		defer api.release()
	}
	if err := h.removeMount(api, point); err != nil {
		return err
	}
	if done != nil {
		select {
		case <-done:
			return nil
		case <-time.After(10 * time.Second):
			return errors.New("Dokany accepted unmount request but VaultPool is still mounted")
		}
	}
	return nil
}

func (h *windowsHost) removeMount(api *dokanAPI, point string) error {
	u, err := syscall.UTF16PtrFromString(strings.TrimSuffix(point, `\`))
	if err != nil {
		return err
	}
	r, _, callErr := api.removeMount.Call(uintptr(unsafe.Pointer(u)))
	if r == 0 {
		if callErr != nil && callErr != syscall.Errno(0) {
			return fmt.Errorf("DokanRemoveMountPoint: %w", callErr)
		}
		return errors.New("Dokany could not remove the VaultPool mount point")
	}
	return nil
}

func nt(v uint32) uintptr { return uintptr(v) }

func utf16String(p *uint16) string {
	if p == nil {
		return ""
	}
	const maxUTF16Chars = 32768
	return syscall.UTF16ToString(unsafe.Slice(p, maxUTF16Chars))
}
func fileTime(t time.Time) filetime {
	if t.IsZero() {
		t = time.Unix(0, 0).UTC()
	}
	ticks := (t.UTC().Unix()+11644473600)*10000000 + int64(t.Nanosecond()/100)
	if ticks < 0 {
		ticks = 0
	}
	return filetime{LowDateTime: uint32(ticks), HighDateTime: uint32(uint64(ticks) >> 32)}
}
func fileIndex(id string) uint64 {
	b, err := hex.DecodeString(id)
	if err != nil || len(b) < 8 {
		return 0
	}
	return binary.LittleEndian.Uint64(b[:8])
}
func splitSize(n int64) (uint32, uint32) {
	if n < 0 {
		n = 0
	}
	u := uint64(n)
	return uint32(u >> 32), uint32(u)
}
func putUTF16(dst []uint16, s string) {
	u, _ := syscall.UTF16FromString(s)
	if len(u) > len(dst) {
		u = u[:len(dst)]
		u[len(dst)-1] = 0
	}
	copy(dst[:], u)
}
func writeUTF16Buffer(ptr *uint16, chars uint32, s string) bool {
	if ptr == nil || chars == 0 {
		return false
	}
	u, err := syscall.UTF16FromString(s)
	if err != nil || len(u) > int(chars) {
		return false
	}
	dst := unsafe.Slice(ptr, int(chars))
	copy(dst, u)
	return true
}

func (h *windowsHost) operations(mountPoint string, mounted chan<- struct{}) dokanOperations {
	create := syscall.NewCallback(func(fileName *uint16, security unsafe.Pointer, desiredAccess, fileAttrs, shareAccess, disposition, createOptions uint32, info *dokanFileInfo) uintptr {
		_ = security
		_ = desiredAccess
		_ = fileAttrs
		_ = shareAccess
		path := utf16String(fileName)
		if disposition != openExisting {
			return nt(statusMediaWriteProtected)
		}
		if strings.Trim(path, `\`) == "" {
			if info != nil {
				info.IsDirectory = 1
			}
			return nt(statusSuccess)
		}
		e, ok, err := h.model.Lookup(path)
		_ = e
		if err != nil {
			return nt(statusUnsuccessful)
		}
		if !ok {
			return nt(statusObjectNameNotFound)
		}
		// FILE_DIRECTORY_FILE
		if createOptions&0x1 != 0 {
			return nt(statusNotADirectory)
		}
		return nt(statusSuccess)
	})
	cleanup := syscall.NewCallback(func(fileName, info uintptr) uintptr { _ = fileName; _ = info; return 0 })
	closeFile := syscall.NewCallback(func(fileName, info uintptr) uintptr { _ = fileName; _ = info; return 0 })
	read := syscall.NewCallback(func(fileName *uint16, buffer *byte, bufferLength uint32, readLength *uint32, offset int64, info *dokanFileInfo) uintptr {
		_ = info
		if readLength == nil || buffer == nil {
			return nt(statusInvalidParameter)
		}
		*readLength = 0
		path := utf16String(fileName)
		if strings.Trim(path, `\`) == "" {
			return nt(statusFileIsDirectory)
		}
		data, err := h.model.Read(context.Background(), path, offset, int(bufferLength))
		if err != nil {
			return nt(statusUnsuccessful)
		}
		if len(data) > int(bufferLength) {
			return nt(statusUnsuccessful)
		}
		dst := unsafe.Slice(buffer, int(bufferLength))
		copy(dst, data)
		*readLength = uint32(len(data))
		for i := range data {
			data[i] = 0
		}
		return nt(statusSuccess)
	})
	writeProtected := syscall.NewCallback(func(a, b, c, d, e, f uintptr) uintptr {
		_ = a
		_ = b
		_ = c
		_ = d
		_ = e
		_ = f
		return nt(statusMediaWriteProtected)
	})
	writeProtected2 := syscall.NewCallback(func(a, b uintptr) uintptr { _ = a; _ = b; return nt(statusMediaWriteProtected) })
	writeProtected3 := syscall.NewCallback(func(a, b, c uintptr) uintptr { _ = a; _ = b; _ = c; return nt(statusMediaWriteProtected) })
	writeProtected4 := syscall.NewCallback(func(a, b, c, d uintptr) uintptr { _ = a; _ = b; _ = c; _ = d; return nt(statusMediaWriteProtected) })
	writeProtected5 := syscall.NewCallback(func(a, b, c, d, e uintptr) uintptr {
		_ = a
		_ = b
		_ = c
		_ = d
		_ = e
		return nt(statusMediaWriteProtected)
	})
	flush := syscall.NewCallback(func(fileName, info uintptr) uintptr { _ = fileName; _ = info; return nt(statusSuccess) })
	getInfo := syscall.NewCallback(func(fileName *uint16, buffer *byHandleFileInformation, info *dokanFileInfo) uintptr {
		_ = info
		if buffer == nil {
			return nt(statusInvalidParameter)
		}
		out := buffer
		*out = byHandleFileInformation{VolumeSerialNumber: 0x56504F4C, NumberOfLinks: 1}
		path := utf16String(fileName)
		if strings.Trim(path, `\`) == "" {
			out.FileAttributes = fileAttributeDirectory | fileAttributeReadOnly
			t := fileTime(time.Unix(0, 0))
			out.CreationTime = t
			out.LastAccessTime = t
			out.LastWriteTime = t
			return nt(statusSuccess)
		}
		e, ok, err := h.model.Lookup(path)
		if err != nil {
			return nt(statusUnsuccessful)
		}
		if !ok {
			return nt(statusObjectNameNotFound)
		}
		out.FileAttributes = fileAttributeReadOnly | fileAttributeArchive
		out.CreationTime = fileTime(e.CreatedAt)
		out.LastAccessTime = out.CreationTime
		out.LastWriteTime = fileTime(e.Registered)
		out.FileSizeHigh, out.FileSizeLow = splitSize(e.Size)
		idx := fileIndex(e.FileID)
		out.FileIndexHigh = uint32(idx >> 32)
		out.FileIndexLow = uint32(idx)
		return nt(statusSuccess)
	})
	findFiles := syscall.NewCallback(func(fileName *uint16, fill uintptr, info *dokanFileInfo) uintptr {
		path := utf16String(fileName)
		if strings.Trim(path, `\`) != "" {
			return nt(statusObjectPathNotFound)
		}
		if fill == 0 {
			return nt(statusInvalidParameter)
		}
		add := func(d *win32FindDataW) bool {
			r, _, _ := syscall.SyscallN(fill, uintptr(unsafe.Pointer(d)), uintptr(unsafe.Pointer(info)))
			return int32(r) == 0
		}
		for _, name := range []string{".", ".."} {
			d := win32FindDataW{FileAttributes: fileAttributeDirectory | fileAttributeReadOnly}
			putUTF16(d.FileName[:], name)
			if !add(&d) {
				return nt(statusSuccess)
			}
		}
		entries, err := h.model.ListRoot()
		if err != nil {
			return nt(statusUnsuccessful)
		}
		for _, e := range entries {
			d := win32FindDataW{FileAttributes: fileAttributeReadOnly | fileAttributeArchive, CreationTime: fileTime(e.CreatedAt), LastWriteTime: fileTime(e.Registered)}
			d.LastAccessTime = d.CreationTime
			d.FileSizeHigh, d.FileSizeLow = splitSize(e.Size)
			putUTF16(d.FileName[:], e.Name)
			if !add(&d) {
				break
			}
		}
		return nt(statusSuccess)
	})
	getDisk := syscall.NewCallback(func(freeAvail, totalBytes, totalFree *uint64, info *dokanFileInfo) uintptr {
		_ = info
		total, free := h.model.Capacity()
		if total == 0 {
			total = free
		}
		if total < free {
			total = free
		}
		if freeAvail != nil {
			*freeAvail = free
		}
		if totalBytes != nil {
			*totalBytes = total
		}
		if totalFree != nil {
			*totalFree = free
		}
		return nt(statusSuccess)
	})
	getVolume := syscall.NewCallback(func(volBuf *uint16, volChars uint32, serial, maxComponent, flags *uint32, fsBuf *uint16, fsChars uint32, info *dokanFileInfo) uintptr {
		_ = info
		if !writeUTF16Buffer(volBuf, volChars, "VaultPool") || !writeUTF16Buffer(fsBuf, fsChars, "NTFS") {
			return nt(statusInvalidParameter)
		}
		if serial != nil {
			*serial = 0x56504F4C
		}
		if maxComponent != nil {
			*maxComponent = 255
		}
		if flags != nil {
			*flags = fileCasePreservedNames | fileUnicodeOnDisk | fileReadOnlyVolume
		}
		return nt(statusSuccess)
	})
	mountedCB := syscall.NewCallback(func(point *uint16, info *dokanFileInfo) uintptr {
		_ = info
		actual := utf16String(point)
		if actual == "" {
			actual = mountPoint
		}
		h.mu.Lock()
		h.starting = false
		h.state.Running = true
		h.state.MountPoint = actual
		h.state.LastError = ""
		h.mu.Unlock()
		select {
		case mounted <- struct{}{}:
		default:
		}
		return nt(statusSuccess)
	})
	unmountedCB := syscall.NewCallback(func(info *dokanFileInfo) uintptr {
		_ = info
		h.mu.Lock()
		h.starting = false
		h.state.Running = false
		h.mu.Unlock()
		return nt(statusSuccess)
	})
	getSecurity := syscall.NewCallback(func(a, b, c, d, e, f uintptr) uintptr {
		_ = a
		_ = b
		_ = c
		_ = d
		_ = e
		_ = f
		return nt(statusNotImplemented)
	})

	return dokanOperations{
		ZwCreateFile: create, Cleanup: cleanup, CloseFile: closeFile, ReadFile: read,
		WriteFile: writeProtected, FlushFileBuffers: flush, GetFileInformation: getInfo, FindFiles: findFiles,
		SetFileAttributes: writeProtected3, SetFileTime: writeProtected5, DeleteFile: writeProtected2, DeleteDirectory: writeProtected2,
		MoveFile: writeProtected4, SetEndOfFile: writeProtected3, SetAllocationSize: writeProtected3,
		GetDiskFreeSpace: getDisk, GetVolumeInformation: getVolume, Mounted: mountedCB, Unmounted: unmountedCB, GetFileSecurity: getSecurity,
	}
}

func (h *windowsHost) mountLoop(api *dokanAPI, mountPoint string, mounted chan<- struct{}, done chan<- error) {
	mountUTF16, err := syscall.UTF16PtrFromString(mountPoint)
	if err != nil {
		done <- err
		return
	}
	ops := h.operations(mountPoint, mounted)
	opts := dokanOptions{Version: dokanVersion, Options: dokanOptionWriteProtect | dokanOptionCurrentSession, MountPoint: mountUTF16, Timeout: 300000, AllocationUnitSize: 4096, SectorSize: 4096}
	api.init.Call()
	r, _, callErr := api.main.Call(uintptr(unsafe.Pointer(&opts)), uintptr(unsafe.Pointer(&ops)))
	api.shutdown.Call()
	api.release()
	code := int32(uint32(r))
	var final error
	if code != 0 {
		if callErr != nil && callErr != syscall.Errno(0) {
			final = fmt.Errorf("DokanMain failed (%d): %w", code, callErr)
		} else {
			final = fmt.Errorf("DokanMain failed with code %d", code)
		}
	}
	h.mu.Lock()
	h.starting = false
	h.state.Running = false
	if final != nil {
		h.state.LastError = final.Error()
	}
	h.mu.Unlock()
	done <- final
}
