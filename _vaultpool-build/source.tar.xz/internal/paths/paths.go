package paths

import (
	"errors"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

type Layout struct {
	Root            string
	State           string
	Secrets         string
	RecoveryPackage string
	ManagedFiles    string
	Staging         string
	Logs            string
}

func Default() (Layout, error) {
	if home := strings.TrimSpace(os.Getenv("VAULTPOOL_HOME")); home != "" {
		if !filepath.IsAbs(home) {
			return Layout{}, errors.New("VAULTPOOL_HOME must be an absolute path")
		}
		return FromRoot(home), nil
	}
	var root string
	if runtime.GOOS == "windows" {
		root = strings.TrimSpace(os.Getenv("LOCALAPPDATA"))
		if root == "" {
			if p, err := os.UserConfigDir(); err == nil {
				root = p
			}
		}
	} else {
		var err error
		root, err = os.UserConfigDir()
		if err != nil {
			return Layout{}, err
		}
	}
	if strings.TrimSpace(root) == "" {
		return Layout{}, errors.New("could not determine user application data directory")
	}
	return FromRoot(filepath.Join(root, "VaultPool")), nil
}

func FromRoot(root string) Layout {
	root = filepath.Clean(root)
	return Layout{
		Root:            root,
		State:           filepath.Join(root, "ui-state.json"),
		Secrets:         filepath.Join(root, "secrets.vpv"),
		RecoveryPackage: filepath.Join(root, "VaultPool-Recovery.vpr"),
		ManagedFiles:    filepath.Join(root, "files"),
		Staging:         filepath.Join(root, "staging"),
		Logs:            filepath.Join(root, "logs"),
	}
}

func (l Layout) Ensure() error {
	for _, p := range []string{l.Root, l.ManagedFiles, l.Staging, l.Logs} {
		if err := os.MkdirAll(p, 0o700); err != nil {
			return err
		}
	}
	return nil
}
