package paths

import (
	"path/filepath"
	"testing"
)

func TestFromRoot(t *testing.T) {
	root := filepath.Join(t.TempDir(), "vp")
	l := FromRoot(root)
	if l.State != filepath.Join(root, "ui-state.json") {
		t.Fatalf("bad state path: %s", l.State)
	}
	if err := l.Ensure(); err != nil {
		t.Fatal(err)
	}
}
