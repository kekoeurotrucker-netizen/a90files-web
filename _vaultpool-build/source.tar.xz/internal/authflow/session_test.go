package authflow

import "testing"

func TestSessionStateOneTimeAndPKCE(t *testing.T) {
	m := NewSessionManager()
	s, state, err := m.Start("a", "google-drive", Plan{Mode: SystemBrowserOAuth, OAuthPKCE: true})
	if err != nil {
		t.Fatal(err)
	}
	if s.PKCEChallenge == "" || s.PKCEMethod != "S256" {
		t.Fatalf("missing PKCE: %+v", s)
	}
	verifier, err := m.ValidateCallback(s.ID, state)
	if err != nil {
		t.Fatal(err)
	}
	if verifier == "" {
		t.Fatal("missing verifier")
	}
	if _, err := m.ValidateCallback(s.ID, state); err == nil {
		t.Fatal("session must be one-time")
	}
}
func TestSessionRejectsWrongState(t *testing.T) {
	m := NewSessionManager()
	s, _, err := m.Start("a", "x", Plan{Mode: SystemBrowserOAuth})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := m.ValidateCallback(s.ID, "wrong"); err == nil {
		t.Fatal("expected state rejection")
	}
}

func TestConsumeStateFindsSessionWithoutSeparateID(t *testing.T) {
	m := NewSessionManager()
	p := Plan{Mode: SystemBrowserOAuth, OAuthPKCE: true}
	_, state, err := m.StartOAuth("acct", "google-drive", p, "http://127.0.0.1:8742/oauth/callback")
	if err != nil {
		t.Fatal(err)
	}
	ctx, err := m.ConsumeState(state)
	if err != nil {
		t.Fatal(err)
	}
	if ctx.AccountID != "acct" || ctx.ProviderID != "google-drive" || ctx.Verifier == "" || ctx.RedirectURI == "" {
		t.Fatalf("got %+v", ctx)
	}
	if _, err := m.ConsumeState(state); err == nil {
		t.Fatal("state must be one-time")
	}
}
