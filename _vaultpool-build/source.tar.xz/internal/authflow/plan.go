package authflow

import (
	"fmt"

	"github.com/vaultpool-project/vaultpool/internal/catalog"
)

type Mode string

const (
	SystemBrowserOAuth Mode = "system_browser_oauth"
	EmbeddedWebView    Mode = "embedded_webview"
	DeviceCode         Mode = "device_code"
	DirectCredentials  Mode = "direct_credentials"
	ExternalSession    Mode = "external_session"
	Blocked            Mode = "blocked"
)

type ShellCapabilities struct {
	SystemBrowser   bool `json:"system_browser"`
	EmbeddedWebView bool `json:"embedded_webview"`
	DeviceCode      bool `json:"device_code"`
	CredentialVault bool `json:"credential_vault"`
	ExternalSession bool `json:"external_session"`
}

type Plan struct {
	Mode                 Mode   `json:"mode"`
	CaptchaManualOnly    bool   `json:"captcha_manual_only"`
	OAuthPKCE            bool   `json:"oauth_pkce"`
	RequiresDesktopShell bool   `json:"requires_desktop_shell"`
	RequiresVault        bool   `json:"requires_vault"`
	Reason               string `json:"reason"`
}

// Decide is the single machine-enforced mapping between reviewed provider
// policy and an authentication UX. It never upgrades a provider's strategy and
// never falls back to a weaker method merely because a shell lacks capability.
func Decide(p catalog.Provider, caps ShellCapabilities) Plan {
	if p.Status != catalog.Allowed {
		return Plan{Mode: Blocked, CaptchaManualOnly: true, Reason: "El proveedor no está aprobado para conexión."}
	}

	switch p.AuthStrategy {
	case catalog.AuthSystemBrowserOAuth:
		if !caps.SystemBrowser {
			return Plan{Mode: Blocked, CaptchaManualOnly: true, OAuthPKCE: p.OAuthPKCE, RequiresDesktopShell: true, Reason: "Este proveedor exige navegador del sistema y el contenedor actual no puede abrirlo de forma segura."}
		}
		return Plan{Mode: SystemBrowserOAuth, CaptchaManualOnly: true, OAuthPKCE: p.OAuthPKCE, Reason: "La cuenta se autoriza en el navegador del sistema y vuelve a VaultPool por un callback local validado."}

	case catalog.AuthEmbeddedWebView:
		if !caps.EmbeddedWebView {
			return Plan{Mode: Blocked, CaptchaManualOnly: true, RequiresDesktopShell: true, Reason: "La política aprobada requiere WebView interna, pero este contenedor no dispone de una WebView segura."}
		}
		return Plan{Mode: EmbeddedWebView, CaptchaManualOnly: true, Reason: "La página oficial puede abrirse dentro de la WebView aislada de VaultPool; cualquier CAPTCHA lo resuelve manualmente el usuario."}

	case catalog.AuthDeviceCode:
		if !caps.DeviceCode {
			return Plan{Mode: Blocked, CaptchaManualOnly: true, RequiresDesktopShell: true, Reason: "El flujo de código de dispositivo no está disponible en este contenedor."}
		}
		return Plan{Mode: DeviceCode, CaptchaManualOnly: true, Reason: "VaultPool mostrará un código de dispositivo y la URL oficial de verificación."}

	case catalog.AuthDirectCredentials:
		if !caps.CredentialVault {
			return Plan{Mode: Blocked, CaptchaManualOnly: true, RequiresVault: true, Reason: "El proveedor requiere credenciales directas y la bóveda segura todavía no está disponible."}
		}
		return Plan{Mode: DirectCredentials, CaptchaManualOnly: true, RequiresVault: true, Reason: "Las credenciales se introducirán únicamente en la bóveda local cifrada de VaultPool."}

	case catalog.AuthExternalSession:
		if !caps.ExternalSession {
			return Plan{Mode: Blocked, CaptchaManualOnly: true, RequiresDesktopShell: true, Reason: "Este proveedor requiere una sesión iniciada mediante su cliente oficial y el entorno actual no puede lanzarlo."}
		}
		return Plan{Mode: ExternalSession, CaptchaManualOnly: true, RequiresDesktopShell: true, Reason: "VaultPool abrirá el cliente oficial del proveedor; las credenciales se introducen allí y VaultPool reutiliza únicamente la sesión ya iniciada."}

	default:
		return Plan{Mode: Blocked, CaptchaManualOnly: true, Reason: fmt.Sprintf("No existe un flujo de autenticación aprobado para %s.", p.Name)}
	}
}
