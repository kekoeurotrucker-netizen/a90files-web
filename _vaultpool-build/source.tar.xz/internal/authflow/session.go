package authflow

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"
)

type Session struct {
	ID            string `json:"id"`
	AccountID     string `json:"account_id"`
	ProviderID    string `json:"provider_id"`
	Mode          Mode   `json:"mode"`
	PKCEChallenge string `json:"pkce_challenge,omitempty"`
	PKCEMethod    string `json:"pkce_method,omitempty"`
	ExpiresAt     string `json:"expires_at"`
}

type sessionSecret struct {
	Session
	state       []byte
	verifier    string
	redirectURI string
	expires     time.Time
	used        bool
}

type CallbackContext struct {
	AccountID   string
	ProviderID  string
	Verifier    string
	RedirectURI string
}

type SessionManager struct {
	mu       sync.Mutex
	now      func() time.Time
	sessions map[string]*sessionSecret
}

func NewSessionManager() *SessionManager {
	return &SessionManager{now: time.Now, sessions: map[string]*sessionSecret{}}
}

func randomURLSafe(n int) ([]byte, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	return b, nil
}

// Start creates short-lived, in-memory authorization state. State and PKCE
// verifier are never persisted to disk and are not exposed through JSON.
func (m *SessionManager) Start(accountID, providerID string, plan Plan) (Session, string, error) {
	return m.StartOAuth(accountID, providerID, plan, "")
}

func (m *SessionManager) StartOAuth(accountID, providerID string, plan Plan, redirectURI string) (Session, string, error) {
	if plan.Mode == Blocked {
		return Session{}, "", errors.New("blocked authentication plan")
	}
	rawID, err := randomURLSafe(18)
	if err != nil {
		return Session{}, "", err
	}
	rawState, err := randomURLSafe(32)
	if err != nil {
		return Session{}, "", err
	}
	id := "auth_" + base64.RawURLEncoding.EncodeToString(rawID)
	stateToken := id + "." + base64.RawURLEncoding.EncodeToString(rawState)
	exp := m.now().UTC().Add(10 * time.Minute)
	ss := &sessionSecret{Session: Session{ID: id, AccountID: accountID, ProviderID: providerID, Mode: plan.Mode, ExpiresAt: exp.Format(time.RFC3339)}, state: []byte(stateToken), redirectURI: redirectURI, expires: exp}
	if plan.OAuthPKCE {
		rawVerifier, err := randomURLSafe(48)
		if err != nil {
			return Session{}, "", err
		}
		ss.verifier = base64.RawURLEncoding.EncodeToString(rawVerifier)
		h := sha256.Sum256([]byte(ss.verifier))
		ss.PKCEChallenge = base64.RawURLEncoding.EncodeToString(h[:])
		ss.PKCEMethod = "S256"
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.cleanupLocked()
	m.sessions[id] = ss
	return ss.Session, stateToken, nil
}

// ConsumeState identifies and consumes a session using only the opaque state
// returned by the provider. This is what the loopback callback uses.
func (m *SessionManager) ConsumeState(stateToken string) (CallbackContext, error) {
	parts := strings.SplitN(stateToken, ".", 2)
	if len(parts) != 2 || !strings.HasPrefix(parts[0], "auth_") {
		return CallbackContext{}, errors.New("invalid oauth state")
	}
	id := parts[0]
	m.mu.Lock()
	defer m.mu.Unlock()
	m.cleanupLocked()
	s, ok := m.sessions[id]
	if !ok {
		return CallbackContext{}, errors.New("unknown or expired auth session")
	}
	if subtle.ConstantTimeCompare(s.state, []byte(stateToken)) != 1 {
		return CallbackContext{}, errors.New("invalid oauth state")
	}
	s.used = true
	delete(m.sessions, id)
	return CallbackContext{AccountID: s.AccountID, ProviderID: s.ProviderID, Verifier: s.verifier, RedirectURI: s.redirectURI}, nil
}

func (m *SessionManager) cleanupLocked() {
	now := m.now()
	for id, s := range m.sessions {
		if s.used || !now.Before(s.expires) {
			delete(m.sessions, id)
		}
	}
}

// ValidateCallback consumes a session exactly once and returns the PKCE
// verifier only to backend code that will exchange the authorization code.
func (m *SessionManager) ValidateCallback(id, state string) (string, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.cleanupLocked()
	s, ok := m.sessions[id]
	if !ok {
		return "", errors.New("unknown or expired auth session")
	}
	if subtle.ConstantTimeCompare(s.state, []byte(state)) != 1 {
		return "", errors.New("invalid oauth state")
	}
	s.used = true
	verifier := s.verifier
	delete(m.sessions, id)
	return verifier, nil
}

func (m *SessionManager) Cancel(id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.sessions[id]; !ok {
		return fmt.Errorf("auth session not found")
	}
	delete(m.sessions, id)
	return nil
}
