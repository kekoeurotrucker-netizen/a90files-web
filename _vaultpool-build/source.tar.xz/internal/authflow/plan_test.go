package authflow

import (
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"testing"
)

func caps() ShellCapabilities {
	return ShellCapabilities{SystemBrowser: true, EmbeddedWebView: true, DeviceCode: true, CredentialVault: true, ExternalSession: true}
}

func TestSystemBrowserOAuthNeverFallsBackToEmbedded(t *testing.T) {
	p := catalog.Provider{Name: "X", Status: catalog.Allowed, AuthStrategy: catalog.AuthSystemBrowserOAuth, OAuthPKCE: true}
	c := caps()
	c.SystemBrowser = false
	got := Decide(p, c)
	if got.Mode != Blocked {
		t.Fatalf("got %s", got.Mode)
	}
	c.SystemBrowser = true
	got = Decide(p, c)
	if got.Mode != SystemBrowserOAuth || !got.OAuthPKCE {
		t.Fatalf("got %+v", got)
	}
}

func TestEmbeddedRequiresExplicitStrategyAndCapability(t *testing.T) {
	p := catalog.Provider{Name: "X", Status: catalog.Allowed, AuthStrategy: catalog.AuthEmbeddedWebView}
	c := caps()
	c.EmbeddedWebView = false
	if got := Decide(p, c).Mode; got != Blocked {
		t.Fatalf("got %s", got)
	}
	c.EmbeddedWebView = true
	if got := Decide(p, c).Mode; got != EmbeddedWebView {
		t.Fatalf("got %s", got)
	}
}

func TestDirectCredentialsRequiresVault(t *testing.T) {
	p := catalog.Provider{Name: "X", Status: catalog.Allowed, AuthStrategy: catalog.AuthDirectCredentials}
	c := caps()
	c.CredentialVault = false
	if got := Decide(p, c); got.Mode != Blocked || !got.RequiresVault {
		t.Fatalf("got %+v", got)
	}
}

func TestReviewRequiredAlwaysBlocked(t *testing.T) {
	p := catalog.Provider{Name: "X", Status: catalog.ReviewRequired, AuthStrategy: catalog.AuthEmbeddedWebView}
	if got := Decide(p, caps()).Mode; got != Blocked {
		t.Fatalf("got %s", got)
	}
}

func TestExternalSessionRequiresOfficialClientCapability(t *testing.T) {
	p := catalog.Provider{Name: "MEGA", Status: catalog.Allowed, AuthStrategy: catalog.AuthExternalSession}
	c := caps()
	c.ExternalSession = false
	if got := Decide(p, c); got.Mode != Blocked || !got.RequiresDesktopShell {
		t.Fatalf("got %+v", got)
	}
	c.ExternalSession = true
	if got := Decide(p, c); got.Mode != ExternalSession || !got.RequiresDesktopShell {
		t.Fatalf("got %+v", got)
	}
}
