package controlclient

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type Client struct {
	Base string
	HTTP *http.Client
	csrf string
}

func New(base string) (*Client, error) {
	base = strings.TrimRight(strings.TrimSpace(base), "/")
	u, err := url.Parse(base)
	if err != nil {
		return nil, err
	}
	host := strings.ToLower(u.Hostname())
	if u.Scheme != "http" || (host != "localhost" && host != "127.0.0.1" && host != "::1") {
		return nil, errors.New("VaultPool control client only permits local HTTP loopback")
	}
	return &Client{Base: base, HTTP: &http.Client{Timeout: 30 * time.Second}}, nil
}

func (c *Client) init(ctx context.Context) error {
	if c.csrf != "" {
		return nil
	}
	var v struct {
		CSRF string `json:"csrf_token"`
	}
	if err := c.Get(ctx, "/api/session", &v); err != nil {
		return err
	}
	if v.CSRF == "" {
		return errors.New("VaultPool server returned no CSRF token")
	}
	c.csrf = v.CSRF
	return nil
}

func (c *Client) request(ctx context.Context, method, path string, body any, out any) error {
	var r io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return err
		}
		r = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.Base+path, r)
	if err != nil {
		return err
	}
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if method != http.MethodGet && method != http.MethodHead && method != http.MethodOptions {
		if err := c.init(ctx); err != nil {
			return err
		}
		req.Header.Set("X-VaultPool-CSRF", c.csrf)
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return fmt.Errorf("VaultPool local service unavailable: %w", err)
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(io.LimitReader(resp.Body, 16<<20))
	if err != nil {
		return err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		var e struct {
			Error string `json:"error"`
		}
		_ = json.Unmarshal(data, &e)
		if e.Error == "" {
			e.Error = strings.TrimSpace(string(data))
		}
		if e.Error == "" {
			e.Error = resp.Status
		}
		return fmt.Errorf("%s", e.Error)
	}
	if out != nil && len(data) > 0 {
		if err := json.Unmarshal(data, out); err != nil {
			return fmt.Errorf("decode VaultPool response: %w", err)
		}
	}
	return nil
}

func (c *Client) Get(ctx context.Context, path string, out any) error {
	return c.request(ctx, http.MethodGet, path, nil, out)
}
func (c *Client) Post(ctx context.Context, path string, body any, out any) error {
	return c.request(ctx, http.MethodPost, path, body, out)
}
