package controlclient

import "testing"

func TestOnlyLoopback(t *testing.T) {
	for _, u := range []string{"http://127.0.0.1:8742", "http://localhost:8742", "http://[::1]:8742"} {
		if _, err := New(u); err != nil {
			t.Fatalf("%s: %v", u, err)
		}
	}
	if _, err := New("https://example.com"); err == nil {
		t.Fatal("expected remote rejection")
	}
}
