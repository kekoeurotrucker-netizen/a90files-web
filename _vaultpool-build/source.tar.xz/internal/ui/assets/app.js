const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let model={};
let fileModel={ready:false,recovery_configured:false,files:[]};
let libraryModel={ready:false,folders:[],assignments:{},categories:[],file_categories:{},extensions:{}};
let transferModel={ready:false,jobs:[]};
let dialogModel={ready:false};
let driveModel={supported:false,installed:false,compatible:false,running:false,read_only:true,backend:'dokany2'};
let oauthBrowserModel={selected:{mode:'default'},options:[],effective_label:'navegador predeterminado de Windows'};
const transferSeenStates={};
let transferTimer=null;
const fileHealth={};
const fileDistributions={};
let authModalAccount=null, authModalReady=false, authModalMode=null, authModalProvider=null;
let filenTwoFactorPending=false;
const expandedProviderAccounts=new Set();
let responsibleResolver=null;
let authPollTimer=null;
let authPollBusy=false;
let nativeDialogBusy=false;
let accountRefreshTimer=null;
let accountRefreshBusy=false;
let accountRefreshLast=0;
const accountAutoRefreshCooldown=60000;
const accountAutoRefreshEvery=300000;
let playerFile=null;
let playerTimer=null;
let playerModel=null;
function isMegaDevBridgeEnabled(){return false}
function clearAuthPoll(){if(authPollTimer){clearInterval(authPollTimer);authPollTimer=null}authPollBusy=false}
function resetAuthButton(){const btn=$('#auth-continue');if(btn)btn.disabled=false;const filenBtn=$('#auth-filen-submit');if(filenBtn)filenBtn.disabled=false}
function clearFilenAuthFields(){filenTwoFactorPending=false;['#auth-filen-email','#auth-filen-password','#auth-filen-2fa'].forEach(s=>{const el=$(s);if(el)el.value=''});$('#auth-filen-msg')&&( $('#auth-filen-msg').textContent='');$('#auth-filen-credentials')?.classList.remove('hidden');$('#auth-filen-2fa-wrap')?.classList.add('hidden');const btn=$('#auth-filen-submit');if(btn)btn.textContent='Conectar'}
function clearWebDAVAuthFields(){['#auth-webdav-user','#auth-webdav-password'].forEach(s=>{const el=$(s);if(el)el.value=''});const msg=$('#auth-webdav-msg');if(msg){msg.textContent='';msg.classList.remove('bad-msg')}}
function closeAuthModal(){clearAuthPoll();resetAuthButton();clearFilenAuthFields();clearWebDAVAuthFields();$('#auth-modal')?.classList.add('hidden');authModalAccount=null;authModalReady=false;authModalMode=null;authModalProvider=null}
function megaNormalUserBlocked(){return authModalProvider==='mega'&&authModalMode==='external_session'&&!isMegaDevBridgeEnabled()}
let toastTimer=null;
function notify(msg,bad=false){let el=$('#toast');if(!el){el=document.createElement('div');el.id='toast';document.body.appendChild(el)}el.textContent=msg||'';el.className=`toast ${bad?'bad':'ok'}`;if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>{el.classList.add('hidden')},5200)}
let csrfToken='';
let recoveryModel={available:false};
let currentRecoveryCode='';
let recoveryRevealTimer=null,clipboardClearTimer=null;
function fmtBytes(n){if(!n)return '—';const u=['B','KB','MB','GB','TB','PB'];let i=0,x=n;while(x>=1000&&i<u.length-1){x/=1000;i++}return `${x>=100?x.toFixed(0):x>=10?x.toFixed(1):x.toFixed(2)} ${u[i]}`}
function fmtDurationSeconds(v){let s=Math.max(0,Math.round(Number(v)||0));if(s<60)return s?`${s} s`:'<1 s';const h=Math.floor(s/3600);s-=h*3600;const m=Math.floor(s/60);const r=s%60;if(h)return `${h} h${m?` ${m} min`:''}`;return r?`${m} min ${r} s`:`${m} min`}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function initSession(){const r=await fetch('/api/session',{cache:'no-store'});if(!r.ok)throw new Error(`session HTTP ${r.status}`);const b=await r.json();csrfToken=b.csrf_token||'';if(!csrfToken)throw new Error('VaultPool no entregó token CSRF')}
async function rawFetch(url,opt={}){const method=(opt.method||'GET').toUpperCase();const headers=new Headers(opt.headers||{});if(!['GET','HEAD','OPTIONS'].includes(method)){if(!csrfToken)throw new Error('sesión segura no inicializada');headers.set('X-VaultPool-CSRF',csrfToken)}if(opt.body&&!(opt.body instanceof FormData)&&!headers.has('Content-Type'))headers.set('Content-Type','application/json');return fetch(url,{...opt,headers,cache:'no-store'})}
async function api(url,opt={}){const r=await rawFetch(url,opt);let b={};try{b=await r.json()}catch{}if(!r.ok)throw new Error(b.error||`HTTP ${r.status}`);return b}
async function apiTimeout(url,opt={},ms=18000){const ctrl=new AbortController();const t=setTimeout(()=>ctrl.abort(),ms);try{return await api(url,{...opt,signal:ctrl.signal})}catch(e){if(e&&e.name==='AbortError')throw new Error('La operación tardó demasiado y fue cancelada para no bloquear VaultPool. Cierra cualquier ventana externa pendiente y vuelve a intentarlo.');throw e}finally{clearTimeout(t)}}

function browserSelectValue(cfg){cfg=cfg||{mode:'default'};if(cfg.mode==='browser'&&cfg.browser_id)return `browser:${cfg.browser_id}`;if(cfg.mode==='custom')return 'custom';return 'default'}
function renderOAuthBrowser(){
 const sel=$('#oauth-browser-select'),custom=$('#oauth-browser-custom'),wrap=$('#oauth-browser-custom-wrap'),pill=$('#oauth-browser-pill'),msg=$('#oauth-browser-msg');
 if(!sel)return;
 const selected=oauthBrowserModel.selected||{mode:'default'};
 const opts=oauthBrowserModel.options||[];
 const detected=oauthBrowserModel.detected_default_name?` — detectado: ${oauthBrowserModel.detected_default_name}`:'';
 let html=`<option value="default">Predeterminado de Windows${esc(detected)}</option>`;
 for(const o of opts){if(o.id==='default')continue;const disabled=o.installed?'':' disabled';const mark=o.default?' · predeterminado':'';const suffix=o.installed?mark:' · no encontrado';html+=`<option value="browser:${esc(o.id)}"${disabled}>${esc(o.name+suffix)}</option>`}
 html+=`<option value="custom">Elegir ejecutable…</option>`;
 sel.innerHTML=html;
 sel.value=browserSelectValue(selected);
 if(![...sel.options].some(o=>o.value===sel.value))sel.value='default';
 if(custom)custom.value=selected.mode==='custom'?(selected.custom_path||''):'';
 if(wrap)wrap.classList.toggle('hidden',sel.value!=='custom');
 if(pill){pill.textContent=oauthBrowserModel.effective_label||'Predeterminado';pill.className='status-pill ok'}
 if(msg)msg.textContent=`OAuth se abrirá en ${oauthBrowserModel.effective_label||'el navegador predeterminado'}; VaultPool solo recibirá el retorno local seguro.`;
}
function updateOAuthBrowserDraft(){
 const sel=$('#oauth-browser-select'),wrap=$('#oauth-browser-custom-wrap'),msg=$('#oauth-browser-msg');if(!sel)return;
 if(wrap)wrap.classList.toggle('hidden',sel.value!=='custom');
 if(msg){
  if(sel.value==='custom')msg.textContent='Pega la ruta completa al .exe del navegador o pulsa Examinar. VaultPool abrirá el selector en un proceso aislado con timeout.';
  else if(sel.value.startsWith('browser:')){const opt=sel.options[sel.selectedIndex];msg.textContent=`Selección pendiente: ${opt?.textContent||sel.value}. Pulsa Guardar navegador OAuth.`}
  else msg.textContent='Selección pendiente: navegador predeterminado de Windows. Pulsa Guardar navegador OAuth.';
 }
}
async function pickOAuthBrowserExecutable(){
 const btn=$('#oauth-browser-browse'),input=$('#oauth-browser-custom'),msg=$('#oauth-browser-msg');if(!btn||!input)return;
 if(!dialogModel.ready){if(msg)msg.textContent=dialogModel.reason||'Selector no disponible: pega manualmente la ruta completa al .exe.';input.focus();return}
 const old=btn.textContent;btn.disabled=true;btn.textContent='Abriendo…';
 try{
  const r=await withNativeDialog(()=>apiTimeout('/api/dialogs/open-executable',{method:'POST'},95000));
  if(r?.selected&&r.path){input.value=r.path;if(msg)msg.textContent='Ejecutable seleccionado. Pulsa Guardar navegador OAuth para aplicarlo.';input.focus()}
  else if(r&&msg)msg.textContent='Selección cancelada; no se cambió el navegador OAuth.';
 }catch(e){if(msg)msg.textContent=`No se pudo abrir el selector: ${nativeDialogError(e)}. Si hay otra ventana de selección abierta, ciérrala o pega la ruta manualmente.`;}
 finally{btn.disabled=nativeDialogBusy||!dialogModel.ready;btn.textContent=old}
}
async function refreshOAuthBrowser(){try{oauthBrowserModel=await api('/api/oauth/browser')}catch(e){oauthBrowserModel={selected:{mode:'default'},options:[],effective_label:'navegador predeterminado',error:e.message};const msg=$('#oauth-browser-msg');if(msg)msg.textContent=`No se pudo detectar el navegador: ${e.message}`;}renderOAuthBrowser()}
async function saveOAuthBrowser(){
 const sel=$('#oauth-browser-select'),custom=$('#oauth-browser-custom'),msg=$('#oauth-browser-msg');if(!sel)return;
 let payload={mode:'default'};
 if(sel.value.startsWith('browser:'))payload={mode:'browser',browser_id:sel.value.slice(8)};
 if(sel.value==='custom')payload={mode:'custom',custom_path:(custom?.value||'').trim()};
 if(payload.mode==='custom'&&!payload.custom_path){if(msg)msg.textContent='Indica la ruta del navegador.exe o vuelve a Predeterminado.';custom?.focus();return}
 const btn=$('#oauth-browser-save'),old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Guardando…'}
 try{oauthBrowserModel=await api('/api/oauth/browser',{method:'PUT',body:JSON.stringify(payload)});renderOAuthBrowser();if(msg)msg.textContent=`Guardado. OAuth se abrirá en ${oauthBrowserModel.effective_label}.`}catch(e){if(msg)msg.textContent=`No se pudo guardar: ${e.message}`;}finally{if(btn){btn.disabled=false;btn.textContent=old}}
}

function oauthTerms(providerID){
 if(providerID==='dropbox')return {
  idLabel:'App Key público de Dropbox',
  idPlaceholder:'Pega aquí la App key de Dropbox',
  empty:'Introduce la App Key pública de Dropbox. No introduzcas contraseña, token ni App Secret.',
  helper:'Dropbox llama a esto App key. Es el identificador público de la app OAuth; no es tu contraseña ni un token. En la App Console añade también esta Redirect URI exacta: http://127.0.0.1:8742/oauth/callback. El App Secret no se pide en VaultPool para PKCE.',
  save:'Guardar App Key y activar Dropbox',
  helpTitle:'Cómo crear la App Key',
  helpSteps:['Abre la app de VaultPool en Dropbox App Console.','En Permissions activa account_info.read, files.metadata.read, files.content.read y files.content.write. Guarda con Submit.','Añade la Redirect URI exacta: http://127.0.0.1:8742/oauth/callback.','Copia solo la App key pública. No pegues el App secret. Tras cambiar permisos, vuelve a autorizar la cuenta.']
 };
 if(providerID==='onedrive')return {
  idLabel:'Application (client) ID de Microsoft',
  idPlaceholder:'Pega aquí el Application / Client ID público',
  empty:'Introduce el Application (client) ID público de Microsoft. No introduzcas contraseña ni tokens.',
  helper:'Microsoft lo llama Application (client) ID. Es público, no es tu contraseña ni un token. El retorno de OneDrive es http://localhost:8742/. En Microsoft registra http://localhost como aplicación de escritorio; Microsoft permite un puerto local variable. No añadas /oauth/callback.',
  save:'Guardar Client ID y activar OneDrive',
  helpTitle:'Cómo crear el Client ID',
  helpSteps:['Abre Microsoft Entra y el registro de la aplicación que corresponde a tu Application (client) ID.','En Authentication añade la plataforma Mobile and desktop applications con redirect http://localhost. VaultPool recibe el retorno en http://localhost:8742/.','Copia Application (client) ID. No pegues secretos, contraseñas ni tokens.']
 };
 if(providerID==='pcloud')return {
  idLabel:'Client ID de pCloud',
  idPlaceholder:'Pega aquí el Client ID de tu app pCloud',
  empty:'Introduce el Client ID de pCloud y su Client Secret.',
  helper:'pCloud exige Client ID + Client Secret para el flujo OAuth de código. VaultPool guarda ambos cifrados localmente y nunca los registra en logs. Redirect URI: http://127.0.0.1:8742/oauth/callback.',
  save:'Guardar API y activar pCloud',
  helpTitle:'Cómo preparar pCloud',
  helpSteps:['Abre pCloud Developers > My Apps y crea/abre la app de VaultPool.','Configura la Redirect URI http://127.0.0.1:8742/oauth/callback.','Copia Client ID y Client Secret en VaultPool.','Cada cuenta autorizada conservará su región US/EU y su token cifrado por separado.']
 };
 if(providerID==='google-drive')return {
  idLabel:'Client ID público OAuth de Google',
  idPlaceholder:'Pega aquí el Client ID público de Google',
  empty:'Introduce el Client ID público OAuth de Google. No introduzcas tu contraseña ni tokens.',
  helper:'No introduzcas tu contraseña de Google ni tokens. El Secret de escritorio solo identifica este cliente de pruebas y se usa únicamente contra el endpoint oficial de token.',
  save:'Guardar Client ID y activar Google Drive',
  helpTitle:'Cómo crear el Client ID',
  helpSteps:['Abre Google Cloud Console, crea o elige un proyecto y habilita Google Drive API.','En Credentials crea un OAuth Client ID de tipo Desktop app.','Copia el Client ID y, si Google lo muestra para esa app de escritorio, pega también el Client Secret.']
 };
 return {idLabel:'Identificador público OAuth',idPlaceholder:'Pega aquí el identificador público OAuth',empty:'Introduce el identificador público OAuth. No introduzcas contraseñas ni tokens.',helper:'No introduzcas contraseñas, tokens ni claves privadas. Este campo solo acepta el identificador público del cliente OAuth.',save:'Guardar y activar conector',helpTitle:'Cómo prepararlo',helpSteps:['Crea una aplicación OAuth pública o de escritorio en el portal oficial del proveedor.','Configura el redirect local que muestre VaultPool para ese proveedor.','Pega solo identificadores públicos; nunca contraseñas, tokens ni secretos no solicitados.']}
}
function oauthHelpHTML(t){return `<strong>${esc(t.helpTitle||'Cómo conseguirlo')}</strong><ol>${(t.helpSteps||[]).map(s=>`<li>${esc(s)}</li>`).join('')}</ol>`}
function applyOAuthTerms(providerID){
 const t=oauthTerms(providerID);
 const label=$('#auth-client-id-label'), input=$('#auth-client-id'), helper=$('#auth-oauth-helper'), btn=$('#auth-save-client'), help=$('#auth-oauth-help'), toggle=$('#auth-oauth-help-toggle');
 if(label)label.textContent=t.idLabel;
 if(input)input.placeholder=t.idPlaceholder;
 if(helper)helper.textContent=t.helper;
 if(btn)btn.textContent=t.save;
 if(help){help.innerHTML=oauthHelpHTML(t);help.classList.add('hidden')}
 if(toggle){toggle.textContent=t.helpTitle||'Cómo conseguirlo';toggle.setAttribute('aria-expanded','false')}
}


function providerIconMarkup(p,small=false){
 const id=p?.id||p?.provider_id||'';
 const cls=`provider-logo ${small?'small':''} logo-${esc(id)}`;
 if(id==='google-drive')return `<div class="${cls}" title="Google Drive" aria-label="Google Drive"><svg viewBox="0 0 64 64" role="img"><path class="gd-a" d="M24 8h16l20 34H44z"/><path class="gd-b" d="M4 42 24 8l12 22-8 12z"/><path class="gd-c" d="M4 42h40l-8 14H12z"/></svg></div>`;
 if(id==='dropbox')return `<div class="${cls}" title="Dropbox" aria-label="Dropbox"><svg viewBox="0 0 64 64" role="img"><path d="M18 8 4 18l14 9 14-9zM46 8 32 18l14 9 14-9zM18 31 4 41l14 9 14-9zM46 31 32 41l14 9 14-9zM32 45 18 54l14 8 14-8z"/></svg></div>`;
 if(id==='onedrive')return `<div class="${cls}" title="Microsoft OneDrive" aria-label="Microsoft OneDrive"><svg viewBox="0 0 64 64" role="img"><path d="M25 42h28c6 0 10-4 10-9s-4-10-10-10c-2 0-4 1-6 2-3-8-10-13-19-13-10 0-18 6-21 16C3 30 0 34 0 38c0 6 5 10 12 10h13z"/></svg></div>`;
 if(id==='mega')return `<div class="${cls}" title="MEGA" aria-label="MEGA"><svg viewBox="0 0 64 64" role="img"><circle cx="32" cy="32" r="28"/><path d="M16 45V19h9l7 11 7-11h9v26h-9V32l-7 10-7-10v13z"/></svg></div>`;
 if(id==='terabox')return `<div class="${cls}" title="TeraBox" aria-label="TeraBox"><svg viewBox="0 0 64 64" role="img"><rect x="7" y="12" width="50" height="40" rx="12"/><path d="M18 29h28v8H18zM24 21h16v8H24zM24 37h16v8H24z"/></svg></div>`;
 const icon=String(p?.icon_url||'');if(icon.startsWith('data:image/png;base64,')||icon.startsWith('data:image/x-icon;base64,')||icon.startsWith('data:image/vnd.microsoft.icon;base64,'))return `<div class="${cls} custom-logo" title="${esc(p?.name||'Nube')}"><img alt="" src="${esc(icon)}" /></div>`;
 return `<div class="provider-badge">${esc(p?.short_name||p?.name?.slice(0,2).toUpperCase()||'☁')}</div>`;
}
function badge(p){return providerIconMarkup(p,true)}
function statusText(a){if(a.state==='connected')return ['Conectada','ok'];if(a.state==='reauth_required')return ['Reautenticar','warn'];if(a.state==='attention')return ['Atención','bad'];return ['Pendiente','']}
function authLabel(p){const m=p.auth_strategy;if(p.id==='mega'&&m==='external_session')return 'MEGAcmd · avanzado';if(p.id==='filen'&&m==='direct_credentials')return 'Directo · SDK oficial';if(p.id==='mediafire'&&m==='direct_credentials')return 'Directo · API oficial';return m==='system_browser_oauth'?'OAuth · navegador':m==='embedded_webview'?'WebView autorizada':m==='device_code'?'Código dispositivo':m==='direct_credentials'?'Bóveda local':m==='external_session'?'Cliente oficial':'Sin flujo aprobado'}
function detailsByAccount(){return Object.fromEntries((model.account_details||[]).map(d=>[d.account.id,d]))}
function quotaPercent(used,total){if(!total||total<=0)return 0;return Math.max(0,Math.min(100,used/total*100))}
function quotaDonut(used,total,compact=false){const pct=quotaPercent(used,total);const title=total?`Ocupado ${fmtBytes(used)} de ${fmtBytes(total)} (${pct.toFixed(1)}%)`:'Cuota sin verificar';return `<div class="quota-donut${compact?' compact':''}" style="--pct:${pct.toFixed(2)}" title="${esc(title)}"><span>${total?`${pct.toFixed(0)}%`:'—'}</span></div>`}
function planLabel(a,d,p){const plan=String(a.plan_name||d.account?.plan_name||'').trim();if(plan)return plan;if(a.state==='connected')return 'Membresía no expuesta por API';if(a.state==='pending_auth')return 'Membresía pendiente';return 'Membresía sin verificar'}
function accountsForQuotaRefresh(){return (model.accounts||[]).filter(a=>['connected','attention'].includes(a.state)&&a.id)}
function hasActiveTransfers(){return (transferModel.jobs||[]).some(j=>['queued','running','canceling'].includes(j.state))}
function setAccountRefreshUI(active){
 const btn=$('#refresh-accounts'),accounts=accountsForQuotaRefresh();
 if(!btn)return;
 btn.disabled=!!active||!accounts.length;
 btn.textContent=active?'Actualizando…':'Actualizar todo';
 btn.title=accounts.length?'Comprobar cuota y estado de todas las cuentas conectadas':'No hay cuentas conectadas para actualizar';
}
function providerGroupsForUI(){
 if(Array.isArray(model.provider_groups)&&model.provider_groups.length)return model.provider_groups;
 const details=detailsByAccount(),groups=new Map();
 for(const a of model.accounts||[]){const p=model.providers_by_id[a.provider_id]||{id:a.provider_id,name:a.provider_id,short_name:'☁',max_accounts:1};let g=groups.get(p.id);if(!g){g={provider:p,accounts:[],account_count:0,total_bytes:0,used_bytes:0,free_bytes:0,can_add_account:p.max_accounts===0};groups.set(p.id,g)}const d=details[a.id]||{account:a,provider:p};g.accounts.push({...d,account:a,provider:p});g.account_count++;g.total_bytes+=a.total_bytes||0;g.used_bytes+=a.used_bytes||0;g.free_bytes+=a.free_bytes||0;if(p.max_accounts>0)g.can_add_account=g.account_count<p.max_accounts}
 return [...groups.values()].sort((a,b)=>String(a.provider.name).localeCompare(String(b.provider.name)));
}
function accountRowHTML(d,p){
 const a=d.account||d,total=a.total_bytes||0,used=a.used_bytes||0,pct=quotaPercent(used,total),st=statusText(a),sub=d.display_identity||a.label||'Cuenta sin identificar';
 const usage=total?`${fmtBytes(used)} ocupado · ${fmtBytes(Math.max(0,total-used))} libre · ${fmtBytes(total)} total`:'Cuota sin verificar',plan=planLabel(a,d,p);
 const own='Los datos previos de esta nube se respetan: cuentan como espacio ocupado y VaultPool solo escribe objetos propios cifrados.';
 // Keep the established Filen direct-login UI contract: p.id==='filen'?'Conectar':'Ver acceso'
 const needsAuth=['pending_auth','reauth_required'].includes(a.state),direct=p.id==='filen'||p.id==='mediafire'||p.generic_protocol==='webdav';
 const pendingAction=a.state==='reauth_required'?'Volver a conectar':direct?'Conectar':'Ver acceso';
 const disconnect=a.state==='connected'&&p.id!=='mega'?`<button class="tiny-btn disconnect-account" data-account="${esc(a.id)}" data-provider-name="${esc(p.name)}">Desconectar</button>`:'';
 const renew=p.id==='dropbox'&&a.state==='connected'?`<button class="tiny-btn auth-account" data-account="${esc(a.id)}">Renovar permisos</button>`:'';
 return `<div class="provider-account-row"><div class="account-identity"><strong>${esc(sub)}</strong><small>Membresía: ${esc(plan)}</small></div><div class="quota-cell">${quotaDonut(used,total,true)}</div><div class="usage"><progress class="usage-progress" max="100" value="${pct.toFixed(2)}"></progress><small>${esc(usage)}</small></div><div class="account-actions"><span class="status-pill ${st[1]}">${st[0]}</span>${needsAuth?`<button class="tiny-btn auth-account" data-account="${esc(a.id)}">${pendingAction}</button>`:`<button class="tiny-btn probe-account" data-account="${esc(a.id)}">Comprobar</button><button class="tiny-btn manage-account-data" data-account="${esc(a.id)}">Datos</button>${disconnect}${renew}`}</div><small class="provider-account-note">${esc(a.status_note||d.connector_status||own)}</small></div>`;
}
function providerGroupHTML(g){
 const p=g.provider||{},accounts=Array.isArray(g.accounts)?g.accounts:[],expanded=expandedProviderAccounts.has(p.id),shown=expanded?accounts:accounts.slice(0,3),hidden=Math.max(0,accounts.length-shown.length);
 const total=g.total_bytes||0,free=Math.max(0,g.free_bytes||0),summary=total?`${fmtBytes(free)} libres · ${fmtBytes(total)} totales`:'Cuota pendiente de verificar';
 const add=g.can_add_account?`<button class="small-btn add-provider-group" data-provider="${esc(p.id)}">＋ Añadir otra cuenta</button>`:`${g.add_account_note?`<span class="provider-limit-note">${esc(g.add_account_note)}</span>`:''}`;
 const toggle=accounts.length>3?`<button class="tiny-btn toggle-provider-accounts" data-provider="${esc(p.id)}">${expanded?'Mostrar menos':`Mostrar ${hidden} cuenta${hidden===1?'':'s'} más`}</button>`:'';
 return `<article class="provider-account-group"><div class="provider-group-head"><div class="provider-group-title">${providerIconMarkup(p,true)}<div><strong>${esc(p.name)}</strong><small>${accounts.length} cuenta${accounts.length===1?'':'s'} · ${esc(summary)}</small><small class="failure-domain-note">Dominio de seguridad: ${esc(p.failure_domain||p.id)}</small></div></div><div class="provider-group-actions">${add}</div></div><div class="provider-group-accounts">${shown.map(d=>accountRowHTML(d,p)).join('')}</div>${toggle?`<div class="provider-group-more">${toggle}</div>`:''}</article>`;
}
function bindProviderGroupActions(){
 $$('.auth-account').forEach(el=>el.addEventListener('click',()=>showAuthPlan(el.dataset.account)));
 $$('.probe-account').forEach(el=>el.addEventListener('click',()=>probeAccount(el.dataset.account)));
 $$('.manage-account-data').forEach(el=>el.addEventListener('click',()=>showAccountDataPolicy(el.dataset.account)));
 $$('.disconnect-account').forEach(el=>el.addEventListener('click',()=>disconnectAccount(el.dataset.account,el.dataset.providerName)));
 $$('.add-provider-group').forEach(el=>el.addEventListener('click',()=>addProvider(el.dataset.provider)));
 $$('.toggle-provider-accounts').forEach(el=>el.addEventListener('click',()=>{const id=el.dataset.provider;if(expandedProviderAccounts.has(id))expandedProviderAccounts.delete(id);else expandedProviderAccounts.add(id);renderAccounts()}));
}
function renderAccounts(){
 const groups=providerGroupsForUI(),roots=[$('#accounts'),$('#provider-groups')].filter(Boolean);
 if(!groups.length){for(const root of roots){root.className='provider-account-groups empty-box';root.textContent='No hay cuentas asociadas todavía.'}setAccountRefreshUI(accountRefreshBusy);return}
 const html=groups.map(providerGroupHTML).join('')+`<div class="account-policy-note"><strong>Datos existentes intactos.</strong> La cuota ocupada viene del proveedor e incluye archivos anteriores del usuario. VaultPool no los mueve, no los borra y no los usa como fragmentos; solo consume espacio libre y reconoce como suyos los manifiestos/objetos autenticados de VaultPool.</div>`;
 for(const root of roots){root.className='provider-account-groups';root.innerHTML=html}
 bindProviderGroupActions();setAccountRefreshUI(accountRefreshBusy);
}
function providerCard(p,addable){const status=p.status==='allowed'?'<span class="tag allowed">Aprobado</span>':p.status==='review_required'?'<span class="tag review">En revisión</span>':'<span class="tag disabled">No disponible</span>';const accounts=p.account_types?.slice(0,3).join(' · ')||'—';return `<article class="provider-card"><div class="provider-top"><div class="provider-title">${badge(p)}<div><strong>${esc(p.name)}</strong><small>${esc(accounts)}</small></div></div>${status}</div><p>${esc(p.status_note)}</p><div class="auth-meta">🔐 ${esc(authLabel(p))}${p.oauth_pkce?' · PKCE':''}</div><div class="actions"><span class="tag">${p.max_accounts?`Máx. ${p.max_accounts} cuenta${p.max_accounts>1?'s':''}`:'Varias cuentas legítimas'}</span><button class="small-btn add-provider" data-provider="${esc(p.id)}" ${addable?'':'disabled'}>${addable?'Añadir':'Bloqueado'}</button></div></article>`}
function renderProviders(){
 const available=model.available_providers||[], gated=model.gated_providers||[];
 $('#available-all').innerHTML=available.length?available.map(p=>providerCard(p,true)).join(''):'<div class="empty-box">No quedan servicios nuevos por añadir. Para conectar otra cuenta de un servicio que ya usas, pulsa “＋ Añadir otra cuenta” dentro de su tarjeta.</div>';
 $('#gated-all').innerHTML=gated.length?gated.map(p=>providerCard(p,false)).join(''):'<div class="empty-box">No hay proveedores pendientes o bloqueados.</div>';
 $('#available-mini').innerHTML=available.length?available.slice(0,5).map(p=>`<div class="mini-service add-provider" data-provider="${esc(p.id)}">${badge(p)}<div><strong>${esc(p.name)}</strong><small>＋ Añadir</small></div></div>`).join(''):'<span class="empty-box full-width">No quedan servicios nuevos. Las cuentas adicionales se añaden desde la tarjeta de cada proveedor.</span>';
 $$('.add-provider').forEach(el=>el.addEventListener('click',()=>addProvider(el.dataset.provider)));
}

function protectionStatus(){return model.protection||{ready:false,label:'Protección insuficiente',independent_providers:0,reason:'protección todavía no verificada'}}
function canProtect(){const p=protectionStatus();return !!fileModel.ready&&!!fileModel.recovery_configured&&!!p.ready}
function renderProtection(){
 const p=protectionStatus(),mode=$('#protection-mode'),tops=[$('#add-file'),$('#add-folder')];
 if(mode)mode.textContent=p.label||'Protección sin verificar';
 tops.forEach(top=>{if(top){top.disabled=nativeDialogBusy;top.title=nativeDialogBusy?nativeDialogBusyMessage():'Abrir el selector de Windows'}});
 const warning=$('#files-protection-warning'),reason=$('#files-protection-reason');
 if(warning)warning.classList.toggle('hidden',!fileModel.ready||(p.independent_providers||0)>=2);
 if(reason)reason.textContent=p.reason||'Conecta al menos dos proveedores independientes antes de proteger archivos.';
 $('#field-test-warning')?.classList.toggle('hidden',model.build_purpose!=='field-test');
}

function riskVisual(level){
 const map={VERY_LOW:['Muy bajo','risk-green','✓'],LOW:['Bajo','risk-green','✓'],REDUCED:['Reducido','risk-yellow','!'],HIGH:['Alto','risk-orange','!'],CRITICAL:['Crítico','risk-red','!'],UNRECOVERABLE:['Irrecuperable','risk-red','×']};
 return map[level]||['Sin auditar','risk-neutral','•'];
}
function normText(v){return String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()}
function categoryForFile(f){return libraryModel.file_categories?.[f.file_id]||{id:'other',label:'Otros',icon:'▱'}}
function folderForFile(f){const id=libraryModel.assignments?.[f.file_id]||'';return (libraryModel.folders||[]).find(x=>x.id===id)||null}
function fileExt(name){const m=String(name||'').toLowerCase().match(/(\.[^.\\\/]+)$/);return m?m[1]:''}
function isVideoFile(f){return categoryForFile(f).id==='video'}
function isIntegratedVideo(name){return ['.mp4','.m4v','.mov','.webm','.avi','.mpg','.mpeg','.ogv','.ogg','.3gp','.3g2','.ts'].includes(fileExt(name))}
function playerPhaseLabel(st){const p=st?.phase||st?.state||'';const map={idle:'Sin preparar',queued:'En cola',recovering:'Recuperando claves',preflight:'Analizando',restoring:'Reconstruyendo fragmentos',verifying:'Verificando SHA-256',streaming:'Streaming por rangos',ready:'Listo',failed:'Falló'};return map[p]||map[st?.state]||p||'Preparando'}
function playerProgressText(st){if(!st)return 'Preparando reproducción…';if(st.state==='failed')return st.error||'No se pudo preparar el vídeo.';if(st.state==='ready'&&st.streaming){const cached=st.cache_chunks||0,total=st.cache_chunks_total||0;return total?`Streaming listo · caché ${cached}/${total} bloques · precargando los siguientes`:'Streaming listo · preparando el primer bloque'}if(st.state==='ready')return 'Listo para reproducir desde caché local temporal.';const done=st.bytes_processed||0,total=st.bytes_total||0,pct=total?Math.min(100,done/total*100):0;const speed=st.bytes_per_second?` · ${fmtBytes(st.bytes_per_second)}/s`:'';const eta=st.eta_seconds?` · quedan ${fmtDurationSeconds(st.eta_seconds)}`:'';const blocks=st.blocks_total?` · bloques ${st.blocks_done||0}/${st.blocks_total}`:'';return total?`${playerPhaseLabel(st)} · ${fmtBytes(done)} / ${fmtBytes(total)} · ${pct.toFixed(0)}%${speed}${eta}${blocks} · empieza al 100%`:`${playerPhaseLabel(st)}…`}
function renderLibraryControls(){
 const cats=libraryModel.categories||[],folders=libraryModel.folders||[],files=fileModel.files||[];
 const type=$('#library-type-filter'),folder=$('#library-folder-filter');
 if(type){const keep=type.value;type.innerHTML='<option value="">Todos los tipos</option>'+cats.map(c=>`<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('');type.value=[...type.options].some(o=>o.value===keep)?keep:''}
 if(folder){const keep=folder.value;folder.innerHTML='<option value="">Todas las carpetas</option><option value="__none__">Sin carpeta</option>'+folders.map(f=>`<option value="${esc(f.id)}">${esc(f.name)}</option>`).join('');folder.value=[...folder.options].some(o=>o.value===keep)?keep:''}
 const chips=$('#library-category-chips');
 if(chips){const active=type?.value||'';chips.innerHTML=cats.map(c=>{const n=files.filter(f=>categoryForFile(f).id===c.id).length;return `<button class="category-chip${active===c.id?' active':''}" type="button" data-category="${esc(c.id)}"><span class="category-chip__icon">${esc(c.icon)}</span><span class="category-chip__label">${esc(c.label)}</span><strong class="category-chip__count">${n}</strong></button>`}).join('');$$('.category-chip').forEach(b=>b.addEventListener('click',()=>{if(type){type.value=type.value===b.dataset.category?'':b.dataset.category;renderFiles()}}))}
 const list=$('#library-folders');
 if(list){list.innerHTML=folders.length?folders.map(f=>{const n=Object.values(libraryModel.assignments||{}).filter(x=>x===f.id).length;return `<div class="library-folder-pill"><span>📁 ${esc(f.name)} <small>${n}</small></span><button class="tiny-btn rename-folder" type="button" data-folder="${esc(f.id)}">Renombrar</button><button class="tiny-btn delete-folder" type="button" data-folder="${esc(f.id)}">Eliminar</button></div>`}).join(''):'<span class="muted-text">Aún no has creado carpetas personalizadas.</span>';
  $$('.rename-folder').forEach(b=>b.addEventListener('click',()=>renameLibraryFolder(b.dataset.folder)));
  $$('.delete-folder').forEach(b=>b.addEventListener('click',()=>deleteLibraryFolder(b.dataset.folder)));
 }
}
function filteredLibraryFiles(){
 const files=[...(fileModel.files||[])],q=normText($('#library-search')?.value||''),type=$('#library-type-filter')?.value||'',folder=$('#library-folder-filter')?.value||'',sort=$('#library-sort')?.value||'newest';
 const out=files.filter(f=>{const c=categoryForFile(f),fo=folderForFile(f),assigned=libraryModel.assignments?.[f.file_id]||'',ext=libraryModel.extensions?.[f.file_id]||'';if(type&&c.id!==type)return false;if(folder==='__none__'&&assigned)return false;if(folder&&folder!=='__none__'&&assigned!==folder)return false;if(q&&!normText(`${f.file_name} ${ext} ${c.label} ${fo?.name||''}`).includes(q))return false;return true});
 const stamp=f=>Date.parse(f.registered_at||f.created_at||0)||0;
 out.sort((a,b)=>{const ca=categoryForFile(a),cb=categoryForFile(b);switch(sort){case'oldest':return stamp(a)-stamp(b);case'name-asc':return a.file_name.localeCompare(b.file_name,undefined,{sensitivity:'base'});case'name-desc':return b.file_name.localeCompare(a.file_name,undefined,{sensitivity:'base'});case'size-desc':return (b.original_size||0)-(a.original_size||0);case'size-asc':return (a.original_size||0)-(b.original_size||0);case'type':return ca.label.localeCompare(cb.label,undefined,{sensitivity:'base'})||a.file_name.localeCompare(b.file_name,undefined,{sensitivity:'base'});default:return stamp(b)-stamp(a)}});return out;
}
function fileDistributionMarkup(d){
 const geometry=`Reed-Solomon ${d.data_shards}+${d.parity_shards} · ${d.blocks} bloque${d.blocks===1?'':'s'} · ${d.fragments} fragmentos`;
 const providers=(d.providers||[]).map(p=>{const assigned=(p.fragments||0)>0;const detail=assigned?`${p.fragments} fragmento${p.fragments===1?'':'s'} · ${fmtBytes(p.bytes)} · ${p.blocks} bloque${p.blocks===1?'':'s'}`:'Sin fragmentos de este archivo';const status=assigned?(p.connected?'Conectada':'Cuenta no conectada ahora'):'No asignada por el plan';return `<li><strong>${esc(p.name)}</strong><span>${esc(detail)}</span><small class="${assigned?'distribution-assigned':'distribution-unassigned'}">${esc(status)}</small></li>`}).join('');
 return `<details class="file-distribution" open><summary>Detalle de fragmentos cifrados</summary><p>${esc(geometry)} · ${esc(fmtBytes(d.bytes))} almacenados como fragmentos cifrados.</p><ul>${providers}</ul><small>${esc(d.note||'')}</small></details>`;
}
function fileDistributionHint(d){
 if(!d)return 'Fragmentos cifrados: pulsa "Dónde están" para ver proveedor y tamaño.';
 const assigned=(d.providers||[]).filter(p=>(p.fragments||0)>0).map(p=>`${p.name}: ${p.fragments} frag. (${fmtBytes(p.bytes)})`);
 return assigned.length?`Fragmentos cifrados: ${assigned.join(' · ')}`:'Fragmentos cifrados: sin proveedor asignado visible.';
}
async function toggleFileDistribution(id){
 if(fileDistributions[id]){delete fileDistributions[id];renderFiles();return}
 const btn=document.querySelector(`.distribution-file[data-file="${CSS.escape(id)}"]`);if(btn){btn.disabled=true;btn.textContent='Leyendo reparto…'}
 try{fileDistributions[id]=await api(`/api/files/${encodeURIComponent(id)}/distribution`);renderFiles()}catch(e){notify(`No se pudo leer el reparto: ${e.message}`,true);renderFiles()}
}
function closePlayer(){if(playerTimer){clearTimeout(playerTimer);playerTimer=null}const v=$('#player-video');if(v){v.pause();v.removeAttribute('src');v.load();v.classList.add('hidden')}$('#player-progress')?.classList.add('hidden');$('#player-progress-help')?.classList.add('hidden');$('#player-modal')?.classList.add('hidden');playerFile=null;playerModel=null}
function playerPluginLabel(p){if(!p)return 'VLC portable no comprobado.';if(p.installing){const total=p.bytes_total||0,done=p.bytes_downloaded||0;return total?`Descargando VLC portable · ${fmtBytes(done)} / ${fmtBytes(total)}`:`Descargando VLC portable · ${fmtBytes(done)}`}if(p.installed)return 'VLC portable instalado localmente en VaultPool.';if(p.error)return `VLC no instalado: ${p.error}`;return 'VLC portable no instalado. Se descargará desde VideoLAN y se verificará por SHA-256 antes de usarlo.'}
function renderPlayer(st){
 playerModel=st||playerModel;
 const m=playerModel||{},state=$('#player-state'),bar=$('#player-progress'),help=$('#player-progress-help'),video=$('#player-video'),panel=$('#player-plugin-panel'),plugin=$('#player-plugin-status'),openVLC=$('#player-open-vlc'),openDefault=$('#player-open-default'),install=$('#player-install-vlc'),clear=$('#player-clear-cache');
 if(state){state.textContent=playerProgressText(m);state.className=`connector-readiness ${m.state==='ready'?'ready':m.state==='failed'?'pending':'pending'}`}
 const pct=m.bytes_total?Math.min(100,Math.max(0,Number(m.progress_percent)||((m.bytes_processed||0)/m.bytes_total*100))):0;
 if(bar){bar.classList.toggle('hidden',!(m.state==='preparing'||m.state==='ready'));bar.value=m.streaming?pct:m.state==='ready'?100:pct}
 if(help){help.classList.toggle('hidden',!(m.state==='preparing'||m.state==='ready'));help.textContent=m.streaming?'Descifra solo los rangos que pide el reproductor y precarga los siguientes; los fragmentos remotos siguen cifrados.':m.state==='ready'?'Copia temporal verificada. Puedes reproducir o abrirla con otro reproductor.':'La reproducción empieza cuando termina la reconstrucción y la comprobación SHA-256.'}
 const ready=m.state==='ready';
 const integrated=ready&&!!m.integrated_candidate;
 if(video){
  if(integrated&&video.dataset.file!==m.file_id){video.dataset.file=m.file_id||'';video.src=m.stream_url||'';video.classList.remove('hidden');video.load();const play=video.play();if(play&&typeof play.catch==='function')play.catch(()=>{if(help)help.textContent='Copia temporal verificada. Pulsa play si Windows no permitió empezar automáticamente.'})}
  else video.classList.toggle('hidden',!integrated);
 }
 const needsPanel=ready&&(!m.integrated_candidate||m.external_recommended);
 if(panel)panel.classList.toggle('hidden',!needsPanel);
 if(plugin)plugin.textContent=playerPluginLabel(m.plugin);
 if(openVLC)openVLC.disabled=!ready||!(m.plugin&&m.plugin.installed);
 if(openDefault)openDefault.disabled=!ready||!!m.streaming;
 if(install){install.disabled=!!(m.plugin&&m.plugin.installing)||!!(m.plugin&&m.plugin.installed);install.textContent=m.plugin?.installed?'VLC instalado':m.plugin?.installing?'Instalando…':'Instalar VLC portable'}
 if(clear){clear.disabled=!m.file_id;clear.textContent=m.state==='preparing'?'Cancelar preparación':'Limpiar caché'}
 if((m.state==='preparing'||m.plugin?.installing||(m.streaming&&m.cache_chunks_total>0&&m.cache_chunks<m.cache_chunks_total))&&playerFile)schedulePlayerPoll(1000);
}
function showPlayerFallback(message){
 const panel=$('#player-plugin-panel'),state=$('#player-state');
 if(state&&message){state.textContent=message;state.className='connector-readiness pending'}
 if(panel)panel.classList.remove('hidden');
}
function schedulePlayerPoll(delay=1200){if(playerTimer)clearTimeout(playerTimer);playerTimer=setTimeout(refreshPlayerStatus,delay)}
async function refreshPlayerStatus(){if(!playerFile)return;try{const st=await api(`/api/player/${encodeURIComponent(playerFile.id)}/status`);renderPlayer(st)}catch(e){showPlayerFallback(e.message)}}
async function playFile(id,name){
 playerFile={id,name};playerModel=null;
 $('#player-title').textContent=name?`Reproducir ${name}`:'Reproducir vídeo';
 $('#player-modal')?.classList.remove('hidden');
 const video=$('#player-video');if(video){video.pause();video.removeAttribute('src');video.dataset.file='';video.load();video.classList.add('hidden')}
 $('#player-plugin-panel')?.classList.add('hidden');renderPlayer({file_id:id,file_name:name,state:'preparing',bytes_total:0,integrated_candidate:isIntegratedVideo(name),plugin:{}});
 try{const st=await api(`/api/player/${encodeURIComponent(id)}/prepare`,{method:'POST'});renderPlayer(st)}catch(e){showPlayerFallback(`No se pudo preparar el vídeo: ${e.message}`)}
}
async function openPlayerDefault(){if(!playerFile)return;try{await api(`/api/player/${encodeURIComponent(playerFile.id)}/open-default`,{method:'POST'});notify('Abierto con el reproductor asociado de Windows.')}catch(e){notify(e.message,true)}}
async function openPlayerVLC(){if(!playerFile)return;try{await api(`/api/player/${encodeURIComponent(playerFile.id)}/open-vlc`,{method:'POST'});notify('Abierto con VLC portable.')}catch(e){notify(e.message,true);showPlayerFallback(e.message)}}
async function installPlayerVLC(){
 if(!confirm('VaultPool descargará VLC portable desde VideoLAN, lo verificará por SHA-256 y lo guardará localmente sin instalar códecs globales. ¿Continuar?'))return;
 try{const st=await api('/api/player/plugins/vlc/install',{method:'POST'});renderPlayer({...(playerModel||{}),plugin:st});schedulePlayerPoll(1000);notify('Descarga de VLC portable iniciada.')}catch(e){notify(`No se pudo iniciar la descarga de VLC: ${e.message}`,true)}
}
async function clearPlayerCache(){if(!playerFile)return;const id=playerFile.id;try{await api(`/api/player/${encodeURIComponent(id)}/cache`,{method:'DELETE'});notify('Caché multimedia limpiada.');closePlayer()}catch(e){notify(`No se pudo limpiar la caché: ${e.message}`,true)}}
function renderFiles(){
 const all=fileModel.files||[],root=$('#managed-files');
 $('#file-count').textContent=all.length;
 const healths=Object.values(fileHealth);
 $('#file-healthy-count').textContent=healths.filter(h=>h.level==='VERY_LOW'||h.level==='LOW').length;
 $('#file-attention-count').textContent=healths.filter(h=>['REDUCED','HIGH','CRITICAL','UNRECOVERABLE'].includes(h.level)||h.missing_shards||h.corrupt_shards||h.unavailable_shards).length;
 $('#files-recovery-warning')?.classList.toggle('hidden',!fileModel.ready||!!fileModel.recovery_configured);
 const uploadBtn=$('#upload-path-submit');if(uploadBtn)uploadBtn.disabled=!canProtect();
 renderProtection();renderLibraryControls();
 if(!fileModel.ready){root.className='file-list empty-box';root.textContent=fileModel.reason||'La gestión segura de archivos no está disponible en este entorno.';return}
 if(!all.length){$('#library-result-count').textContent='0 archivos';root.className='file-list empty-box';root.textContent='Todavía no hay archivos registrados en VaultPool.';return}
 const files=filteredLibraryFiles();$('#library-result-count').textContent=`${files.length} de ${all.length} archivo${all.length===1?'':'s'}`;
 if(!files.length){root.className='file-list empty-box';root.textContent='No hay archivos que coincidan con estos filtros.';return}
 const folders=libraryModel.folders||[];root.className='file-list';
 root.innerHTML=files.map(f=>{
   const h=fileHealth[f.file_id],rv=riskVisual(h?.level),gen=f.generation||1,c=categoryForFile(f),folderID=libraryModel.assignments?.[f.file_id]||'',ext=libraryModel.extensions?.[f.file_id]||'';
   const status=h?`${h.valid_shards}/${h.total_shards}`:'—/—';
   const faults=h?(h.missing_shards||0)+(h.corrupt_shards||0):0;
   const sub=h?`${faults?`${faults} pérdida/corrupción confirmada · `:''}${h.unavailable_shards?`${h.unavailable_shards} inaccesible(s) · `:''}margen ${h.recovery_margin}`:`${f.data_shards}+${f.parity_shards} · generación ${gen}`;
   const repair=h?.repair_allowed?`<button class="small-btn repair-file" data-file="${esc(f.file_id)}">Reparar protección</button>`:'';
   const play=isVideoFile(f)?`<button class="small-btn play-file" data-file="${esc(f.file_id)}" data-name="${esc(f.file_name)}">Reproducir</button>`:'';
   const restore=`<button class="small-btn restore-file" data-file="${esc(f.file_id)}" data-name="${esc(f.file_name)}">Descargar</button>`;
   const del=`<button class="tiny-btn danger delete-file" data-file="${esc(f.file_id)}" data-name="${esc(f.file_name)}">Borrar</button>`;
   const distribution=fileDistributions[f.file_id];
   const distributionButton=`<button class="small-btn distribution-file" data-file="${esc(f.file_id)}" title="Mostrar proveedor, bloques y tamaño de cada fragmento cifrado">${distribution?'Ocultar detalles':'Dónde están'}</button>`;
   const folderOptions='<option value="">Sin carpeta</option>'+folders.map(x=>`<option value="${esc(x.id)}"${x.id===folderID?' selected':''}>${esc(x.name)}</option>`).join('');
   return `<article class="file-row"><div class="file-type" title="${esc(c.label)}">${esc(c.icon)}</div><div class="file-main"><strong>${esc(f.file_name)}</strong><small><span class="file-category-label">${esc(c.label)}</span>${ext?` · ${esc(ext)}`:''} · ${fmtBytes(f.original_size)} · SHA-256 registrado</small><small class="file-fragment-hint">${esc(fileDistributionHint(distribution))}</small><label class="file-folder-label">Carpeta <select class="file-folder-select" data-file="${esc(f.file_id)}">${folderOptions}</select></label></div><div class="file-health"><span class="risk-dot ${rv[1]}">${rv[2]}</span><div><strong>${rv[0]}</strong><small>${esc(status)} · ${esc(sub)}</small></div></div><div class="file-actions">${distributionButton}<button class="tiny-btn audit-file" data-file="${esc(f.file_id)}">Comprobar salud</button>${play}${restore}${repair}${del}</div>${distribution?`<div class="file-distribution-wrap">${fileDistributionMarkup(distribution)}</div>`:''}${h?`<div class="file-health-detail"><span>Integridad: ${h.corrupt_shards?'⚠ corrupción detectada':'✓ sin corrupción detectada en fragmentos accesibles'}</span><span>Proveedor: margen ${h.provider_failure_margin}</span><span>${esc(h.repair_reason||h.summary||'')}</span></div>`:''}</article>`
 }).join('');
 $$('.audit-file').forEach(b=>b.addEventListener('click',()=>auditFile(b.dataset.file)));
 $$('.repair-file').forEach(b=>b.addEventListener('click',()=>repairFile(b.dataset.file)));
 $$('.play-file').forEach(b=>b.addEventListener('click',()=>playFile(b.dataset.file,b.dataset.name)));
 $$('.restore-file').forEach(b=>b.addEventListener('click',()=>restoreFile(b.dataset.file,b.dataset.name)));
 $$('.delete-file').forEach(b=>b.addEventListener('click',()=>deleteFile(b.dataset.file,b.dataset.name)));
 $$('.distribution-file').forEach(b=>b.addEventListener('click',()=>toggleFileDistribution(b.dataset.file)));
 $$('.file-folder-select').forEach(el=>el.addEventListener('change',()=>assignLibraryFolder(el.dataset.file,el.value)));
}
async function refreshFiles(){
 try{const [fm,lm]=await Promise.all([api('/api/files'),api('/api/library')]);fileModel=fm;libraryModel=lm;renderFiles()}catch(e){fileModel={ready:false,files:[],reason:e.message};libraryModel={ready:false,folders:[],assignments:{},categories:[],file_categories:{},extensions:{}};renderFiles()}
}
function setLibraryMessage(msg,bad=false){const el=$('#library-msg');if(!el)return;el.textContent=msg||'';el.classList.toggle('bad-msg',bad)}
async function createLibraryFolder(ev){ev.preventDefault();const input=$('#library-folder-name');const name=input?.value||'';if(!name.trim())return;try{await api('/api/library/folders',{method:'POST',body:JSON.stringify({name})});input.value='';setLibraryMessage('✓ Carpeta creada.');await refreshFiles()}catch(e){setLibraryMessage(e.message,true)}}
async function renameLibraryFolder(id){const f=(libraryModel.folders||[]).find(x=>x.id===id);if(!f)return;const name=prompt('Nuevo nombre de la carpeta:',f.name);if(name===null)return;try{await api(`/api/library/folders/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({name})});setLibraryMessage('✓ Carpeta renombrada.');await refreshFiles()}catch(e){setLibraryMessage(e.message,true)}}
async function deleteLibraryFolder(id){const f=(libraryModel.folders||[]).find(x=>x.id===id);if(!f)return;if(!confirm(`¿Eliminar la carpeta virtual “${f.name}”? Los archivos no se borrarán ni se moverán en la nube; quedarán sin carpeta.`))return;try{await api(`/api/library/folders/${encodeURIComponent(id)}`,{method:'DELETE'});setLibraryMessage('✓ Carpeta eliminada; los archivos siguen protegidos.');await refreshFiles()}catch(e){setLibraryMessage(e.message,true)}}
async function assignLibraryFolder(fileID,folderID){try{await api(`/api/library/files/${encodeURIComponent(fileID)}/folder`,{method:'POST',body:JSON.stringify({folder_id:folderID})});libraryModel.assignments=libraryModel.assignments||{};if(folderID)libraryModel.assignments[fileID]=folderID;else delete libraryModel.assignments[fileID];setLibraryMessage('✓ Organización actualizada.');renderFiles()}catch(e){setLibraryMessage(e.message,true);await refreshFiles()}}
async function auditFile(id){
 const btn=document.querySelector(`.audit-file[data-file="${CSS.escape(id)}"]`);if(btn){btn.disabled=true;btn.textContent='Comprobando…'}
 try{const r=await api(`/api/files/${encodeURIComponent(id)}/audit`,{method:'POST'});fileHealth[id]=r.health;renderFiles();renderSystemHealth()}catch(e){alert(`Auditoría no completada: ${e.message}`);renderFiles()}
}
async function repairFile(id){
 if(!confirm('VaultPool reconstruirá solo fragmentos confirmados como perdidos o corruptos. Los fragmentos temporalmente inaccesibles no se moverán. ¿Continuar?'))return;
 const btn=document.querySelector(`.repair-file[data-file="${CSS.escape(id)}"]`);if(btn){btn.disabled=true;btn.textContent='Reparando…'}
 try{const r=await api(`/api/files/${encodeURIComponent(id)}/repair`,{method:'POST'});fileHealth[id]=r.health;await refreshFiles();renderFiles();renderSystemHealth()}catch(e){alert(`Reparación bloqueada o fallida: ${e.message}`);renderFiles()}
}
function renderSystemHealth(){
 const hs=Object.values(fileHealth),el=$('#system-health'),p=protectionStatus();if(!el)return;
 if(hs.some(h=>h.level==='UNRECOVERABLE'||h.level==='CRITICAL'))el.textContent='Atención urgente';
 else if(hs.some(h=>['HIGH','REDUCED'].includes(h.level)||h.unavailable_shards))el.textContent='Revisar archivos';
 else if(!p.ready)el.textContent='Configurar protección';
 else el.textContent='Protegido';
 renderProtection();
}

function transferPhaseLabel(j){
 const map={queued:'En cola',packaging:'Empaquetando carpeta',recovering:'Protegiendo la recuperación',preflight:'Analizando el archivo',compressing:'Comprimiendo',encrypting:'Cifrando',fragmenting:'Preparando fragmentos',uploading:'Subiendo y verificando',finalizing:'Verificando y confirmando',restoring:'Reconstruyendo y descifrando',verifying:'Verificando SHA-256 final',canceling:'Cancelando de forma segura',canceled:'Cancelada',complete:'Completada',failed:'Fallida'};
 return map[j.phase]||j.phase||'Preparando';
}
function transferPercent(j){if(!j.bytes_total)return 0;return Math.max(0,Math.min(100,(j.bytes_processed||0)/j.bytes_total*100))}
function fmtTransferDuration(ms){const seconds=Math.max(0,Math.round((Number(ms)||0)/1000));if(seconds<60)return seconds?`${seconds} s`:'<1 s';const minutes=Math.floor(seconds/60),rest=seconds%60;return rest?`${minutes} min ${rest} s`:`${minutes} min`}
function uploadReportMarkup(j){const r=j.upload_report;if(j.kind!=='upload'||j.state!=='completed'||!r)return '';const original=Number(r.original_bytes)||0,stored=Number(r.stored_bytes)||0,saved=Math.max(0,Number(r.compression_savings_bytes)||0),pct=original?Math.round(saved/original*100):0;const folderPackage=String(j.label||'').endsWith('.vaultpool-folder.zip');const compressionNote=folderPackage?'Carpeta empaquetada localmente; el paquete resultante se cifró y fragmentó.':saved>0?'Compresión sin pérdida aplicada.':'No se comprimió: el archivo ya estaba comprimido o no reducía su tamaño.';const labels={packaging:'Paquete carpeta',recovering:'Recuperación',preflight:'Análisis',compressing:'Compresión',encrypting:'Cifrado',fragmenting:'Fragmentación',uploading:'Subida',finalizing:'Confirmación'};const phases=Object.entries(labels).filter(([phase])=>Object.prototype.hasOwnProperty.call(r.phase_milliseconds||{},phase)).map(([phase,label])=>`<span><b>${esc(label)}</b>${esc(fmtTransferDuration(r.phase_milliseconds[phase]))}</span>`).join('');return `<section class="transfer-report"><div class="transfer-report-head"><strong>Resumen de protección</strong><small>Total ${esc(fmtTransferDuration(r.total_milliseconds))}</small></div><div class="transfer-report-stats"><span><b>Original</b>${esc(fmtBytes(original))}</span><span><b>Tras compresión</b>${esc(fmtBytes(stored))}</span><span><b>Ahorro</b>${esc(`${fmtBytes(saved)}${saved&&original?` (${pct}%)`:''}`)}</span><span><b>Datos cifrados</b>${esc(fmtBytes(r.encrypted_bytes||0))}</span><span><b>Distribuido</b>${esc(fmtBytes(r.distributed_bytes||0))}</span></div>${phases?`<div class="transfer-report-times">${phases}</div>`:''}<small class="transfer-report-note">${esc(compressionNote)}</small></section>`}
function renderTransfers(){
 const jobs=transferModel.jobs||[],root=$('#transfer-list');
 const active=jobs.filter(j=>['queued','running','canceling'].includes(j.state)).length;
 $('#transfer-active-count').textContent=active;
 $('#transfer-complete-count').textContent=jobs.filter(j=>j.state==='completed').length;
 $('#transfer-failed-count').textContent=jobs.filter(j=>j.state==='failed').length;
 if(!transferModel.ready){root.className='transfer-list empty-box';root.textContent='El servicio de transferencias no está disponible en este entorno.';return}
 if(!jobs.length){root.className='transfer-list empty-box';root.textContent='No hay transferencias en esta sesión.';return}
 root.className='transfer-list';
 root.innerHTML=jobs.map(j=>{const pct=transferPercent(j),canceling=j.state==='canceling',active=['queued','running'].includes(j.state);const icon=j.state==='completed'?'✓':j.state==='failed'?'×':j.state==='canceled'?'—':j.kind==='upload'?'↑':'↓';const kind=j.kind==='upload'?'Protegiendo':'Recuperando';const detail=j.bytes_total?`${fmtBytes(j.bytes_processed||0)} / ${fmtBytes(j.bytes_total)} · ${pct.toFixed(0)}%`:(j.phase==='packaging'?'Creando paquete local sin rutas absolutas':j.phase==='preflight'?'Leyendo el archivo para planificar sin escribir todavía':'Preparando…');const blocks=j.blocks_total?` · bloques ${j.blocks_done||0}/${j.blocks_total}`:'';return `<article class="transfer-row transfer-state-${esc(j.state)}"><div class="transfer-icon">${icon}</div><div class="transfer-main"><strong>${esc(j.label||'Transferencia')}</strong><small>${kind}${j.file_id?` · ${esc(j.file_id.slice(0,8))}…`:''}</small></div><div class="transfer-progress-wrap"><div class="transfer-progress-copy"><strong>${esc(transferPhaseLabel(j))}</strong><small>${esc(detail+blocks)}</small></div><progress class="transfer-progress" max="100" value="${pct.toFixed(2)}"></progress></div><div class="transfer-actions">${canceling?'<span class="status-pill warn">Cancelando…</span>':active?`<button class="tiny-btn cancel-transfer" data-transfer="${esc(j.id)}">Cancelar</button>`:`<span class="status-pill ${j.state==='completed'?'ok':j.state==='failed'?'bad':''}">${esc(j.state==='completed'?'Completada':j.state==='failed'?'Error':j.state==='canceled'?'Cancelada':'Finalizada')}</span>`}</div>${canceling?'<div class="transfer-cancel-note">Cancelación solicitada. VaultPool está esperando a que termine la operación remota de forma segura.</div>':''}${uploadReportMarkup(j)}${j.error?`<div class="transfer-error">${esc(j.error)}</div>`:''}</article>`}).join('');
 $$('.cancel-transfer').forEach(b=>b.addEventListener('click',()=>cancelTransfer(b.dataset.transfer)));
 jobs.forEach((j,index)=>{if(!['completed','failed','canceled'].includes(j.state))return;const actions=root.children[index]?.querySelector('.transfer-actions');if(!actions)return;const button=document.createElement('button');button.className='tiny-btn clear-transfer';button.dataset.transfer=j.id;button.textContent='Quitar';actions.append(button)});
 $$('.clear-transfer').forEach(b=>b.addEventListener('click',()=>removeTransferHistory(b.dataset.transfer)));
}
async function refreshTransfers(){
 try{
  const prev={...transferSeenStates};transferModel=await api('/api/transfers');
  for(const j of transferModel.jobs||[]){if(prev[j.id]!==j.state&&j.state==='completed'&&j.kind==='upload'){refreshFiles();refreshAccountsNow({force:true})}transferSeenStates[j.id]=j.state}
  renderTransfers();
 }catch(e){transferModel={ready:false,jobs:[]};renderTransfers()}
 scheduleTransferPoll();
}
function scheduleTransferPoll(){if(transferTimer)clearTimeout(transferTimer);const active=(transferModel.jobs||[]).some(j=>['queued','running','canceling'].includes(j.state));transferTimer=setTimeout(refreshTransfers,active?1200:5000)}
async function removeTransferHistory(id){try{await api(`/api/transfers/${encodeURIComponent(id)}`,{method:'DELETE'});await refreshTransfers();notify('Transferencia quitada de Actividad. El archivo protegido sigue en Archivos.')}catch(e){notify(`No se pudo quitar la transferencia: ${e.message}`,true)}}
async function clearTransferHistory(){const count=(transferModel.jobs||[]).filter(j=>['completed','failed','canceled'].includes(j.state)).length;if(!count){notify('No hay transferencias finalizadas para limpiar.');return}if(!confirm(`Se quitarán ${count} transferencias de Actividad. Los archivos protegidos seguirán disponibles en Archivos.`))return;try{await api('/api/transfers/history',{method:'DELETE'});await refreshTransfers();notify('Actividad limpiada. Los archivos protegidos siguen en Archivos.')}catch(e){notify(`No se pudo limpiar la actividad: ${e.message}`,true)}}
function nativeDialogBusyMessage(){return 'Ya hay un selector de Windows abierto. Ciérralo o elige un archivo en él antes de abrir otro.'}
function syncNativeDialogButtons(){const ready=!!dialogModel.ready,busy=nativeDialogBusy;for(const b of [$('#upload-path-browse'),$('#oauth-browser-browse')]){if(!b)continue;b.disabled=!ready||busy;b.title=busy?nativeDialogBusyMessage():(ready?'Abrir selector de Windows aislado':(dialogModel.reason||'Selector de Windows no disponible'))}for(const top of [$('#add-file'),$('#add-folder'),$('#upload-pick-and-protect'),$('#upload-pick-folder')]){if(top){top.disabled=busy;if(busy)top.title=nativeDialogBusyMessage()}}}
async function withNativeDialog(open){if(nativeDialogBusy){notify(nativeDialogBusyMessage(),true);return null}nativeDialogBusy=true;syncNativeDialogButtons();try{return await open()}finally{nativeDialogBusy=false;syncNativeDialogButtons();renderProtection()}}
function nativeDialogError(e){const message=String(e?.message||e||'');return message.includes('another native file dialog')?nativeDialogBusyMessage():message}
async function refreshDialogStatus(){
 try{dialogModel=await api('/api/dialogs/status')}catch(_){dialogModel={ready:false,safe_mode:true,reason:'Selector de Windows no disponible'}}
 const ready=!!dialogModel.ready;
 const disabledText=dialogModel.reason||'Selector de Windows no disponible: pega la ruta manualmente.';
 const readyText='Selector de Windows disponible en proceso aislado. Si no responde, VaultPool lo cancelará y podrás pegar la ruta manual.';
 const upload=$('#upload-path-browse'),browser=$('#oauth-browser-browse'),status=$('#upload-dialog-status'),pathMsg=$('#upload-path-msg');
 for(const b of [upload,browser]){
  if(!b)continue;
  b.disabled=!ready;
  b.textContent=ready?'Examinar':'Examinar desactivado';
  b.title=ready?'Abrir selector de Windows aislado':disabledText;
 }
 if(status)status.textContent=ready?readyText:disabledText;
 if(pathMsg)pathMsg.textContent=ready?'También puedes pegar aquí la ruta completa de un archivo o carpeta. La ruta nunca se publica en Actividad.':'Selector no disponible: pega aquí la ruta completa de un archivo o carpeta. La ruta nunca se publica en Actividad.';
 syncNativeDialogButtons();
}
async function pickUploadPath(){if(!dialogModel.ready){$('#upload-path')?.focus();return}const b=$('#upload-path-browse');const old=b?.textContent;if(b){b.disabled=true;b.textContent='Abriendo…'}try{const r=await withNativeDialog(()=>apiTimeout('/api/dialogs/open-file',{method:'POST'},95000));if(r?.selected&&r.path)$('#upload-path').value=r.path}catch(e){alert(`No se pudo abrir el selector de Windows: ${nativeDialogError(e)}`)}finally{if(b){b.disabled=nativeDialogBusy||!dialogModel.ready;b.textContent=old||'Examinar'}}}
async function pickRestorePath(name){if(dialogModel.ready){const r=await withNativeDialog(()=>apiTimeout('/api/dialogs/save-file',{method:'POST',body:JSON.stringify({suggested_name:name||''})},95000));return r?.selected?r.path:''}return prompt(`Ruta ABSOLUTA donde recuperar “${name}”.\nVaultPool no reemplazará el destino hasta verificar el SHA-256 completo.`,'')||''}
async function queueUpload(path){await api('/api/transfers/upload',{method:'POST',body:JSON.stringify({path})});await refreshTransfers();switchView('activity')}
async function queueFolderUpload(path){await api('/api/transfers/upload-folder',{method:'POST',body:JSON.stringify({path})});await refreshTransfers();switchView('activity');notify('Carpeta puesta en cola como un único paquete local comprimido y cifrado.')}
async function startUploadPath(ev){ev.preventDefault();const path=$('#upload-path').value.trim();if(!path)return;const blocked=explainUploadBlock();if(blocked){notify(blocked,true);alert(blocked);return}const btn=$('#upload-path-submit');btn.disabled=true;btn.textContent='Iniciando…';try{await queueUpload(path);$('#upload-path').value=''}catch(e){alert(`No se pudo iniciar la protección: ${e.message}`)}finally{btn.disabled=false;btn.textContent='Proteger ruta'}}
function explainUploadBlock(){const p=protectionStatus();if(!fileModel.ready)return fileModel.reason||'La gestión segura de archivos no está disponible.';if(!fileModel.recovery_configured)return 'Antes de añadir archivos hay que confirmar el kit de recuperación portable. VaultPool no subirá datos si luego no puede recuperar las claves.';if(!p.ready)return p.reason||'Conecta y verifica al menos dos proveedores independientes antes de proteger archivos.';return ''}
async function prepareUploadDialog(){
 if(nativeDialogBusy)return false;
 switchView('files');
 try{await Promise.all([refresh(),refreshFiles(),refreshDialogStatus()])}catch{}
 if(dialogModel.ready)return true;
 notify(dialogModel.reason||'Selector no disponible. Pega la ruta manualmente.',true);
 document.querySelector('.advanced-path')?.setAttribute('open','open');
 $('#upload-path')?.focus();
 return false;
}
async function addFileFromTop(ev){if(nativeDialogBusy){notify(nativeDialogBusyMessage(),true);return}if(!await prepareUploadDialog())return;const btn=ev?.currentTarget||$('#add-file');const old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Seleccionando…'}try{const r=await withNativeDialog(()=>apiTimeout('/api/dialogs/open-file',{method:'POST'},95000));if(r?.selected&&r.path){const blocked=explainUploadBlock();if(blocked){notify(blocked,true);return}await queueUpload(r.path)}else if(r){notify('Selección cancelada. Puedes pegar la ruta manualmente en Archivos.')}}catch(e){notify(`Selector falló: ${nativeDialogError(e)}. Abre el modo avanzado y pega la ruta manualmente.`,true);document.querySelector('.advanced-path')?.setAttribute('open','open');$('#upload-path')?.focus()}finally{if(btn){btn.disabled=nativeDialogBusy;btn.textContent=old||'Subir archivo'}renderProtection()}}
async function restoreFile(id,name){let out='';try{out=await pickRestorePath(name)}catch(e){alert(`No se pudo abrir el selector de Windows: ${e.message}`);return}if(!out)return;try{await api('/api/transfers/restore',{method:'POST',body:JSON.stringify({file_id:id,output_path:out})});await refreshTransfers();switchView('activity');notify('Descarga/recuperación iniciada. Verifica el archivo antes de borrar nada.')}catch(e){alert(`No se pudo iniciar la descarga: ${e.message}`)}}
async function deleteFile(id,name){
 const safeName=String(name||'');
 const msg=`Vas a borrar “${safeName}” de VaultPool.

Esto elimina los fragmentos cifrados, manifiestos y registros de recuperación de las nubes conectadas. Los archivos ajenos o anteriores a VaultPool NO se tocarán.

Recomendado: pulsa Cancelar, usa Descargar y comprueba la copia antes de borrar.

Para confirmar escribe exactamente el nombre del archivo:`;
 const typed=prompt(msg,'');
 if(typed===null)return;
 if(typed!==safeName){alert('Nombre no coincide. Borrado cancelado.');return}
 if(!confirm('Última confirmación: este borrado es voluntario e irreversible desde VaultPool. ¿Continuar?'))return;
 const btn=document.querySelector(`.delete-file[data-file="${CSS.escape(id)}"]`);const old=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Borrando…'}
 try{const r=await apiTimeout(`/api/files/${encodeURIComponent(id)}`,{method:'DELETE',body:JSON.stringify({confirm_name:safeName,understand_irreversible:true})},120000);await refreshFiles();await refresh();notify(`Archivo borrado de VaultPool. Objetos eliminados: ${r.result?.report?.data_objects_deleted||0}.`)}catch(e){alert(`No se pudo completar el borrado: ${e.message}

VaultPool conserva el catálogo local para que puedas reintentar y no perder control sobre objetos huérfanos.`);await refreshFiles()}finally{if(btn){btn.disabled=false;btn.textContent=old||'Borrar'}}
}
function showAccountDataPolicy(accountID){
 const a=(model.accounts||[]).find(x=>x.id===accountID);if(!a)return;
 const p=model.providers_by_id?.[a.provider_id]||{name:a.provider_id};
 const used=fmtBytes(a.used_bytes||0),free=fmtBytes(a.free_bytes||0),total=fmtBytes(a.total_bytes||0);
 alert(`${p.name}: ${used} ocupado · ${free} libre · ${total} total.

Política VaultPool:
• Los archivos anteriores o ajenos a VaultPool cuentan como ocupado, pero no se tocan automáticamente.
• Borrado directo desde VaultPool solo para objetos propios cifrados y autenticados.
• Limpieza de datos previos requiere un modo avanzado separado, con inventario, selección archivo a archivo, opción Descargar antes de borrar y permisos ampliados explícitos.

No habrá botón de “borrar todo” sin vista previa y confirmación.`);
}

async function cancelTransfer(id){if(!confirm('¿Cancelar esta transferencia? VaultPool conservará cualquier estado ya comprometido y limpiará solo lo que sea seguro eliminar.'))return;try{await api(`/api/transfers/${encodeURIComponent(id)}/cancel`,{method:'POST'});notify('Cancelación solicitada. Se cerrará la operación remota antes de marcarla como cancelada.');await refreshTransfers()}catch(e){alert(`No se pudo cancelar: ${e.message}`)}}

function ensureSummaryDonut(){const card=$('.summary-card.storage');if(!card)return null;let d=$('#summary-storage-donut');if(!d){d=document.createElement('div');d.id='summary-storage-donut';d.className='quota-donut summary-donut';d.innerHTML='<span>—</span>';card.appendChild(d)}return d}
function renderSummary(){let total=0,used=0;for(const a of model.accounts||[]){if(a.state!=='connected')continue;total+=a.total_bytes||0;used+=a.used_bytes||0}const free=Math.max(0,total-used),pct=quotaPercent(used,total);$('#total-capacity').textContent=total?fmtBytes(total):'0 GB';$('#total-used').textContent=total?`${fmtBytes(used)} ocupado · ${fmtBytes(free)} libre · ${fmtBytes(total)} total`:'Todavía no hay cuotas verificadas';const d=ensureSummaryDonut();if(d){d.style.setProperty('--pct',pct.toFixed(2));d.title=total?`Ocupado ${fmtBytes(used)} de ${fmtBytes(total)} (${pct.toFixed(1)}%)`:'Cuota sin verificar';const sp=d.querySelector('span');if(sp)sp.textContent=total?`${pct.toFixed(0)}%`:'—'}}
function render(){renderAccounts();renderProviders();renderSummary();renderFiles();renderSystemHealth()}
async function refresh(){model=await api('/api/overview');model.providers_by_id=Object.fromEntries((model.all_providers||[]).map(p=>[p.id,p]));render()}
function scheduleAccountAutoRefresh(delay=accountAutoRefreshEvery){if(accountRefreshTimer)clearTimeout(accountRefreshTimer);accountRefreshTimer=setTimeout(()=>refreshAccountsNow({force:false}),delay)}
async function refreshAccountsNow({manual=false,force=false}={}){
 if(accountRefreshBusy)return;
 const accounts=accountsForQuotaRefresh();
 if(!accounts.length){setAccountRefreshUI(false);if(manual)notify('No hay cuentas conectadas para actualizar.');scheduleAccountAutoRefresh();return}
 const now=Date.now();
 if(!force&&now-accountRefreshLast<accountAutoRefreshCooldown){scheduleAccountAutoRefresh(accountAutoRefreshCooldown);return}
 if(!manual&&!force&&hasActiveTransfers()){scheduleAccountAutoRefresh(30000);return}
 accountRefreshBusy=true;accountRefreshLast=now;setAccountRefreshUI(true);
 let ok=0,fail=0;
 try{
  for(const a of accounts){
   try{await apiTimeout(`/api/accounts/${encodeURIComponent(a.id)}/probe`,{method:'POST'},20000);ok++}
   catch(_){fail++}
  }
  await refresh();
  if(manual)notify(fail?`Actualizadas ${ok} cuenta${ok===1?'':'s'}; ${fail} requieren atención.`:`${ok} cuenta${ok===1?'':'s'} actualizada${ok===1?'':'s'}.`,!!fail);
 }finally{
  accountRefreshBusy=false;setAccountRefreshUI(false);scheduleAccountAutoRefresh();
 }
}
function authCopy(plan,p){if(plan.mode==='system_browser_oauth')return `VaultPool abrirá ${p.name} en ${oauthBrowserModel.effective_label||'el navegador predeterminado del sistema'}. ${plan.oauth_pkce?'El flujo exige PKCE. ':''}La cuenta seguirá pendiente hasta que un conector real valide el retorno y la cuota.`;if(plan.mode==='embedded_webview')return 'La página oficial se mostrará dentro de una WebView aislada permitida por el proveedor. Cualquier CAPTCHA lo resolverás manualmente.';if(plan.mode==='device_code')return 'VaultPool mostrará un código y una web oficial de verificación. El usuario completa el acceso manualmente.';if(plan.mode==='direct_credentials'){if(p.id==='filen')return 'Conecta directamente tu cuenta de Filen. Tus credenciales se utilizan localmente para iniciar sesión y VaultPool no necesita un servidor propio.';if(p.id==='mediafire')return 'MediaFire se conecta mediante su API oficial HTTPS. La contraseña se usa una sola vez y VaultPool guarda exclusivamente la sesión v2 cifrada en la bóveda local.';if(p.generic_protocol==='webdav')return `Conecta otra cuenta de ${p.name} al endpoint WebDAV HTTPS ya auditado. Las credenciales quedan separadas por cuenta dentro de la bóveda cifrada local.`;return 'Las credenciales solo podrán introducirse cuando la bóveda cifrada esté disponible.'}if(plan.mode==='external_session')return p.id==='mega'?'MEGA está protegido en el flujo normal: VaultPool no abrirá consola ni pedirá comandos. Si ya iniciaste sesión en MEGAcmd, pulsa Comprobar. Para usuarios finales este proveedor necesita un asistente gráfico o integración directa antes de publicarse.':`VaultPool abrirá el cliente oficial de ${p.name}. Inicia sesión allí; VaultPool no recibirá ni guardará tu contraseña y solo comprobará la sesión resultante.`;return plan.reason||'Este proveedor no tiene un flujo de autenticación aprobado.'}
function openAuthModal(p,plan,ready,accountID,status=''){
 clearAuthPoll();clearFilenAuthFields();authModalAccount=accountID;authModalReady=ready;authModalMode=plan.mode;authModalProvider=p.id;applyOAuthTerms(p.id);
 const blocked=p.id==='mega'&&plan.mode==='external_session',directFilen=p.id==='filen'&&plan.mode==='direct_credentials',directMediaFire=p.id==='mediafire'&&plan.mode==='direct_credentials',directWebDAV=p.generic_protocol==='webdav'&&plan.mode==='direct_credentials';
 $('#auth-title').textContent=`Conectar ${p.name}`;$('#auth-text').textContent=authCopy(plan,p);
 $('#auth-ready').textContent=blocked?'MEGA no abrirá consola en el flujo normal. Comprueba una sesión existente o usa un asistente gráfico cuando esté disponible.':(status||(ready?'Conector y bóveda listos':'Conector todavía no configurado'));
 $('#auth-ready').className=`connector-readiness ${ready&&!blocked?'ready':'pending'}`;
 const oauthSetup=$('#auth-oauth-setup'),megaSetup=$('#auth-mega-setup'),filenSetup=$('#auth-filen-setup'),mediafireSetup=$('#auth-mediafire-setup'),webdavSetup=$('#auth-webdav-setup');
 oauthSetup?.classList.toggle('hidden',ready||plan.mode!=='system_browser_oauth');megaSetup?.classList.toggle('hidden',p.id!=='mega');filenSetup?.classList.toggle('hidden',!directFilen);mediafireSetup?.classList.toggle('hidden',!directMediaFire);webdavSetup?.classList.toggle('hidden',!directWebDAV);
 if($('#auth-client-id'))$('#auth-client-id').value='';if($('#auth-client-secret'))$('#auth-client-secret').value='';$('#auth-client-secret-wrap')?.classList.toggle('hidden',!['google-drive','pcloud'].includes(p.id));
 const btn=$('#auth-continue');btn.disabled=false;btn.classList.toggle('hidden',directFilen||directMediaFire||directWebDAV);btn.textContent=blocked?'Cerrar':ready&&plan.mode==='system_browser_oauth'?'Abrir acceso seguro':ready&&plan.mode==='external_session'?'Abrir cliente oficial':'Cerrar';
 $('#auth-modal').classList.remove('hidden');
}
function closeResponsibleModal(result=false){const modal=$('#responsible-modal');modal?.classList.add('hidden');const resolve=responsibleResolver;responsibleResolver=null;if(resolve)resolve(!!result)}
function requestResponsibleUse(p){
 const modal=$('#responsible-modal');if(!modal)return Promise.resolve(confirm(`Uso responsable de varias cuentas\n\nVaultPool permite conectar varias cuentas legítimas de ${p?.name||'este proveedor'}. Eres responsable de cumplir sus condiciones. No uses esta función para crear cuentas en masa ni eludir límites.`));
 if(responsibleResolver)closeResponsibleModal(false);
 const copy=$('#responsible-provider-copy');if(copy)copy.textContent=`Vas a añadir otra cuenta de ${p?.name||'este proveedor'}. Esta confirmación se pide desde la segunda cuenta.`;
 modal.classList.remove('hidden');return new Promise(resolve=>{responsibleResolver=resolve});
}
async function addProvider(id){id=String(id||'').trim().toLowerCase();const existing=(model.accounts||[]).filter(a=>String(a.provider_id||'').toLowerCase()===id).length;let confirmed=false;if(existing>0){const p=model.providers_by_id[id]||{id,name:id};confirmed=await requestResponsibleUse(p);if(!confirmed)return}try{const r=await api('/api/accounts',{method:'POST',body:JSON.stringify({provider_id:id,responsible_use_confirmed:confirmed})});openAuthModal(r.provider,r.auth,!!r.connector_ready,r.account.id,r.connector_status||'');await refresh()}catch(e){alert(e.message)}}
async function showAuthPlan(accountID){try{const r=await api(`/api/accounts/${encodeURIComponent(accountID)}/auth-plan`);openAuthModal(r.provider,r.auth,!!r.connector_ready,r.account.id,r.connector_status||'')}catch(e){alert(e.message)}}
function setFilenTwoFactorMode(on,message=''){
 filenTwoFactorPending=!!on;$('#auth-filen-credentials')?.classList.toggle('hidden',on);$('#auth-filen-2fa-wrap')?.classList.toggle('hidden',!on);
 const email=$('#auth-filen-email'),password=$('#auth-filen-password'),code=$('#auth-filen-2fa');if(email)email.required=!on;if(password)password.required=!on;if(code)code.required=on;
 const btn=$('#auth-filen-submit');if(btn)btn.textContent=on?'Verificar':'Conectar';const msg=$('#auth-filen-msg');if(msg){msg.textContent=message;msg.classList.toggle('bad-msg',false)}
}
function filenErrorMessage(err){
 const message=String(err?.message||'').trim();
 if(/failed to fetch/i.test(message))return 'VaultPool perdió la conexión local antes de recibir la respuesta de Filen. La cuenta sigue pendiente; vuelve a pulsar Conectar. Si se repite, reinicia VaultPool e inténtalo otra vez.';
 return message||'No se pudo conectar Filen.';
}
async function connectFilen(e){
 e.preventDefault();if(!authModalAccount||authModalProvider!=='filen')return;
 const email=$('#auth-filen-email'),password=$('#auth-filen-password'),code=$('#auth-filen-2fa'),btn=$('#auth-filen-submit'),msg=$('#auth-filen-msg');
 const payload={email:email?.value.trim()||'',password:password?.value||'',two_factor_code:filenTwoFactorPending?(code?.value.trim()||''):''};
 if(!payload.email||(!filenTwoFactorPending&&!payload.password)||(filenTwoFactorPending&&!payload.two_factor_code)){if(msg){msg.textContent=filenTwoFactorPending?'Introduce tu código de verificación de Filen.':'Introduce el email y la contraseña de Filen.';msg.classList.add('bad-msg')}return}
 btn.disabled=true;const old=btn.textContent;btn.textContent=filenTwoFactorPending?'Verificando…':'Conectando…';
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),95000);
 try{
  const r=await rawFetch(`/api/accounts/${encodeURIComponent(authModalAccount)}/filen/login`,{method:'POST',body:JSON.stringify(payload),signal:ctrl.signal});let body={};try{body=await r.json()}catch{}
  if(!r.ok){const err=new Error(body.error||`HTTP ${r.status}`);err.code=body.code||'';err.twoFactorRequired=!!body.two_factor_required;throw err}
  clearFilenAuthFields();closeAuthModal();await refresh();notify('Cuenta Filen conectada y cuota verificada.');
 }catch(err){
  if(err?.name==='AbortError'){if(msg){msg.textContent='El inicio de sesión tardó demasiado y fue cancelado. Puedes volver a intentarlo.';msg.classList.add('bad-msg')}return}
  if(err?.twoFactorRequired||err?.code==='two_factor_required'){setFilenTwoFactorMode(true,err.message||'Introduce tu código de verificación de Filen.');code?.focus();return}
  if(err?.code==='two_factor_invalid'){setFilenTwoFactorMode(true,err.message||'El código de verificación de Filen no es válido.');if(code)code.value='';code?.focus();return}
  const message=filenErrorMessage(err);setFilenTwoFactorMode(false,message);notify(`Filen no se conectó: ${message}`,true);if(password)password.value='';if(code)code.value='';
 }finally{clearTimeout(timer);btn.disabled=false;if(btn.textContent==='Conectando…'||btn.textContent==='Verificando…')btn.textContent=old}
}
async function disconnectFilen(accountID){
 if(!confirm('¿Desconectar Filen? Se borrará la sesión local, pero no se eliminarán la carpeta VaultPool ni ningún dato remoto.'))return;
 try{await api(`/api/accounts/${encodeURIComponent(accountID)}/filen/logout`,{method:'POST'});await refresh();notify('Filen desconectado. Los datos remotos se conservaron.')}catch(e){notify(`No se pudo desconectar Filen: ${e.message}`,true)}
}
async function connectMediaFire(e){e.preventDefault();if(!authModalAccount||authModalProvider!=='mediafire')return;const app=$('#auth-mediafire-app-id'),email=$('#auth-mediafire-email'),password=$('#auth-mediafire-password'),btn=$('#auth-mediafire-submit'),msg=$('#auth-mediafire-msg');const payload={application_id:app?.value.trim()||'',email:email?.value.trim()||'',password:password?.value||''};if(!payload.application_id||!payload.email||!payload.password){if(msg){msg.textContent='Introduce el Application ID, email y contraseña de MediaFire.';msg.classList.add('bad-msg')}return}btn.disabled=true;const old=btn.textContent;btn.textContent='Conectando…';const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),95000);try{const r=await rawFetch(`/api/accounts/${encodeURIComponent(authModalAccount)}/mediafire/login`,{method:'POST',body:JSON.stringify(payload),signal:ctrl.signal});let body={};try{body=await r.json()}catch{}if(!r.ok)throw new Error(body.error||`HTTP ${r.status}`);if(password)password.value='';closeAuthModal();await refresh();notify('Cuenta MediaFire conectada y cuota verificada.')}catch(err){if(msg){msg.textContent=err?.name==='AbortError'?'El inicio de sesión tardó demasiado y fue cancelado.':String(err.message||'No se pudo conectar MediaFire.');msg.classList.add('bad-msg')}if(password)password.value=''}finally{clearTimeout(timer);btn.disabled=false;btn.textContent=old}}
async function disconnectMediaFire(accountID){if(!confirm('¿Desconectar MediaFire? Se borrará solo la sesión local cifrada; los datos remotos no se eliminarán.'))return;try{await api(`/api/accounts/${encodeURIComponent(accountID)}/mediafire/logout`,{method:'POST'});await refresh();notify('MediaFire desconectado. Los datos remotos se conservaron.')}catch(e){notify(`No se pudo desconectar MediaFire: ${e.message}`,true)}}
async function connectWebDAV(e){e.preventDefault();if(!authModalAccount)return;const p=model.providers_by_id[authModalProvider];if(!p||p.generic_protocol!=='webdav')return;const user=$('#auth-webdav-user'),password=$('#auth-webdav-password'),btn=$('#auth-webdav-submit'),msg=$('#auth-webdav-msg');const payload={username:user?.value.trim()||'',password:password?.value||''};if(!payload.username||!payload.password){if(msg){msg.textContent='Introduce el usuario y la contraseña/token WebDAV.';msg.classList.add('bad-msg')}return}btn.disabled=true;const old=btn.textContent;btn.textContent='Conectando…';try{await apiTimeout(`/api/accounts/${encodeURIComponent(authModalAccount)}/webdav/login`,{method:'POST',body:JSON.stringify(payload)},30000);if(password)password.value='';closeAuthModal();await refresh();notify(`Cuenta ${p.name} conectada y cuota verificada.`)}catch(err){if(password)password.value='';if(msg){msg.textContent=err.message||'No se pudo conectar la cuenta WebDAV.';msg.classList.add('bad-msg')}}finally{btn.disabled=false;btn.textContent=old}}
async function disconnectAccount(accountID,providerName='esta cuenta'){if(!confirm(`¿Desconectar ${providerName}? Se borrará solo la sesión local de esta cuenta. Los datos remotos y las demás cuentas del mismo proveedor se conservarán.`))return;try{await api(`/api/accounts/${encodeURIComponent(accountID)}/disconnect`,{method:'POST'});await refresh();notify(`${providerName} desconectada. Los datos remotos se conservaron.`)}catch(e){notify(`No se pudo desconectar la cuenta: ${e.message}`,true)}}
async function configureOAuthFromModal(){if(!authModalProvider||!authModalAccount)return;const input=$('#auth-client-id'),clientID=input?.value.trim()||'';const secretInput=$('#auth-client-secret'),clientSecret=['google-drive','pcloud'].includes(authModalProvider)?(secretInput?.value.trim()||''):'';if(!clientID){alert(oauthTerms(authModalProvider).empty);input?.focus();return}if(authModalProvider==='pcloud'&&!clientSecret){alert('Introduce también el Client Secret de pCloud.');secretInput?.focus();return}const payload={client_id:clientID};if(clientSecret)payload.client_secret=clientSecret;const btn=$('#auth-save-client');btn.disabled=true;btn.textContent='Guardando…';try{await api(`/api/connectors/${encodeURIComponent(authModalProvider)}/configure`,{method:'POST',body:JSON.stringify(payload)});if(secretInput)secretInput.value='';await refresh();await showAuthPlan(authModalAccount)}catch(e){alert(`No se pudo activar el conector: ${e.message}`)}finally{btn.disabled=false;btn.textContent=oauthTerms(authModalProvider).save}}
async function recheckAuthModal(){if(!authModalAccount)return;await refresh();await showAuthPlan(authModalAccount)}
async function probeAccount(accountID){const buttons=$$('.probe-account').filter(b=>b.dataset.account===accountID);const prev=buttons.map(b=>b.textContent);buttons.forEach(b=>{b.disabled=true;b.textContent='Comprobando…'});try{await apiTimeout(`/api/accounts/${encodeURIComponent(accountID)}/probe`,{method:'POST'},20000);accountRefreshLast=Date.now();await refresh();notify('Cuenta comprobada correctamente.')}catch(e){notify(`No se pudo comprobar: ${e.message}`,true);alert(`No se ha modificado la cuenta: ${e.message}`);await refresh()}finally{buttons.forEach((b,i)=>{b.disabled=false;b.textContent=prev[i]||'Comprobar'});setAccountRefreshUI(accountRefreshBusy);scheduleAccountAutoRefresh()}}
function switchView(id){$$('.view').forEach(v=>v.classList.remove('active-view'));$('#'+id)?.classList.add('active-view');$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===id));if(id==='files'){refreshFiles();refreshDialogStatus()}if(id==='activity')refreshTransfers();if(id==='settings')refreshRecovery()}

function setRecoveryMessage(text,bad=false){const el=$('#recovery-msg');if(!el)return;el.textContent=text||'';el.classList.toggle('bad-msg',!!bad)}
function hideRecoveryCode(){const i=$('#recovery-code');if(i)i.type='password';if(recoveryRevealTimer){clearTimeout(recoveryRevealTimer);recoveryRevealTimer=null}}
function toggleRecoveryCode(){const i=$('#recovery-code');if(!i)return;if(i.type==='password'){i.type='text';if(recoveryRevealTimer)clearTimeout(recoveryRevealTimer);recoveryRevealTimer=setTimeout(hideRecoveryCode,30000)}else hideRecoveryCode()}
async function copyRecoveryCode(){if(!currentRecoveryCode)return;const copied=currentRecoveryCode;try{await navigator.clipboard.writeText(copied);if(clipboardClearTimer)clearTimeout(clipboardClearTimer);clipboardClearTimer=setTimeout(async()=>{try{const now=await navigator.clipboard.readText();if(now===copied)await navigator.clipboard.writeText('')}catch{}},45000);setRecoveryMessage('Código copiado. VaultPool intentará retirarlo del portapapeles en 45 segundos si sigue siendo el mismo contenido.')}catch{setRecoveryMessage('No se pudo copiar automáticamente; usa el botón de revelar y copia manualmente.',true)}}

function renderDrive(){
 const d=driveModel||{},pill=$('#drive-state-pill'),note=$('#drive-driver-note'),mount=$('#drive-mount'),unmount=$('#drive-unmount'),letter=$('#drive-letter');
 if(pill){if(d.running){pill.textContent=`Montada ${d.mount_point||''}`.trim();pill.className='status-pill ok'}else if(!d.supported){pill.textContent='Solo Windows';pill.className='status-pill warn'}else if(!d.installed){pill.textContent='Dokany 2 no instalado';pill.className='status-pill warn'}else if(!d.compatible){pill.textContent='Dokany incompatible';pill.className='status-pill bad'}else{pill.textContent='Lista para montar';pill.className='status-pill'}}
 if(note){if(!d.supported)note.textContent='La unidad virtual solo está disponible en Windows. GUI y CLI siguen funcionando sin ella.';else if(!d.installed)note.textContent='Dokany 2 no está instalado o su driver firmado no está disponible. VaultPool no instalará un driver en silencio.';else if(!d.compatible)note.textContent=`Dokany detectado pero incompatible (DLL ${d.library_version||'—'} · driver ${d.driver_version||'—'}).`;else note.textContent=`Dokany 2 listo · DLL ${d.library_version||'—'} · driver ${d.driver_version||'—'} · solo lectura.`}
 if(letter){letter.disabled=!!d.running;if(d.running&&d.mount_point)letter.value=String(d.mount_point).replace('\\','')}
 if(mount)mount.disabled=!!d.running||!d.supported||!d.installed||!d.compatible;
 if(unmount)unmount.disabled=!d.running;
}
function setDriveMessage(msg,bad=false){const el=$('#drive-msg');if(!el)return;el.textContent=msg||'';el.classList.toggle('bad-msg',bad)}
async function refreshDrive(){try{driveModel=await api('/api/drive/status');renderDrive()}catch(e){driveModel={supported:false,installed:false,compatible:false,running:false,read_only:true,backend:'dokany2',last_error:e.message};renderDrive();setDriveMessage(e.message,true)}}
async function mountDrive(ev){ev?.preventDefault();const point=($('#drive-letter')?.value||'P:').trim().toUpperCase();setDriveMessage('Montando unidad…');try{driveModel=await api('/api/drive/mount',{method:'POST',body:JSON.stringify({mount_point:point})});renderDrive();setDriveMessage(`✓ Unidad VaultPool montada en ${driveModel.mount_point||point} (solo lectura).`)}catch(e){await refreshDrive();setDriveMessage(`No se pudo montar: ${e.message}`,true)}}
async function unmountDrive(){setDriveMessage('Desmontando…');try{driveModel=await api('/api/drive/unmount',{method:'POST'});renderDrive();setDriveMessage('✓ Unidad desmontada de forma segura.')}catch(e){await refreshDrive();setDriveMessage(`No se pudo desmontar: ${e.message}`,true)}}

function renderRecovery(){
 const r=recoveryModel||{},available=!!r.available;
 $('#recovery-unavailable')?.classList.toggle('hidden',available);
 $('#recovery-setup')?.classList.toggle('hidden',!available||r.configured||r.pending);
 $('#recovery-pending')?.classList.toggle('hidden',!available||!r.pending);
 $('#recovery-configured')?.classList.toggle('hidden',!available||!r.configured);
 $('#restore-form')?.classList.toggle('hidden',!available||!!r.restore_pending);
 $('#restore-pending')?.classList.toggle('hidden',!available||!r.restore_pending);
 $('#credential-refresh-warning')?.classList.toggle('hidden',!available||!r.configured||!r.credentials_refresh_required);
 $('#catalog-recovery-panel')?.classList.toggle('hidden',!available||!r.configured||!!r.restore_pending);
 const pill=$('#recovery-state-pill');if(pill){if(!available){pill.textContent='No disponible';pill.className='status-pill warn'}else if(r.restore_pending){pill.textContent='Reinicio requerido';pill.className='status-pill warn'}else if(r.configured&&r.credentials_refresh_required){pill.textContent='Credenciales: copia pendiente';pill.className='status-pill warn'}else if(r.configured){pill.textContent='Protegido';pill.className='status-pill ok'}else if(r.pending){pill.textContent='Pendiente';pill.className='status-pill warn'}else{pill.textContent='Sin configurar';pill.className='status-pill'}}
 $('#recovery-code-wrap')?.classList.toggle('hidden',!currentRecoveryCode);
 if(currentRecoveryCode&&$('#recovery-code'))$('#recovery-code').value=currentRecoveryCode;
 const c=$('#recovery-confirm');if(c)c.disabled=!($('#saved-package')?.checked&&$('#saved-code')?.checked);
 const cr=$('#credential-refresh-confirm');if(cr)cr.disabled=!$('#credential-refresh-saved')?.checked||!r.credentials_refresh_required;
}
async function refreshRecovery(){try{recoveryModel=await api('/api/recovery/status');renderRecovery()}catch(e){recoveryModel={available:false};renderRecovery();setRecoveryMessage(e.message,true)}}
async function beginRecovery(){if(recoveryModel.pending&&!confirm('Regenerar el kit invalidará el código pendiente anterior. ¿Continuar?'))return;setRecoveryMessage('Generando kit…');try{const r=await api('/api/recovery/begin',{method:'POST'});currentRecoveryCode=r.recovery_code||'';recoveryModel=r.status||{};$('#saved-package').checked=false;$('#saved-code').checked=false;renderRecovery();setRecoveryMessage('Kit generado. Guarda el paquete y el código antes de confirmar.')}catch(e){setRecoveryMessage(e.message,true)}}
async function downloadRecoveryPackage(){try{const r=await rawFetch('/api/recovery/package',{method:'POST'});if(!r.ok){let b={};try{b=await r.json()}catch{}throw new Error(b.error||`HTTP ${r.status}`)}const blob=await r.blob();const cd=r.headers.get('Content-Disposition')||'';const m=/filename="?([^";]+)"?/i.exec(cd);const name=m?.[1]||'VaultPool-Recovery.vpr';const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);setRecoveryMessage('Paquete descargado. Guárdalo fuera de este PC.')}catch(e){setRecoveryMessage(e.message,true)}}
async function confirmRecovery(){try{const r=await api('/api/recovery/confirm',{method:'POST',body:JSON.stringify({saved_package:!!$('#saved-package').checked,saved_code:!!$('#saved-code').checked})});recoveryModel=r;currentRecoveryCode='';hideRecoveryCode();if($('#recovery-code'))$('#recovery-code').value='';renderRecovery();await refreshFiles();setRecoveryMessage('✓ Recuperación portable confirmada.')}catch(e){setRecoveryMessage(e.message,true)}}
async function confirmCredentialRefresh(){try{const r=await api('/api/recovery/confirm-credential-refresh',{method:'POST',body:JSON.stringify({saved_package:!!$('#credential-refresh-saved')?.checked})});recoveryModel=r;if($('#credential-refresh-saved'))$('#credential-refresh-saved').checked=false;renderRecovery();setRecoveryMessage('✓ Copia externa de credenciales confirmada como actual.')}catch(e){setRecoveryMessage(e.message,true)}}
function renderRebuildReport(r){const el=$('#rebuild-catalog-result');if(!el)return;const warnings=Array.isArray(r.warnings)?r.warnings:[];const files=(r.files_restored||0)+(r.files_updated||0)+(r.files_already_known||0);const parts=[`Claves recuperadas: ${r.keys_recovered||0}`,`Manifiestos: ${r.manifests_found||0}`,`Archivos reconstruidos/actualizados: ${files}`,`Auditorías pendientes: ${r.health_audits_pending||0}`];if(r.files_failed)parts.push(`Fallidos: ${r.files_failed}`);if(warnings.length)parts.push(`Avisos: ${warnings.length}`);el.textContent=parts.join(' · ');el.classList.toggle('bad-msg',!!r.files_failed);}
async function rebuildCatalog(){const btn=$('#rebuild-catalog');if(!btn)return;btn.disabled=true;const prev=btn.textContent;btn.textContent='Reconstruyendo…';const el=$('#rebuild-catalog-result');if(el){el.textContent='Buscando claves y manifiestos autenticados…';el.classList.remove('bad-msg')}try{const r=await api('/api/recovery/rebuild-catalog',{method:'POST'});renderRebuildReport(r);await refreshFiles();if(r.needs_review&&el&&!r.files_failed)el.textContent+=` · Revisión recomendada`; }catch(e){if(el){el.textContent=`No se pudo reconstruir el catálogo: ${e.message}`;el.classList.add('bad-msg')}}finally{btn.disabled=false;btn.textContent=prev}}
async function stageRestore(ev){ev.preventDefault();if(!$('#restore-replace').checked){setRecoveryMessage('Debes confirmar explícitamente el reemplazo al reiniciar.',true);return}const file=$('#restore-package').files?.[0];if(!file){setRecoveryMessage('Selecciona un paquete .vpr.',true);return}if(file.size>64*1024*1024){setRecoveryMessage('El paquete supera el límite de seguridad.',true);return}const fd=new FormData();fd.append('package',file,file.name);fd.append('recovery_code',$('#restore-code').value);fd.append('replace_current','true');const btn=$('#restore-stage');btn.disabled=true;btn.textContent='Validando…';try{const r=await rawFetch('/api/recovery/stage',{method:'POST',body:fd});let b={};try{b=await r.json()}catch{}if(!r.ok)throw new Error(b.error||`HTTP ${r.status}`);recoveryModel=b;$('#restore-code').value='';$('#restore-package').value='';renderRecovery();setRecoveryMessage('✓ Kit autenticado. Reinicia VaultPool para aplicar la restauración.')}catch(e){setRecoveryMessage(`Restauración no preparada: ${e.message}`,true)}finally{btn.disabled=false;btn.textContent='Validar y preparar restauración'}}
async function cancelStagedRestore(){if(!confirm('¿Cancelar la restauración preparada? La bóveda actual seguirá intacta.'))return;try{recoveryModel=await api('/api/recovery/cancel-staged',{method:'POST'});renderRecovery();setRecoveryMessage('Restauración pendiente cancelada.')}catch(e){setRecoveryMessage(e.message,true)}}


function customAuditHTML(r){
 const steps=Array.isArray(r?.steps)?r.steps:[];
 let h=steps.length?`<div class="audit-steps">${steps.map(x=>`<div class="audit-step ${x.passed?'pass':'fail'}"><span>${x.passed?'✓':'×'}</span><div><strong>${esc(x.label||x.id)}</strong><small>${esc(x.detail||'')}</small></div></div>`).join('')}</div>`:'';
 if(r?.passed){h+=`<div class="audit-final pass"><strong>✓ Compatible y añadida</strong><p>VaultPool ha validado WebDAV, cuota y una prueba real de subida/lectura/borrado. La contraseña no se muestra ni se guarda fuera de la bóveda cifrada.</p></div>`}
 else if(r){h+=`<div class="audit-final fail"><strong>Bloqueada: ${esc(r.reason||'no superó los filtros')}</strong><p>${esc(r.guidance||'VaultPool no permitirá saltarse este control.')}</p><button class="ghost" id="request-custom-review" type="button">Guardar revisión local antes de conectar</button></div>`}
 return h;
}
async function requestCustomReview(){
 const name=$('#custom-cloud-name')?.value.trim()||'',officialURL=$('#custom-cloud-official')?.value.trim()||'',msg=$('#review-msg');
 if(!name||!officialURL){notify('Indica el nombre y la web oficial para preparar la revisión local.',true);return}
 try{
  const r=await api('/api/provider-reviews',{method:'POST',body:JSON.stringify({name,official_url:officialURL})});
  if(msg)msg.textContent=`✓ ${r.review.name} queda en revisión local. No podrá conectarse hasta tener una política local aprobada.`;
  $('#review-form')?.scrollIntoView({behavior:'smooth',block:'center'});
  notify('Revisión local guardada. La nube sigue bloqueada hasta aprobarse en este catálogo.');
 }catch(err){if(msg)msg.textContent=`⚠ ${err.message}`;notify(err.message,true)}
}
async function addCustomCloud(e){
 e.preventDefault();const btn=$('#custom-cloud-submit'),result=$('#custom-cloud-result');if(!btn||!result)return;
 const payload={name:$('#custom-cloud-name')?.value.trim()||'',official_url:$('#custom-cloud-official')?.value.trim()||'',endpoint_url:$('#custom-cloud-endpoint')?.value.trim()||'',username:$('#custom-cloud-user')?.value.trim()||'',password:$('#custom-cloud-password')?.value||''};
 btn.disabled=true;const old=btn.textContent;btn.textContent='Analizando…';result.innerHTML='<div class="audit-running">Comprobando HTTPS, WebDAV, cuota y una subida temporal segura…</div>';
 try{
  const r=await rawFetch('/api/custom-providers',{method:'POST',body:JSON.stringify(payload)});let b={};try{b=await r.json()}catch{}
  if(r.status===422){result.innerHTML=customAuditHTML(b);notify(`No se añadió: ${b.reason||'el servicio no superó la auditoría'}`,true);return}
  if(!r.ok)throw new Error(b.error||`HTTP ${r.status}`);
  result.innerHTML=customAuditHTML(b.audit||{passed:true,steps:[]});
  if($('#custom-cloud-password'))$('#custom-cloud-password').value='';
  e.target.reset();await refresh();notify(r.connected?'Nueva nube añadida y verificada.':'Nube añadida; revisa la comprobación final.',!r.connected);
 }catch(err){result.innerHTML=`<div class="audit-final fail"><strong>No se pudo añadir</strong><p>${esc(err.message)}</p></div>`;notify(err.message,true)}finally{btn.disabled=false;btn.textContent=old}
}
$$('.nav').forEach(n=>n.addEventListener('click',()=>switchView(n.dataset.view)));$$('[data-view-target]').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.viewTarget)));
$('#auth-close').onclick=closeAuthModal;
$('#player-close')?.addEventListener('click',closePlayer);
$('#player-close-action')?.addEventListener('click',closePlayer);
$('#player-open-default')?.addEventListener('click',openPlayerDefault);
$('#player-open-vlc')?.addEventListener('click',openPlayerVLC);
$('#player-install-vlc')?.addEventListener('click',installPlayerVLC);
$('#player-clear-cache')?.addEventListener('click',clearPlayerCache);
$('#player-video')?.addEventListener('error',()=>showPlayerFallback('El visor integrado no pudo decodificar este vídeo. Puedes abrirlo con Windows o instalar VLC portable.'));
$('#auth-filen-form')?.addEventListener('submit',connectFilen);
$('#auth-mediafire-form')?.addEventListener('submit',connectMediaFire);
$('#auth-webdav-form')?.addEventListener('submit',connectWebDAV);
$('#responsible-close')?.addEventListener('click',()=>closeResponsibleModal(false));
$('#responsible-cancel')?.addEventListener('click',()=>closeResponsibleModal(false));
$('#responsible-confirm')?.addEventListener('click',()=>closeResponsibleModal(true));
$('#auth-continue').onclick=async()=>{if(megaNormalUserBlocked()){notify('MEGA por consola queda bloqueado en el flujo normal de usuario.',true);closeAuthModal();return}if(!authModalReady||!['system_browser_oauth','external_session'].includes(authModalMode)||!authModalAccount){closeAuthModal();return}const accountID=authModalAccount,mode=authModalMode,btn=$('#auth-continue');clearAuthPoll();btn.disabled=true;const oldText=btn.textContent;btn.textContent=mode==='system_browser_oauth'?'Abriendo navegador…':'Abriendo cliente…';try{const r=await apiTimeout(`/api/accounts/${encodeURIComponent(accountID)}/auth/launch`,{method:'POST'},15000);if(mode==='external_session'){closeAuthModal();notify(r.message||'Cliente oficial abierto. Cuando termines, pulsa Comprobar.');await refresh();return}else{$('#auth-modal').classList.add('hidden')}let tries=0;authPollTimer=setInterval(async()=>{if(authPollBusy)return;authPollBusy=true;tries++;try{await refresh();const a=(model.accounts||[]).find(x=>x.id===accountID);if((a&&a.state==='connected')||tries>90){clearAuthPoll()}}catch{if(tries>90)clearAuthPoll()}finally{authPollBusy=false}},2000)}catch(e){$('#auth-ready').textContent=`No se pudo abrir el acceso: ${e.message}`;$('#auth-ready').className='connector-readiness pending'}finally{btn.disabled=false;btn.textContent=oldText}};
$('#auth-save-client')?.addEventListener('click',configureOAuthFromModal);
$('#auth-oauth-help-toggle')?.addEventListener('click',()=>{const help=$('#auth-oauth-help'),btn=$('#auth-oauth-help-toggle');if(!help||!btn)return;const show=help.classList.contains('hidden');help.classList.toggle('hidden',!show);btn.setAttribute('aria-expanded',show?'true':'false')});
$('#auth-recheck')?.addEventListener('click',recheckAuthModal);
$('#auth-mega-download')?.addEventListener('click',()=>window.open('https://mega.nz/cmd','_blank','noopener'));
$('#refresh-files')?.addEventListener('click',refreshFiles);
$('#refresh-accounts')?.addEventListener('click',()=>refreshAccountsNow({manual:true,force:true}));
$('#library-search')?.addEventListener('input',renderFiles);
$('#library-type-filter')?.addEventListener('change',renderFiles);
$('#library-folder-filter')?.addEventListener('change',renderFiles);
$('#library-sort')?.addEventListener('change',renderFiles);
$('#library-folder-create')?.addEventListener('submit',createLibraryFolder);
$('#refresh-transfers')?.addEventListener('click',refreshTransfers);
$('#clear-transfer-history')?.addEventListener('click',clearTransferHistory);
$('#upload-path-form')?.addEventListener('submit',startUploadPath);
$('#add-file')?.addEventListener('click',addFileFromTop);
$('#add-folder')?.addEventListener('click',addFolderFromTop);
$('#upload-path-browse')?.addEventListener('click',pickUploadPath);
$('#upload-pick-and-protect')?.addEventListener('click',addFileFromTop);
$('#upload-pick-folder')?.addEventListener('click',addFolderFromTop);
$('#oauth-browser-select')?.addEventListener('change',updateOAuthBrowserDraft);
$('#oauth-browser-browse')?.addEventListener('click',pickOAuthBrowserExecutable);
$('#oauth-browser-save')?.addEventListener('click',saveOAuthBrowser);
$('#oauth-browser-refresh')?.addEventListener('click',refreshOAuthBrowser);
refreshDialogStatus();
$('#drive-form')?.addEventListener('submit',mountDrive);
$('#drive-unmount')?.addEventListener('click',unmountDrive);
$('#recovery-begin')?.addEventListener('click',beginRecovery);
$('#recovery-regenerate')?.addEventListener('click',beginRecovery);
$('#recovery-download')?.addEventListener('click',downloadRecoveryPackage);
$('#recovery-download-confirmed')?.addEventListener('click',downloadRecoveryPackage);
$('#credential-refresh-download')?.addEventListener('click',downloadRecoveryPackage);
$('#credential-refresh-saved')?.addEventListener('change',renderRecovery);
$('#credential-refresh-confirm')?.addEventListener('click',confirmCredentialRefresh);
$('#rebuild-catalog')?.addEventListener('click',rebuildCatalog);
$('#recovery-eye')?.addEventListener('click',toggleRecoveryCode);
$('#restore-eye')?.addEventListener('click',()=>{const i=$('#restore-code');if(i)i.type=i.type==='password'?'text':'password'});
$('#recovery-copy')?.addEventListener('click',copyRecoveryCode);
$('#saved-package')?.addEventListener('change',renderRecovery);$('#saved-code')?.addEventListener('change',renderRecovery);
$('#recovery-confirm')?.addEventListener('click',confirmRecovery);
$('#restore-form')?.addEventListener('submit',stageRestore);
$('#restore-cancel')?.addEventListener('click',cancelStagedRestore);
document.addEventListener('visibilitychange',()=>{if(document.hidden){hideRecoveryCode();return}refreshAccountsNow({force:false})});
window.addEventListener('blur',hideRecoveryCode);
window.addEventListener('focus',()=>refreshAccountsNow({force:false}));
$('#custom-cloud-form')?.addEventListener('submit',addCustomCloud);
document.addEventListener('click',e=>{if(e.target.closest('#request-custom-review'))requestCustomReview()});
$('#review-form').addEventListener('submit',async e=>{e.preventDefault();const msg=$('#review-msg');msg.textContent='Guardando revisión local…';try{const r=await api('/api/provider-reviews',{method:'POST',body:JSON.stringify({name:$('#review-name').value,official_url:$('#review-url').value})});msg.textContent=`✓ ${r.review.name} queda en revisión local. No podrá conectarse hasta tener una política local aprobada.`;e.target.reset();await refresh()}catch(err){msg.textContent=`⚠ ${err.message}`}});
initSession().then(async()=>{await Promise.all([refresh(),refreshFiles(),refreshRecovery(),refreshTransfers(),refreshDrive(),refreshOAuthBrowser()]);scheduleAccountAutoRefresh(8000)}).catch(e=>{document.body.innerHTML=`<pre class="fatal-error">VaultPool UI error: ${esc(e.message)}</pre>`});
async function addFolderFromTop(ev){if(nativeDialogBusy){notify(nativeDialogBusyMessage(),true);return}if(!await prepareUploadDialog())return;const btn=ev?.currentTarget||$('#upload-pick-folder');const oldText=btn?.textContent;if(btn){btn.disabled=true;btn.textContent='Seleccionando…'}try{const r=await withNativeDialog(()=>apiTimeout('/api/dialogs/open-folder',{method:'POST'},95000));if(r?.selected&&r.path){const blocked=explainUploadBlock();if(blocked){notify(blocked,true);return}await queueFolderUpload(r.path)}else if(r){notify('Selección cancelada.')}}catch(e){notify('No se pudo seleccionar la carpeta: '+nativeDialogError(e),true)}finally{if(btn){btn.disabled=nativeDialogBusy;btn.textContent=oldText||'Subir carpeta'}renderProtection()}}
async function restoreFile(id,name){let out='';try{out=await pickRestorePath(name)}catch(e){alert(`No se pudo abrir el selector de Windows: ${e.message}`);return}if(!out)return;try{await api('/api/transfers/restore',{method:'POST',body:JSON.stringify({file_id:id,output_path:out})});await refreshTransfers();switchView('activity');notify('Descarga/recuperación iniciada. Verifica el archivo antes de borrar nada.')}catch(e){alert(`No se pudo iniciar la descarga: ${e.message}`)}}
