package ui

import (
	"context"
	"crypto/rand"
	"embed"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/authflow"
	"github.com/vaultpool-project/vaultpool/internal/buildinfo"
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/cloudconnector"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/desktop"
	"github.com/vaultpool-project/vaultpool/internal/drivehost"
	"github.com/vaultpool-project/vaultpool/internal/filedialog"
	filenconnector "github.com/vaultpool-project/vaultpool/internal/filen"
	"github.com/vaultpool-project/vaultpool/internal/library"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
	mediafireconnector "github.com/vaultpool-project/vaultpool/internal/mediafire"
	"github.com/vaultpool-project/vaultpool/internal/oauthconfig"
	"github.com/vaultpool-project/vaultpool/internal/oauthnative"
	mediaplayer "github.com/vaultpool-project/vaultpool/internal/player"
	"github.com/vaultpool-project/vaultpool/internal/recoveryassistant"
	"github.com/vaultpool-project/vaultpool/internal/recoverycenter"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/transfers"
	"github.com/vaultpool-project/vaultpool/internal/webdavgeneric"
)

//go:embed assets/*
var assets embed.FS

type Server struct {
	catalog         *catalog.Catalog
	store           *appstate.Store
	connectors      *connector.Registry
	oauth           map[string]*oauthnative.Client
	connectorMu     sync.RWMutex
	vault           *secretvault.Vault
	sessions        *authflow.SessionManager
	files           *managedfiles.Manager
	recovery        *recoverycenter.Service
	assistant       *recoveryassistant.Service
	transfers       *transfers.Service
	dialogs         *filedialog.Service
	drive           drivehost.Host
	library         *library.Service
	player          *mediaplayer.Service
	csrfToken       string
	mux             *http.ServeMux
	profileID       string
	serverMu        sync.Mutex
	httpServer      *http.Server
	shutdownRequest chan struct{}
	openAuthURL     func(string, desktop.BrowserConfig) error
}

type AccountDetail struct {
	Account         appstate.Account `json:"account"`
	DisplayIdentity string           `json:"display_identity,omitempty"`
	Provider        catalog.Provider `json:"provider"`
	Auth            authflow.Plan    `json:"auth"`
	ConnectorReady  bool             `json:"connector_ready"`
	ConnectorStatus string           `json:"connector_status"`
}

type ProviderGroup struct {
	Provider       catalog.Provider `json:"provider"`
	Accounts       []AccountDetail  `json:"accounts"`
	AccountCount   int              `json:"account_count"`
	TotalBytes     int64            `json:"total_bytes"`
	UsedBytes      int64            `json:"used_bytes"`
	FreeBytes      int64            `json:"free_bytes"`
	CanAddAccount  bool             `json:"can_add_account"`
	AddAccountNote string           `json:"add_account_note,omitempty"`
}

type ProtectionStatus struct {
	Ready                bool   `json:"ready"`
	Mode                 string `json:"mode,omitempty"`
	Label                string `json:"label"`
	IndependentProviders int    `json:"independent_providers"`
	RecoveryConfigured   bool   `json:"recovery_configured"`
	Reason               string `json:"reason,omitempty"`
}

type Overview struct {
	Version            string                   `json:"version"`
	BuildPurpose       string                   `json:"build_purpose"`
	Accounts           []appstate.Account       `json:"accounts"`
	ReviewRequests     []appstate.ReviewRequest `json:"review_requests"`
	AvailableProviders []catalog.Provider       `json:"available_providers"`
	GatedProviders     []catalog.Provider       `json:"gated_providers"`
	AllProviders       []catalog.Provider       `json:"all_providers"`
	AccountDetails     []AccountDetail          `json:"account_details"`
	ProviderGroups     []ProviderGroup          `json:"provider_groups"`
	Protection         ProtectionStatus         `json:"protection"`
}

func New(cat *catalog.Catalog, store *appstate.Store) (*Server, error) {
	reg := connector.NewRegistry()
	if cat != nil {
		for _, p := range cat.All() {
			if p.Status == catalog.Allowed {
				_ = reg.Register(connector.Unconfigured{ID: p.ID})
			}
		}
	}
	return NewWithConnectors(cat, store, reg)
}

func NewWithConnectors(cat *catalog.Catalog, store *appstate.Store, reg *connector.Registry) (*Server, error) {
	return NewSecure(cat, store, reg, nil, nil)
}

func NewSecure(cat *catalog.Catalog, store *appstate.Store, reg *connector.Registry, vault *secretvault.Vault, oauth map[string]*oauthnative.Client) (*Server, error) {
	return NewSecureManaged(cat, store, reg, vault, oauth, nil)
}

func NewSecureManaged(cat *catalog.Catalog, store *appstate.Store, reg *connector.Registry, vault *secretvault.Vault, oauth map[string]*oauthnative.Client, files *managedfiles.Manager) (*Server, error) {
	return NewSecureManagedRecovery(cat, store, reg, vault, oauth, files, nil)
}

func NewSecureManagedRecovery(cat *catalog.Catalog, store *appstate.Store, reg *connector.Registry, vault *secretvault.Vault, oauth map[string]*oauthnative.Client, files *managedfiles.Manager, recovery *recoverycenter.Service) (*Server, error) {
	if cat == nil || store == nil || reg == nil {
		return nil, errors.New("catalog, store and connector registry are required")
	}
	if oauth == nil {
		oauth = map[string]*oauthnative.Client{}
	}
	csrf, err := newCSRFToken()
	if err != nil {
		return nil, fmt.Errorf("csrf token: %w", err)
	}
	s := &Server{catalog: cat, store: store, connectors: reg, oauth: oauth, vault: vault, sessions: authflow.NewSessionManager(), files: files, recovery: recovery, csrfToken: csrf, mux: http.NewServeMux(), shutdownRequest: make(chan struct{}, 1), openAuthURL: desktop.OpenAuthURL}
	if err := s.migrateLegacyIdentities(); err != nil {
		return nil, err
	}
	static, err := fs.Sub(assets, "assets")
	if err != nil {
		return nil, err
	}
	s.mux.Handle("GET /assets/", http.StripPrefix("/assets/", http.FileServer(http.FS(static))))
	s.mux.HandleFunc("GET /", s.index)
	s.mux.HandleFunc("GET /api/identity", s.identity)
	s.mux.HandleFunc("POST /api/shutdown", s.requestShutdown)
	s.mux.HandleFunc("GET /api/overview", s.overview)
	s.mux.HandleFunc("POST /api/accounts", s.addAccount)
	s.mux.HandleFunc("GET /api/accounts/{id}/auth-plan", s.accountAuthPlan)
	s.mux.HandleFunc("POST /api/accounts/{id}/auth/start", s.startAuth)
	s.mux.HandleFunc("POST /api/accounts/{id}/auth/launch", s.launchAuth)
	s.mux.HandleFunc("GET /api/accounts/{id}/auth/launch", s.authLaunchInfo)
	s.mux.HandleFunc("POST /api/accounts/{id}/filen/login", s.filenLogin)
	s.mux.HandleFunc("POST /api/accounts/{id}/filen/logout", s.filenLogout)
	s.mux.HandleFunc("POST /api/accounts/{id}/mediafire/login", s.mediafireLogin)
	s.mux.HandleFunc("POST /api/accounts/{id}/mediafire/logout", s.mediafireLogout)
	s.mux.HandleFunc("POST /api/accounts/{id}/webdav/login", s.webDAVLogin)
	s.mux.HandleFunc("POST /api/accounts/{id}/disconnect", s.disconnectAccount)
	s.mux.HandleFunc("POST /api/accounts/{id}/probe", s.probeAccount)
	s.mux.HandleFunc("POST /api/connectors/{id}/configure", s.configureConnector)
	s.mux.HandleFunc("GET /api/oauth/browser", s.oauthBrowserStatus)
	s.mux.HandleFunc("PUT /api/oauth/browser", s.oauthBrowserConfigure)
	s.mux.HandleFunc("GET /oauth/callback", s.oauthCallback)
	s.mux.HandleFunc("POST /api/provider-reviews", s.requestReview)
	s.mux.HandleFunc("POST /api/custom-providers", s.addCustomProvider)
	s.mux.HandleFunc("GET /api/files", s.listFiles)
	s.mux.HandleFunc("GET /api/files/{id}/distribution", s.fileDistribution)
	s.mux.HandleFunc("GET /api/library", s.libraryState)
	s.mux.HandleFunc("POST /api/library/folders", s.libraryCreateFolder)
	s.mux.HandleFunc("PATCH /api/library/folders/{id}", s.libraryRenameFolder)
	s.mux.HandleFunc("DELETE /api/library/folders/{id}", s.libraryDeleteFolder)
	s.mux.HandleFunc("POST /api/library/files/{id}/folder", s.libraryAssignFolder)
	s.mux.HandleFunc("POST /api/files/{id}/audit", s.auditFile)
	s.mux.HandleFunc("POST /api/files/{id}/repair", s.repairFile)
	s.mux.HandleFunc("DELETE /api/files/{id}", s.deleteFile)
	s.mux.HandleFunc("POST /api/player/{id}/prepare", s.playerPrepare)
	s.mux.HandleFunc("GET /api/player/{id}/status", s.playerStatus)
	s.mux.HandleFunc("GET /api/player/{id}/stream", s.playerStream)
	s.mux.HandleFunc("POST /api/player/{id}/open-default", s.playerOpenDefault)
	s.mux.HandleFunc("POST /api/player/{id}/open-vlc", s.playerOpenVLC)
	s.mux.HandleFunc("DELETE /api/player/{id}/cache", s.playerClearCache)
	s.mux.HandleFunc("GET /api/player/plugins", s.playerPlugins)
	s.mux.HandleFunc("POST /api/player/plugins/{id}/install", s.playerInstallPlugin)
	s.mux.HandleFunc("GET /api/transfers", s.listTransfers)
	s.mux.HandleFunc("DELETE /api/transfers/history", s.clearTransferHistory)
	s.mux.HandleFunc("DELETE /api/transfers/{id}", s.removeTransferHistory)
	s.mux.HandleFunc("POST /api/transfers/upload", s.startUploadTransfer)
	s.mux.HandleFunc("POST /api/transfers/upload-folder", s.startFolderUploadTransfer)
	s.mux.HandleFunc("POST /api/transfers/upload-folder-contents", s.startFolderContentsUploadTransfer)
	s.mux.HandleFunc("POST /api/transfers/restore", s.startRestoreTransfer)
	s.mux.HandleFunc("POST /api/transfers/{id}/cancel", s.cancelTransfer)
	s.mux.HandleFunc("GET /api/dialogs/status", s.dialogStatus)
	s.mux.HandleFunc("GET /api/drive/status", s.driveStatus)
	s.mux.HandleFunc("POST /api/drive/mount", s.driveMount)
	s.mux.HandleFunc("POST /api/drive/unmount", s.driveUnmount)
	s.mux.HandleFunc("POST /api/dialogs/open-file", s.dialogOpenFile)
	s.mux.HandleFunc("POST /api/dialogs/open-folder", s.dialogOpenFolder)
	s.mux.HandleFunc("POST /api/dialogs/open-executable", s.dialogOpenExecutable)
	s.mux.HandleFunc("POST /api/dialogs/save-file", s.dialogSaveFile)
	s.mux.HandleFunc("GET /api/session", s.sessionInfo)
	s.mux.HandleFunc("GET /api/recovery/status", s.recoveryStatus)
	s.mux.HandleFunc("POST /api/recovery/begin", s.recoveryBegin)
	s.mux.HandleFunc("POST /api/recovery/confirm", s.recoveryConfirm)
	s.mux.HandleFunc("POST /api/recovery/confirm-credential-refresh", s.recoveryConfirmCredentialRefresh)
	s.mux.HandleFunc("POST /api/recovery/package", s.recoveryPackage)
	s.mux.HandleFunc("POST /api/recovery/rebuild-catalog", s.recoveryRebuildCatalog)
	s.mux.HandleFunc("POST /api/recovery/stage", s.recoveryStage)
	s.mux.HandleFunc("POST /api/recovery/cancel-staged", s.recoveryCancelStaged)
	return s, nil
}

func (s *Server) SetIdentity(profileID string) {
	s.profileID = strings.TrimSpace(profileID)
}

func (s *Server) identity(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{
		"product":   buildinfo.Product,
		"version":   buildinfo.Version,
		"milestone": buildinfo.Milestone,
		"profile":   s.profileID,
	})
}

func (s *Server) requestShutdown(w http.ResponseWriter, r *http.Request) {
	select {
	case s.shutdownRequest <- struct{}{}:
	default:
	}
	writeJSON(w, http.StatusAccepted, map[string]bool{"accepted": true})
}

// ShutdownRequested is signaled only by an authenticated same-origin/CSRF POST
// to /api/shutdown. It lets the desktop launcher request the same controlled
// teardown path used for Ctrl+C instead of force-killing the service on Windows.
func (s *Server) ShutdownRequested() <-chan struct{} {
	return s.shutdownRequest
}

// SetRecoveryAssistant attaches the metadata-only disaster-recovery workflow.
// It is optional so non-Windows/test UIs can still start without pretending
// that recovery is available.
func (s *Server) SetRecoveryAssistant(a *recoveryassistant.Service) {
	s.assistant = a
}

// SetTransfers attaches the long-running transfer scheduler. The HTTP routes are
// always present but remain unavailable until the managed-file backend is ready.
func (s *Server) SetTransfers(t *transfers.Service) {
	s.transfers = t
}

// SetFileDialog attaches the native OS file-selection surface. Dialog actions
// are still protected by exact same-origin + CSRF because selecting a local
// path is privileged local-machine intent.
func (s *Server) SetFileDialog(d *filedialog.Service) {
	s.dialogs = d
}

// SetDriveHost attaches the optional Windows virtual-drive host. The UI remains
// fully usable when Dokany is absent; it must never claim that a drive is
// mounted unless the backend confirms it.
func (s *Server) SetDriveHost(h drivehost.Host) {
	s.drive = h
}

// SetLibrary attaches the encrypted, metadata-only organization layer. Virtual
// folders never change shard placement and are intentionally non-critical for
// disaster recovery: losing them must not make file contents unrecoverable.
func (s *Server) SetLibrary(l *library.Service) {
	s.library = l
}

// SetPlayer attaches the local decrypted-media cache. It is optional: VaultPool
// can still manage files on systems where playback support is unavailable.
func (s *Server) SetPlayer(p *mediaplayer.Service) {
	s.player = p
}

func (s *Server) driveStatus(w http.ResponseWriter, r *http.Request) {
	if s.drive == nil {
		writeJSON(w, http.StatusOK, drivehost.Status{ReadOnly: true, Backend: "dokany2"})
		return
	}
	writeJSON(w, http.StatusOK, s.drive.Status())
}

func (s *Server) driveMount(w http.ResponseWriter, r *http.Request) {
	if s.drive == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("virtual drive service unavailable"))
		return
	}
	var req struct {
		MountPoint string `json:"mount_point"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	if strings.TrimSpace(req.MountPoint) == "" {
		req.MountPoint = "P:"
	}
	if err := s.drive.Mount(req.MountPoint); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, s.drive.Status())
}

func (s *Server) driveUnmount(w http.ResponseWriter, r *http.Request) {
	if s.drive == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("virtual drive service unavailable"))
		return
	}
	if err := s.drive.Unmount(); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, s.drive.Status())
}

func (s *Server) dialogStatus(w http.ResponseWriter, r *http.Request) {
	ready := s.dialogs != nil && s.dialogs.Supported()
	reason := ""
	if !ready {
		reason = "Modo seguro activo: los selectores nativos de Windows están desactivados temporalmente mientras se investiga un posible cuelgue del shell. Usa rutas manuales; VaultPool no invocará Explorer desde su proceso."
	}
	writeJSON(w, http.StatusOK, map[string]any{"ready": ready, "safe_mode": !ready, "reason": reason})
}

func (s *Server) dialogOpenFile(w http.ResponseWriter, r *http.Request) {
	if s.dialogs == nil || !s.dialogs.Supported() {
		writeError(w, http.StatusNotImplemented, filedialog.ErrUnsupported)
		return
	}
	path, selected, err := s.dialogs.OpenFile()
	if err != nil {
		if errors.Is(err, filedialog.ErrBusy) {
			writeError(w, http.StatusConflict, err)
			return
		}
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"selected": selected, "path": path})
}

func (s *Server) dialogOpenFolder(w http.ResponseWriter, r *http.Request) {
	if s.dialogs == nil || !s.dialogs.Supported() {
		writeError(w, http.StatusNotImplemented, filedialog.ErrUnsupported)
		return
	}
	path, selected, err := s.dialogs.OpenDirectory()
	if err != nil {
		if errors.Is(err, filedialog.ErrBusy) {
			writeError(w, http.StatusConflict, err)
			return
		}
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"selected": selected, "path": path})
}

func (s *Server) dialogOpenExecutable(w http.ResponseWriter, r *http.Request) {
	if s.dialogs == nil || !s.dialogs.Supported() {
		writeError(w, http.StatusNotImplemented, filedialog.ErrUnsupported)
		return
	}
	path, selected, err := s.dialogs.OpenExecutable()
	if err != nil {
		if errors.Is(err, filedialog.ErrBusy) {
			writeError(w, http.StatusConflict, err)
			return
		}
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"selected": selected, "path": path})
}

func (s *Server) dialogSaveFile(w http.ResponseWriter, r *http.Request) {
	if s.dialogs == nil || !s.dialogs.Supported() {
		writeError(w, http.StatusNotImplemented, filedialog.ErrUnsupported)
		return
	}
	var req struct {
		SuggestedName string `json:"suggested_name"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	path, selected, err := s.dialogs.SaveFile(req.SuggestedName)
	if err != nil {
		if errors.Is(err, filedialog.ErrBusy) {
			writeError(w, http.StatusConflict, err)
			return
		}
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"selected": selected, "path": path})
}

func newCSRFToken() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

func (s *Server) listTransfers(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeJSON(w, http.StatusOK, map[string]any{"ready": false, "jobs": []transfers.Job{}})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"ready": true, "jobs": s.transfers.List()})
}

func (s *Server) clearTransferHistory(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("transfer service unavailable"))
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"removed": s.transfers.ClearFinished()})
}

func (s *Server) removeTransferHistory(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("transfer service unavailable"))
		return
	}
	removed, err := s.transfers.RemoveFinished(r.PathValue("id"))
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"removed": removed})
}

func (s *Server) startUploadTransfer(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("secure file transfer service unavailable"))
		return
	}
	protection := s.protectionStatus()
	if !protection.Ready {
		writeError(w, http.StatusConflict, fmt.Errorf("protection unavailable: %s", protection.Reason))
		return
	}
	var req struct {
		Path string `json:"path"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	job, err := s.transfers.StartUpload(req.Path)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"job": job})
}

func (s *Server) startFolderUploadTransfer(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("secure file transfer service unavailable"))
		return
	}
	protection := s.protectionStatus()
	if !protection.Ready {
		writeError(w, http.StatusConflict, fmt.Errorf("protection unavailable: %s", protection.Reason))
		return
	}
	var req struct {
		Path string `json:"path"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	root := filepath.Clean(strings.TrimSpace(req.Path))
	if root == "." || root == "" || !filepath.IsAbs(root) {
		writeError(w, http.StatusBadRequest, errors.New("folder path must be absolute"))
		return
	}
	st, err := os.Lstat(root)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if st.Mode()&os.ModeSymlink != 0 {
		writeError(w, http.StatusBadRequest, errors.New("symbolic-link folders are not accepted; select the real folder"))
		return
	}
	if !st.IsDir() {
		writeError(w, http.StatusBadRequest, errors.New("selected path is not a folder"))
		return
	}
	job, err := s.transfers.StartUpload(root)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"folder": root, "job": job, "mode": "folder-package"})
}

func (s *Server) startFolderContentsUploadTransfer(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("secure file transfer service unavailable"))
		return
	}
	protection := s.protectionStatus()
	if !protection.Ready {
		writeError(w, http.StatusConflict, fmt.Errorf("protection unavailable: %s", protection.Reason))
		return
	}
	var req struct {
		Path string `json:"path"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	root := filepath.Clean(strings.TrimSpace(req.Path))
	if root == "." || root == "" || !filepath.IsAbs(root) {
		writeError(w, http.StatusBadRequest, errors.New("folder path must be absolute"))
		return
	}
	st, err := os.Stat(root)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if !st.IsDir() {
		writeError(w, http.StatusBadRequest, errors.New("selected path is not a folder"))
		return
	}
	const maxFolderFiles = 2000
	paths := make([]string, 0, 32)
	err = filepath.WalkDir(root, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.Type()&os.ModeSymlink != 0 {
			if entry.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		if entry.IsDir() {
			return nil
		}
		info, infoErr := entry.Info()
		if infoErr != nil {
			return infoErr
		}
		if !info.Mode().IsRegular() {
			return nil
		}
		paths = append(paths, path)
		if len(paths) > maxFolderFiles {
			return errors.New("folder contains more than 2000 files")
		}
		return nil
	})
	if err != nil {
		writeError(w, http.StatusBadRequest, fmt.Errorf("cannot enumerate folder: %w", err))
		return
	}
	sort.Strings(paths)
	if len(paths) == 0 {
		writeError(w, http.StatusBadRequest, errors.New("folder contains no regular files"))
		return
	}
	jobs := make([]transfers.Job, 0, len(paths))
	for _, path := range paths {
		job, startErr := s.transfers.StartUpload(path)
		if startErr != nil {
			writeError(w, http.StatusBadRequest, startErr)
			return
		}
		jobs = append(jobs, job)
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"folder": root, "count": len(jobs), "jobs": jobs})
}

func (s *Server) startRestoreTransfer(w http.ResponseWriter, r *http.Request) {
	if !buildinfo.DataOperationsEnabled() {
		writeError(w, http.StatusForbidden, errors.New("this build does not permit restore operations"))
		return
	}
	if s.transfers == nil || s.files == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("secure file transfer service unavailable"))
		return
	}
	var req struct {
		FileID     string `json:"file_id"`
		OutputPath string `json:"output_path"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	meta, ok, err := s.files.Get(strings.TrimSpace(req.FileID))
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("managed file not found"))
		return
	}
	job, err := s.transfers.StartRestore(meta.FileID, req.OutputPath, meta.FileName)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]any{"job": job})
}

func (s *Server) cancelTransfer(w http.ResponseWriter, r *http.Request) {
	if s.transfers == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("transfer service unavailable"))
		return
	}
	job, err := s.transfers.Cancel(strings.TrimSpace(r.PathValue("id")))
	if err != nil {
		if _, ok := s.transfers.Get(strings.TrimSpace(r.PathValue("id"))); !ok {
			writeError(w, http.StatusNotFound, err)
			return
		}
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"job": job})
}

func (s *Server) sessionInfo(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"csrf_token": s.csrfToken})
}

func (s *Server) csrfOK(r *http.Request) bool {
	if r.Header.Get("X-VaultPool-CSRF") == s.csrfToken {
		return true
	}
	ct := r.Header.Get("Content-Type")
	if strings.HasPrefix(ct, "application/x-www-form-urlencoded") {
		if err := r.ParseForm(); err == nil && r.PostForm.Get("_csrf") == s.csrfToken {
			return true
		}
	}
	return false
}

func (s *Server) csrfProtection(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet, http.MethodHead, http.MethodOptions:
			next.ServeHTTP(w, r)
			return
		}
		if !s.csrfOK(r) {
			writeError(w, http.StatusForbidden, errors.New("missing or invalid VaultPool CSRF token"))
			return
		}
		next.ServeHTTP(w, r)
	})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func writeError(w http.ResponseWriter, status int, err error) {
	writeJSON(w, status, map[string]string{"error": err.Error()})
}

func (s *Server) index(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	// Microsoft desktop registrations use the loopback root. OAuth responses
	// still pass through the same single-use state and PKCE validation.
	if q := r.URL.Query(); q.Has("code") || q.Has("error") || q.Has("state") {
		s.oauthCallback(w, r)
		return
	}
	b, err := assets.ReadFile("assets/index.html")
	if err != nil {
		http.Error(w, "UI unavailable", 500)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = w.Write(b)
}

func (s *Server) migrateLegacyIdentities() error {
	if s.vault == nil {
		return nil
	}
	for _, a := range s.store.Snapshot().Accounts {
		if strings.TrimSpace(a.Identity) == "" {
			continue
		}
		secret := []byte(a.Identity)
		err := s.vault.Put(a.ID, secretvault.AccountIdentity, secret)
		for i := range secret {
			secret[i] = 0
		}
		if err != nil {
			return fmt.Errorf("migrate legacy account identity: %w", err)
		}
		if err := s.store.ClearIdentity(a.ID); err != nil {
			return fmt.Errorf("scrub legacy account identity: %w", err)
		}
	}
	return nil
}

func (s *Server) applyConnectorSnapshot(snap connector.Snapshot) (appstate.Account, error) {
	identity := strings.TrimSpace(snap.Identity)
	if identity != "" && s.vault != nil {
		for _, account := range s.store.Snapshot().Accounts {
			if account.ID == snap.AccountID || account.ProviderID != snap.ProviderID {
				continue
			}
			stored, ok, err := s.vault.Get(account.ID, secretvault.AccountIdentity)
			if err != nil {
				return appstate.Account{}, fmt.Errorf("read encrypted account identity: %w", err)
			}
			matches := ok && strings.EqualFold(strings.TrimSpace(string(stored)), identity)
			for i := range stored {
				stored[i] = 0
			}
			if matches {
				// If this was a freshly-created pending account, reject it without
				// leaving an empty duplicate card or account-scoped session behind.
				// Existing/re-authenticated accounts are kept intact so a failed
				// identity check can never delete an established target.
				if pending, ok := s.store.GetAccount(snap.AccountID); ok && pending.State == "pending_auth" && strings.TrimSpace(pending.StableTargetID) == "" {
					s.cleanupRejectedPendingAccount(pending)
				}
				return appstate.Account{}, errors.New("no se puede añadir esta cuenta porque ya está conectada")
			}
		}
		b := []byte(identity)
		err := s.vault.Put(snap.AccountID, secretvault.AccountIdentity, b)
		for i := range b {
			b[i] = 0
		}
		if err != nil {
			return appstate.Account{}, fmt.Errorf("store encrypted account identity: %w", err)
		}
	}
	snap.Identity = ""
	return s.store.ApplySnapshot(snap)
}

func (s *Server) cleanupRejectedPendingAccount(a appstate.Account) {
	if s == nil || strings.TrimSpace(a.ID) == "" {
		return
	}
	if s.vault != nil {
		for _, kind := range []secretvault.Kind{
			secretvault.ProviderSession,
			secretvault.FilenSession,
			secretvault.MediaFireSession,
			secretvault.OAuthRefreshToken,
			secretvault.OAuthAccessToken,
			secretvault.AccountIdentity,
		} {
			_ = s.vault.Delete(a.ID, kind)
		}
	}
	_ = s.store.RemoveAccount(a.ID)
}

func (s *Server) protectionStatus() ProtectionStatus {
	if !buildinfo.DataOperationsEnabled() {
		return ProtectionStatus{Ready: false, Label: "Validación de cuentas", Reason: "esta build solo permite conectar/verificar cuentas; no admite operaciones de datos"}
	}
	domains := map[string]struct{}{}
	for _, a := range s.store.Snapshot().Accounts {
		if a.State == "connected" && strings.TrimSpace(a.ProviderID) != "" && strings.TrimSpace(a.StableTargetID) != "" {
			domains[a.ProviderID] = struct{}{}
		}
	}
	st := ProtectionStatus{IndependentProviders: len(domains), Label: "Protección insuficiente"}
	// Field-test binaries use the self-contained fallback erasure implementation.
	// Restrict them to the 1+1 / 1+2 layouts, where shards are complete replicas
	// and therefore independent of the production Reed-Solomon matrix implementation.
	// This makes disposable cloud tests forward-recoverable by later release builds.
	if buildinfo.FieldTest() && len(domains) > 3 {
		st.Reason = "la build de campo admite 2 o 3 proveedores; usa la build de producción para Reed-Solomon con 4+"
		return st
	}
	switch len(domains) {
	case 2:
		st.Mode = "mirror-2x"
		st.Label = "Espejo seguro 2×"
	case 3:
		st.Mode = "triple-replica"
		st.Label = "Triple réplica"
	default:
		if len(domains) >= 4 {
			st.Mode = "reed-solomon"
			st.Label = "Reed-Solomon adaptativo"
		}
	}
	if len(domains) < 2 {
		st.Reason = "se requieren al menos 2 proveedores independientes conectados y verificados"
		return st
	}
	if s.recovery == nil {
		st.Reason = "la recuperación portable no está disponible en este entorno"
		return st
	}
	recovery := s.recovery.Status()
	st.RecoveryConfigured = recovery.Configured
	if !recovery.Configured {
		st.Reason = "confirma primero el kit de recuperación portable"
		return st
	}
	st.Ready = true
	return st
}

type externalAuthLauncher interface {
	LaunchAuth(context.Context, string) error
}

func (s *Server) oauthClient(providerID string) *oauthnative.Client {
	s.connectorMu.RLock()
	defer s.connectorMu.RUnlock()
	return s.oauth[providerID]
}

func (s *Server) setOAuthConnector(providerID string, client *oauthnative.Client) error {
	if client == nil || s.vault == nil {
		return errors.New("OAuth connector requires Windows secret vault")
	}
	c := &cloudconnector.OAuthConnector{ID: providerID, OAuth: client, Secrets: s.vault}
	if err := s.connectors.Set(c); err != nil {
		return err
	}
	s.connectorMu.Lock()
	s.oauth[providerID] = client
	s.connectorMu.Unlock()
	return nil
}

func (s *Server) connectorReadyFor(p catalog.Provider) bool {
	if !s.connectors.Ready(p.ID) {
		return false
	}
	switch p.AuthStrategy {
	case catalog.AuthSystemBrowserOAuth:
		if s.vault == nil || s.oauthClient(p.ID) == nil {
			return false
		}
		if p.ID == "google-drive" || p.ID == "pcloud" {
			cfg, ok, err := oauthconfig.Load(s.vault, p.ID)
			return err == nil && ok && cfg.ClientID != "" && cfg.ClientSecret != ""
		}
		return true
	case catalog.AuthExternalSession:
		_, ok := s.connectors.Get(p.ID)
		return ok
	case catalog.AuthDirectCredentials:
		return s.vault != nil
	default:
		return s.vault != nil
	}
}

func (s *Server) connectorStatusFor(p catalog.Provider) string {
	switch p.AuthStrategy {
	case catalog.AuthSystemBrowserOAuth:
		if s.vault == nil {
			return "Bóveda segura de Windows no disponible."
		}
		cfg, ok, err := oauthconfig.Load(s.vault, p.ID)
		if err != nil {
			return "No se pudo leer la configuración OAuth local."
		}
		if s.oauthClient(p.ID) == nil || !ok || cfg.ClientID == "" {
			switch p.ID {
			case "dropbox":
				return "Falta configurar la App Key pública de Dropbox. No es tu contraseña ni un token."
			case "onedrive":
				return "Falta configurar el Application (client) ID público de Microsoft. No es tu contraseña."
			case "pcloud":
				return "Falta configurar el Client ID y Client Secret de tu app pCloud."
			default:
				return "Falta configurar el Client ID público OAuth. No es tu contraseña."
			}
		}
		if p.ID == "pcloud" && cfg.ClientSecret == "" {
			return "Falta añadir el Client Secret de pCloud; se guarda cifrado localmente."
		}
		if p.ID == "google-drive" && cfg.ClientSecret == "" {
			return "Falta añadir el Client Secret del cliente Google Desktop. No es tu contraseña de Google; se guarda protegido y solo se envía al endpoint oficial de token."
		}
		if !s.connectors.Ready(p.ID) {
			return "Conector OAuth todavía no está listo."
		}
		return "OAuth listo para abrir el acceso oficial."
	case catalog.AuthExternalSession:
		if p.ID == "mega" && !s.connectors.Ready(p.ID) {
			return "MEGAcmd oficial no detectado. Instálalo y VaultPool lo volverá a comprobar."
		}
		if s.connectors.Ready(p.ID) {
			return "Cliente oficial detectado; ya puedes abrir el inicio de sesión."
		}
		return "Integración externa aprobada no detectada."
	case catalog.AuthDirectCredentials:
		if s.vault == nil {
			return "Bóveda segura de Windows no disponible."
		}
		if p.ID == filenconnector.ProviderID {
			if !s.connectors.Ready(p.ID) {
				return "Conector directo de Filen no disponible."
			}
			return "Conector directo de Filen listo. Email, contraseña y 2FA se usan solo para iniciar sesión localmente."
		}
		if !s.connectors.Ready(p.ID) {
			return "Conector seguro todavía no está listo."
		}
		return "Conector seguro preparado."
	default:
		if s.vault == nil {
			return "Bóveda segura no disponible."
		}
		return "Conector seguro preparado."
	}
}

func (s *Server) snapshotOverview() Overview {
	d := s.store.Snapshot()
	available := appstate.AvailableProviders(s.catalog, d)
	all := s.catalog.All()
	counts := map[string]int{}
	for _, a := range d.Accounts {
		counts[a.ProviderID]++
	}
	gated := make([]catalog.Provider, 0)
	for _, p := range all {
		if p.Status != catalog.Allowed || (p.MaxAccounts > 0 && counts[p.ID] >= p.MaxAccounts) {
			if p.Status != catalog.Allowed {
				gated = append(gated, p)
			}
		}
	}
	details := make([]AccountDetail, 0, len(d.Accounts))
	caps := s.shellCapabilities()
	for _, a := range d.Accounts {
		p, ok := s.catalog.Get(a.ProviderID)
		if !ok {
			continue
		}
		connectorReady := s.connectorReadyFor(p)
		status := s.connectorStatusFor(p)
		displayIdentity := ""
		if s.vault != nil {
			if secret, ok, err := s.vault.Get(a.ID, secretvault.AccountIdentity); err == nil && ok {
				displayIdentity = string(secret)
				for i := range secret {
					secret[i] = 0
				}
			}
		}
		if displayIdentity == "" {
			displayIdentity = a.Identity
		} // legacy-only fallback before migration
		details = append(details, AccountDetail{Account: a, DisplayIdentity: displayIdentity, Provider: p, Auth: authflow.Decide(p, caps), ConnectorReady: connectorReady, ConnectorStatus: status})
	}
	groupsByID := make(map[string]*ProviderGroup)
	for _, detail := range details {
		id := detail.Provider.ID
		group := groupsByID[id]
		if group == nil {
			p := detail.Provider
			group = &ProviderGroup{Provider: p}
			groupsByID[id] = group
		}
		group.Accounts = append(group.Accounts, detail)
		group.AccountCount++
		group.TotalBytes += detail.Account.TotalBytes
		group.UsedBytes += detail.Account.UsedBytes
		group.FreeBytes += detail.Account.FreeBytes
	}
	groups := make([]ProviderGroup, 0, len(groupsByID))
	for _, group := range groupsByID {
		p := group.Provider
		group.CanAddAccount = p.Status == catalog.Allowed && (p.MaxAccounts == 0 || group.AccountCount < p.MaxAccounts)
		if !group.CanAddAccount && p.ID == "mega" {
			group.AddAccountNote = "Multicuenta pendiente: MEGAcmd mantiene una sesión global activa."
		}
		groups = append(groups, *group)
	}
	sort.Slice(groups, func(i, j int) bool {
		return strings.ToLower(groups[i].Provider.Name) < strings.ToLower(groups[j].Provider.Name)
	})
	return Overview{Version: buildinfo.Version, BuildPurpose: buildinfo.BuildPurpose, Accounts: d.Accounts, ReviewRequests: d.ReviewRequests, AvailableProviders: available, GatedProviders: gated, AllProviders: all, AccountDetails: details, ProviderGroups: groups, Protection: s.protectionStatus()}
}

func (s *Server) overview(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, 200, s.snapshotOverview())
}

func decodeJSON(w http.ResponseWriter, r *http.Request, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 64<<10)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		writeError(w, 400, fmt.Errorf("invalid request: %w", err))
		return false
	}
	return true
}

func shellCapabilities() authflow.ShellCapabilities {
	// The current local web UI can hand off to the system browser and display a
	// device code, but it is not yet a native WebView shell and the credential
	// vault capabilities are exposed only when the native Windows shell opens it.
	return authflow.ShellCapabilities{SystemBrowser: true, EmbeddedWebView: false, DeviceCode: true, CredentialVault: false, ExternalSession: true}
}

func (s *Server) shellCapabilities() authflow.ShellCapabilities {
	caps := shellCapabilities()
	caps.CredentialVault = s != nil && s.vault != nil
	return caps
}

func (s *Server) accountAuthPlan(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	p, ok := s.catalog.Get(a.ProviderID)
	if !ok {
		writeError(w, http.StatusConflict, errors.New("provider policy missing"))
		return
	}
	ready := s.connectorReadyFor(p)
	writeJSON(w, http.StatusOK, map[string]any{"account": a, "provider": p, "auth": authflow.Decide(p, s.shellCapabilities()), "connector_ready": ready, "connector_status": s.connectorStatusFor(p)})
}

func (s *Server) startAuth(w http.ResponseWriter, r *http.Request) {
	authURL, session, plan, status, err := s.beginSystemBrowserAuth(r.PathValue("id"), r.Host)
	if err != nil {
		writeError(w, status, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"authorization_url": authURL, "expires_at": session.ExpiresAt, "mode": plan.Mode})
}

// launchAuth is called by the local UI using a same-origin, CSRF-protected POST.
// For OAuth, VaultPool first creates a PKCE session whose loopback callback
// points at the stable UI listener, then opens the provider URL through the
// configured system browser handler. This deliberately does not reuse an
// embedded WebView: users normally keep their sessions, passwords and 2FA in
// their chosen browser. The provider URL is never rendered inside VaultPool.
func (s *Server) launchAuth(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	p, ok := s.catalog.Get(a.ProviderID)
	if !ok {
		writeError(w, http.StatusConflict, errors.New("provider policy missing"))
		return
	}
	plan := authflow.Decide(p, s.shellCapabilities())
	switch plan.Mode {
	case authflow.SystemBrowserOAuth:
		// Use the already-running VaultPool UI listener for the loopback
		// callback. Earlier field-test builds created a second short-lived
		// listener for each OAuth attempt; on some Windows/browser combinations
		// the provider could return after that helper listener had gone away,
		// producing ERR_CONNECTION_REFUSED on 127.0.0.1. The UI service is the
		// stable process the user is already interacting with, so it is the most
		// reliable loopback endpoint. The request remains same-origin and
		// CSRF-protected, and the provider still receives a normal PKCE loopback
		// redirect URI.
		authURL, session, _, status, err := s.beginSystemBrowserAuth(a.ID, r.Host)
		if err != nil {
			writeError(w, status, err)
			return
		}
		if s.openAuthURL == nil {
			_ = s.sessions.Cancel(session.ID)
			writeError(w, http.StatusServiceUnavailable, errors.New("system browser launcher unavailable"))
			return
		}
		browser := s.store.OAuthBrowser()
		browserStatus, _ := desktop.BrowserStatusFor(desktop.BrowserConfig{Mode: browser.Mode, BrowserID: browser.BrowserID, CustomPath: browser.CustomPath})
		if err := s.openAuthURL(authURL, desktop.BrowserConfig{Mode: browser.Mode, BrowserID: browser.BrowserID, CustomPath: browser.CustomPath}); err != nil {
			_ = s.sessions.Cancel(session.ID)
			writeError(w, http.StatusServiceUnavailable, fmt.Errorf("open OAuth browser: %w", err))
			return
		}
		writeJSON(w, http.StatusCreated, map[string]any{
			"opened":        true,
			"expires_at":    session.ExpiresAt,
			"mode":          plan.Mode,
			"callback_host": r.Host,
			"browser":       browserStatus.EffectiveLabel,
		})
	case authflow.ExternalSession:
		if a.ProviderID == "mega" && strings.TrimSpace(os.Getenv("VAULTPOOL_ALLOW_MEGACMD_INTERACTIVE")) != "1" {
			writeError(w, http.StatusConflict, errors.New("MEGA interactive console is disabled in the normal user flow; use Comprobar for an existing MEGAcmd session or enable VAULTPOOL_ALLOW_MEGACMD_INTERACTIVE=1 only in developer diagnostics"))
			return
		}
		c, ok := s.connectors.Get(a.ProviderID)
		if !ok || !s.connectorReadyFor(p) {
			writeError(w, http.StatusServiceUnavailable, errors.New("official provider bridge is not installed or ready"))
			return
		}
		launcher, ok := c.(externalAuthLauncher)
		if !ok {
			writeError(w, http.StatusServiceUnavailable, errors.New("provider bridge cannot launch its official login client"))
			return
		}
		if err := launcher.LaunchAuth(r.Context(), a.ID); err != nil {
			writeError(w, http.StatusServiceUnavailable, err)
			return
		}
		msg := "VaultPool ha abierto el cliente oficial del proveedor en modo diagnóstico. Cuando termine, vuelve a VaultPool y pulsa Comprobar otra vez."
		writeJSON(w, http.StatusOK, map[string]any{"opened": true, "mode": plan.Mode, "message": msg})
	default:
		writeError(w, http.StatusConflict, errors.New("provider does not have a launchable authentication flow"))
	}
}

func (s *Server) authLaunchInfo(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusMethodNotAllowed)
	_, _ = w.Write([]byte(`<!doctype html><meta charset="utf-8"><title>VaultPool</title><body style="font-family:system-ui,Segoe UI,sans-serif;padding:32px"><h2>VaultPool no inicia OAuth desde esta pestaña</h2><p>Vuelve a la ventana principal de VaultPool y pulsa <strong>Abrir acceso seguro</strong>. El inicio de sesión se lanzará con una petición local protegida y se abrirá en el navegador configurado.</p></body>`))
}

func (s *Server) oauthBrowserStatus(w http.ResponseWriter, r *http.Request) {
	pref := s.store.OAuthBrowser()
	status, err := desktop.BrowserStatusFor(desktop.BrowserConfig{Mode: pref.Mode, BrowserID: pref.BrowserID, CustomPath: pref.CustomPath})
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, status)
}

func (s *Server) oauthBrowserConfigure(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Mode       string `json:"mode"`
		BrowserID  string `json:"browser_id"`
		CustomPath string `json:"custom_path"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	wanted := desktop.BrowserConfig{Mode: req.Mode, BrowserID: req.BrowserID, CustomPath: req.CustomPath}
	status, err := desktop.BrowserStatusFor(wanted)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	selected := status.Selected
	if selected.Mode == "browser" {
		installed := false
		for _, o := range status.Options {
			if o.ID == selected.BrowserID {
				installed = o.Installed
				break
			}
		}
		if !installed {
			writeError(w, http.StatusBadRequest, fmt.Errorf("%s no está instalado o VaultPool no lo encuentra; usa Detectar otra vez o Elegir ejecutable", selected.BrowserID))
			return
		}
	}
	if selected.Mode == "custom" {
		st, err := os.Stat(selected.CustomPath)
		if err != nil || st.IsDir() {
			writeError(w, http.StatusBadRequest, fmt.Errorf("ejecutable de navegador no válido: %s", selected.CustomPath))
			return
		}
	}
	cfg, err := s.store.SetOAuthBrowser(appstate.OAuthBrowser{Mode: selected.Mode, BrowserID: selected.BrowserID, CustomPath: selected.CustomPath})
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	status, err = desktop.BrowserStatusFor(desktop.BrowserConfig{Mode: cfg.Mode, BrowserID: cfg.BrowserID, CustomPath: cfg.CustomPath})
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, status)
}

func (s *Server) configureConnector(w http.ResponseWriter, r *http.Request) {
	providerID := strings.TrimSpace(r.PathValue("id"))
	p, ok := s.catalog.Get(providerID)
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("provider not found"))
		return
	}
	if p.AuthStrategy != catalog.AuthSystemBrowserOAuth {
		writeError(w, http.StatusConflict, errors.New("this provider does not use a configurable OAuth client ID"))
		return
	}
	if s.vault == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("Windows secret vault is unavailable"))
		return
	}
	var req struct {
		ClientID     string `json:"client_id"`
		ClientSecret string `json:"client_secret"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	cfg := oauthconfig.Clean(oauthconfig.Config{ClientID: req.ClientID, ClientSecret: req.ClientSecret})
	if providerID != "google-drive" && providerID != "pcloud" && cfg.ClientSecret != "" {
		writeError(w, http.StatusBadRequest, errors.New("este proveedor no usa Client Secret en VaultPool"))
		return
	}
	if err := oauthconfig.Validate(cfg); err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	var (
		client *oauthnative.Client
		err    error
	)
	switch providerID {
	case "google-drive":
		client, err = oauthnative.GoogleWithSecret(cfg.ClientID, cfg.ClientSecret, nil)
	case "onedrive":
		client, err = oauthnative.Microsoft(cfg.ClientID, nil)
	case "dropbox":
		client, err = oauthnative.Dropbox(cfg.ClientID, nil)
	case "pcloud":
		client, err = oauthnative.PCloud(cfg.ClientID, cfg.ClientSecret, nil)
	default:
		err = errors.New("OAuth runtime configuration is not implemented for this provider")
	}
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if err := oauthconfig.Store(s.vault, providerID, cfg); err != nil {
		writeError(w, http.StatusInternalServerError, fmt.Errorf("guardar configuración OAuth del conector: %w", err))
		return
	}
	if err := s.setOAuthConnector(providerID, client); err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"provider_id": providerID, "connector_ready": true, "status": s.connectorStatusFor(p)})
}

type filenLoginConnector interface {
	Login(context.Context, string, string, string, string) (connector.Snapshot, error)
}

type filenLogoutConnector interface {
	Logout(string) error
}

func (s *Server) filenLogin(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeFilenLoginError(w, http.StatusNotFound, "", errors.New("account not found"))
		return
	}
	if a.ProviderID != filenconnector.ProviderID {
		writeFilenLoginError(w, http.StatusConflict, "", errors.New("account is not a Filen account"))
		return
	}
	p, ok := s.catalog.Get(a.ProviderID)
	if !ok || p.AuthStrategy != catalog.AuthDirectCredentials {
		writeFilenLoginError(w, http.StatusConflict, "", errors.New("provider is not approved for direct credentials"))
		return
	}
	if s.vault == nil {
		writeFilenLoginError(w, http.StatusServiceUnavailable, "", errors.New("Bóveda segura de Windows no disponible."))
		return
	}
	c, ok := s.connectors.Get(filenconnector.ProviderID)
	if !ok || !s.connectorReadyFor(p) {
		writeFilenLoginError(w, http.StatusServiceUnavailable, "", errors.New(s.connectorStatusFor(p)))
		return
	}
	login, ok := c.(filenLoginConnector)
	if !ok {
		writeFilenLoginError(w, http.StatusServiceUnavailable, "", errors.New("Conector directo de Filen no disponible."))
		return
	}
	var req struct {
		Email         string `json:"email"`
		Password      string `json:"password"`
		TwoFactorCode string `json:"two_factor_code"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	if len(req.Email) > 320 || len(req.Password) > 1024 || len(req.TwoFactorCode) > 128 {
		writeFilenLoginError(w, http.StatusBadRequest, "", errors.New("Campos de acceso de Filen demasiado largos."))
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
	defer cancel()
	snap, err := login.Login(ctx, a.ID, req.Email, req.Password, req.TwoFactorCode)
	if err != nil {
		writeFilenLoginError(w, filenStatus(err), filenconnector.Code(err), err)
		return
	}
	updated, err := s.applyConnectorSnapshot(snap)
	if err != nil {
		if logout, ok := c.(filenLogoutConnector); ok {
			_ = logout.Logout(a.ID)
		}
		writeFilenLoginError(w, http.StatusConflict, "", err)
		return
	}
	snap.Identity = ""
	writeJSON(w, http.StatusOK, map[string]any{"connected": true, "account": updated, "snapshot": snap})
}

func (s *Server) filenLogout(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	if a.ProviderID != filenconnector.ProviderID {
		writeError(w, http.StatusConflict, errors.New("account is not a Filen account"))
		return
	}
	c, ok := s.connectors.Get(filenconnector.ProviderID)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("Filen direct connector is not available"))
		return
	}
	logout, ok := c.(filenLogoutConnector)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("Filen direct connector is not available"))
		return
	}
	if err := logout.Logout(a.ID); err != nil {
		writeError(w, http.StatusInternalServerError, errors.New("No se pudo borrar la sesión segura de Filen."))
		return
	}
	if s.vault != nil {
		if err := s.vault.Delete(a.ID, secretvault.FilenSession); err != nil {
			writeError(w, http.StatusInternalServerError, errors.New("No se pudo borrar la sesión segura de Filen."))
			return
		}
		if err := s.vault.Delete(a.ID, secretvault.AccountIdentity); err != nil {
			writeError(w, http.StatusInternalServerError, errors.New("No se pudo borrar la identidad segura de Filen."))
			return
		}
	}
	updated, err := s.store.MarkReauthRequired(a.ID, "Sesión de Filen desconectada. Los datos remotos y el catálogo se conservaron.")
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"disconnected": true, "account": updated})
}

type mediafireLoginConnector interface {
	Login(context.Context, string, string, string, string) (connector.Snapshot, error)
}

type mediafireLogoutConnector interface{ Logout(string) error }

func (s *Server) mediafireLogin(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	if a.ProviderID != mediafireconnector.ProviderID {
		writeError(w, http.StatusConflict, errors.New("account is not a MediaFire account"))
		return
	}
	if s.vault == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("Bóveda segura de Windows no disponible."))
		return
	}
	c, ok := s.connectors.Get(mediafireconnector.ProviderID)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("Conector oficial de MediaFire no disponible."))
		return
	}
	login, ok := c.(mediafireLoginConnector)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("Conector oficial de MediaFire no disponible."))
		return
	}
	var req struct {
		ApplicationID string `json:"application_id"`
		Email         string `json:"email"`
		Password      string `json:"password"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	if len(req.ApplicationID) > 128 || len(req.Email) > 320 || len(req.Password) > 1024 {
		writeError(w, http.StatusBadRequest, errors.New("Campos de acceso de MediaFire demasiado largos."))
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 90*time.Second)
	defer cancel()
	snap, err := login.Login(ctx, a.ID, req.ApplicationID, req.Email, req.Password)
	// Clear the request object before the handler returns; it must not survive in
	// diagnostics, logs, UI state or the secret vault.
	req.Password = ""
	if err != nil {
		writeError(w, http.StatusBadGateway, err)
		return
	}
	updated, err := s.applyConnectorSnapshot(snap)
	if err != nil {
		if logout, ok := c.(mediafireLogoutConnector); ok {
			_ = logout.Logout(a.ID)
		}
		writeError(w, http.StatusConflict, err)
		return
	}
	snap.Identity = ""
	writeJSON(w, http.StatusOK, map[string]any{"connected": true, "account": updated, "snapshot": snap})
}

func (s *Server) mediafireLogout(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	if a.ProviderID != mediafireconnector.ProviderID {
		writeError(w, http.StatusConflict, errors.New("account is not a MediaFire account"))
		return
	}
	c, ok := s.connectors.Get(mediafireconnector.ProviderID)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("Conector oficial de MediaFire no disponible."))
		return
	}
	logout, ok := c.(mediafireLogoutConnector)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("Conector oficial de MediaFire no disponible."))
		return
	}
	if err := logout.Logout(a.ID); err != nil {
		writeError(w, http.StatusInternalServerError, errors.New("No se pudo borrar la sesión segura de MediaFire."))
		return
	}
	if s.vault != nil {
		_ = s.vault.Delete(a.ID, secretvault.AccountIdentity)
	}
	updated, err := s.store.MarkReauthRequired(a.ID, "Sesión de MediaFire desconectada. Los datos remotos y el catálogo se conservaron.")
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"disconnected": true, "account": updated})
}

func (s *Server) webDAVLogin(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	p, ok := s.catalog.Get(a.ProviderID)
	if !ok || p.GenericProtocol != "webdav" || p.AuthStrategy != catalog.AuthDirectCredentials {
		writeError(w, http.StatusConflict, errors.New("account is not an audited WebDAV account"))
		return
	}
	if s.vault == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("la bóveda cifrada no está disponible"))
		return
	}
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	req.Username = strings.TrimSpace(req.Username)
	if req.Username == "" || req.Password == "" {
		writeError(w, http.StatusBadRequest, errors.New("introduce usuario y contraseña/token WebDAV"))
		return
	}
	if len(req.Username) > 512 || len(req.Password) > 2048 {
		writeError(w, http.StatusBadRequest, errors.New("credenciales WebDAV demasiado largas"))
		return
	}
	secret, err := json.Marshal(webdavgeneric.Credentials{Username: req.Username, Password: req.Password})
	req.Password = ""
	if err != nil {
		writeError(w, http.StatusInternalServerError, errors.New("no se pudieron preparar las credenciales WebDAV"))
		return
	}
	defer func() {
		for i := range secret {
			secret[i] = 0
		}
	}()
	if err := s.vault.Put(a.ID, secretvault.ProviderSession, secret); err != nil {
		writeError(w, http.StatusInternalServerError, errors.New("no se pudieron guardar las credenciales WebDAV en la bóveda cifrada"))
		return
	}

	wc := webdavgeneric.NewConnector(p, s.vault)
	if err := s.connectors.Set(wc); err != nil {
		_ = s.vault.Delete(a.ID, secretvault.ProviderSession)
		writeError(w, http.StatusInternalServerError, errors.New("no se pudo activar el conector WebDAV"))
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 25*time.Second)
	defer cancel()
	snap, err := wc.Probe(ctx, a.ID)
	if err != nil {
		_ = s.vault.Delete(a.ID, secretvault.ProviderSession)
		writeError(w, http.StatusBadGateway, err)
		return
	}
	updated, err := s.applyConnectorSnapshot(snap)
	if err != nil {
		_ = s.vault.Delete(a.ID, secretvault.ProviderSession)
		writeError(w, http.StatusConflict, err)
		return
	}
	snap.Identity = ""
	writeJSON(w, http.StatusOK, map[string]any{"connected": true, "account": updated, "snapshot": snap})
}

func (s *Server) disconnectAccount(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	if s.vault == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("la bóveda cifrada no está disponible"))
		return
	}
	p, ok := s.catalog.Get(a.ProviderID)
	if !ok {
		writeError(w, http.StatusConflict, errors.New("provider policy missing"))
		return
	}

	// Providers with connector-owned session state get their normal logout
	// first. This is account-scoped for Filen/MediaFire and therefore cannot
	// disconnect sibling accounts from the same provider.
	switch a.ProviderID {
	case filenconnector.ProviderID:
		c, ok := s.connectors.Get(a.ProviderID)
		if !ok {
			writeError(w, http.StatusServiceUnavailable, errors.New("Filen direct connector is not available"))
			return
		}
		logout, ok := c.(filenLogoutConnector)
		if !ok || logout.Logout(a.ID) != nil {
			writeError(w, http.StatusInternalServerError, errors.New("No se pudo borrar la sesión segura de Filen."))
			return
		}
	case mediafireconnector.ProviderID:
		c, ok := s.connectors.Get(a.ProviderID)
		if !ok {
			writeError(w, http.StatusServiceUnavailable, errors.New("Conector oficial de MediaFire no disponible."))
			return
		}
		logout, ok := c.(mediafireLogoutConnector)
		if !ok || logout.Logout(a.ID) != nil {
			writeError(w, http.StatusInternalServerError, errors.New("No se pudo borrar la sesión segura de MediaFire."))
			return
		}
	case "mega":
		writeError(w, http.StatusConflict, errors.New("MEGA usa una sesión global de MEGAcmd; la desconexión individual permanece bloqueada para evitar afectar otra identidad"))
		return
	}

	for _, kind := range []secretvault.Kind{
		secretvault.ProviderSession,
		secretvault.FilenSession,
		secretvault.MediaFireSession,
		secretvault.OAuthRefreshToken,
		secretvault.OAuthAccessToken,
		secretvault.AccountIdentity,
	} {
		if err := s.vault.Delete(a.ID, kind); err != nil {
			writeError(w, http.StatusInternalServerError, fmt.Errorf("no se pudo borrar la sesión local de %s", p.Name))
			return
		}
	}
	updated, err := s.store.MarkReauthRequired(a.ID, "Sesión desconectada. Los datos remotos y el catálogo se conservaron.")
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"disconnected": true, "account": updated})
}

func filenStatus(err error) int {
	switch filenconnector.Code(err) {
	case filenconnector.ErrInvalidCredentials, filenconnector.ErrTwoFactorInvalid:
		return http.StatusUnauthorized
	case filenconnector.ErrTwoFactorRequired:
		return http.StatusConflict
	case filenconnector.ErrRateLimited:
		return http.StatusTooManyRequests
	case filenconnector.ErrNetwork:
		if errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled) {
			return http.StatusGatewayTimeout
		}
		return http.StatusBadGateway
	case filenconnector.ErrSessionInvalid, filenconnector.ErrAccountInvalid:
		return http.StatusBadGateway
	default:
		return http.StatusBadGateway
	}
}

func writeFilenLoginError(w http.ResponseWriter, status int, code filenconnector.ErrorCode, err error) {
	message := "No se pudo completar el inicio de sesión directo con Filen."
	switch code {
	case filenconnector.ErrInvalidCredentials:
		message = "Email o contraseña de Filen incorrectos."
	case filenconnector.ErrTwoFactorRequired:
		message = "Introduce tu código de verificación de Filen."
	case filenconnector.ErrTwoFactorInvalid:
		message = "El código de verificación de Filen no es válido."
	case filenconnector.ErrSessionInvalid:
		message = "No se pudo renovar la sesión de Filen. Inicia sesión de nuevo."
	case filenconnector.ErrRateLimited:
		message = "Filen limitó temporalmente el inicio de sesión. Espera y vuelve a intentarlo."
	case filenconnector.ErrNetwork:
		message = "No se pudo comunicar con Filen. Comprueba la conexión y vuelve a intentarlo."
	case filenconnector.ErrAccountInvalid:
		// Connector account-validation errors are deliberately written as safe,
		// user-facing messages and never include credentials/session material.
		// Preserve the concrete reason instead of collapsing every Filen metadata
		// issue into one ambiguous message.
		if strings.TrimSpace(err.Error()) != "" {
			message = err.Error()
		} else {
			message = "Filen no devolvió una identidad o cuota de cuenta válida."
		}
	}
	body := map[string]any{"error": message}
	if code != "" {
		body["code"] = string(code)
		body["two_factor_required"] = code == filenconnector.ErrTwoFactorRequired
	}
	writeJSON(w, status, body)
}

func (s *Server) startOAuthCallbackListener() (string, func(context.Context) error, error) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return "", nil, err
	}
	addr := ln.Addr().String()
	if err := validateLocalListen(addr); err != nil {
		_ = ln.Close()
		return "", nil, err
	}
	var once sync.Once
	var shutdownErr error
	callbackMux := http.NewServeMux()
	srv := &http.Server{Handler: securityHeaders(localRequestOnly(callbackMux)), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second, IdleTimeout: 30 * time.Second, ErrorLog: log.Default()}
	stop := func(ctx context.Context) error {
		once.Do(func() { shutdownErr = srv.Shutdown(ctx) })
		return shutdownErr
	}
	callbackMux.HandleFunc("GET /oauth/callback", func(w http.ResponseWriter, r *http.Request) {
		s.oauthCallback(w, r)
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			_ = stop(ctx)
		}()
	})
	go func() {
		if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Printf("VaultPool OAuth callback listener stopped unexpectedly: %v", err)
		}
	}()
	go func() {
		t := time.NewTimer(10 * time.Minute)
		defer t.Stop()
		<-t.C
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = stop(ctx)
	}()
	return addr, stop, nil
}

func (s *Server) callbackHost(providerID, requestHost string) (string, error) {
	if err := validateLocalListen(requestHost); err != nil {
		return "", errors.New("OAuth callback listener is unavailable")
	}
	host, port, err := net.SplitHostPort(requestHost)
	if err != nil || strings.TrimSpace(port) == "" {
		return "", errors.New("OAuth callback listener is unavailable")
	}
	if !loopbackHost(host) {
		return "", errors.New("OAuth callback listener is unavailable")
	}
	// Dropbox is strict about the literal registered redirect URI. Keep its
	// documented IPv4 loopback address without imposing it on other providers.
	if providerID == "dropbox" {
		return net.JoinHostPort("127.0.0.1", port), nil
	}
	// Microsoft desktop registrations conventionally use localhost. This stays
	// on the same loopback listener but avoids turning a Dropbox-only migration
	// into a OneDrive redirect mismatch.
	if providerID == "onedrive" {
		return net.JoinHostPort("localhost", port), nil
	}
	return net.JoinHostPort(host, port), nil
}

func (s *Server) beginSystemBrowserAuth(accountID, requestHost string) (string, authflow.Session, authflow.Plan, int, error) {
	a, ok := s.store.GetAccount(accountID)
	if !ok {
		return "", authflow.Session{}, authflow.Plan{}, http.StatusNotFound, errors.New("account not found")
	}
	p, ok := s.catalog.Get(a.ProviderID)
	if !ok {
		return "", authflow.Session{}, authflow.Plan{}, http.StatusConflict, errors.New("provider policy missing")
	}
	plan := authflow.Decide(p, s.shellCapabilities())
	if plan.Mode != authflow.SystemBrowserOAuth {
		return "", authflow.Session{}, plan, http.StatusConflict, errors.New("provider is not approved for system-browser OAuth")
	}
	client := s.oauthClient(p.ID)
	if client == nil || s.vault == nil || !s.connectorReadyFor(p) {
		return "", authflow.Session{}, plan, http.StatusServiceUnavailable, errors.New(s.connectorStatusFor(p))
	}
	callbackHost, err := s.callbackHost(p.ID, requestHost)
	if err != nil {
		return "", authflow.Session{}, plan, http.StatusServiceUnavailable, err
	}
	redirectURI := "http://" + callbackHost + "/oauth/callback"
	if p.ID == "onedrive" {
		redirectURI = "http://" + callbackHost + "/"
	}
	session, state, err := s.sessions.StartOAuth(a.ID, p.ID, plan, redirectURI)
	if err != nil {
		return "", authflow.Session{}, plan, http.StatusInternalServerError, err
	}
	authURL, err := client.AuthorizationURL(redirectURI, state, session.PKCEChallenge)
	if err != nil {
		_ = s.sessions.Cancel(session.ID)
		return "", authflow.Session{}, plan, http.StatusInternalServerError, err
	}
	return authURL, session, plan, http.StatusCreated, nil
}

func (s *Server) oauthCallback(w http.ResponseWriter, r *http.Request) {
	state := r.URL.Query().Get("state")
	if state == "" {
		http.Error(w, "VaultPool: missing OAuth state", http.StatusBadRequest)
		return
	}
	ctx, err := s.sessions.ConsumeState(state)
	if err != nil {
		http.Error(w, "VaultPool: invalid or expired OAuth session", http.StatusBadRequest)
		return
	}
	if providerErr := r.URL.Query().Get("error"); providerErr != "" {
		http.Error(w, "VaultPool: provider denied authorization", http.StatusBadRequest)
		return
	}
	code := r.URL.Query().Get("code")
	if code == "" {
		http.Error(w, "VaultPool: missing authorization code", http.StatusBadRequest)
		return
	}
	client := s.oauthClient(ctx.ProviderID)
	if client == nil || s.vault == nil {
		http.Error(w, "VaultPool: OAuth connector unavailable", http.StatusServiceUnavailable)
		return
	}
	var tok oauthnative.Token
	if ctx.ProviderID == "pcloud" {
		hostname := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("hostname")))
		locationID, _ := strconv.Atoi(r.URL.Query().Get("locationid"))
		if hostname != "api.pcloud.com" && hostname != "eapi.pcloud.com" {
			http.Error(w, "VaultPool: pCloud did not return a valid regional API hostname", http.StatusBadRequest)
			return
		}
		tok, err = client.ExchangeCodeAtHost(r.Context(), code, ctx.Verifier, ctx.RedirectURI, hostname)
		if err == nil {
			tok.PCloudHostname = hostname
			tok.PCloudLocationID = locationID
		}
	} else {
		tok, err = client.ExchangeCode(r.Context(), code, ctx.Verifier, ctx.RedirectURI)
	}
	if err != nil {
		http.Error(w, "VaultPool: token exchange failed: "+err.Error(), http.StatusBadGateway)
		return
	}
	if err := cloudconnector.StoreToken(s.vault, ctx.AccountID, tok); err != nil {
		http.Error(w, "VaultPool: secure token storage failed", http.StatusInternalServerError)
		return
	}
	c, ok := s.connectors.Get(ctx.ProviderID)
	if !ok || !s.connectors.Ready(ctx.ProviderID) {
		http.Error(w, "VaultPool: connector unavailable", http.StatusServiceUnavailable)
		return
	}
	snap, err := c.Probe(r.Context(), ctx.AccountID)
	if err != nil {
		http.Error(w, "VaultPool: account authorized; quota verification pending", http.StatusBadGateway)
		return
	}
	if _, err := s.applyConnectorSnapshot(snap); err != nil {
		http.Error(w, "VaultPool: account verification failed", http.StatusConflict)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = w.Write([]byte("<!doctype html><meta charset=utf-8><title>VaultPool</title><body><h2>Cuenta conectada correctamente</h2><p>La identidad y la cuota han sido verificadas. Ya puedes cerrar esta pestaña y volver a VaultPool.</p></body>"))
}

func (s *Server) probeAccount(w http.ResponseWriter, r *http.Request) {
	a, ok := s.store.GetAccount(r.PathValue("id"))
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("account not found"))
		return
	}
	c, ok := s.connectors.Get(a.ProviderID)
	if !ok {
		writeError(w, http.StatusServiceUnavailable, errors.New("connector not registered"))
		return
	}
	probeCtx, cancel := context.WithTimeout(r.Context(), 18*time.Second)
	defer cancel()
	snap, err := c.Probe(probeCtx, a.ID)
	if err != nil {
		if a.ProviderID == filenconnector.ProviderID && filenconnector.Code(err) == filenconnector.ErrSessionInvalid {
			_, _ = s.store.MarkReauthRequired(a.ID, "No se pudo renovar la sesión de Filen. Inicia sesión de nuevo. Los datos remotos se conservaron.")
			writeError(w, http.StatusUnauthorized, errors.New("No se pudo renovar la sesión de Filen. Inicia sesión de nuevo."))
			return
		}
		// A failed probe must never manufacture a connected state. The error is
		// returned to the user while the previous trusted snapshot is preserved.
		if errors.Is(probeCtx.Err(), context.DeadlineExceeded) || errors.Is(err, context.DeadlineExceeded) {
			writeError(w, http.StatusGatewayTimeout, errors.New("provider check timed out; VaultPool cancelled it to keep the UI usable"))
			return
		}
		writeError(w, http.StatusServiceUnavailable, err)
		return
	}
	updated, err := s.applyConnectorSnapshot(snap)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"account": updated, "snapshot": snap})
}

func (s *Server) addAccount(w http.ResponseWriter, r *http.Request) {
	var req struct {
		ProviderID              string `json:"provider_id"`
		ResponsibleUseConfirmed bool   `json:"responsible_use_confirmed"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	providerID := strings.ToLower(strings.TrimSpace(req.ProviderID))
	count := 0
	for _, account := range s.store.Snapshot().Accounts {
		if strings.EqualFold(strings.TrimSpace(account.ProviderID), providerID) {
			count++
		}
	}
	if count > 0 && !req.ResponsibleUseConfirmed {
		writeError(w, http.StatusPreconditionRequired, errors.New("confirma el uso responsable antes de añadir otra cuenta del mismo proveedor"))
		return
	}
	a, p, err := s.store.AddAccount(providerID)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	caps := s.shellCapabilities()
	ready := s.connectorReadyFor(p)
	writeJSON(w, 201, map[string]any{"account": a, "provider": p, "auth": authflow.Decide(p, caps), "connector_ready": ready, "connector_status": s.connectorStatusFor(p)})
}

func (s *Server) addCustomProvider(w http.ResponseWriter, r *http.Request) {
	if s.vault == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("la bóveda cifrada no está disponible; no se pueden guardar credenciales WebDAV"))
		return
	}
	var req webdavgeneric.AuditInput
	if !decodeJSON(w, r, &req) {
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
	defer cancel()
	result := webdavgeneric.Audit(ctx, req)
	if !result.Passed {
		writeJSON(w, http.StatusUnprocessableEntity, result)
		return
	}
	if err := s.store.AddCustomProvider(result.Provider); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	wc := webdavgeneric.NewConnector(result.Provider, s.vault)
	if err := s.connectors.Register(wc); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	a, _, err := s.store.AddAccount(result.Provider.ID)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	secret, err := json.Marshal(result.Credentials)
	if err != nil {
		_ = s.store.RemoveAccount(a.ID)
		writeError(w, http.StatusInternalServerError, errors.New("no se pudieron preparar las credenciales"))
		return
	}
	if err := s.vault.Put(a.ID, secretvault.ProviderSession, secret); err != nil {
		for i := range secret {
			secret[i] = 0
		}
		_ = s.store.RemoveAccount(a.ID)
		writeError(w, http.StatusInternalServerError, errors.New("no se pudieron guardar las credenciales en la bóveda cifrada"))
		return
	}
	for i := range secret {
		secret[i] = 0
	}

	snap, err := wc.Probe(ctx, a.ID)
	if err != nil {
		writeJSON(w, http.StatusCreated, map[string]any{
			"provider":  result.Provider,
			"account":   a,
			"audit":     result,
			"connected": false,
			"warning":   "La auditoría pasó y la nube se añadió, pero la comprobación final de cuota falló: " + err.Error(),
		})
		return
	}
	updated, err := s.applyConnectorSnapshot(snap)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{
		"provider":  result.Provider,
		"account":   updated,
		"audit":     result,
		"connected": true,
	})
}

func (s *Server) requestReview(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Name        string `json:"name"`
		OfficialURL string `json:"official_url"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	review, err := s.store.RequestProviderReview(req.Name, req.OfficialURL)
	if err != nil {
		writeError(w, 400, err)
		return
	}
	writeJSON(w, 201, map[string]any{
		"review":             review,
		"connection_allowed": false,
		"local_only":         review.LocalOnly,
		"review_scope":       review.ReviewScope,
		"connection_policy":  review.ConnectionPolicy,
	})
}

func (s *Server) libraryState(w http.ResponseWriter, r *http.Request) {
	categories := library.Categories()
	if s.library == nil {
		writeJSON(w, http.StatusOK, map[string]any{"ready": false, "folders": []library.Folder{}, "assignments": map[string]string{}, "categories": categories, "file_categories": map[string]library.Category{}, "extensions": map[string]string{}})
		return
	}
	st, err := s.library.Snapshot()
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	fileCategories := map[string]library.Category{}
	extensions := map[string]string{}
	if s.files != nil {
		items, err := s.files.List()
		if err != nil {
			writeError(w, http.StatusInternalServerError, err)
			return
		}
		for _, f := range items {
			fileCategories[f.FileID] = library.CategoryFor(f.FileName)
			extensions[f.FileID] = library.Extension(f.FileName)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"ready": true, "folders": st.Folders, "assignments": st.Assignments,
		"categories": categories, "file_categories": fileCategories, "extensions": extensions,
	})
}

func (s *Server) libraryCreateFolder(w http.ResponseWriter, r *http.Request) {
	if s.library == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("encrypted library unavailable"))
		return
	}
	var req struct {
		Name string `json:"name"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	folder, err := s.library.CreateFolder(req.Name)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"folder": folder})
}

func (s *Server) libraryRenameFolder(w http.ResponseWriter, r *http.Request) {
	if s.library == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("encrypted library unavailable"))
		return
	}
	var req struct {
		Name string `json:"name"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	folder, err := s.library.RenameFolder(strings.TrimSpace(r.PathValue("id")), req.Name)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"folder": folder})
}

func (s *Server) libraryDeleteFolder(w http.ResponseWriter, r *http.Request) {
	if s.library == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("encrypted library unavailable"))
		return
	}
	if err := s.library.DeleteFolder(strings.TrimSpace(r.PathValue("id"))); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"deleted": true})
}

func (s *Server) libraryAssignFolder(w http.ResponseWriter, r *http.Request) {
	if s.library == nil || s.files == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("encrypted library unavailable"))
		return
	}
	fileID := strings.TrimSpace(r.PathValue("id"))
	if _, ok, err := s.files.Get(fileID); err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	} else if !ok {
		writeError(w, http.StatusNotFound, errors.New("managed file not found"))
		return
	}
	var req struct {
		FolderID string `json:"folder_id"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	if err := s.library.Assign(fileID, strings.TrimSpace(req.FolderID)); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"file_id": fileID, "folder_id": strings.TrimSpace(req.FolderID)})
}

func (s *Server) listFiles(w http.ResponseWriter, r *http.Request) {
	if s.files == nil {
		writeJSON(w, http.StatusOK, map[string]any{"ready": false, "files": []any{}, "reason": "La gestión segura de archivos requiere la bóveda local de Windows."})
		return
	}
	items, err := s.files.List()
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	recovery, _ := s.files.RecoveryConfigured()
	writeJSON(w, http.StatusOK, map[string]any{"ready": true, "recovery_configured": recovery, "files": items})
}

func (s *Server) fileDistribution(w http.ResponseWriter, r *http.Request) {
	if s.files == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("managed file service unavailable"))
		return
	}
	report, err := s.files.Distribution(strings.TrimSpace(r.PathValue("id")))
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	type providerView struct {
		ID        string `json:"id"`
		Name      string `json:"name"`
		Fragments int    `json:"fragments"`
		Blocks    int    `json:"blocks"`
		Bytes     int64  `json:"bytes"`
		Connected bool   `json:"connected"`
	}
	byProvider := map[string]*providerView{}
	for _, item := range report.Providers {
		entry := byProvider[item.ProviderID]
		if entry == nil {
			name := item.ProviderID
			if p, ok := s.catalog.Get(item.ProviderID); ok {
				name = p.Name
			}
			entry = &providerView{ID: item.ProviderID, Name: name}
			byProvider[item.ProviderID] = entry
		}
		entry.Fragments += item.Fragments
		entry.Blocks += item.Blocks
		entry.Bytes += item.Bytes
	}
	for _, account := range s.store.Snapshot().Accounts {
		if account.State != "connected" || strings.TrimSpace(account.ProviderID) == "" {
			continue
		}
		entry := byProvider[account.ProviderID]
		if entry == nil {
			name := account.ProviderID
			if p, ok := s.catalog.Get(account.ProviderID); ok {
				name = p.Name
			}
			entry = &providerView{ID: account.ProviderID, Name: name}
			byProvider[account.ProviderID] = entry
		}
		entry.Connected = true
	}
	providers := make([]providerView, 0, len(byProvider))
	for _, entry := range byProvider {
		providers = append(providers, *entry)
	}
	sort.Slice(providers, func(i, j int) bool { return providers[i].Name < providers[j].Name })
	writeJSON(w, http.StatusOK, map[string]any{
		"file_id": report.FileID, "data_shards": report.DataShards, "parity_shards": report.ParityShards,
		"blocks": report.Blocks, "fragments": report.Fragments, "bytes": report.Bytes, "providers": providers,
		"note": "El reparto queda fijado al proteger el archivo. Las nubes conectadas después no reciben fragmentos de archivos ya protegidos.",
	})
}

func (s *Server) playerUnavailable(w http.ResponseWriter) bool {
	if !buildinfo.DataOperationsEnabled() {
		writeError(w, http.StatusForbidden, errors.New("this build does not permit media playback"))
		return true
	}
	if s.player == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("media player service unavailable"))
		return true
	}
	return false
}

func (s *Server) playerPrepare(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	st, err := s.player.Prepare(strings.TrimSpace(r.PathValue("id")))
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	writeJSON(w, http.StatusAccepted, st)
}

func (s *Server) playerStatus(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	st, err := s.player.Status(strings.TrimSpace(r.PathValue("id")))
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	writeJSON(w, http.StatusOK, st)
}

func (s *Server) playerStream(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	if err := s.player.Stream(w, r, strings.TrimSpace(r.PathValue("id"))); err != nil {
		if r.Context().Err() != nil {
			return
		}
		writeError(w, http.StatusConflict, err)
	}
}

func (s *Server) playerOpenDefault(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	if err := s.player.OpenDefault(strings.TrimSpace(r.PathValue("id"))); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]bool{"opened": true})
}

func (s *Server) playerOpenVLC(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	if err := s.player.OpenVLC(strings.TrimSpace(r.PathValue("id"))); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusAccepted, map[string]bool{"opened": true})
}

func (s *Server) playerClearCache(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	if err := s.player.Clear(strings.TrimSpace(r.PathValue("id"))); err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"cleared": true})
}

func (s *Server) playerPlugins(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"plugins": []mediaplayer.PluginStatus{s.player.PluginStatus("vlc")}})
}

func (s *Server) playerInstallPlugin(w http.ResponseWriter, r *http.Request) {
	if s.playerUnavailable(w) {
		return
	}
	st, err := s.player.StartInstallPlugin(strings.TrimSpace(r.PathValue("id")))
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	writeJSON(w, http.StatusAccepted, st)
}

func (s *Server) auditFile(w http.ResponseWriter, r *http.Request) {
	if !buildinfo.DataOperationsEnabled() {
		writeError(w, http.StatusForbidden, errors.New("this build does not permit file audit"))
		return
	}
	if s.files == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("managed file service unavailable"))
		return
	}
	h, err := s.files.Audit(r.Context(), r.PathValue("id"))
	if err != nil {
		writeError(w, http.StatusServiceUnavailable, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"health": h})
}

func (s *Server) repairFile(w http.ResponseWriter, r *http.Request) {
	if !buildinfo.DataOperationsEnabled() {
		writeError(w, http.StatusForbidden, errors.New("this build does not permit repair"))
		return
	}
	if s.files == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("managed file service unavailable"))
		return
	}
	result, err := s.files.Repair(r.Context(), r.PathValue("id"))
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, result)
}

func (s *Server) deleteFile(w http.ResponseWriter, r *http.Request) {
	if !buildinfo.DataOperationsEnabled() {
		writeError(w, http.StatusForbidden, errors.New("this build does not permit deletion"))
		return
	}
	if s.files == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("managed file service unavailable"))
		return
	}
	var req struct {
		ConfirmName            string `json:"confirm_name"`
		UnderstandIrreversible bool   `json:"understand_irreversible"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	fileID := strings.TrimSpace(r.PathValue("id"))
	meta, ok, err := s.files.Get(fileID)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if !ok {
		writeError(w, http.StatusNotFound, errors.New("managed file not found"))
		return
	}
	if strings.TrimSpace(req.ConfirmName) != meta.FileName || !req.UnderstandIrreversible {
		writeError(w, http.StatusConflict, errors.New("deletion requires exact file-name confirmation and irreversible-delete acknowledgement"))
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 2*time.Minute)
	defer cancel()
	result, err := s.files.Delete(ctx, fileID)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"deleted": true, "result": result})
}

func (s *Server) recoveryStatus(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeJSON(w, http.StatusOK, recoverycenter.Status{Available: false})
		return
	}
	writeJSON(w, http.StatusOK, s.recovery.Status())
}

func (s *Server) recoveryBegin(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeError(w, http.StatusServiceUnavailable, recoverycenter.ErrUnavailable)
		return
	}
	code, status, err := s.recovery.Begin()
	if err != nil {
		statusCode := http.StatusConflict
		if !errors.Is(err, recoverycenter.ErrAlreadyConfigured) {
			statusCode = http.StatusInternalServerError
		}
		writeError(w, statusCode, err)
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"recovery_code": code, "status": status})
}

func (s *Server) recoveryConfirm(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeError(w, http.StatusServiceUnavailable, recoverycenter.ErrUnavailable)
		return
	}
	var req struct {
		SavedPackage bool `json:"saved_package"`
		SavedCode    bool `json:"saved_code"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	status, err := s.recovery.Confirm(req.SavedPackage, req.SavedCode)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, status)
}

func (s *Server) recoveryConfirmCredentialRefresh(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeError(w, http.StatusServiceUnavailable, recoverycenter.ErrUnavailable)
		return
	}
	var req struct {
		SavedPackage bool `json:"saved_package"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	status, err := s.recovery.ConfirmCredentialRefresh(req.SavedPackage)
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, status)
}

func (s *Server) recoveryRebuildCatalog(w http.ResponseWriter, r *http.Request) {
	if !buildinfo.DataOperationsEnabled() {
		writeError(w, http.StatusForbidden, errors.New("this build does not permit catalog rebuild"))
		return
	}
	if s.assistant == nil {
		writeError(w, http.StatusServiceUnavailable, errors.New("recovery catalog assistant unavailable"))
		return
	}
	report, err := s.assistant.RebuildCatalog(r.Context())
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusOK, report)
}

func (s *Server) recoveryPackage(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeError(w, http.StatusServiceUnavailable, recoverycenter.ErrUnavailable)
		return
	}
	b, name, err := s.recovery.ExportPackage()
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	if name == "" {
		name = "VaultPool-Recovery.vpr"
	}
	name = filepath.Base(name)
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", name))
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(b)))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(b)
}

func (s *Server) recoveryStage(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeError(w, http.StatusServiceUnavailable, recoverycenter.ErrUnavailable)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, recoverycenter.MaxRecoveryPackageBytes+(1<<20))
	if err := r.ParseMultipartForm(1 << 20); err != nil {
		writeError(w, http.StatusBadRequest, fmt.Errorf("invalid recovery upload: %w", err))
		return
	}
	if r.MultipartForm != nil {
		defer r.MultipartForm.RemoveAll()
	}
	f, _, err := r.FormFile("package")
	if err != nil {
		writeError(w, http.StatusBadRequest, errors.New("recovery package required"))
		return
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, recoverycenter.MaxRecoveryPackageBytes+1))
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if int64(len(b)) > recoverycenter.MaxRecoveryPackageBytes {
		writeError(w, http.StatusRequestEntityTooLarge, errors.New("recovery package exceeds safety limit"))
		return
	}
	code := strings.TrimSpace(r.FormValue("recovery_code"))
	if len(code) > 256 {
		writeError(w, http.StatusBadRequest, errors.New("recovery code too long"))
		return
	}
	replaceCurrent := r.FormValue("replace_current") == "true"
	status, err := s.recovery.StageRestore(b, code, replaceCurrent)
	for i := range b {
		b[i] = 0
	}
	if err != nil {
		writeError(w, http.StatusConflict, err)
		return
	}
	writeJSON(w, http.StatusAccepted, status)
}

func (s *Server) recoveryCancelStaged(w http.ResponseWriter, r *http.Request) {
	if s.recovery == nil {
		writeError(w, http.StatusServiceUnavailable, recoverycenter.ErrUnavailable)
		return
	}
	status, err := s.recovery.CancelStagedRestore()
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, status)
}

func loopbackHost(raw string) bool {
	host := raw
	if h, _, err := net.SplitHostPort(raw); err == nil {
		host = h
	}
	host = strings.Trim(strings.ToLower(strings.TrimSpace(host)), "[]")
	if host == "localhost" {
		return true
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}

func localRequestOnly(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !loopbackHost(r.Host) {
			writeError(w, http.StatusForbidden, errors.New("non-local Host rejected"))
			return
		}
		if origin := strings.TrimSpace(r.Header.Get("Origin")); origin != "" {
			u, err := url.Parse(origin)
			if err != nil || u.Scheme != "http" || u.User != nil || u.Host == "" || !strings.EqualFold(u.Host, r.Host) {
				writeError(w, http.StatusForbidden, errors.New("cross-origin request rejected"))
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()")
		w.Header().Set("Cache-Control", "no-store")
		next.ServeHTTP(w, r)
	})
}

func recoverLocalRequest(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if recovered := recover(); recovered != nil {
				log.Printf("VaultPool recovered local API handler panic (%T)", recovered)
				writeError(w, http.StatusInternalServerError, errors.New("VaultPool no pudo completar la operación. La cuenta sigue pendiente; vuelve a intentarlo."))
			}
		}()
		next.ServeHTTP(w, r)
	})
}

func (s *Server) Handler() http.Handler {
	return recoverLocalRequest(securityHeaders(localRequestOnly(s.csrfProtection(s.mux))))
}

func validateLocalListen(addr string) error {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return fmt.Errorf("invalid listen address: %w", err)
	}
	h := strings.TrimSpace(strings.ToLower(host))
	if h == "localhost" {
		return nil
	}
	ip := net.ParseIP(h)
	if ip == nil || !ip.IsLoopback() {
		return fmt.Errorf("VaultPool UI may listen only on loopback, got %q", host)
	}
	return nil
}

func (s *Server) ListenAndServe(addr string) error {
	if err := validateLocalListen(addr); err != nil {
		return err
	}
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	actual := ln.Addr().String()
	if err := validateLocalListen(actual); err != nil {
		_ = ln.Close()
		return err
	}
	if s.player != nil {
		s.player.SetBaseURL("http://" + actual)
	}
	srv := &http.Server{Addr: actual, Handler: s.Handler(), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second, WriteTimeout: 0, IdleTimeout: 60 * time.Second, ErrorLog: log.Default()}
	s.serverMu.Lock()
	if s.httpServer != nil {
		s.serverMu.Unlock()
		_ = ln.Close()
		return errors.New("VaultPool UI server is already running")
	}
	s.httpServer = srv
	s.serverMu.Unlock()
	err = srv.Serve(ln)
	s.serverMu.Lock()
	if s.httpServer == srv {
		s.httpServer = nil
	}
	s.serverMu.Unlock()
	if errors.Is(err, http.ErrServerClosed) {
		return nil
	}
	return err
}

func (s *Server) Shutdown(ctx context.Context) error {
	s.serverMu.Lock()
	srv := s.httpServer
	s.serverMu.Unlock()
	if srv == nil {
		return nil
	}
	return srv.Shutdown(ctx)
}
