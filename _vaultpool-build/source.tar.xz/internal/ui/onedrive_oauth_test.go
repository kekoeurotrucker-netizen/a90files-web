package ui

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path/filepath"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/cloudconnector"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/desktop"
	"github.com/vaultpool-project/vaultpool/internal/oauthnative"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

func TestOneDriveRootCallbackExchangesMatchingRedirectAndPKCE(t *testing.T) {
	var tokenForm url.Values
	tokenCalls := 0
	api := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/token":
			tokenCalls++
			_ = r.ParseForm()
			tokenForm = r.PostForm
			_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "test-access", "refresh_token": "test-refresh", "token_type": "Bearer", "expires_in": 3600})
		case "/me":
			_ = json.NewEncoder(w).Encode(map[string]string{"id": "user-id", "mail": "test@example.com"})
		case "/me/drive":
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "drive-id", "quota": map[string]any{"total": 1000, "used": 100, "remaining": 900, "state": "normal"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer api.Close()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("onedrive")
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(t.TempDir(), "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	oauth, err := oauthnative.New(oauthnative.Config{ProviderID: "onedrive", ClientID: "test-client", AuthorizeURL: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize", TokenURL: api.URL + "/token"}, api.Client())
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	if err := reg.Register(&cloudconnector.OAuthConnector{ID: "onedrive", OAuth: oauth, Secrets: v, HTTP: api.Client(), MSGraphBaseURL: api.URL}); err != nil {
		t.Fatal(err)
	}
	s, err := NewSecure(cat, st, reg, v, map[string]*oauthnative.Client{"onedrive": oauth})
	if err != nil {
		t.Fatal(err)
	}
	var launched string
	s.openAuthURL = func(raw string, _ desktop.BrowserConfig) error { launched = raw; return nil }
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts/"+a.ID+"/auth/launch", nil))
	if w.Code != http.StatusCreated {
		t.Fatalf("launch: %d %s", w.Code, w.Body.String())
	}
	u, err := url.Parse(launched)
	if err != nil {
		t.Fatal(err)
	}
	const redirect = "http://localhost:8742/"
	q := u.Query()
	if q.Get("redirect_uri") != redirect || q.Get("code_challenge_method") != "S256" {
		t.Fatalf("incorrect OAuth redirect/PKCE: %s", launched)
	}
	callback := redirect + "?code=test-code&state=" + url.QueryEscape(q.Get("state"))
	w = httptest.NewRecorder()
	s.Handler().ServeHTTP(w, httptest.NewRequest("GET", callback, nil))
	if w.Code != http.StatusOK {
		t.Fatalf("callback: %d %s", w.Code, w.Body.String())
	}
	if tokenForm.Get("redirect_uri") != redirect || tokenForm.Get("code") != "test-code" || tokenForm.Get("code_verifier") == "" {
		t.Fatalf("invalid token exchange: %v", tokenForm)
	}
	hash := sha256.Sum256([]byte(tokenForm.Get("code_verifier")))
	if base64.RawURLEncoding.EncodeToString(hash[:]) != q.Get("code_challenge") {
		t.Fatal("PKCE verifier does not match the challenge")
	}
	connected, _ := st.GetAccount(a.ID)
	if connected.State != "connected" || connected.TotalBytes != 1000 {
		t.Fatalf("account not verified: %+v", connected)
	}
	w = httptest.NewRecorder()
	s.Handler().ServeHTTP(w, httptest.NewRequest("GET", callback, nil))
	if w.Code != http.StatusBadRequest || tokenCalls != 1 {
		t.Fatalf("replay was not rejected: status=%d exchanges=%d", w.Code, tokenCalls)
	}
}

func TestRootOAuthRejectsMissingAndInvalidState(t *testing.T) {
	s := testServer(t)
	for _, query := range []string{"?code=untrusted", "?code=untrusted&state=invalid", "?error=access_denied", "?state=invalid"} {
		w := httptest.NewRecorder()
		s.Handler().ServeHTTP(w, httptest.NewRequest("GET", "http://localhost:8742/"+query, nil))
		if w.Code != http.StatusBadRequest {
			t.Fatalf("%s: status=%d", query, w.Code)
		}
	}
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, httptest.NewRequest("GET", "http://localhost:8742/", nil))
	if w.Code != http.StatusOK {
		t.Fatalf("normal UI status=%d", w.Code)
	}
}
