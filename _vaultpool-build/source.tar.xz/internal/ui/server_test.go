package ui

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/buildinfo"
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/cloudconnector"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/core"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/desktop"
	"github.com/vaultpool-project/vaultpool/internal/drivehost"
	"github.com/vaultpool-project/vaultpool/internal/filedialog"
	"github.com/vaultpool-project/vaultpool/internal/library"
	"github.com/vaultpool-project/vaultpool/internal/managedfiles"
	"github.com/vaultpool-project/vaultpool/internal/oauthconfig"
	"github.com/vaultpool-project/vaultpool/internal/oauthnative"
	"github.com/vaultpool-project/vaultpool/internal/recoverycenter"
	"github.com/vaultpool-project/vaultpool/internal/recoveryrecords"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
	"github.com/vaultpool-project/vaultpool/internal/storage"
	"github.com/vaultpool-project/vaultpool/internal/transfers"
)

func testServer(t *testing.T) *Server {
	t.Helper()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	s, err := New(cat, st)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func unsafeRequest(s *Server, method, target string, body io.Reader) *http.Request {
	r := httptest.NewRequest(method, target, body)
	r.Header.Set("X-VaultPool-CSRF", s.csrfToken)
	r.Header.Set("Origin", "http://127.0.0.1:8742")
	return r
}

func TestUIOnlyAllowsLoopback(t *testing.T) {
	for _, a := range []string{"0.0.0.0:8742", "192.168.1.10:8742", ":8742"} {
		if validateLocalListen(a) == nil {
			t.Fatalf("should reject %s", a)
		}
	}
	for _, a := range []string{"127.0.0.1:8742", "localhost:8742", "[::1]:8742"} {
		if err := validateLocalListen(a); err != nil {
			t.Fatalf("should accept %s: %v", a, err)
		}
	}
}
func TestSecurityHeaders(t *testing.T) {
	s := testServer(t)
	r := httptest.NewRequest("GET", "http://127.0.0.1:8742/", nil)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != 200 {
		t.Fatal(w.Code)
	}
	if w.Header().Get("Content-Security-Policy") == "" {
		t.Fatal("missing CSP")
	}
	if w.Header().Get("X-Frame-Options") != "DENY" {
		t.Fatal("missing clickjacking protection")
	}
}

func TestHandlerReturnsJSONAfterAPIPanic(t *testing.T) {
	s := testServer(t)
	s.mux.HandleFunc("GET /api/panic-for-test", func(http.ResponseWriter, *http.Request) { panic("test panic") })
	r := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:8742/api/panic-for-test", nil)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusInternalServerError {
		t.Fatalf("panic response: %d %s", w.Code, w.Body.String())
	}
	if !bytes.Contains(w.Body.Bytes(), []byte("cuenta sigue pendiente")) {
		t.Fatalf("panic response omitted safe error: %s", w.Body.String())
	}
}
func TestAvailableProviderDisappearsAfterAdd(t *testing.T) {
	s := testServer(t)
	body := bytes.NewBufferString(`{"provider_id":"google-drive"}`)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", body)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != 201 {
		t.Fatalf("add: %d %s", w.Code, w.Body.String())
	}
	r2 := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/overview", nil)
	w2 := httptest.NewRecorder()
	s.Handler().ServeHTTP(w2, r2)
	var ov Overview
	if err := json.Unmarshal(w2.Body.Bytes(), &ov); err != nil {
		t.Fatal(err)
	}
	for _, p := range ov.AvailableProviders {
		if p.ID == "google-drive" {
			t.Fatal("google-drive still available")
		}
	}
}

func TestSecondAccountRequiresResponsibleUseConfirmationAndAppearsInProviderGroup(t *testing.T) {
	s := testServer(t)
	first := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"google-drive"}`))
	fw := httptest.NewRecorder()
	s.Handler().ServeHTTP(fw, first)
	if fw.Code != http.StatusCreated {
		t.Fatalf("first account: %d %s", fw.Code, fw.Body.String())
	}

	blocked := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":" GOOGLE-DRIVE "}`))
	bw := httptest.NewRecorder()
	s.Handler().ServeHTTP(bw, blocked)
	if bw.Code != http.StatusPreconditionRequired {
		t.Fatalf("second account without confirmation: %d %s", bw.Code, bw.Body.String())
	}

	second := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"google-drive","responsible_use_confirmed":true}`))
	sw := httptest.NewRecorder()
	s.Handler().ServeHTTP(sw, second)
	if sw.Code != http.StatusCreated {
		t.Fatalf("second account with confirmation: %d %s", sw.Code, sw.Body.String())
	}

	ov := s.snapshotOverview()
	if len(ov.ProviderGroups) != 1 {
		t.Fatalf("provider groups: %+v", ov.ProviderGroups)
	}
	g := ov.ProviderGroups[0]
	if g.Provider.ID != "google-drive" || g.AccountCount != 2 || len(g.Accounts) != 2 || !g.CanAddAccount {
		t.Fatalf("unexpected google group: %+v", g)
	}
}

func TestDuplicateProviderIdentityRejectsAndCleansFreshPendingAccount(t *testing.T) {
	dir := t.TempDir()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status == catalog.Allowed {
			_ = reg.Register(connector.Unconfigured{ID: p.ID})
		}
	}
	s, err := NewSecure(cat, st, reg, v, nil)
	if err != nil {
		t.Fatal(err)
	}

	first, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.applyConnectorSnapshot(connector.Snapshot{
		ProviderID:      "google-drive",
		AccountID:       first.ID,
		ProviderSubject: "google-subject-1",
		Identity:        "same@example.test",
		Auth:            connector.Authenticated,
		Health:          connector.HealthOK,
		Transfer:        connector.TransferReady,
		TotalBytes:      100,
		UsedBytes:       10,
		FreeBytes:       90,
	}); err != nil {
		t.Fatal(err)
	}

	second, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	if err := v.Put(second.ID, secretvault.ProviderSession, []byte("temporary-session")); err != nil {
		t.Fatal(err)
	}
	_, err = s.applyConnectorSnapshot(connector.Snapshot{
		ProviderID:      "google-drive",
		AccountID:       second.ID,
		ProviderSubject: "google-subject-1",
		Identity:        "same@example.test",
		Auth:            connector.Authenticated,
		Health:          connector.HealthOK,
		Transfer:        connector.TransferReady,
		TotalBytes:      100,
		UsedBytes:       10,
		FreeBytes:       90,
	})
	if err == nil || !strings.Contains(strings.ToLower(err.Error()), "ya está conectada") {
		t.Fatalf("duplicate identity should be rejected clearly, got %v", err)
	}
	if _, ok := st.GetAccount(second.ID); ok {
		t.Fatal("fresh duplicate pending account should be removed")
	}
	if _, ok, err := v.Get(second.ID, secretvault.ProviderSession); err != nil || ok {
		t.Fatalf("temporary duplicate session should be deleted, ok=%v err=%v", ok, err)
	}
	if _, ok := st.GetAccount(first.ID); !ok {
		t.Fatal("existing connected account must remain intact")
	}
}

func TestMegaProviderGroupDoesNotAdvertiseUnsupportedMultiSession(t *testing.T) {
	s := testServer(t)
	if _, _, err := s.store.AddAccount("mega"); err != nil {
		t.Fatal(err)
	}
	ov := s.snapshotOverview()
	for _, g := range ov.ProviderGroups {
		if g.Provider.ID == "mega" {
			if g.CanAddAccount || !strings.Contains(strings.ToLower(g.AddAccountNote), "multicuenta") {
				t.Fatalf("MEGA group should remain single-session: %+v", g)
			}
			return
		}
	}
	t.Fatal("MEGA provider group missing")
}

func TestProviderGroupedMultiAccountFrontendMarkers(t *testing.T) {
	html, err := assets.ReadFile("assets/index.html")
	if err != nil {
		t.Fatal(err)
	}
	js, err := assets.ReadFile("assets/app.js")
	if err != nil {
		t.Fatal(err)
	}
	textHTML, textJS := string(html), string(js)
	for _, marker := range []string{`id="provider-groups"`, `id="responsible-modal"`, `id="responsible-confirm"`, "Uso responsable de varias cuentas"} {
		if !strings.Contains(textHTML, marker) {
			t.Fatalf("grouped provider UI marker missing: %q", marker)
		}
	}
	for _, marker := range []string{"providerGroupsForUI", "providerGroupHTML", "add-provider-group", "＋ Añadir otra cuenta", "requestResponsibleUse"} {
		if !strings.Contains(textJS, marker) {
			t.Fatalf("grouped provider JS marker missing: %q", marker)
		}
	}
}

func TestGatedProviderRejectedServerSide(t *testing.T) {
	s := testServer(t)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"proton-drive"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusConflict {
		t.Fatalf("want 409 got %d: %s", w.Code, w.Body.String())
	}
}

func TestPCloudApprovedProviderAcceptedServerSide(t *testing.T) {
	s := testServer(t)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"pcloud"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusCreated {
		t.Fatalf("pCloud should be accepted, got %d: %s", w.Code, w.Body.String())
	}
}
func TestUnknownProviderReviewDoesNotConnect(t *testing.T) {
	s := testServer(t)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/provider-reviews", bytes.NewBufferString(`{"name":"FutureCloud","official_url":"https://example.org/"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != 201 {
		t.Fatalf("review: %d %s", w.Code, w.Body.String())
	}
	if !bytes.Contains(w.Body.Bytes(), []byte(`"connection_allowed":false`)) {
		t.Fatal("review must be non-connectable")
	}
	var resp struct {
		Review            appstate.ReviewRequest `json:"review"`
		ConnectionAllowed bool                   `json:"connection_allowed"`
		LocalOnly         bool                   `json:"local_only"`
		ReviewScope       string                 `json:"review_scope"`
		ConnectionPolicy  string                 `json:"connection_policy"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatal(err)
	}
	if resp.ConnectionAllowed || !resp.LocalOnly || !resp.Review.LocalOnly || resp.ReviewScope != appstate.ReviewScopeLocalCatalog || resp.ConnectionPolicy != appstate.ReviewPolicyBlockedUntilLocal {
		t.Fatalf("review must be local-only and blocked: %+v", resp)
	}
}

func TestCSRFRequiredForStateChangingRequests(t *testing.T) {
	s := testServer(t)
	r := httptest.NewRequest("POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"google-drive"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusForbidden {
		t.Fatalf("missing CSRF should be rejected, got %d", w.Code)
	}
	good := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"google-drive"}`))
	gw := httptest.NewRecorder()
	s.Handler().ServeHTTP(gw, good)
	if gw.Code != http.StatusCreated {
		t.Fatalf("valid CSRF rejected: %d %s", gw.Code, gw.Body.String())
	}
}

func TestExactSameOriginRequiredWhenOriginPresent(t *testing.T) {
	s := testServer(t)
	r := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/overview", nil)
	r.Header.Set("Origin", "http://localhost:8742")
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusForbidden {
		t.Fatalf("different loopback origin should be rejected, got %d", w.Code)
	}
	r2 := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/overview", nil)
	r2.Header.Set("Origin", "http://127.0.0.1:8742")
	w2 := httptest.NewRecorder()
	s.Handler().ServeHTTP(w2, r2)
	if w2.Code != http.StatusOK {
		t.Fatalf("same origin should pass, got %d", w2.Code)
	}
}

func TestRejectsNonLocalHostAndOrigin(t *testing.T) {
	s := testServer(t)
	r := httptest.NewRequest("GET", "http://evil.example/api/overview", nil)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusForbidden {
		t.Fatalf("non-local host should be rejected: %d", w.Code)
	}
	r2 := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/overview", nil)
	r2.Header.Set("Origin", "https://evil.example")
	w2 := httptest.NewRecorder()
	s.Handler().ServeHTTP(w2, r2)
	if w2.Code != http.StatusForbidden {
		t.Fatalf("non-local origin should be rejected: %d", w2.Code)
	}
}

func TestRecoveryCenterEndpointsRequireTwoStepConfirmation(t *testing.T) {
	dir := t.TempDir()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	rc, err := recoverycenter.New(v, filepath.Join(dir, "secrets.vpv"), filepath.Join(dir, "VaultPool-Recovery.vpr"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status == catalog.Allowed {
			_ = reg.Register(connector.Unconfigured{ID: p.ID})
		}
	}
	srv, err := NewSecureManagedRecovery(cat, st, reg, v, nil, nil, rc)
	if err != nil {
		t.Fatal(err)
	}

	statusReq := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/recovery/status", nil)
	statusW := httptest.NewRecorder()
	srv.Handler().ServeHTTP(statusW, statusReq)
	if statusW.Code != http.StatusOK || !bytes.Contains(statusW.Body.Bytes(), []byte(`"available":true`)) {
		t.Fatalf("status: %d %s", statusW.Code, statusW.Body.String())
	}

	begin := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/begin", nil)
	bw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(bw, begin)
	if bw.Code != http.StatusCreated {
		t.Fatalf("begin: %d %s", bw.Code, bw.Body.String())
	}
	var result struct {
		RecoveryCode string `json:"recovery_code"`
	}
	if err := json.Unmarshal(bw.Body.Bytes(), &result); err != nil || len(result.RecoveryCode) < 40 {
		t.Fatalf("code missing: %q err=%v", result.RecoveryCode, err)
	}

	dl := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/package", nil)
	dw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(dw, dl)
	if dw.Code != http.StatusOK || dw.Body.Len() == 0 || dw.Header().Get("Content-Disposition") == "" {
		t.Fatalf("download: %d", dw.Code)
	}

	badConfirm := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/confirm", bytes.NewBufferString(`{"saved_package":true,"saved_code":false}`))
	bcw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(bcw, badConfirm)
	if bcw.Code != http.StatusConflict {
		t.Fatalf("partial confirmation accepted: %d", bcw.Code)
	}
	goodConfirm := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/confirm", bytes.NewBufferString(`{"saved_package":true,"saved_code":true}`))
	gcw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(gcw, goodConfirm)
	if gcw.Code != http.StatusOK || !bytes.Contains(gcw.Body.Bytes(), []byte(`"configured":true`)) {
		t.Fatalf("confirm: %d %s", gcw.Code, gcw.Body.String())
	}

	if err := v.Put("acct-credential-test", secretvault.RecoverablePassword, []byte("new-password")); err != nil {
		t.Fatalf("put recoverable credential: %v", err)
	}
	staleConfirm := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/confirm-credential-refresh", bytes.NewBufferString(`{"saved_package":true}`))
	scw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(scw, staleConfirm)
	if scw.Code != http.StatusConflict {
		t.Fatalf("credential refresh accepted without exporting current revision: %d %s", scw.Code, scw.Body.String())
	}

	currentDL := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/package", nil)
	currentDW := httptest.NewRecorder()
	srv.Handler().ServeHTTP(currentDW, currentDL)
	if currentDW.Code != http.StatusOK || currentDW.Body.Len() == 0 {
		t.Fatalf("current credential package export: %d %s", currentDW.Code, currentDW.Body.String())
	}
	refreshConfirm := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/recovery/confirm-credential-refresh", bytes.NewBufferString(`{"saved_package":true}`))
	rcw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(rcw, refreshConfirm)
	if rcw.Code != http.StatusOK || !bytes.Contains(rcw.Body.Bytes(), []byte(`"credentials_refresh_required":false`)) {
		t.Fatalf("current credential refresh confirmation: %d %s", rcw.Code, rcw.Body.String())
	}
}

func TestRecoveryCatalogRebuildUnavailableWithoutAssistant(t *testing.T) {
	s := testServer(t)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/recovery/rebuild-catalog", nil)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusServiceUnavailable {
		t.Fatalf("missing recovery assistant should be explicit, got %d: %s", w.Code, w.Body.String())
	}
}

type fakeConnector struct {
	snapshot connector.Snapshot
	err      error
}

func (f fakeConnector) ProviderID() string { return f.snapshot.ProviderID }
func (f fakeConnector) Probe(_ context.Context, accountID string) (connector.Snapshot, error) {
	s := f.snapshot
	s.AccountID = accountID
	return s, f.err
}

func TestGoogleAuthPlanIsSystemBrowserPKCE(t *testing.T) {
	s := testServer(t)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"google-drive"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	if w.Code != 201 {
		t.Fatalf("add: %d %s", w.Code, w.Body.String())
	}
	var add struct {
		Account appstate.Account `json:"account"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &add); err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/accounts/"+add.Account.ID+"/auth-plan", nil)
	ww := httptest.NewRecorder()
	s.Handler().ServeHTTP(ww, rr)
	if ww.Code != 200 {
		t.Fatalf("plan: %d %s", ww.Code, ww.Body.String())
	}
	var got struct {
		Auth struct {
			Mode      string `json:"mode"`
			OAuthPKCE bool   `json:"oauth_pkce"`
		} `json:"auth"`
	}
	if err := json.Unmarshal(ww.Body.Bytes(), &got); err != nil {
		t.Fatal(err)
	}
	if got.Auth.Mode != "system_browser_oauth" || !got.Auth.OAuthPKCE {
		t.Fatalf("got %+v", got.Auth)
	}
}

func TestProbePromotesOnlyAfterValidatedConnectorSnapshot(t *testing.T) {
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	err = reg.Register(fakeConnector{snapshot: connector.Snapshot{ProviderID: "google-drive", ProviderSubject: "g-subject", Identity: "person@example.com", PlanName: "Free", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: 1000, UsedBytes: 250, FreeBytes: 750}})
	if err != nil {
		t.Fatal(err)
	}
	srv, err := NewWithConnectors(cat, st, reg)
	if err != nil {
		t.Fatal(err)
	}
	r := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/accounts/"+a.ID+"/probe", nil)
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, r)
	if w.Code != 200 {
		t.Fatalf("probe: %d %s", w.Code, w.Body.String())
	}
	got, ok := st.GetAccount(a.ID)
	if !ok {
		t.Fatal("missing account")
	}
	if got.State != "connected" || got.TotalBytes != 1000 || got.FreeBytes != 750 {
		t.Fatalf("got %+v", got)
	}
}

func TestUnconfiguredProbePreservesPendingState(t *testing.T) {
	s := testServer(t)
	r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"google-drive"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	var add struct {
		Account appstate.Account `json:"account"`
	}
	_ = json.Unmarshal(w.Body.Bytes(), &add)
	pr := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts/"+add.Account.ID+"/probe", nil)
	pw := httptest.NewRecorder()
	s.Handler().ServeHTTP(pw, pr)
	if pw.Code != http.StatusServiceUnavailable {
		t.Fatalf("want 503 got %d", pw.Code)
	}
	got, _ := s.store.GetAccount(add.Account.ID)
	if got.State != "pending_auth" || got.TotalBytes != 0 {
		t.Fatalf("state changed on failed probe: %+v", got)
	}
}

func TestReviewOnlyProvidersRemainGatedUntilSafeNativeAuth(t *testing.T) {
	s := testServer(t)
	for _, id := range []string{"proton-drive", "box"} {
		r := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/accounts", bytes.NewBufferString(`{"provider_id":"`+id+`"}`))
		w := httptest.NewRecorder()
		s.Handler().ServeHTTP(w, r)
		if w.Code != http.StatusConflict {
			t.Fatalf("%s should be gated, got %d", id, w.Code)
		}
	}
}

type uiTestProtector struct{}

func (uiTestProtector) Name() string { return "ui-test" }
func (uiTestProtector) Protect(b []byte) ([]byte, error) {
	out := append([]byte(nil), b...)
	for i := range out {
		out[i] ^= 0x5a
	}
	return out, nil
}
func (uiTestProtector) Unprotect(b []byte) ([]byte, error) { return uiTestProtector{}.Protect(b) }

func TestSecureOAuthCallbackStoresTokenAndConnectsAccount(t *testing.T) {
	var tokenForm url.Values
	api := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/token":
			_ = r.ParseForm()
			tokenForm = r.PostForm
			_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "access", "refresh_token": "refresh", "token_type": "Bearer", "expires_in": 3600})
		case "/about":
			if r.Header.Get("Authorization") != "Bearer access" {
				t.Errorf("missing bearer: %q", r.Header.Get("Authorization"))
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"user": map[string]string{"emailAddress": "person@example.com", "permissionId": "g-perm"}, "storageQuota": map[string]string{"limit": "1000", "usage": "100"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer api.Close()

	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(t.TempDir(), "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	a, _, err := st.AddAccount("google-drive")
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(t.TempDir(), "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	if err := oauthconfig.Store(v, "google-drive", oauthconfig.Config{ClientID: "public-client", ClientSecret: "desktop-secret"}); err != nil {
		t.Fatal(err)
	}
	oauth, err := oauthnative.New(oauthnative.Config{ProviderID: "google-drive", ClientID: "public-client", ClientSecret: "desktop-secret", AuthorizeURL: "https://accounts.example/authorize", TokenURL: api.URL + "/token", Scopes: []string{"files"}}, api.Client())
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	if err := reg.Register(&cloudconnector.OAuthConnector{ID: "google-drive", OAuth: oauth, Secrets: v, HTTP: api.Client(), GoogleAboutURL: api.URL + "/about"}); err != nil {
		t.Fatal(err)
	}
	srv, err := NewSecure(cat, st, reg, v, map[string]*oauthnative.Client{"google-drive": oauth})
	if err != nil {
		t.Fatal(err)
	}

	start := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/accounts/"+a.ID+"/auth/start", nil)
	sw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(sw, start)
	if sw.Code != http.StatusCreated {
		t.Fatalf("start %d %s", sw.Code, sw.Body.String())
	}
	var sr struct {
		AuthorizationURL string `json:"authorization_url"`
	}
	if err := json.Unmarshal(sw.Body.Bytes(), &sr); err != nil {
		t.Fatal(err)
	}
	u, err := url.Parse(sr.AuthorizationURL)
	if err != nil {
		t.Fatal(err)
	}
	state := u.Query().Get("state")
	if state == "" || u.Query().Get("code_challenge") == "" {
		t.Fatal("missing state/PKCE")
	}
	// The local UI POST remains same-origin and CSRF protected; VaultPool itself
	// hands the provider URL to the configured system browser. OAuth callbacks
	// use the stable UI listener instead of a short-lived helper listener.
	var launchedURL string
	srv.openAuthURL = func(raw string, cfg desktop.BrowserConfig) error { launchedURL = raw; return nil }
	launch := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/accounts/"+a.ID+"/auth/launch", nil)
	lw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(lw, launch)
	if lw.Code != http.StatusCreated {
		t.Fatalf("launch %d %s", lw.Code, lw.Body.String())
	}
	lu, err := url.Parse(launchedURL)
	if err != nil || lu.Scheme != "https" || lu.Host != "accounts.example" || lu.Query().Get("state") == "" || lu.Query().Get("code_challenge") == "" {
		t.Fatalf("unsafe system-browser launch: %q err=%v", launchedURL, err)
	}
	redirectURI := lu.Query().Get("redirect_uri")
	ru, err := url.Parse(redirectURI)
	if err != nil || ru.Scheme != "http" || ru.Host != "127.0.0.1:8742" || ru.Path != "/oauth/callback" {
		t.Fatalf("launch must use the stable VaultPool UI listener as callback, got %q err=%v", redirectURI, err)
	}
	launchState := lu.Query().Get("state")
	cb := httptest.NewRequest("GET", "http://127.0.0.1:8742/oauth/callback?state="+url.QueryEscape(launchState)+"&code=abc", nil)
	cw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(cw, cb)
	if cw.Code != http.StatusOK {
		t.Fatalf("callback %d %s", cw.Code, cw.Body.String())
	}
	if tokenForm.Get("client_secret") != "desktop-secret" {
		t.Fatalf("desktop client secret missing from token exchange: %v", tokenForm)
	}
	if tokenForm.Get("code_verifier") == "" {
		t.Fatal("PKCE verifier missing")
	}
	got, _ := st.GetAccount(a.ID)
	if got.State != "connected" || got.Identity != "" || got.FreeBytes != 900 {
		t.Fatalf("plaintext app state must not retain account identity: %+v", got)
	}
	identity, ok, err := v.Get(a.ID, secretvault.AccountIdentity)
	if err != nil || !ok || string(identity) != "person@example.com" {
		t.Fatalf("encrypted identity missing: %q ok=%v err=%v", identity, ok, err)
	}
	for i := range identity {
		identity[i] = 0
	}
	if _, ok, err := v.Get(a.ID, secretvault.ProviderSession); err != nil || !ok {
		t.Fatalf("token not vaulted: %v %v", ok, err)
	}
	// State is one-time: replay must fail.
	replay := httptest.NewRequest("GET", "http://127.0.0.1:8742/oauth/callback?state="+url.QueryEscape(launchState)+"&code=abc", nil)
	rw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(rw, replay)
	if rw.Code != http.StatusBadRequest {
		t.Fatalf("replay got %d", rw.Code)
	}
}

func TestCallbackHostUsesProviderSpecificLoopbackName(t *testing.T) {
	s := testServer(t)
	for _, tc := range []struct {
		provider string
		want     string
	}{
		{provider: "dropbox", want: "127.0.0.1:8742"},
		{provider: "onedrive", want: "localhost:8742"},
		{provider: "google-drive", want: "127.0.0.1:8742"},
	} {
		got, err := s.callbackHost(tc.provider, "127.0.0.1:8742")
		if err != nil || got != tc.want {
			t.Fatalf("%s callback host = %q, %v; want %q", tc.provider, got, err, tc.want)
		}
	}
}

func TestManagedFilesUIListsAndAuditsWithoutExposingFileKey(t *testing.T) {
	dir := t.TempDir()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	if _, err := v.ConfigurePortableRecovery(filepath.Join(dir, "recovery.vpr")); err != nil {
		t.Fatal(err)
	}
	if err := v.ConfirmPortableRecovery(); err != nil {
		t.Fatal(err)
	}
	e, err := core.New(core.DefaultConfig())
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	pool := filepath.Join(dir, "pool")
	for i := 0; i < 6; i++ {
		if err := os.MkdirAll(filepath.Join(pool, fmt.Sprintf("p%d", i)), 0o700); err != nil {
			t.Fatal(err)
		}
	}
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	rr, err := recoveryrecords.New(v, 2)
	if err != nil {
		t.Fatal(err)
	}
	mgr, err := managedfiles.New(filepath.Join(dir, "files"), v, e, func(context.Context) ([]storage.Target, error) { return targets, nil }, rr)
	if err != nil {
		t.Fatal(err)
	}
	input := filepath.Join(dir, "important.txt")
	if err := os.WriteFile(input, bytes.Repeat([]byte("important-data\n"), 80000), 0o600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		for i := range key {
			key[i] = 0
		}
	}()
	mf := filepath.Join(dir, "source.vpm")
	if err := e.PackTargets(context.Background(), input, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	meta, err := mgr.RegisterCommitted(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	srv, err := NewSecureManaged(cat, st, reg, v, nil, mgr)
	if err != nil {
		t.Fatal(err)
	}

	r := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/files", nil)
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusOK {
		t.Fatalf("list: %d %s", w.Code, w.Body.String())
	}
	if !bytes.Contains(w.Body.Bytes(), []byte("important.txt")) || !bytes.Contains(w.Body.Bytes(), []byte(`"recovery_configured":true`)) {
		t.Fatalf("unexpected list body: %s", w.Body.String())
	}
	if bytes.Contains(w.Body.Bytes(), key) {
		t.Fatal("file key exposed by UI API")
	}

	a := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/files/"+meta.FileID+"/audit", nil)
	aw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(aw, a)
	if aw.Code != http.StatusOK {
		t.Fatalf("audit: %d %s", aw.Code, aw.Body.String())
	}
	if !bytes.Contains(aw.Body.Bytes(), []byte(`"repair_allowed":false`)) {
		t.Fatalf("healthy file should not offer repair: %s", aw.Body.String())
	}
}

type fakeDriveHost struct {
	status drivehost.Status
}

func (f *fakeDriveHost) Status() drivehost.Status { return f.status }
func (f *fakeDriveHost) Mount(point string) error {
	p, err := drivehost.NormalizeMountPoint(point)
	if err != nil {
		return err
	}
	if !f.status.Supported || !f.status.Installed || !f.status.Compatible {
		return fmt.Errorf("Dokany unavailable")
	}
	if f.status.Running {
		return fmt.Errorf("already mounted")
	}
	f.status.Running = true
	f.status.MountPoint = p
	return nil
}
func (f *fakeDriveHost) Unmount() error {
	if !f.status.Running {
		return fmt.Errorf("not mounted")
	}
	f.status.Running = false
	f.status.MountPoint = ""
	return nil
}

func TestDriveAPIStatusAndMutationsRequireCSRF(t *testing.T) {
	s := testServer(t)
	h := &fakeDriveHost{status: drivehost.Status{Supported: true, Installed: true, Compatible: true, ReadOnly: true, Backend: "dokany2", LibraryVersion: 231, DriverVersion: 231}}
	s.SetDriveHost(h)

	statusReq := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:8742/api/drive/status", nil)
	statusW := httptest.NewRecorder()
	s.Handler().ServeHTTP(statusW, statusReq)
	if statusW.Code != http.StatusOK || !bytes.Contains(statusW.Body.Bytes(), []byte(`"read_only":true`)) {
		t.Fatalf("drive status: %d %s", statusW.Code, statusW.Body.String())
	}

	bad := httptest.NewRequest(http.MethodPost, "http://127.0.0.1:8742/api/drive/mount", bytes.NewBufferString(`{"mount_point":"P:"}`))
	bad.Header.Set("Content-Type", "application/json")
	badW := httptest.NewRecorder()
	s.Handler().ServeHTTP(badW, bad)
	if badW.Code != http.StatusForbidden {
		t.Fatalf("drive mount without CSRF accepted: %d", badW.Code)
	}

	good := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/drive/mount", bytes.NewBufferString(`{"mount_point":"P:"}`))
	good.Header.Set("Content-Type", "application/json")
	goodW := httptest.NewRecorder()
	s.Handler().ServeHTTP(goodW, good)
	if goodW.Code != http.StatusOK {
		t.Fatalf("drive mount: %d %s", goodW.Code, goodW.Body.String())
	}
	var mounted drivehost.Status
	if err := json.Unmarshal(goodW.Body.Bytes(), &mounted); err != nil {
		t.Fatal(err)
	}
	if !mounted.Running || mounted.MountPoint != `P:\` || !mounted.ReadOnly {
		t.Fatalf("unexpected mounted state: %+v", mounted)
	}

	unmount := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/drive/unmount", nil)
	uw := httptest.NewRecorder()
	s.Handler().ServeHTTP(uw, unmount)
	if uw.Code != http.StatusOK || !bytes.Contains(uw.Body.Bytes(), []byte(`"running":false`)) {
		t.Fatalf("drive unmount: %d %s", uw.Code, uw.Body.String())
	}
}

type uiTransferManager struct{}

func (uiTransferManager) AddPath(ctx context.Context, path string, progress core.ProgressFunc) (managedfiles.Metadata, error) {
	progress(core.TransferProgress{Phase: "uploading", BlocksDone: 1, BlocksTotal: 1, BytesProcessed: 100, BytesTotal: 100, OriginalBytes: 100, StoredBytes: 75, EncryptedBytes: 103, DistributedBytes: 206})
	return managedfiles.Metadata{FileID: "00112233445566778899aabbccddeeff", FileName: filepath.Base(path)}, nil
}

func (uiTransferManager) RestoreToPath(ctx context.Context, fileID, out string, progress core.ProgressFunc) error {
	progress(core.TransferProgress{Phase: "restoring", BlocksDone: 1, BlocksTotal: 1, BytesProcessed: 100, BytesTotal: 100})
	return nil
}

type testDialogBackend struct{}

func (testDialogBackend) Supported() bool { return true }
func (testDialogBackend) OpenFile() (string, bool, error) {
	return `C:\Users\Test\video.mkv`, true, nil
}
func (testDialogBackend) OpenDirectory() (string, bool, error) {
	return `C:\Users\Test\Proyecto`, true, nil
}
func (testDialogBackend) OpenExecutable() (string, bool, error) {
	return `C:\Program Files\Opera\launcher.exe`, true, nil
}
func (testDialogBackend) SaveFile(name string) (string, bool, error) {
	if name == "" {
		name = "restored.bin"
	}
	return `C:\Users\Test\` + name, true, nil
}

func TestNativeDialogAPIRequiresCSRF(t *testing.T) {
	s := testServer(t)
	s.SetFileDialog(filedialog.New(testDialogBackend{}))

	statusReq := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:8742/api/dialogs/status", nil)
	statusW := httptest.NewRecorder()
	s.Handler().ServeHTTP(statusW, statusReq)
	if statusW.Code != http.StatusOK || !bytes.Contains(statusW.Body.Bytes(), []byte(`"ready":true`)) {
		t.Fatalf("dialog status: %d %s", statusW.Code, statusW.Body.String())
	}

	bad := httptest.NewRequest(http.MethodPost, "http://127.0.0.1:8742/api/dialogs/open-file", nil)
	badW := httptest.NewRecorder()
	s.Handler().ServeHTTP(badW, bad)
	if badW.Code != http.StatusForbidden {
		t.Fatalf("native dialog mutation without CSRF accepted: %d", badW.Code)
	}

	good := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/dialogs/open-file", nil)
	goodW := httptest.NewRecorder()
	s.Handler().ServeHTTP(goodW, good)
	if goodW.Code != http.StatusOK || !bytes.Contains(goodW.Body.Bytes(), []byte(`"selected":true`)) || !bytes.Contains(goodW.Body.Bytes(), []byte(`video.mkv`)) {
		t.Fatalf("open dialog: %d %s", goodW.Code, goodW.Body.String())
	}

	exe := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/dialogs/open-executable", nil)
	exeW := httptest.NewRecorder()
	s.Handler().ServeHTTP(exeW, exe)
	if exeW.Code != http.StatusOK || !bytes.Contains(exeW.Body.Bytes(), []byte(`launcher.exe`)) {
		t.Fatalf("executable dialog: %d %s", exeW.Code, exeW.Body.String())
	}

	folder := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/dialogs/open-folder", nil)
	folderW := httptest.NewRecorder()
	s.Handler().ServeHTTP(folderW, folder)
	if folderW.Code != http.StatusOK || !bytes.Contains(folderW.Body.Bytes(), []byte(`Proyecto`)) {
		t.Fatalf("folder dialog: %d %s", folderW.Code, folderW.Body.String())
	}

	save := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/dialogs/save-file", bytes.NewBufferString(`{"suggested_name":"movie.mkv"}`))
	save.Header.Set("Content-Type", "application/json")
	saveW := httptest.NewRecorder()
	s.Handler().ServeHTTP(saveW, save)
	if saveW.Code != http.StatusOK || !bytes.Contains(saveW.Body.Bytes(), []byte(`movie.mkv`)) {
		t.Fatalf("save dialog: %d %s", saveW.Code, saveW.Body.String())
	}
}

func readyTransferServer(t *testing.T) *Server {
	t.Helper()
	dir := t.TempDir()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { v.Close() })
	rc, err := recoverycenter.New(v, filepath.Join(dir, "secrets.vpv"), filepath.Join(dir, "VaultPool-Recovery.vpr"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := rc.Begin(); err != nil {
		t.Fatal(err)
	}
	if _, err := rc.Confirm(true, true); err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status == catalog.Allowed {
			_ = reg.Register(connector.Unconfigured{ID: p.ID})
		}
	}
	s, err := NewSecureManagedRecovery(cat, st, reg, v, nil, nil, rc)
	if err != nil {
		t.Fatal(err)
	}
	for i, providerID := range []string{"google-drive", "onedrive"} {
		a, _, err := st.AddAccount(providerID)
		if err != nil {
			t.Fatal(err)
		}
		_, err = st.ApplySnapshot(connector.Snapshot{
			ProviderID: providerID, AccountID: a.ID, ProviderSubject: fmt.Sprintf("subject-%d", i),
			Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady,
			TotalBytes: 10_000, UsedBytes: 0, FreeBytes: 10_000,
		})
		if err != nil {
			t.Fatal(err)
		}
	}
	return s
}

func TestShutdownAPIRequiresCSRFAndSignalsControlledClose(t *testing.T) {
	s := testServer(t)
	bad := httptest.NewRequest(http.MethodPost, "http://127.0.0.1:8742/api/shutdown", nil)
	badW := httptest.NewRecorder()
	s.Handler().ServeHTTP(badW, bad)
	if badW.Code != http.StatusForbidden {
		t.Fatalf("shutdown without CSRF accepted: %d", badW.Code)
	}
	good := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/shutdown", nil)
	goodW := httptest.NewRecorder()
	s.Handler().ServeHTTP(goodW, good)
	if goodW.Code != http.StatusAccepted {
		t.Fatalf("shutdown request: %d %s", goodW.Code, goodW.Body.String())
	}
	select {
	case <-s.ShutdownRequested():
	case <-time.After(time.Second):
		t.Fatal("shutdown signal was not delivered")
	}
}

func TestTransferAPIRequiresCSRFAndDoesNotExposePaths(t *testing.T) {
	s := readyTransferServer(t)
	ts, err := transfers.New(uiTransferManager{})
	if err != nil {
		t.Fatal(err)
	}
	s.SetTransfers(ts)
	missing := httptest.NewRequest("POST", "http://127.0.0.1:8742/api/transfers/upload", bytes.NewBufferString(`{"path":"/private/source.bin"}`))
	mw := httptest.NewRecorder()
	s.Handler().ServeHTTP(mw, missing)
	if mw.Code != http.StatusForbidden {
		t.Fatalf("transfer mutation without CSRF accepted: %d", mw.Code)
	}
	start := unsafeRequest(s, "POST", "http://127.0.0.1:8742/api/transfers/upload", bytes.NewBufferString(`{"path":"/private/source.bin"}`))
	sw := httptest.NewRecorder()
	s.Handler().ServeHTTP(sw, start)
	if sw.Code != http.StatusAccepted {
		t.Fatalf("start upload: %d %s", sw.Code, sw.Body.String())
	}
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		list := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/transfers", nil)
		lw := httptest.NewRecorder()
		s.Handler().ServeHTTP(lw, list)
		if lw.Code != http.StatusOK {
			t.Fatalf("list transfers: %d", lw.Code)
		}
		if bytes.Contains(lw.Body.Bytes(), []byte("/private/source.bin")) {
			t.Fatalf("private source path leaked in transfer API: %s", lw.Body.String())
		}
		if bytes.Contains(lw.Body.Bytes(), []byte(`"state":"completed"`)) {
			if !bytes.Contains(lw.Body.Bytes(), []byte(`"upload_report"`)) {
				t.Fatalf("completed upload did not expose a report: %s", lw.Body.String())
			}
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal("transfer did not finish")
}

func TestFieldTestBuildAcceptsUploadsOver64MiB(t *testing.T) {
	old := buildinfo.BuildPurpose
	buildinfo.BuildPurpose = "field-test"
	defer func() { buildinfo.BuildPurpose = old }()

	input, err := os.CreateTemp(t.TempDir(), "large-upload-*")
	if err != nil {
		t.Fatal(err)
	}
	if err := input.Truncate((64 << 20) + 1); err != nil {
		_ = input.Close()
		t.Fatal(err)
	}
	if err := input.Close(); err != nil {
		t.Fatal(err)
	}

	s := readyTransferServer(t)
	ts, err := transfers.New(uiTransferManager{})
	if err != nil {
		t.Fatal(err)
	}
	s.SetTransfers(ts)
	payload, err := json.Marshal(map[string]string{"path": input.Name()})
	if err != nil {
		t.Fatal(err)
	}
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/transfers/upload", bytes.NewReader(payload)))
	if w.Code != http.StatusAccepted {
		t.Fatalf("large field-test upload: %d %s", w.Code, w.Body.String())
	}
}

func TestAccountValidationBuildDisablesProtection(t *testing.T) {
	old := buildinfo.BuildPurpose
	buildinfo.BuildPurpose = "account-validation"
	defer func() { buildinfo.BuildPurpose = old }()
	s := testServer(t)
	st := s.protectionStatus()
	if st.Ready || st.Label != "Validación de cuentas" || st.Reason == "" {
		t.Fatalf("validation build should fail closed for data operations: %+v", st)
	}
}

func TestLibraryFoldersWorkBeforeRecoverySetup(t *testing.T) {
	dir := t.TempDir()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status == catalog.Allowed {
			_ = reg.Register(connector.Unconfigured{ID: p.ID})
		}
	}
	srv, err := NewSecureManagedRecovery(cat, st, reg, v, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	lib, err := library.New(v)
	if err != nil {
		t.Fatal(err)
	}
	srv.SetLibrary(lib)
	create := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/library/folders", bytes.NewBufferString(`{"name":"Trabajo"}`))
	cw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(cw, create)
	if cw.Code != http.StatusCreated {
		t.Fatalf("create folder before recovery: %d %s", cw.Code, cw.Body.String())
	}
	get := httptest.NewRequest("GET", "http://127.0.0.1:8742/api/library", nil)
	gw := httptest.NewRecorder()
	srv.Handler().ServeHTTP(gw, get)
	if gw.Code != http.StatusOK || !bytes.Contains(gw.Body.Bytes(), []byte(`"name":"Trabajo"`)) || !bytes.Contains(gw.Body.Bytes(), []byte(`"label":"Vídeos"`)) {
		t.Fatalf("library snapshot: %d %s", gw.Code, gw.Body.String())
	}
}

func TestFieldTestBuildAllowsProtectionChecksToProceed(t *testing.T) {
	old := buildinfo.BuildPurpose
	buildinfo.BuildPurpose = "field-test"
	defer func() { buildinfo.BuildPurpose = old }()
	s := testServer(t)
	st := s.protectionStatus()
	if st.Label == "Validación de cuentas" {
		t.Fatalf("field-test must not be treated as account-validation: %+v", st)
	}
}

func TestRuntimeOAuthClientIDConfigurationPersistsAndActivatesConnector(t *testing.T) {
	cat := catalog.MustBuiltin()
	dir := t.TempDir()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	defer v.Close()
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status == catalog.Allowed {
			if err := reg.Register(connector.Unconfigured{ID: p.ID}); err != nil {
				t.Fatal(err)
			}
		}
	}
	srv, err := NewSecure(cat, st, reg, v, nil)
	if err != nil {
		t.Fatal(err)
	}
	body := bytes.NewBufferString(`{"client_id":"11111111-2222-3333-4444-555555555555"}`)
	r := unsafeRequest(srv, "POST", "http://127.0.0.1:8742/api/connectors/onedrive/configure", body)
	w := httptest.NewRecorder()
	srv.Handler().ServeHTTP(w, r)
	if w.Code != http.StatusOK {
		t.Fatalf("configure: %d %s", w.Code, w.Body.String())
	}
	p, _ := cat.Get("onedrive")
	if !srv.connectorReadyFor(p) {
		t.Fatal("OneDrive connector should be ready after runtime client-id configuration")
	}
	cfg, ok, err := oauthconfig.Load(v, "onedrive")
	if err != nil || !ok {
		t.Fatalf("stored OAuth config: ok=%v err=%v", ok, err)
	}
	if cfg.ClientID != "11111111-2222-3333-4444-555555555555" || cfg.ClientSecret != "" {
		t.Fatalf("unexpected stored OAuth config %+v", cfg)
	}
}

func TestQuotaDonutInnerDiscIsAnchoredToDonut(t *testing.T) {
	css, err := assets.ReadFile("assets/app.css")
	if err != nil {
		t.Fatal(err)
	}
	text := string(css)
	if !strings.Contains(text, ".quota-donut{--pct:0;position:relative;") {
		t.Fatal("quota donut must establish a positioning context for its absolute ::before inner disc")
	}
	if !strings.Contains(text, ".quota-donut::before{content:\"\";position:absolute;") {
		t.Fatal("quota donut inner disc regression marker missing")
	}
}

func TestFilePickerLabelsFollowDialogStatus(t *testing.T) {
	html, err := assets.ReadFile("assets/index.html")
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(html), ">Examinar desactivado</button>") {
		t.Fatal("file picker buttons must not be hard-coded as disabled in the HTML")
	}
	if !strings.Contains(string(html), `id="upload-dialog-status"`) || !strings.Contains(string(html), `id="upload-path-msg"`) {
		t.Fatal("file picker status copy must be addressable from JS")
	}
	js, err := assets.ReadFile("assets/app.js")
	if err != nil {
		t.Fatal(err)
	}
	text := string(js)
	if !strings.Contains(text, "b.textContent=ready?'Examinar':'Examinar desactivado'") {
		t.Fatal("dialog status refresh must update the browse button label")
	}
	if !strings.Contains(text, "Selector de Windows disponible en proceso aislado") {
		t.Fatal("dialog status refresh must describe the isolated helper when ready")
	}
}

func TestOAuthBrowserDropdownKeepsDraftSelectionAndCanBrowseExecutable(t *testing.T) {
	js, err := assets.ReadFile("assets/app.js")
	if err != nil {
		t.Fatal(err)
	}
	text := string(js)
	if strings.Contains(text, "$('#oauth-browser-select')?.addEventListener('change',renderOAuthBrowser)") {
		t.Fatal("browser dropdown change must not rerender from persisted model and reset the user's draft selection")
	}
	if !strings.Contains(text, "$('#oauth-browser-select')?.addEventListener('change',updateOAuthBrowserDraft)") {
		t.Fatal("browser dropdown draft handler missing")
	}
	if !strings.Contains(text, "/api/dialogs/open-executable") || !strings.Contains(text, "oauth-browser-browse") {
		t.Fatal("custom browser executable picker is not wired")
	}
}
