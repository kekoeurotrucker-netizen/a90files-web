package ui

import (
	"bytes"
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/appstate"
	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	filenconnector "github.com/vaultpool-project/vaultpool/internal/filen"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type fakeFilenHTTPConnector struct {
	snapshot    connector.Snapshot
	loginErr    error
	probeErr    error
	loginCalls  int
	logoutCalls int
}

func (f *fakeFilenHTTPConnector) ProviderID() string { return filenconnector.ProviderID }
func (f *fakeFilenHTTPConnector) Ready() bool        { return true }
func (f *fakeFilenHTTPConnector) Probe(_ context.Context, accountID string) (connector.Snapshot, error) {
	if f.probeErr != nil {
		return connector.Snapshot{}, f.probeErr
	}
	snap := f.snapshot
	snap.AccountID = accountID
	return snap, nil
}
func (f *fakeFilenHTTPConnector) Login(_ context.Context, accountID, _, _, _ string) (connector.Snapshot, error) {
	f.loginCalls++
	if f.loginErr != nil {
		return connector.Snapshot{}, f.loginErr
	}
	snap := f.snapshot
	snap.AccountID = accountID
	return snap, nil
}
func (f *fakeFilenHTTPConnector) Logout(string) error { f.logoutCalls++; return nil }

func newFilenHTTPTestServer(t *testing.T, fake *fakeFilenHTTPConnector) (*Server, *secretvault.Vault, appstate.Account, string) {
	t.Helper()
	dir := t.TempDir()
	cat := catalog.MustBuiltin()
	st, err := appstate.Open(filepath.Join(dir, "state.json"), cat)
	if err != nil {
		t.Fatal(err)
	}
	v, err := secretvault.Open(filepath.Join(dir, "secrets.vpv"), uiTestProtector{})
	if err != nil {
		t.Fatal(err)
	}
	reg := connector.NewRegistry()
	for _, p := range cat.All() {
		if p.Status == catalog.Allowed {
			if err := reg.Register(connector.Unconfigured{ID: p.ID}); err != nil {
				t.Fatal(err)
			}
		}
	}
	if err := reg.Set(fake); err != nil {
		t.Fatal(err)
	}
	s, err := NewSecure(cat, st, reg, v, nil)
	if err != nil {
		v.Close()
		t.Fatal(err)
	}
	a, _, err := st.AddAccount(filenconnector.ProviderID)
	if err != nil {
		v.Close()
		t.Fatal(err)
	}
	return s, v, a, filepath.Join(dir, "state.json")
}

func validFilenHTTPSnapshot() connector.Snapshot {
	return connector.Snapshot{
		ProviderID:      filenconnector.ProviderID,
		ProviderSubject: "user:7\x00base:folder-7",
		Identity:        "person@example.com",
		PlanName:        "Filen Premium",
		Auth:            connector.Authenticated,
		Health:          connector.HealthOK,
		Transfer:        connector.TransferReady,
		TotalBytes:      10_000,
		UsedBytes:       2_000,
		FreeBytes:       8_000,
	}
}

func TestFilenLoginEndpointUsesTwoFactorStateAndDoesNotExposeSecrets(t *testing.T) {
	fake := &fakeFilenHTTPConnector{snapshot: validFilenHTTPSnapshot()}
	s, v, account, statePath := newFilenHTTPTestServer(t, fake)
	defer v.Close()

	req := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/filen/login", bytes.NewBufferString(`{"email":"person@example.com","password":"password-marker","two_factor_code":""}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusOK || !bytes.Contains(w.Body.Bytes(), []byte(`"connected":true`)) {
		t.Fatalf("login response: %d %s", w.Code, w.Body.String())
	}
	if bytes.Contains(w.Body.Bytes(), []byte("password-marker")) || bytes.Contains(w.Body.Bytes(), []byte("ProviderSubject")) || bytes.Contains(w.Body.Bytes(), []byte("user:7")) {
		t.Fatalf("secret/provider identity leaked to frontend: %s", w.Body.String())
	}
	rawState, err := os.ReadFile(statePath)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(rawState, []byte("person@example.com")) {
		t.Fatal("email identity leaked into plaintext app state")
	}
	identity, ok, err := v.Get(account.ID, secretvault.AccountIdentity)
	if err != nil || !ok || string(identity) != "person@example.com" {
		t.Fatalf("encrypted identity not stored: ok=%v err=%v", ok, err)
	}

	fake.loginErr = &filenconnector.Error{Code: filenconnector.ErrTwoFactorRequired, Message: "raw provider response must not escape"}
	req = unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/filen/login", bytes.NewBufferString(`{"email":"person@example.com","password":"password-marker"}`))
	w = httptest.NewRecorder()
	s.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusConflict || !bytes.Contains(w.Body.Bytes(), []byte(`"two_factor_required":true`)) || !bytes.Contains(w.Body.Bytes(), []byte("código de verificación")) {
		t.Fatalf("2FA response: %d %s", w.Code, w.Body.String())
	}
	if bytes.Contains(w.Body.Bytes(), []byte("raw provider response")) || bytes.Contains(w.Body.Bytes(), []byte("password-marker")) {
		t.Fatalf("raw login detail leaked: %s", w.Body.String())
	}
}

func TestFilenLoginEndpointRequiresCSRFAndMapsInvalidTwoFactor(t *testing.T) {
	fake := &fakeFilenHTTPConnector{snapshot: validFilenHTTPSnapshot(), loginErr: &filenconnector.Error{Code: filenconnector.ErrTwoFactorInvalid, Message: "provider detail"}}
	s, v, account, _ := newFilenHTTPTestServer(t, fake)
	defer v.Close()

	noCSRF := httptest.NewRequest(http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/filen/login", strings.NewReader(`{"email":"person@example.com","password":"pw"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, noCSRF)
	if w.Code != http.StatusForbidden || fake.loginCalls != 0 {
		t.Fatalf("missing CSRF was accepted: %d calls=%d", w.Code, fake.loginCalls)
	}

	req := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/filen/login", strings.NewReader(`{"email":"person@example.com","password":"pw","two_factor_code":"123456"}`))
	w = httptest.NewRecorder()
	s.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusUnauthorized || !bytes.Contains(w.Body.Bytes(), []byte(`"code":"two_factor_invalid"`)) {
		t.Fatalf("invalid 2FA mapping: %d %s", w.Code, w.Body.String())
	}
}

func TestFilenLoginEndpointPreservesSafeAccountValidationReason(t *testing.T) {
	fake := &fakeFilenHTTPConnector{
		snapshot: validFilenHTTPSnapshot(),
		loginErr: &filenconnector.Error{
			Code:    filenconnector.ErrAccountInvalid,
			Message: "Filen autenticó la cuenta, pero no devolvió una cuota total de almacenamiento utilizable.",
			Cause:   errors.New("sensitive-provider-detail"),
		},
	}
	s, v, account, _ := newFilenHTTPTestServer(t, fake)
	defer v.Close()

	req := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/filen/login", strings.NewReader(`{"email":"person@example.com","password":"pw"}`))
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusBadGateway || !bytes.Contains(w.Body.Bytes(), []byte("cuota total de almacenamiento")) {
		t.Fatalf("account validation response: %d %s", w.Code, w.Body.String())
	}
	if bytes.Contains(w.Body.Bytes(), []byte("sensitive-provider-detail")) {
		t.Fatalf("provider detail leaked: %s", w.Body.String())
	}
}

func TestFilenLogoutEndpointPreservesAccountAndDeletesLocalSecrets(t *testing.T) {
	fake := &fakeFilenHTTPConnector{snapshot: validFilenHTTPSnapshot()}
	s, v, account, _ := newFilenHTTPTestServer(t, fake)
	defer v.Close()
	if _, err := s.applyConnectorSnapshot(validFilenHTTPSnapshotWithAccount(account.ID)); err != nil {
		t.Fatal(err)
	}
	if err := v.Put(account.ID, secretvault.FilenSession, []byte("sensitive-session")); err != nil {
		t.Fatal(err)
	}
	if err := v.Put(account.ID, secretvault.AccountIdentity, []byte("person@example.com")); err != nil {
		t.Fatal(err)
	}

	req := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/filen/logout", nil)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusOK || !bytes.Contains(w.Body.Bytes(), []byte(`"disconnected":true`)) {
		t.Fatalf("logout response: %d %s", w.Code, w.Body.String())
	}
	got, ok := s.store.GetAccount(account.ID)
	if !ok || got.State != "reauth_required" {
		t.Fatalf("account was not marked for reauthentication: %+v", got)
	}
	for _, kind := range []secretvault.Kind{secretvault.FilenSession, secretvault.AccountIdentity} {
		if _, ok, err := v.Get(account.ID, kind); err != nil || ok {
			t.Fatalf("secret %s remained: ok=%v err=%v", kind, ok, err)
		}
	}
	if fake.logoutCalls != 1 {
		t.Fatalf("logout connector calls=%d", fake.logoutCalls)
	}
}

func TestFilenInvalidRestoredSessionMovesAccountToReauthentication(t *testing.T) {
	fake := &fakeFilenHTTPConnector{snapshot: validFilenHTTPSnapshot(), probeErr: &filenconnector.Error{Code: filenconnector.ErrSessionInvalid, Message: "provider detail"}}
	s, v, account, _ := newFilenHTTPTestServer(t, fake)
	defer v.Close()
	if _, err := s.applyConnectorSnapshot(validFilenHTTPSnapshotWithAccount(account.ID)); err != nil {
		t.Fatal(err)
	}
	req := unsafeRequest(s, http.MethodPost, "http://127.0.0.1:8742/api/accounts/"+account.ID+"/probe", nil)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, req)
	if w.Code != http.StatusUnauthorized || !bytes.Contains(w.Body.Bytes(), []byte("Inicia sesión de nuevo")) || bytes.Contains(w.Body.Bytes(), []byte("provider detail")) {
		t.Fatalf("invalid session response: %d %s", w.Code, w.Body.String())
	}
	got, ok := s.store.GetAccount(account.ID)
	if !ok || got.State != "reauth_required" {
		t.Fatalf("invalid session did not require reauthentication: %+v", got)
	}
}

func TestFilenFrontendUsesDirectModal(t *testing.T) {
	html, err := assets.ReadFile("assets/index.html")
	if err != nil {
		t.Fatal(err)
	}
	js, err := assets.ReadFile("assets/app.js")
	if err != nil {
		t.Fatal(err)
	}
	textHTML, textJS := string(html), string(js)
	for _, marker := range []string{"id=\"auth-filen-form\"", "Tus credenciales se utilizan localmente", "auth-filen-2fa"} {
		if !strings.Contains(textHTML, marker) {
			t.Fatalf("Filen direct UI marker missing: %q", marker)
		}
	}
	for _, marker := range []string{"/filen/login", "two_factor_required", "disconnectFilen", "p.id==='filen'?'Conectar':'Ver acceso'", "filenErrorMessage"} {
		if !strings.Contains(textJS, marker) {
			t.Fatalf("Filen direct JS marker missing: %q", marker)
		}
	}
	for _, forbidden := range []string{"filen-cli", "VAULTPOOL_FILEN_CLI", "Abrir cliente oficial de Filen"} {
		if strings.Contains(textHTML+textJS, forbidden) {
			t.Fatalf("legacy Filen UI marker remains: %q", forbidden)
		}
	}
}

func validFilenHTTPSnapshotWithAccount(accountID string) connector.Snapshot {
	snap := validFilenHTTPSnapshot()
	snap.AccountID = accountID
	return snap
}
