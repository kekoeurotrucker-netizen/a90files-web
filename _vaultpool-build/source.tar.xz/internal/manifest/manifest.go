package manifest

import (
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/safefile"
)

const (
	Version = 1
	// MaxSealedBytes is the current monolithic-manifest safety ceiling. It is
	// shared by packing and recovery so VaultPool never commits metadata that
	// its recovery path would later refuse to read. Paged manifests will remove
	// this prototype ceiling in a later milestone.
	MaxSealedBytes int64 = 64 << 20
)

var manifestAAD = []byte("vaultpool-manifest-v1")

type Shard struct {
	Index    int    `json:"index"`
	Provider string `json:"provider"`
	Object   string `json:"object"`
	SHA256   string `json:"sha256"`
}

type Block struct {
	Index       int     `json:"index"`
	PlainSize   int     `json:"plain_size"`
	StoredSize  int     `json:"stored_size"`
	Compressed  bool    `json:"compressed"`
	Compression string  `json:"compression"`
	CipherSize  int     `json:"cipher_size"`
	ShardSize   int     `json:"shard_size"`
	Shards      []Shard `json:"shards"`
}

type Manifest struct {
	Version                  int       `json:"version"`
	Generation               uint64    `json:"generation"`
	FileID                   string    `json:"file_id"`
	FileName                 string    `json:"file_name"`
	OriginalSize             int64     `json:"original_size"`
	OriginalSHA256           string    `json:"original_sha256"`
	BlockSize                int       `json:"block_size"`
	DataShards               int       `json:"data_shards"`
	ParityShards             int       `json:"parity_shards"`
	MinProviderFailureMargin int       `json:"min_provider_failure_margin"`
	CreatedAt                time.Time `json:"created_at"`
	Blocks                   []Block   `json:"blocks"`
}

func (m *Manifest) Validate() error {
	if m.Version != Version {
		return fmt.Errorf("unsupported manifest version %d", m.Version)
	}
	if m.FileID == "" {
		return fmt.Errorf("missing file id")
	}
	if m.Generation < 1 {
		return fmt.Errorf("invalid manifest generation %d", m.Generation)
	}
	if m.DataShards < 1 || m.ParityShards < 1 {
		return fmt.Errorf("invalid shard counts")
	}
	if m.MinProviderFailureMargin < 0 || m.MinProviderFailureMargin >= m.ParityShards {
		return fmt.Errorf("invalid provider failure margin %d", m.MinProviderFailureMargin)
	}
	for i, b := range m.Blocks {
		if b.Index != i {
			return fmt.Errorf("block index mismatch at %d", i)
		}
		if b.PlainSize < 0 || b.StoredSize < 0 || b.CipherSize < 0 || b.ShardSize < 0 {
			return fmt.Errorf("block %d contains negative sizes", i)
		}
		if len(b.Shards) != m.DataShards+m.ParityShards {
			return fmt.Errorf("block %d shard count mismatch", i)
		}
		seen := make(map[int]bool, len(b.Shards))
		for _, s := range b.Shards {
			if s.Index < 0 || s.Index >= m.DataShards+m.ParityShards || seen[s.Index] {
				return fmt.Errorf("block %d invalid/duplicate shard index %d", i, s.Index)
			}
			if s.Provider == "" || s.Object == "" || len(s.SHA256) != 64 {
				return fmt.Errorf("block %d shard %d incomplete metadata", i, s.Index)
			}
			seen[s.Index] = true
		}
	}
	return nil
}

func Seal(m *Manifest, key []byte) ([]byte, error) {
	if err := m.Validate(); err != nil {
		return nil, err
	}
	plain, err := json.Marshal(m)
	if err != nil {
		return nil, err
	}
	return cryptokit.Seal(key, plain, manifestAAD)
}

func Open(sealed, key []byte) (*Manifest, error) {
	plain, err := cryptokit.Open(key, sealed, manifestAAD)
	if err != nil {
		return nil, fmt.Errorf("manifest authentication/decryption failed: %w", err)
	}
	var m Manifest
	if err := json.Unmarshal(plain, &m); err != nil {
		return nil, err
	}
	if err := m.Validate(); err != nil {
		return nil, err
	}
	return &m, nil
}

func WriteAtomicBytes(path string, sealed []byte) error {
	return safefile.WriteAtomic(path, sealed, 0o600)
}

func SaveAtomic(path string, m *Manifest, key []byte) error {
	sealed, err := Seal(m, key)
	if err != nil {
		return err
	}
	return WriteAtomicBytes(path, sealed)
}

func Load(path string, key []byte) (*Manifest, error) {
	sealed, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return Open(sealed, key)
}
