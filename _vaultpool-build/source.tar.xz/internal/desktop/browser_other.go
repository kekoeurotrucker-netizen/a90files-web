//go:build !windows

package desktop

import (
	"os"
	"os/exec"
)

func BrowserStatusFor(c BrowserConfig) (BrowserStatus, error) {
	c = NormalizeBrowserConfig(c)
	label := "navegador predeterminado del sistema"
	if c.Mode == "custom" {
		label = c.CustomPath
	}
	return BrowserStatus{Selected: c, EffectiveLabel: label, Options: []BrowserOption{{ID: "default", Name: "Predeterminado del sistema", Installed: true, Default: true}}}, nil
}

func openProgram(path, raw string) error {
	return exec.Command(path, raw).Start()
}

func OpenAuthURL(raw string, c BrowserConfig) error {
	if err := validateAuthURL(raw); err != nil {
		return err
	}
	c = NormalizeBrowserConfig(c)
	if c.Mode == "custom" {
		if st, err := os.Stat(c.CustomPath); err == nil && !st.IsDir() {
			return openProgram(c.CustomPath, raw)
		}
	}
	return OpenURL(raw)
}
