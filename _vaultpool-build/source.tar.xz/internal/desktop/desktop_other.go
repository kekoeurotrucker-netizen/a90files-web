//go:build !windows

package desktop

import (
	"errors"
	"os/exec"
	"runtime"
)

func OpenApp(url, profile string) (*exec.Cmd, error) {
	var name string
	var args []string
	switch runtime.GOOS {
	case "darwin":
		name, args = "open", []string{url}
	default:
		name, args = "xdg-open", []string{url}
	}
	cmd := exec.Command(name, args...)
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	return cmd, nil
}

// OpenURL opens a URL with the operating system default browser.
func OpenURL(url string) error {
	var name string
	var args []string
	switch runtime.GOOS {
	case "darwin":
		name, args = "open", []string{url}
	default:
		name, args = "xdg-open", []string{url}
	}
	return exec.Command(name, args...).Start()
}

func WaitApp(cmd *exec.Cmd) error {
	if cmd == nil {
		return errors.New("no desktop process")
	}
	return cmd.Wait()
}
