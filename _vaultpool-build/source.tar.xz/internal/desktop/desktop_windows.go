//go:build windows

package desktop

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
)

func edgeCandidates() []string {
	var out []string
	if p, err := exec.LookPath("msedge.exe"); err == nil {
		out = append(out, p)
	}
	for _, root := range []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LOCALAPPDATA")} {
		if root == "" {
			continue
		}
		out = append(out, filepath.Join(root, "Microsoft", "Edge", "Application", "msedge.exe"))
	}
	return out
}

func OpenApp(url, profile string) (*exec.Cmd, error) {
	for _, p := range edgeCandidates() {
		if p == "" {
			continue
		}
		if st, err := os.Stat(p); err != nil || st.IsDir() {
			continue
		}
		args := []string{"--app=" + url, "--new-window", "--disable-background-mode", "--no-first-run"}
		if profile != "" {
			args = append(args, "--user-data-dir="+profile)
		}
		cmd := exec.Command(p, args...)
		cmd.SysProcAttr = noConsoleSysProcAttr()
		if err := cmd.Start(); err == nil {
			return cmd, nil
		}
	}
	// Fallback to the user's normal browser. This may not provide a dedicated
	// app chrome, but it preserves functionality.
	cmd := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url)
	cmd.SysProcAttr = hiddenConsoleSysProcAttr()
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	return cmd, nil
}

// OpenURL asks Windows to open a URL with the user's registered default
// handler. OAuth uses this instead of OpenApp so sign-in happens in the
// browser/profile where the user normally keeps sessions, passwords and 2FA.
func OpenURL(url string) error {
	cmd := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url)
	cmd.SysProcAttr = hiddenConsoleSysProcAttr()
	return cmd.Start()
}

func WaitApp(cmd *exec.Cmd) error {
	if cmd == nil {
		return errors.New("no desktop process")
	}
	return cmd.Wait()
}
