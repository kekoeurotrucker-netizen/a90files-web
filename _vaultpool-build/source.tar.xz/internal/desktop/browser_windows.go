//go:build windows

package desktop

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

type knownBrowser struct {
	id       string
	name     string
	paths    []string
	progIDs  []string
	exeNames []string
}

func envPath(name string, parts ...string) string {
	base := os.Getenv(name)
	if base == "" {
		return ""
	}
	all := append([]string{base}, parts...)
	return filepath.Join(all...)
}

func knownBrowsers() []knownBrowser {
	return []knownBrowser{
		{id: "edge", name: "Microsoft Edge", progIDs: []string{"MSEdgeHTM"}, exeNames: []string{"msedge.exe"}, paths: []string{envPath("ProgramFiles(x86)", "Microsoft", "Edge", "Application", "msedge.exe"), envPath("ProgramFiles", "Microsoft", "Edge", "Application", "msedge.exe"), envPath("LOCALAPPDATA", "Microsoft", "Edge", "Application", "msedge.exe")}},
		{id: "chrome", name: "Google Chrome", progIDs: []string{"ChromeHTML"}, exeNames: []string{"chrome.exe"}, paths: []string{envPath("ProgramFiles", "Google", "Chrome", "Application", "chrome.exe"), envPath("ProgramFiles(x86)", "Google", "Chrome", "Application", "chrome.exe"), envPath("LOCALAPPDATA", "Google", "Chrome", "Application", "chrome.exe")}},
		{id: "firefox", name: "Mozilla Firefox", progIDs: []string{"FirefoxURL", "FirefoxHTML"}, exeNames: []string{"firefox.exe"}, paths: []string{envPath("ProgramFiles", "Mozilla Firefox", "firefox.exe"), envPath("ProgramFiles(x86)", "Mozilla Firefox", "firefox.exe")}},
		{id: "opera-gx", name: "Opera GX", progIDs: []string{"OperaGXStable", "OperaGXStableHTML"}, exeNames: []string{"opera.exe", "launcher.exe"}, paths: []string{envPath("LOCALAPPDATA", "Programs", "Opera GX", "launcher.exe"), envPath("LOCALAPPDATA", "Programs", "Opera GX", "opera.exe"), envPath("ProgramFiles", "Opera GX", "launcher.exe"), envPath("ProgramFiles", "Opera GX", "opera.exe"), envPath("ProgramFiles(x86)", "Opera GX", "launcher.exe"), envPath("ProgramFiles(x86)", "Opera GX", "opera.exe")}},
		{id: "opera", name: "Opera", progIDs: []string{"OperaStable", "OperaStableHTML"}, exeNames: []string{"opera.exe", "launcher.exe"}, paths: []string{envPath("LOCALAPPDATA", "Programs", "Opera", "launcher.exe"), envPath("LOCALAPPDATA", "Programs", "Opera", "opera.exe"), envPath("APPDATA", "Opera Software", "Opera Stable", "opera.exe"), envPath("ProgramFiles", "Opera", "launcher.exe"), envPath("ProgramFiles", "Opera", "opera.exe"), envPath("ProgramFiles(x86)", "Opera", "launcher.exe"), envPath("ProgramFiles(x86)", "Opera", "opera.exe")}},
		{id: "brave", name: "Brave", progIDs: []string{"BraveHTML"}, exeNames: []string{"brave.exe"}, paths: []string{envPath("ProgramFiles", "BraveSoftware", "Brave-Browser", "Application", "brave.exe"), envPath("ProgramFiles(x86)", "BraveSoftware", "Brave-Browser", "Application", "brave.exe"), envPath("LOCALAPPDATA", "BraveSoftware", "Brave-Browser", "Application", "brave.exe")}},
		{id: "vivaldi", name: "Vivaldi", progIDs: []string{"VivaldiHTM"}, exeNames: []string{"vivaldi.exe"}, paths: []string{envPath("LOCALAPPDATA", "Vivaldi", "Application", "vivaldi.exe"), envPath("ProgramFiles", "Vivaldi", "Application", "vivaldi.exe"), envPath("ProgramFiles(x86)", "Vivaldi", "Application", "vivaldi.exe")}},
	}
}

func browserPath(b knownBrowser) string {
	for _, p := range b.paths {
		if p == "" {
			continue
		}
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			return p
		}
	}
	for _, exe := range b.exeNames {
		if p, err := exec.LookPath(exe); err == nil {
			return p
		}
		if p := registryAppPath(exe); p != "" {
			return p
		}
	}
	for _, progID := range b.progIDs {
		if p := registryOpenCommandPath(progID); p != "" {
			return p
		}
	}
	return ""
}

func registryQuery(args ...string) ([]byte, error) {
	// Registry discovery is convenience UI, never a reason to block the local
	// VaultPool service. A damaged shell association or stuck reg.exe must fail
	// closed and quickly instead of making the desktop look frozen.
	ctx, cancel := context.WithTimeout(context.Background(), 800*time.Millisecond)
	defer cancel()
	cmd := exec.CommandContext(ctx, "reg.exe", args...)
	cmd.SysProcAttr = hiddenConsoleSysProcAttr()
	return cmd.Output()
}

func registryAppPath(exe string) string {
	for _, root := range []string{`HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\` + exe, `HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\` + exe} {
		out, err := registryQuery("query", root, "/ve")
		if err != nil {
			continue
		}
		if p := pathFromRegOutput(string(out)); p != "" {
			return p
		}
	}
	return ""
}

func registryOpenCommandPath(progID string) string {
	if strings.TrimSpace(progID) == "" {
		return ""
	}
	for _, root := range []string{`HKCU\Software\Classes\` + progID + `\shell\open\command`, `HKCR\` + progID + `\shell\open\command`} {
		out, err := registryQuery("query", root, "/ve")
		if err != nil {
			continue
		}
		if p := executableFromCommand(pathValueFromRegOutput(string(out))); p != "" {
			return p
		}
	}
	return ""
}

func pathFromRegOutput(out string) string {
	return executableFromCommand(pathValueFromRegOutput(out))
}

func pathValueFromRegOutput(out string) string {
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(strings.ToLower(line), "hkey_") {
			continue
		}
		fields := strings.Fields(line)
		for i, f := range fields {
			if strings.HasPrefix(f, "REG_") && i+1 < len(fields) {
				return strings.Join(fields[i+1:], " ")
			}
		}
	}
	return ""
}

func executableFromCommand(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	var p string
	if strings.HasPrefix(raw, "\"") {
		if end := strings.Index(raw[1:], "\""); end >= 0 {
			p = raw[1 : end+1]
		}
	} else {
		parts := strings.Fields(raw)
		if len(parts) > 0 {
			p = parts[0]
		}
	}
	p = os.ExpandEnv(strings.Trim(p, "\""))
	if p == "" {
		return ""
	}
	if st, err := os.Stat(p); err == nil && !st.IsDir() {
		return p
	}
	return ""
}

func firstNonEmpty(v []string) string {
	for _, s := range v {
		if strings.TrimSpace(s) != "" {
			return s
		}
	}
	return "browser.exe"
}

func detectedDefaultProgID() string {
	out, err := registryQuery("query", `HKCU\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice`, "/v", "ProgId")
	if err != nil {
		return ""
	}
	fields := bytes.Fields(out)
	for i, f := range fields {
		if strings.EqualFold(string(f), "ProgId") && i+2 < len(fields) {
			return string(fields[i+2])
		}
	}
	if len(fields) > 0 {
		return string(fields[len(fields)-1])
	}
	return ""
}

func browserMatchesProgID(b knownBrowser, progID string) bool {
	for _, p := range b.progIDs {
		if strings.EqualFold(p, progID) {
			return true
		}
	}
	return false
}

func BrowserStatusFor(c BrowserConfig) (BrowserStatus, error) {
	c = NormalizeBrowserConfig(c)
	progID := detectedDefaultProgID()
	options := []BrowserOption{{ID: "default", Name: "Predeterminado de Windows", Installed: true}}
	detectedID, detectedName := "", ""
	for _, b := range knownBrowsers() {
		p := browserPath(b)
		isDefault := progID != "" && browserMatchesProgID(b, progID)
		if isDefault {
			detectedID, detectedName = b.id, b.name
		}
		options = append(options, BrowserOption{ID: b.id, Name: b.name, Path: p, Installed: p != "", Default: isDefault})
	}
	options[0].Default = detectedID == ""
	effective := "navegador predeterminado de Windows"
	if detectedName != "" && c.Mode == "default" {
		effective = "predeterminado de Windows: " + detectedName
	}
	if c.Mode == "browser" {
		effective = c.BrowserID
		for _, o := range options {
			if o.ID == c.BrowserID {
				effective = o.Name
				break
			}
		}
	}
	if c.Mode == "custom" {
		effective = c.CustomPath
	}
	return BrowserStatus{DetectedDefaultID: detectedID, DetectedDefaultName: detectedName, Selected: c, EffectiveLabel: effective, Options: options}, nil
}

func findKnownBrowser(id string) (knownBrowser, bool) {
	id = strings.TrimSpace(strings.ToLower(id))
	for _, b := range knownBrowsers() {
		if b.id == id {
			return b, true
		}
	}
	return knownBrowser{}, false
}

func openProgram(path, raw string) error {
	cmd := exec.Command(path, raw)
	cmd.SysProcAttr = noConsoleSysProcAttr()
	return cmd.Start()
}

func OpenAuthURL(raw string, c BrowserConfig) error {
	if err := validateAuthURL(raw); err != nil {
		return err
	}
	c = NormalizeBrowserConfig(c)
	switch c.Mode {
	case "browser":
		b, ok := findKnownBrowser(c.BrowserID)
		if !ok {
			return fmt.Errorf("navegador OAuth desconocido: %s", c.BrowserID)
		}
		p := browserPath(b)
		if p == "" {
			return fmt.Errorf("%s no está instalado o VaultPool no lo encuentra", b.name)
		}
		return openProgram(p, raw)
	case "custom":
		st, err := os.Stat(c.CustomPath)
		if err != nil || st.IsDir() {
			return fmt.Errorf("ejecutable de navegador no válido: %s", c.CustomPath)
		}
		return openProgram(c.CustomPath, raw)
	default:
		if err := OpenURL(raw); err != nil {
			return err
		}
		return nil
	}
}

var _ = errors.New
