package desktop

import (
	"errors"
	"strings"
)

// BrowserConfig is a non-secret preference controlling where OAuth login pages
// are opened. OAuth tokens and provider credentials are never stored here.
type BrowserConfig struct {
	Mode       string `json:"mode"` // default, browser, custom
	BrowserID  string `json:"browser_id,omitempty"`
	CustomPath string `json:"custom_path,omitempty"`
}

type BrowserOption struct {
	ID        string `json:"id"`
	Name      string `json:"name"`
	Path      string `json:"path,omitempty"`
	Installed bool   `json:"installed"`
	Default   bool   `json:"default"`
}

type BrowserStatus struct {
	DetectedDefaultID   string          `json:"detected_default_id,omitempty"`
	DetectedDefaultName string          `json:"detected_default_name,omitempty"`
	Selected            BrowserConfig   `json:"selected"`
	EffectiveLabel      string          `json:"effective_label"`
	Options             []BrowserOption `json:"options"`
}

func NormalizeBrowserConfig(c BrowserConfig) BrowserConfig {
	c.Mode = strings.TrimSpace(strings.ToLower(c.Mode))
	c.BrowserID = strings.TrimSpace(strings.ToLower(c.BrowserID))
	c.CustomPath = strings.TrimSpace(c.CustomPath)
	switch c.Mode {
	case "", "default":
		return BrowserConfig{Mode: "default"}
	case "browser":
		if c.BrowserID == "" {
			return BrowserConfig{Mode: "default"}
		}
		return BrowserConfig{Mode: "browser", BrowserID: c.BrowserID}
	case "custom":
		if c.CustomPath == "" {
			return BrowserConfig{Mode: "default"}
		}
		return BrowserConfig{Mode: "custom", CustomPath: c.CustomPath}
	default:
		return BrowserConfig{Mode: "default"}
	}
}

func validateAuthURL(raw string) error {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return errors.New("empty authorization URL")
	}
	if strings.ContainsAny(raw, "\r\n") {
		return errors.New("authorization URL contains control characters")
	}
	if !(strings.HasPrefix(raw, "https://") || strings.HasPrefix(raw, "http://127.0.0.1:") || strings.HasPrefix(raw, "http://localhost:")) {
		return errors.New("authorization URL must be HTTPS or a loopback callback")
	}
	return nil
}
