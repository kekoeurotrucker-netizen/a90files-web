package megacmd

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

type fakeRunner struct {
	ready bool
	out   map[string]string
	err   map[string]error
}

func (f *fakeRunner) Ready() bool { return f.ready }
func (f *fakeRunner) Run(_ context.Context, name string, args ...string) ([]byte, error) {
	key := name + " " + strings.Join(args, " ")
	if e := f.err[key]; e != nil {
		return nil, e
	}
	if e := f.err[name]; e != nil {
		return nil, e
	}
	if s, ok := f.out[key]; ok {
		return []byte(s), nil
	}
	return []byte(f.out[name]), nil
}

func TestProbeUsesOfficialSessionWithoutPassword(t *testing.T) {
	r := &fakeRunner{ready: true, out: map[string]string{
		"mega-whoami -l": "Account e-mail: person@example.com\nAvailable storage: 20.00 GBytes\nIn ROOT: 1.00 GBytes in 1 file(s) and 0 folder(s)\nIn INBOX: 0.00 Bytes in 0 file(s) and 0 folder(s)\nIn RUBBISH: 0.00 Bytes in 0 file(s) and 0 folder(s)\nTotal size taken up by file versions: 0.00 Bytes\nPro level: 0\n",
		"mega-df":        "Total storage used: 1073741824 Bytes\n",
	}}
	b := &Bridge{Runner: r}
	s, err := b.Probe(context.Background(), "acct")
	if err != nil {
		t.Fatal(err)
	}
	if s.ProviderID != "mega" || s.Identity != "person@example.com" || s.TotalBytes != 20*1024*1024*1024 || s.UsedBytes != 1024*1024*1024 || s.FreeBytes != 19*1024*1024*1024 || s.PlanName != "MEGA Free" {
		t.Fatalf("bad snapshot: %+v", s)
	}
}
func TestProbeRequiresLoggedInSession(t *testing.T) {
	r := &fakeRunner{ready: true, out: map[string]string{}, err: map[string]error{"mega-whoami": errors.New("not logged in")}}
	_, err := (&Bridge{Runner: r}).Probe(context.Background(), "acct")
	if err == nil {
		t.Fatal("expected session error")
	}
}
func TestParseFindPathsStaysInsideReservedRoot(t *testing.T) {
	got := parseFindPaths([]byte("/VaultPool/vp-manifest-abc.cpm\n/Other/vp-manifest-bad.cpm\n/VaultPool/nope.txt\n"), "/VaultPool", "vp-manifest-", ".cpm")
	if len(got) != 1 || got[0] != "/VaultPool/vp-manifest-abc.cpm" {
		t.Fatalf("got %#v", got)
	}
}
func TestParseBytesMEGAUnits(t *testing.T) {
	n, err := parseBytes("1.50", "GBytes")
	if err != nil {
		t.Fatal(err)
	}
	if n != 1610612736 {
		t.Fatalf("got %d", n)
	}
}

type storageRunner struct {
	files      map[string][]byte
	email      string
	rootExists bool
}

func (r *storageRunner) Ready() bool { return true }
func (r *storageRunner) Run(_ context.Context, name string, args ...string) ([]byte, error) {
	if r.files == nil {
		r.files = map[string][]byte{}
	}
	switch name {
	case "mega-whoami":
		email := r.email
		if email == "" {
			email = "person@example.com"
		}
		return []byte("Account e-mail: " + email + "\nAvailable storage: 20.00 GBytes\n"), nil
	case "mega-mkdir":
		if r.rootExists {
			return nil, errors.New("Folder already exists")
		}
		r.rootExists = true
		return nil, nil
	case "mega-put":
		if len(args) != 2 {
			return nil, errors.New("bad put args")
		}
		b, err := os.ReadFile(args[0])
		if err != nil {
			return nil, err
		}
		remote := strings.TrimRight(args[1], "/") + "/" + filepath.Base(args[0])
		r.files[remote] = append([]byte(nil), b...)
		return nil, nil
	case "mega-get":
		if len(args) != 2 {
			return nil, errors.New("bad get args")
		}
		b, ok := r.files[args[0]]
		if !ok {
			return nil, errors.New("missing")
		}
		if err := os.WriteFile(filepath.Join(args[1], filepath.Base(args[0])), b, 0o600); err != nil {
			return nil, err
		}
		return nil, nil
	case "mega-rm":
		if len(args) < 2 {
			return nil, errors.New("bad rm args")
		}
		delete(r.files, args[len(args)-1])
		return nil, nil
	case "mega-du":
		b, ok := r.files[args[0]]
		if !ok {
			return nil, errors.New("missing")
		}
		return []byte(fmt.Sprintf("Total storage used: %d Bytes\n", len(b))), nil
	case "mega-find":
		if len(args) == 2 && args[1] == "--type=d" {
			if r.rootExists {
				return []byte("/VaultPool\n"), nil
			}
			return nil, errors.New("folder missing")
		}
		var lines []string
		for p := range r.files {
			if strings.HasPrefix(p, "/VaultPool/") {
				lines = append(lines, p)
			}
		}
		sort.Strings(lines)
		return []byte(strings.Join(lines, "\n")), nil
	default:
		return nil, errors.New("unsupported command")
	}
}

func TestStorePutReadBackAndDelete(t *testing.T) {
	r := &storageRunner{rootExists: true}
	s := &Store{Runner: r, Root: "/VaultPool", TempDir: t.TempDir()}
	data := []byte("already encrypted vaultpool shard")
	sum := remoteobject.SHA256Bytes(data)
	obj, err := s.PutVerified(context.Background(), "acct", "objects/file/block/shard", data, sum)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasPrefix(obj.ID, "/VaultPool/vp-") || !strings.HasSuffix(obj.ID, ".cps") {
		t.Fatalf("unexpected locator %q", obj.ID)
	}
	got, err := s.GetVerified(context.Background(), "acct", obj.ID, int64(len(data)), sum)
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != string(data) {
		t.Fatal("readback mismatch")
	}
	if err := s.Delete(context.Background(), "acct", obj.ID); err != nil {
		t.Fatal(err)
	}
	if _, ok := r.files[obj.ID]; ok {
		t.Fatal("remote object not deleted")
	}
}

func TestBoundStoreBlocksSwitchedMEGASession(t *testing.T) {
	r := &storageRunner{email: "person@example.com"}
	targetID, err := connector.StableTargetID("mega", "person@example.com")
	if err != nil {
		t.Fatal(err)
	}
	s := &Store{Runner: r, Root: "/VaultPool", TempDir: t.TempDir(), ExpectedTargetID: targetID}
	data := []byte("encrypted shard")
	sum := remoteobject.SHA256Bytes(data)
	if _, err := s.PutVerified(context.Background(), "acct", "objects/file/block/shard", data, sum); err != nil {
		t.Fatalf("initial account should work: %v", err)
	}
	r.email = "other@example.com"
	if _, err := s.PutVerified(context.Background(), "acct", "objects/file/block/other", data, sum); err == nil || !strings.Contains(err.Error(), "different account") {
		t.Fatalf("switched MEGA session was not blocked: %v", err)
	}
}
