package megacmd

import (
	"context"
	"errors"
	"testing"
)

func TestExistingRootMustBeVerifiedAsExactDirectory(t *testing.T) {
	for _, tc := range []struct {
		name    string
		output  string
		findErr error
		wantOK  bool
	}{
		{name: "existing", output: "/VaultPool\r\n/VaultPool/child\r\n", wantOK: true},
		{name: "only-child", output: "/VaultPool/child\n"},
		{name: "another-directory", output: "/VaultPool-other\n"},
		{name: "file-or-missing", output: ""},
		{name: "lookup-failed", output: "/VaultPool\n", findErr: errors.New("access denied")},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := &fakeRunner{ready: true, out: map[string]string{"mega-find": tc.output}, err: map[string]error{"mega-mkdir": errors.New("mkdir failed"), "mega-find": tc.findErr}}
			err := (&Store{Runner: r}).ensureRoot(context.Background())
			if (err == nil) != tc.wantOK {
				t.Fatalf("ensureRoot error = %v, want success %v", err, tc.wantOK)
			}
		})
	}
}

func TestEnsureRootPreservesCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	r := &fakeRunner{ready: true, out: map[string]string{"mega-find": "/VaultPool\n"}, err: map[string]error{"mega-mkdir": context.Canceled}}
	if err := (&Store{Runner: r}).ensureRoot(ctx); !errors.Is(err, context.Canceled) {
		t.Fatalf("want cancellation, got %v", err)
	}
}
