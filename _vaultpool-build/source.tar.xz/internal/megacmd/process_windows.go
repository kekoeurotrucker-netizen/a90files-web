//go:build windows

package megacmd

import "syscall"

const createNoWindow = 0x08000000

func hiddenSysProcAttr() *syscall.SysProcAttr {
	return &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
}
