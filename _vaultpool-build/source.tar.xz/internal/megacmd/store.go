package megacmd

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

type Store struct {
	Runner           Runner
	Root             string
	TempDir          string
	ExpectedTargetID string
}

func (s *Store) ProviderID() string { return "mega" }
func (s *Store) root() string {
	r := strings.TrimSpace(s.Root)
	if r == "" {
		return defaultRoot
	}
	return strings.TrimRight(r, "/")
}
func (s *Store) ready() error {
	if s == nil || s.Runner == nil || !s.Runner.Ready() {
		return errors.New("official MEGAcmd is unavailable")
	}
	return nil
}

func (s *Store) verifySession(ctx context.Context) error {
	if err := s.ready(); err != nil {
		return err
	}
	if strings.TrimSpace(s.ExpectedTargetID) == "" {
		return nil
	}
	who, err := s.Runner.Run(ctx, "mega-whoami", "-l")
	if err != nil {
		return errors.New("MEGA session unavailable; reconnect the registered account")
	}
	em := emailRE.FindStringSubmatch(string(who))
	if len(em) != 2 || strings.TrimSpace(em[1]) == "" {
		return errors.New("MEGA session identity unavailable")
	}
	currentID, err := connector.StableTargetID("mega", strings.ToLower(strings.TrimSpace(em[1])))
	if err != nil {
		return errors.New("invalid MEGA session identity")
	}
	if currentID != strings.TrimSpace(s.ExpectedTargetID) {
		return errors.New("active MEGA session belongs to a different account; transfer blocked")
	}
	return nil
}
func (s *Store) ensureRoot(ctx context.Context) error {
	if err := s.verifySession(ctx); err != nil {
		return err
	}
	if _, err := s.Runner.Run(ctx, "mega-mkdir", "-p", s.root()); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		// MEGAcmd returns an error for an existing directory even with -p.
		// Accept it only after verifying that the exact destination is a folder.
		out, findErr := s.Runner.Run(ctx, "mega-find", s.root(), "--type=d")
		if findErr == nil {
			for _, line := range strings.Split(string(out), "\n") {
				if strings.TrimRight(strings.TrimSpace(line), "/") == s.root() {
					return nil
				}
			}
		}
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return fmt.Errorf("cannot create/access VaultPool folder in MEGA: %w", err)
	}
	return nil
}
func (s *Store) stagedFile(name string, data []byte) (string, func(), error) {
	dir := strings.TrimSpace(s.TempDir)
	if dir == "" {
		dir = os.TempDir()
	}
	stage, err := os.MkdirTemp(dir, "vaultpool-mega-stage-")
	if err != nil {
		return "", nil, err
	}
	cleanup := func() { _ = os.RemoveAll(stage) }
	path := filepath.Join(stage, name)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		cleanup()
		return "", nil, err
	}
	return path, cleanup, nil
}

func safeRemotePath(root, name string) (string, error) {
	if name == "" || strings.ContainsAny(name, "/\\\r\n\x00") || name == "." || name == ".." {
		return "", errors.New("unsafe MEGA object name")
	}
	return strings.TrimRight(root, "/") + "/" + name, nil
}

func randomSuffix(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func megaObjectName(key string) (string, error) {
	suffix, err := randomSuffix(6)
	if err != nil {
		return "", err
	}
	if strings.HasPrefix(key, "metadata/manifests/") {
		if id, ok := manifestID(key); ok {
			return "vp-manifest-" + id + "-" + suffix + ".cpm", nil
		}
		return "", errors.New("invalid VaultPool manifest key")
	}
	if id, ok := recoveryID(key); ok {
		return "vp-filekey-" + id + "-" + suffix + ".vprk", nil
	}
	return "vp-" + remoteobject.SHA256Bytes([]byte(key)) + "-" + suffix + ".cps", nil
}
func manifestID(key string) (string, bool) {
	const pre = "metadata/manifests/"
	if !strings.HasPrefix(key, pre) {
		return "", false
	}
	parts := strings.Split(strings.TrimPrefix(key, pre), "/")
	if len(parts) != 2 || len(parts[0]) != 32 || !strings.HasPrefix(parts[1], "generation-") || !strings.HasSuffix(parts[1], ".cpm") {
		return "", false
	}
	return strings.ToLower(parts[0]), true
}
func recoveryID(key string) (string, bool) {
	const pre, suf = "metadata/recovery/filekeys/", ".vprk"
	if !strings.HasPrefix(key, pre) || !strings.HasSuffix(key, suf) {
		return "", false
	}
	id := strings.TrimSuffix(strings.TrimPrefix(key, pre), suf)
	if len(id) != 32 {
		return "", false
	}
	return strings.ToLower(id), true
}

func (s *Store) PutVerified(ctx context.Context, accountID, key string, data []byte, expectedSHA string) (remoteobject.Object, error) {
	_ = accountID
	if err := s.verifySession(ctx); err != nil {
		return remoteobject.Object{}, err
	}
	if err := remoteobject.ValidateKey(key); err != nil {
		return remoteobject.Object{}, err
	}
	if len(data) == 0 {
		return remoteobject.Object{}, errors.New("empty remote objects are not supported")
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(data), expectedSHA) {
		return remoteobject.Object{}, errors.New("local SHA-256 mismatch before MEGA upload")
	}
	if err := s.ensureRoot(ctx); err != nil {
		return remoteobject.Object{}, err
	}
	name, err := megaObjectName(key)
	if err != nil {
		return remoteobject.Object{}, err
	}
	remote, err := safeRemotePath(s.root(), name)
	if err != nil {
		return remoteobject.Object{}, err
	}
	tmp, cleanup, err := s.stagedFile(name, data)
	if err != nil {
		return remoteobject.Object{}, err
	}
	defer cleanup()
	// A fresh random remote name makes upload commit-like: an older verified
	// replica is never removed before the new replica has been uploaded and read
	// back successfully. Arguments are passed directly without shell parsing.
	// -q queues the transfer and returns before completion, so it must not be
	// used for a verified write or before cleaning up the local staging file.
	if _, err := s.Runner.Run(ctx, "mega-put", tmp, s.root()); err != nil {
		return remoteobject.Object{}, errors.New("MEGA upload failed")
	}
	obj := remoteobject.Object{ProviderID: "mega", AccountID: accountID, ID: remote, Key: key, Name: name, Size: int64(len(data)), SHA256: strings.ToLower(expectedSHA)}
	if _, err := s.GetVerified(ctx, accountID, remote, obj.Size, obj.SHA256); err != nil {
		_, _ = s.Runner.Run(ctx, "mega-rm", "-f", remote)
		return remoteobject.Object{}, fmt.Errorf("MEGA post-upload verification failed: %w", err)
	}
	return obj, nil
}

func (s *Store) GetVerified(ctx context.Context, accountID, objectID string, expectedSize int64, expectedSHA string) ([]byte, error) {
	_ = accountID
	if err := s.verifySession(ctx); err != nil {
		return nil, err
	}
	if expectedSize < 0 || objectID == "" || !strings.HasPrefix(objectID, s.root()+"/") {
		return nil, errors.New("invalid MEGA object locator")
	}
	dir, err := os.MkdirTemp(s.TempDir, "vaultpool-mega-get-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	if _, err := s.Runner.Run(ctx, "mega-get", objectID, dir); err != nil {
		return nil, errors.New("MEGA download failed")
	}
	name := filepath.Base(filepath.ToSlash(objectID))
	b, err := os.ReadFile(filepath.Join(dir, name))
	if err != nil {
		return nil, errors.New("MEGA download did not produce expected object")
	}
	if int64(len(b)) != expectedSize {
		return nil, fmt.Errorf("remote size mismatch: got %d want %d", len(b), expectedSize)
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(b), expectedSHA) {
		return nil, errors.New("remote SHA-256 mismatch")
	}
	return b, nil
}

func (s *Store) Delete(ctx context.Context, accountID, objectID string) error {
	_ = accountID
	if err := s.verifySession(ctx); err != nil {
		return err
	}
	if objectID == "" || !strings.HasPrefix(objectID, s.root()+"/") {
		return errors.New("invalid MEGA object locator")
	}
	if _, err := s.Runner.Run(ctx, "mega-rm", "-f", objectID); err != nil {
		return errors.New("MEGA delete failed")
	}
	return nil
}

func (s *Store) candidateSize(ctx context.Context, path string) (int64, error) {
	out, err := s.Runner.Run(ctx, "mega-du", path)
	if err != nil {
		return 0, err
	}
	if n, ok := matchSize(usedRE, string(out)); ok && n > 0 {
		return n, nil
	}
	return 0, errors.New("MEGAcmd did not report object size")
}
func (s *Store) ListManifestCandidates(ctx context.Context, accountID string) ([]remoteobject.ManifestCandidate, error) {
	_ = accountID
	if err := s.ensureRoot(ctx); err != nil {
		return nil, err
	}
	out, err := s.Runner.Run(ctx, "mega-find", s.root(), "--pattern=vp-manifest-*.cpm", "--type=f")
	if err != nil {
		return nil, err
	}
	paths := parseFindPaths(out, s.root(), "vp-manifest-", ".cpm")
	result := make([]remoteobject.ManifestCandidate, 0, len(paths))
	for _, p := range paths {
		size, err := s.candidateSize(ctx, p)
		if err != nil || size <= 0 {
			continue
		}
		name := filepath.Base(filepath.ToSlash(p))
		body := strings.TrimSuffix(strings.TrimPrefix(name, "vp-manifest-"), ".cpm")
		id := ""
		if len(body) >= 32 {
			id = body[:32]
		}
		result = append(result, remoteobject.ManifestCandidate{Locator: p, RecoveryID: id, Size: size})
	}
	return result, nil
}
func (s *Store) ReadManifestCandidate(ctx context.Context, accountID, locator string, maxBytes int64) ([]byte, error) {
	_ = accountID
	if maxBytes <= 0 {
		return nil, errors.New("invalid recovery size cap")
	}
	// Candidate size is provider-sourced and bounded before returning bytes.
	size, err := s.candidateSize(ctx, locator)
	if err != nil {
		return nil, err
	}
	if size > maxBytes {
		return nil, fmt.Errorf("manifest candidate exceeds cap: %d > %d", size, maxBytes)
	}
	return s.readCandidate(ctx, locator, size)
}

// Recovery candidates do not carry a trusted plaintext hash. Download once,
// enforce the provider-reported size bound, and let the higher layer verify the
// authenticated VaultPool envelope (AES-GCM / recovery-record AEAD).
func (s *Store) readCandidate(ctx context.Context, locator string, size int64) ([]byte, error) {
	if locator == "" || !strings.HasPrefix(locator, s.root()+"/") || size <= 0 {
		return nil, errors.New("invalid MEGA recovery locator")
	}
	dir, err := os.MkdirTemp(s.TempDir, "vaultpool-mega-recovery-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	if _, err := s.Runner.Run(ctx, "mega-get", locator, dir); err != nil {
		return nil, errors.New("MEGA recovery download failed")
	}
	b, err := os.ReadFile(filepath.Join(dir, filepath.Base(filepath.ToSlash(locator))))
	if err != nil {
		return nil, errors.New("MEGA recovery candidate missing after download")
	}
	if int64(len(b)) != size {
		return nil, fmt.Errorf("MEGA recovery candidate size mismatch: got %d want %d", len(b), size)
	}
	return b, nil
}

func (s *Store) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]remoteobject.RecoveryRecordCandidate, error) {
	_ = accountID
	if err := s.ensureRoot(ctx); err != nil {
		return nil, err
	}
	out, err := s.Runner.Run(ctx, "mega-find", s.root(), "--pattern=vp-filekey-*.vprk", "--type=f")
	if err != nil {
		return nil, err
	}
	paths := parseFindPaths(out, s.root(), "vp-filekey-", ".vprk")
	result := make([]remoteobject.RecoveryRecordCandidate, 0, len(paths))
	for _, p := range paths {
		size, err := s.candidateSize(ctx, p)
		if err != nil || size <= 0 {
			continue
		}
		name := filepath.Base(filepath.ToSlash(p))
		body := strings.TrimSuffix(strings.TrimPrefix(name, "vp-filekey-"), ".vprk")
		id := ""
		if len(body) >= 32 {
			id = body[:32]
		}
		result = append(result, remoteobject.RecoveryRecordCandidate{Locator: p, RecoveryID: id, Size: size})
	}
	return result, nil
}
func (s *Store) ReadRecoveryRecordCandidate(ctx context.Context, accountID, locator string, maxBytes int64) ([]byte, error) {
	_ = accountID
	if maxBytes <= 0 {
		return nil, errors.New("invalid recovery size cap")
	}
	size, err := s.candidateSize(ctx, locator)
	if err != nil {
		return nil, err
	}
	if size > maxBytes {
		return nil, fmt.Errorf("recovery candidate exceeds cap: %d > %d", size, maxBytes)
	}
	return s.readCandidate(ctx, locator, size)
}
