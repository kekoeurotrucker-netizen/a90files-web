package megacmd

import (
	"bytes"
	"context"
	"os"
	"testing"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

// This opt-in check writes one fresh encrypted object and removes only that
// object. It never enumerates or deletes existing user files.
func TestLiveMEGAEncryptedRoundTrip(t *testing.T) {
	if os.Getenv("VAULTPOOL_LIVE_MEGA_TEST") != "1" {
		t.Skip("live MEGA test disabled")
	}
	expected := os.Getenv("VAULTPOOL_LIVE_MEGA_TARGET")
	if expected == "" {
		t.Fatal("expected MEGA target identity is required")
	}
	s := &Store{Runner: ExecRunner{}, TempDir: t.TempDir(), ExpectedTargetID: expected}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	defer clear(key)
	plain := bytes.Repeat([]byte("VaultPool disposable encrypted round-trip test.\n"), 2048)
	sealed, err := cryptokit.Seal(key, plain, []byte("live-mega-test"))
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	started := time.Now()
	obj, err := s.PutVerified(ctx, "diagnostic", "objects/diagnostic/roundtrip", sealed, remoteobject.SHA256Bytes(sealed))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		cleanupCtx, cleanupCancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cleanupCancel()
		if err := s.Delete(cleanupCtx, "diagnostic", obj.ID); err != nil {
			t.Errorf("remove diagnostic object %s: %v", obj.ID, err)
		}
	})
	got, err := s.GetVerified(ctx, "diagnostic", obj.ID, obj.Size, obj.SHA256)
	if err != nil {
		t.Fatal(err)
	}
	restored, err := cryptokit.Open(key, got, []byte("live-mega-test"))
	if err != nil || !bytes.Equal(plain, restored) {
		t.Fatalf("decryption/readback mismatch: %v", err)
	}
	t.Logf("Encrypted bytes: %d; upload + verified downloads + decryption: %s", len(sealed), time.Since(started).Round(time.Millisecond))
}
