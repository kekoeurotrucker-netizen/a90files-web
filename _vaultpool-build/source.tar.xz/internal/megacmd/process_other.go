//go:build !windows

package megacmd

import "syscall"

func hiddenSysProcAttr() *syscall.SysProcAttr { return nil }
