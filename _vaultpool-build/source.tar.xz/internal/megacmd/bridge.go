package megacmd

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

const defaultRoot = "/VaultPool"

// Runner is intentionally tiny so MEGAcmd integration can be unit-tested
// without a real cloud account. Implementations must execute argument arrays
// directly; never join them into a shell command string.
type Runner interface {
	Ready() bool
	Run(context.Context, string, ...string) ([]byte, error)
}

type ExecRunner struct {
	Dir string
}

func megacmdDirs(explicit string) []string {
	seen := map[string]bool{}
	out := []string{}
	add := func(dir string) {
		dir = strings.TrimSpace(dir)
		if dir == "" {
			return
		}
		key := strings.ToLower(filepath.Clean(dir))
		if seen[key] {
			return
		}
		seen[key] = true
		out = append(out, filepath.Clean(dir))
	}
	add(explicit)
	if runtime.GOOS == "windows" {
		// Current official Windows builds may install per-user under LOCALAPPDATA,
		// while older/all-users installers use Program Files. Probe both.
		if base := strings.TrimSpace(os.Getenv("LOCALAPPDATA")); base != "" {
			add(filepath.Join(base, "MEGAcmd"))
		}
		for _, envName := range []string{"ProgramFiles", "ProgramFiles(x86)"} {
			if base := strings.TrimSpace(os.Getenv(envName)); base != "" {
				add(filepath.Join(base, "MEGAcmd"))
			}
		}
	}
	return out
}

func (r ExecRunner) commandPath(name string) (string, error) {
	names := []string{name}
	if runtime.GOOS == "windows" && filepath.Ext(name) == "" {
		names = append(names, name+".exe")
	}
	for _, dir := range megacmdDirs(r.Dir) {
		for _, n := range names {
			p := filepath.Join(dir, n)
			if st, err := os.Stat(p); err == nil && !st.IsDir() {
				return p, nil
			}
		}
	}
	for _, n := range names {
		if p, err := exec.LookPath(n); err == nil {
			return p, nil
		}
	}
	return "", fmt.Errorf("MEGAcmd command %s not found", name)
}

func (r ExecRunner) megaClientPath() (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("MegaClient.exe is Windows-only")
	}
	for _, dir := range megacmdDirs(r.Dir) {
		for _, n := range []string{"MEGAclient.exe", "MegaClient.exe"} {
			p := filepath.Join(dir, n)
			if st, err := os.Stat(p); err == nil && !st.IsDir() {
				return p, nil
			}
		}
	}
	for _, n := range []string{"MEGAclient.exe", "MegaClient.exe"} {
		if p, err := exec.LookPath(n); err == nil {
			return p, nil
		}
	}
	return "", errors.New("MEGAclient.exe not found")
}

func (r ExecRunner) Ready() bool {
	if runtime.GOOS == "windows" {
		_, err := r.megaClientPath()
		return err == nil
	}
	for _, name := range []string{"mega-whoami", "mega-df", "mega-du", "mega-mkdir", "mega-put", "mega-get", "mega-rm", "mega-find"} {
		if _, err := r.commandPath(name); err != nil {
			return false
		}
	}
	return true
}

func (r ExecRunner) Run(ctx context.Context, name string, args ...string) ([]byte, error) {
	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		p, err := r.megaClientPath()
		if err != nil {
			return nil, err
		}
		command := strings.TrimPrefix(strings.TrimSpace(name), "mega-")
		if command == "" || command == name {
			return nil, fmt.Errorf("invalid MEGAcmd command %q", name)
		}
		argv := append([]string{command}, args...)
		cmd = exec.CommandContext(ctx, p, argv...)
	} else {
		p, err := r.commandPath(name)
		if err != nil {
			return nil, err
		}
		cmd = exec.CommandContext(ctx, p, args...)
	}
	// Do not inherit stdin: VaultPool never feeds MEGA passwords to scriptable
	// commands. Interactive login is performed in the official MEGAcmd shell.
	cmd.Stdin = nil
	cmd.SysProcAttr = hiddenSysProcAttr()
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("MEGAcmd %s failed: %w", name, err)
	}
	return out, nil
}

type Bridge struct {
	Runner  Runner
	Root    string
	TempDir string
	CmdDir  string
}

func New(dir string) *Bridge {
	return &Bridge{Runner: ExecRunner{Dir: dir}, Root: defaultRoot, CmdDir: dir}
}

func (b *Bridge) ProviderID() string { return "mega" }
func (b *Bridge) Ready() bool        { return b != nil && b.Runner != nil && b.Runner.Ready() }

// RemoteStore lets the cloud target resolver reuse the same audited MEGAcmd
// runner for object operations. No MEGA password or session string is copied
// into VaultPool's state or secret vault.
func (b *Bridge) RemoteStore() remoteobject.Store {
	root := strings.TrimSpace(b.Root)
	if root == "" {
		root = defaultRoot
	}
	return &Store{Runner: b.Runner, Root: root, TempDir: b.TempDir}
}

// RemoteStoreFor binds every MEGA operation to the stable identity verified
// when the account was connected. MEGAcmd has one active account session at a
// time, so a manual account switch must never redirect an existing VaultPool
// target to a different MEGA account.
func (b *Bridge) RemoteStoreFor(_ string, stableTargetID string) remoteobject.Store {
	root := strings.TrimSpace(b.Root)
	if root == "" {
		root = defaultRoot
	}
	return &Store{Runner: b.Runner, Root: root, TempDir: b.TempDir, ExpectedTargetID: strings.TrimSpace(stableTargetID)}
}

// LaunchAuth opens MEGA's own interactive shell. The user types credentials
// there; VaultPool only polls the resulting official MEGAcmd session.
func (b *Bridge) LaunchAuth(_ context.Context, _ string) error {
	if runtime.GOOS == "windows" {
		return b.launchAuthWindows()
	}
	return b.launchAuthPOSIX()
}

func (b *Bridge) launchAuthPOSIX() error {
	candidates := []string{}
	if v := strings.TrimSpace(os.Getenv("VAULTPOOL_MEGACMD_SHELL")); v != "" {
		candidates = append(candidates, v)
	}
	if dir := strings.TrimSpace(b.CmdDir); dir != "" {
		candidates = append(candidates, filepath.Join(dir, "mega-cmd"))
	}
	candidates = append(candidates, "mega-cmd")
	for _, c := range candidates {
		p := c
		if !filepath.IsAbs(c) {
			if found, err := exec.LookPath(c); err == nil {
				p = found
			} else {
				continue
			}
		}
		cmd := exec.Command(p)
		cmd.Stdin = os.Stdin
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		if err := cmd.Start(); err == nil {
			return nil
		}
	}
	return errors.New("MEGAcmd interactive shell not found; install/open official MEGAcmd and log in there")
}

func existingFile(path string) bool {
	if strings.TrimSpace(path) == "" {
		return false
	}
	st, err := os.Stat(path)
	return err == nil && !st.IsDir()
}

func (b *Bridge) launchAuthWindows() error {
	var failures []string

	// Prefer the official interactive shell. Calling the scriptable
	// MEGAclient.exe login command without arguments exits immediately, and
	// passing a password on the command line is not acceptable for VaultPool or
	// for end users. MEGAcmdShell is the official human login surface: it can
	// prompt inside MEGA's own client, keeps credentials out of VaultPool, and
	// leaves a resumable MEGAcmd session for later probes.
	tryShell := func(path string) bool {
		if err := startWindowsProgram(path); err == nil {
			return true
		} else {
			failures = append(failures, fmt.Sprintf("%s: %v", path, err))
			return false
		}
	}

	if v := strings.TrimSpace(os.Getenv("VAULTPOOL_MEGACMD_SHELL")); v != "" && tryShell(v) {
		return nil
	}
	for _, dir := range megacmdDirs(b.CmdDir) {
		for _, name := range []string{"MEGAcmdShell.exe", "MEGAcmdShell.bat", "MEGAcmd.exe"} {
			path := filepath.Join(dir, name)
			if existingFile(path) && tryShell(path) {
				return nil
			}
		}
	}
	for _, name := range []string{"MEGAcmdShell.exe", "MEGAcmdShell.bat", "MEGAcmdShell", "MEGAcmd.exe", "MEGAcmd"} {
		if path, err := exec.LookPath(name); err == nil && tryShell(path) {
			return nil
		}
	}

	// Last-resort diagnostic window: do not run MEGAclient.exe login here,
	// because that requires a password argument in non-interactive mode. Show the
	// user exactly what happened and keep the modal reusable.
	if client, err := (ExecRunner{Dir: b.CmdDir}).megaClientPath(); err == nil {
		if err := startWindowsMegaHelp(client, failures); err == nil {
			return nil
		}
	}
	if len(failures) > 0 {
		return fmt.Errorf("Windows no pudo abrir la shell interactiva oficial de MEGAcmd (%s). Abre MEGAcmd desde el menu Inicio e inicia sesion alli", strings.Join(failures, "; "))
	}
	return errors.New("MEGAcmd interactive shell not found; install/open official MEGAcmd and log in there")
}

func startWindowsProgram(path string) error {
	if !filepath.IsAbs(path) {
		if found, err := exec.LookPath(path); err == nil {
			path = found
		}
	}
	if !existingFile(path) {
		return fmt.Errorf("program not found: %s", path)
	}
	dir := filepath.Dir(path)
	cmd := exec.Command("cmd.exe", "/C", "start", "", "/D", dir, path)
	cmd.SysProcAttr = hiddenSysProcAttr()
	return cmd.Start()
}

func startWindowsMegaHelp(client string, failures []string) error {
	if !filepath.IsAbs(client) {
		if found, err := exec.LookPath(client); err == nil {
			client = found
		}
	}
	if !existingFile(client) {
		return fmt.Errorf("MEGAclient.exe not found: %s", client)
	}
	dir := filepath.Dir(client)
	lines := []string{
		"title VaultPool - MEGA login",
		"cd /d " + quoteWindowsCmdArg(dir),
		"echo VaultPool encontro MEGAcmd pero no pudo abrir su shell interactiva.",
		"echo.",
		"echo NO escribas solo el correo en esta consola y NO pegues tu password aqui si no te lo pide MEGAcmd.",
		"echo Abre MEGAcmd desde el menu Inicio y ejecuta dentro: login tu_correo",
		"echo Cuando MEGAcmd pida password/MFA, introducelos alli. VaultPool no recibe esos datos.",
		"echo.",
	}
	if len(failures) > 0 {
		lines = append(lines, "echo Intentos fallidos de shell:")
		for _, f := range failures {
			lines = append(lines, "echo - "+escapeWindowsEcho(f))
		}
	}
	lines = append(lines, "echo.", "echo Cuando termines, vuelve a VaultPool y pulsa Comprobar.")
	cmdline := strings.Join(lines, " & ")
	cmd := exec.Command("cmd.exe", "/C", "start", "", "/D", dir, "cmd.exe", "/K", cmdline)
	cmd.SysProcAttr = hiddenSysProcAttr()
	return cmd.Start()
}

func quoteWindowsCmdArg(s string) string {
	return "\"" + strings.ReplaceAll(s, "\"", "\\\"") + "\""
}

func escapeWindowsEcho(s string) string {
	s = strings.ReplaceAll(s, "&", "^&")
	s = strings.ReplaceAll(s, "|", "^|")
	s = strings.ReplaceAll(s, "<", "^<")
	s = strings.ReplaceAll(s, ">", "^>")
	return s
}

var (
	emailRE     = regexp.MustCompile(`(?im)^\s*Account e-mail:\s*(\S+)\s*$`)
	availableRE = regexp.MustCompile(`(?im)^\s*Available storage:\s*([0-9]+(?:[.,][0-9]+)?)\s*([A-Za-z]+)\s*$`)
	proRE       = regexp.MustCompile(`(?im)^\s*Pro level:\s*([^\r\n]*)$`)
	usedRE      = regexp.MustCompile(`(?im)^\s*Total storage used:\s*([0-9]+(?:[.,][0-9]+)?)\s*([A-Za-z]+)\s*$`)
	folderUseRE = regexp.MustCompile(`(?im)^\s*In\s+(?:ROOT|INBOX|RUBBISH):\s*([0-9]+(?:[.,][0-9]+)?)\s*([A-Za-z]+)\b`)
	versionsRE  = regexp.MustCompile(`(?im)^\s*Total size taken up by file versions:\s*([0-9]+(?:[.,][0-9]+)?)\s*([A-Za-z]+)\s*$`)
)

func parseBytes(value, unit string) (int64, error) {
	value = strings.ReplaceAll(strings.TrimSpace(value), ",", ".")
	f, err := strconv.ParseFloat(value, 64)
	if err != nil || f < 0 || math.IsInf(f, 0) || math.IsNaN(f) {
		return 0, errors.New("invalid MEGAcmd size")
	}
	switch strings.ToLower(strings.TrimSpace(unit)) {
	case "b", "byte", "bytes":
	case "k", "kb", "kbyte", "kbytes", "kib":
		f *= 1024
	case "m", "mb", "mbyte", "mbytes", "mib":
		f *= 1024 * 1024
	case "g", "gb", "gbyte", "gbytes", "gib":
		f *= 1024 * 1024 * 1024
	case "t", "tb", "tbyte", "tbytes", "tib":
		f *= 1024 * 1024 * 1024 * 1024
	default:
		return 0, fmt.Errorf("unknown MEGAcmd size unit %q", unit)
	}
	if f > math.MaxInt64 {
		return 0, errors.New("MEGAcmd size overflow")
	}
	return int64(math.Round(f)), nil
}

func matchSize(re *regexp.Regexp, s string) (int64, bool) {
	m := re.FindStringSubmatch(s)
	if len(m) != 3 {
		return 0, false
	}
	n, err := parseBytes(m[1], m[2])
	return n, err == nil
}

func parseUsed(df, who string) (int64, error) {
	if n, ok := matchSize(usedRE, df); ok {
		return n, nil
	}
	var total int64
	found := false
	for _, m := range folderUseRE.FindAllStringSubmatch(who, -1) {
		if len(m) != 3 {
			continue
		}
		n, err := parseBytes(m[1], m[2])
		if err != nil {
			continue
		}
		total += n
		found = true
	}
	if n, ok := matchSize(versionsRE, who); ok {
		total += n
		found = true
	}
	if !found {
		return 0, errors.New("MEGAcmd did not report storage usage")
	}
	return total, nil
}

func (b *Bridge) Probe(ctx context.Context, accountID string) (connector.Snapshot, error) {
	if !b.Ready() {
		return connector.Snapshot{}, errors.New("official MEGAcmd is not installed or its scriptable commands are not available")
	}
	who, err := b.Runner.Run(ctx, "mega-whoami", "-l")
	if err != nil {
		return connector.Snapshot{}, errors.New("MEGA session not available; open official MEGAcmd and log in")
	}
	text := string(who)
	em := emailRE.FindStringSubmatch(text)
	if len(em) != 2 || strings.TrimSpace(em[1]) == "" {
		return connector.Snapshot{}, errors.New("MEGAcmd is not logged into a MEGA account")
	}
	total, ok := matchSize(availableRE, text)
	if !ok || total <= 0 {
		return connector.Snapshot{}, errors.New("MEGAcmd did not report account storage quota")
	}
	df, _ := b.Runner.Run(ctx, "mega-df")
	used, err := parseUsed(string(df), text)
	if err != nil {
		return connector.Snapshot{}, err
	}
	if used < 0 {
		used = 0
	}
	if used > total {
		// Provider wording/rounding can vary. Refuse an inconsistent trusted
		// snapshot rather than inventing capacity.
		return connector.Snapshot{}, errors.New("MEGAcmd storage usage exceeds reported quota")
	}
	plan := "MEGA"
	if m := proRE.FindStringSubmatch(text); len(m) == 2 {
		p := strings.TrimSpace(m[1])
		if p != "" && p != "0" {
			plan = "MEGA Pro " + p
		} else if p == "0" {
			plan = "MEGA Free"
		}
	}
	identity := strings.TrimSpace(em[1])
	return connector.Snapshot{
		ProviderID: "mega", AccountID: accountID,
		// MEGAcmd's scriptable interface exposes the account email but not a
		// durable opaque user handle. Hashing the normalized email is the least
		// invasive stable subject available through this official bridge.
		ProviderSubject: strings.ToLower(identity), Identity: identity, PlanName: plan,
		Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady,
		TotalBytes: total, UsedBytes: used, FreeBytes: total - used,
		Limits:      connector.Limits{UploadLimitNote: "Sujeto a cuota/transferencia de MEGA.", DownloadLimitNote: "Sujeto a cuota/transferencia de MEGA.", RateLimitNote: "VaultPool no elude límites de transferencia ni throttling de MEGA."},
		LastChecked: time.Now().UTC().Format(time.RFC3339), StatusNote: "Sesión verificada mediante MEGAcmd oficial.",
	}, nil
}

// parseFindPaths accepts MEGAcmd's scriptable find output. VaultPool only ever
// consumes entries below its own reserved root and rejects control characters.
func parseFindPaths(out []byte, root, prefix, suffix string) []string {
	var result []string
	seen := map[string]bool{}
	sc := bufio.NewScanner(strings.NewReader(string(out)))
	for sc.Scan() {
		p := strings.TrimSpace(sc.Text())
		if p == "" || !strings.HasPrefix(p, root+"/") || strings.ContainsAny(p, "\r\n\x00") {
			continue
		}
		name := filepath.Base(filepath.ToSlash(p))
		if !strings.HasPrefix(name, prefix) || !strings.HasSuffix(name, suffix) || seen[p] {
			continue
		}
		seen[p] = true
		result = append(result, p)
	}
	return result
}
