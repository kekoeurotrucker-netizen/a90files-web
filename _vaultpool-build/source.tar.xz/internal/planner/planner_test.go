package planner

import "testing"

func domains(n int, free int64, maxObject int64) []Target {
	out := make([]Target, 0, n)
	for i := 0; i < n; i++ {
		id := string(rune('A' + i))
		out = append(out, Target{ID: "account-" + id, FailureDomain: "provider-" + id, FreeBytes: free, MaxObjectBytes: maxObject, Enabled: true})
	}
	return out
}

func TestSixProvidersChoosesFourPlusTwo(t *testing.T) {
	p, err := Build(1000, domains(6, 10_000, 0), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 4 || p.ParityShards != 2 || p.TotalShards != 6 {
		t.Fatalf("got %d+%d=%d want 4+2=6", p.DataShards, p.ParityShards, p.TotalShards)
	}
	if p.FailureDomainsUsed != 6 || p.MaxShardsInOneFailureDomain != 1 || p.ProviderFailureMargin != 1 {
		t.Fatalf("unexpected failure-domain result: %+v", p)
	}
}

func TestFiveProvidersChoosesSixPlusThree(t *testing.T) {
	p, err := Build(6000, domains(5, 100_000, 0), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 6 || p.ParityShards != 3 || p.TotalShards != 9 {
		t.Fatalf("got %d+%d=%d want 6+3=9", p.DataShards, p.ParityShards, p.TotalShards)
	}
	if p.FailureDomainsUsed != 5 || p.MaxShardsInOneFailureDomain != 2 || p.ProviderFailureMargin != 1 {
		t.Fatalf("unexpected failure-domain result: %+v", p)
	}
}

func TestFourProvidersChoosesEightPlusFour(t *testing.T) {
	p, err := Build(8000, domains(4, 100_000, 0), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 8 || p.ParityShards != 4 || p.TotalShards != 12 {
		t.Fatalf("got %d+%d=%d want 8+4=12", p.DataShards, p.ParityShards, p.TotalShards)
	}
	if p.FailureDomainsUsed != 4 || p.MaxShardsInOneFailureDomain != 3 || p.ProviderFailureMargin != 1 {
		t.Fatalf("unexpected failure-domain result: %+v", p)
	}
}

func TestTwoProvidersUseFullMirror(t *testing.T) {
	p, err := Build(1000, domains(2, 100_000, 0), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 1 || p.ParityShards != 1 || p.TotalShards != 2 {
		t.Fatalf("got %d+%d=%d want 1+1=2", p.DataShards, p.ParityShards, p.TotalShards)
	}
	if p.ProviderFailureMargin != 0 || ModeForGeometry(p.DataShards, p.ParityShards) != ModeMirror2 {
		t.Fatalf("unexpected mirror safety result: %+v", p)
	}
}

func TestThreeProvidersUseTripleReplica(t *testing.T) {
	p, err := Build(1000, domains(3, 100_000, 0), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 1 || p.ParityShards != 2 || p.TotalShards != 3 {
		t.Fatalf("got %d+%d=%d want 1+2=3", p.DataShards, p.ParityShards, p.TotalShards)
	}
	if p.ProviderFailureMargin != 1 || ModeForGeometry(p.DataShards, p.ParityShards) != ModeTripleReplica {
		t.Fatalf("unexpected triple-replica safety result: %+v", p)
	}
}

func TestSmallThirdProviderCannotBreakExistingMirror(t *testing.T) {
	targets := domains(3, 10_000, 0)
	targets[2].FreeBytes = 100
	p, err := Build(1000, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 1 || p.ParityShards != 1 {
		t.Fatalf("expected mirror fallback, got %+v", p)
	}
}

func TestMultipleAccountsSameProviderDoNotCountAsIndependent(t *testing.T) {
	targets := []Target{
		{ID: "mega-1", FailureDomain: "mega", FreeBytes: 10_000, Enabled: true},
		{ID: "mega-2", FailureDomain: "mega", FreeBytes: 10_000, Enabled: true},
		{ID: "drive-1", FailureDomain: "google-drive", FreeBytes: 10_000, Enabled: true},
		{ID: "onedrive-1", FailureDomain: "onedrive", FreeBytes: 10_000, Enabled: true},
	}
	p, err := Build(1000, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.FailureDomainsUsed != 3 || p.DataShards != 1 || p.ParityShards != 2 {
		t.Fatalf("two MEGA accounts must remain one domain; got %+v", p)
	}
}

func TestObjectLimitForcesSmallerShardsAndMoreParts(t *testing.T) {
	p, err := Build(1000, domains(6, 100_000, 200), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	// 4+2 would make 250-byte shards, which violate the 200-byte object cap.
	// 6+3 makes 167-byte shards and preserves the configured safety target.
	if p.DataShards != 6 || p.ParityShards != 3 || p.ShardBytes > 200 {
		t.Fatalf("unexpected object-limit plan: %+v", p)
	}
}

func TestFreeCapacityRespected(t *testing.T) {
	targets := domains(6, 10_000, 0)
	targets[0].FreeBytes = 100 // cannot hold a 250-byte shard in 4+2
	p, err := Build(1000, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	for _, x := range p.Placements {
		if x.TargetID == targets[0].ID {
			t.Fatalf("planner used target without enough free space: %+v", x)
		}
	}
	if p.TotalShards != 9 { // effectively only five usable providers -> 6+3
		t.Fatalf("total shards=%d want 9", p.TotalShards)
	}
}

func TestDisabledTargetIgnored(t *testing.T) {
	targets := domains(6, 10_000, 0)
	targets[0].Enabled = false
	p, err := Build(1000, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	for _, x := range p.Placements {
		if x.TargetID == targets[0].ID {
			t.Fatal("disabled target used")
		}
	}
}

func TestPlacePrefersFastDomainsWhenSafetyEquivalent(t *testing.T) {
	targets := []Target{
		{ID: "slow", FailureDomain: "slow", FreeBytes: 10_000, DownloadBytesPerSec: 10, Enabled: true},
		{ID: "fast-a", FailureDomain: "fast-a", FreeBytes: 10_000, DownloadBytesPerSec: 1000, Enabled: true},
		{ID: "fast-b", FailureDomain: "fast-b", FreeBytes: 10_000, DownloadBytesPerSec: 900, Enabled: true},
		{ID: "fast-c", FailureDomain: "fast-c", FreeBytes: 10_000, DownloadBytesPerSec: 800, Enabled: true},
	}
	placements, _, _, err := place(targets, 100, 1, 2, 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(placements) != 3 {
		t.Fatalf("placements=%d want 3", len(placements))
	}
	for _, p := range placements {
		if p.TargetID == "slow" {
			t.Fatalf("slow target used despite equally safe faster choices: %+v", placements)
		}
	}
}

func TestPlaceBatchBlockPrefersFastDomainsWhenSafetyEquivalent(t *testing.T) {
	targets := []Target{
		{ID: "slow", FailureDomain: "slow", FreeBytes: 10_000, DownloadBytesPerSec: 10, Enabled: true},
		{ID: "fast-a", FailureDomain: "fast-a", FreeBytes: 10_000, DownloadBytesPerSec: 1000, Enabled: true},
		{ID: "fast-b", FailureDomain: "fast-b", FreeBytes: 10_000, DownloadBytesPerSec: 900, Enabled: true},
		{ID: "fast-c", FailureDomain: "fast-c", FreeBytes: 10_000, DownloadBytesPerSec: 800, Enabled: true},
	}
	placements, _, _, err := placeBatchBlock(cloneMutableTargets(targets), 100, 1, 2, 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(placements) != 3 {
		t.Fatalf("placements=%d want 3", len(placements))
	}
	for _, p := range placements {
		if p.TargetID == "slow" {
			t.Fatalf("slow target used despite equally safe faster choices: %+v", placements)
		}
	}
}

func TestExtraAccountWithinSameDomainCanSupplyCapacityButNotSafety(t *testing.T) {
	targets := []Target{
		{ID: "mega-a", FailureDomain: "mega", FreeBytes: 200, Enabled: true},
		{ID: "mega-b", FailureDomain: "mega", FreeBytes: 200, Enabled: true},
		{ID: "drive", FailureDomain: "drive", FreeBytes: 1000, Enabled: true},
		{ID: "one", FailureDomain: "one", FreeBytes: 1000, Enabled: true},
		{ID: "box", FailureDomain: "box", FreeBytes: 1000, Enabled: true},
		{ID: "proton", FailureDomain: "proton", FreeBytes: 1000, Enabled: true},
		{ID: "pcloud", FailureDomain: "pcloud", FreeBytes: 1000, Enabled: true},
	}
	p, err := Build(1000, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.ProviderFailureMargin < 1 {
		t.Fatalf("provider margin=%d", p.ProviderFailureMargin)
	}
	// No matter which account is used, the MEGA domain itself must stay within
	// the same provider-level concentration limit.
	count := 0
	for _, x := range p.Placements {
		if x.FailureDomain == "mega" {
			count++
		}
	}
	if count > p.ParityShards-1 {
		t.Fatalf("MEGA domain concentrated %d shards", count)
	}
}

func TestBuildBatchReservesCapacityAcrossBlocks(t *testing.T) {
	targets := domains(6, 500, 0)
	p, err := BuildBatch([]int64{1000, 1000}, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 4 || p.ParityShards != 2 || p.TotalShards != 6 {
		t.Fatalf("got %d+%d=%d want 4+2=6", p.DataShards, p.ParityShards, p.TotalShards)
	}
	for _, t0 := range targets {
		if got := p.ReservedBytesByTarget[t0.ID]; got > t0.FreeBytes {
			t.Fatalf("target %s overbooked: reserved=%d free=%d", t0.ID, got, t0.FreeBytes)
		}
	}
}

func TestBuildBatchRejectsAggregateOverbooking(t *testing.T) {
	// Each provider can hold one 250-byte shard, so block 0 fits but block 1
	// cannot be placed. Planning must fail before any write occurs.
	targets := domains(6, 300, 0)
	if _, err := BuildBatch([]int64{1000, 1000}, targets, DefaultPolicy()); err == nil {
		t.Fatal("expected cumulative-capacity rejection")
	}
}

func TestBuildBatchCanUseMoreShardsToFitObjectLimit(t *testing.T) {
	p, err := BuildBatch([]int64{1000, 900}, domains(6, 10000, 200), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 6 || p.ParityShards != 3 {
		t.Fatalf("got %d+%d want 6+3", p.DataShards, p.ParityShards)
	}
	for _, b := range p.Blocks {
		if b.ShardBytes > 200 {
			t.Fatalf("block %d shard size %d exceeds object cap", b.BlockIndex, b.ShardBytes)
		}
	}
}

func TestBuildBatchSameProviderAccountsRemainOneFailureDomain(t *testing.T) {
	targets := []Target{
		{ID: "mega-a", FailureDomain: "mega", FreeBytes: 10000, Enabled: true},
		{ID: "mega-b", FailureDomain: "mega", FreeBytes: 10000, Enabled: true},
		{ID: "drive", FailureDomain: "drive", FreeBytes: 10000, Enabled: true},
		{ID: "one", FailureDomain: "one", FreeBytes: 10000, Enabled: true},
	}
	p, err := BuildBatch([]int64{1000, 1000}, targets, DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.FailureDomainsUsed != 3 || p.DataShards != 1 || p.ParityShards != 2 || p.MinProviderFailureMargin != 1 {
		t.Fatalf("same-provider accounts were counted independently: %+v", p)
	}
}

func TestBuildBatchTwoProvidersUsesMirrorAndRecordsZeroAdditionalMargin(t *testing.T) {
	p, err := BuildBatch([]int64{1000, 900}, domains(2, 10_000, 0), DefaultPolicy())
	if err != nil {
		t.Fatal(err)
	}
	if p.DataShards != 1 || p.ParityShards != 1 || p.MinProviderFailureMargin != 0 {
		t.Fatalf("unexpected 2-provider batch: %+v", p)
	}
}

func TestMaxLogicalCapacityReportsSafeCapacityNotPhysicalSum(t *testing.T) {
	if got := MaxLogicalCapacity(domains(2, 15_000, 0), DefaultPolicy()); got != 15_000 {
		t.Fatalf("two mirrored 15k accounts logical capacity=%d want 15000", got)
	}
	if got := MaxLogicalCapacity(domains(3, 15_000, 0), DefaultPolicy()); got != 15_000 {
		t.Fatalf("three equal replicas logical capacity=%d want 15000", got)
	}
	got := MaxLogicalCapacity(domains(4, 15_000, 0), DefaultPolicy())
	if got <= 40_000 || got >= 45_000 {
		t.Fatalf("four-provider adaptive logical capacity=%d, expected safe RS capacity between 40k and 45k", got)
	}
	if _, err := Build(got, domains(4, 15_000, 0), DefaultPolicy()); err != nil {
		t.Fatalf("reported logical capacity must be plannable: %v", err)
	}
	if _, err := Build(got+1, domains(4, 15_000, 0), DefaultPolicy()); err == nil {
		t.Fatalf("capacity boundary is not maximal: %d+1 was still plannable", got)
	}
}
