package planner

import (
	"errors"
	"fmt"
	"math"
	"sort"
)

// Target describes one authenticated storage account/destination. FailureDomain
// is the provider-level blast radius (e.g. all MEGA accounts share "mega").
// Multiple targets in one FailureDomain never count as independent protection.
type Target struct {
	ID                  string `json:"id"`
	FailureDomain       string `json:"failure_domain"`
	FreeBytes           int64  `json:"free_bytes"`
	MaxObjectBytes      int64  `json:"max_object_bytes,omitempty"` // 0 = unknown/unlimited for planning
	UploadBytesPerSec   int64  `json:"upload_bytes_per_sec,omitempty"`
	DownloadBytesPerSec int64  `json:"download_bytes_per_sec,omitempty"`
	Enabled             bool   `json:"enabled"`
}

type Policy struct {
	MinProviderFailureMargin int     `json:"min_provider_failure_margin"`
	MaxRedundancyRatio       float64 `json:"max_redundancy_ratio"` // parity/data, 0.5 = 50%
	MaxDataShards            int     `json:"max_data_shards"`
	MaxParityShards          int     `json:"max_parity_shards"`
}

func DefaultPolicy() Policy {
	return Policy{
		MinProviderFailureMargin: 1,
		MaxRedundancyRatio:       0.50,
		MaxDataShards:            64,
		MaxParityShards:          32,
	}
}

type Placement struct {
	ShardIndex    int    `json:"shard_index"`
	TargetID      string `json:"target_id"`
	FailureDomain string `json:"failure_domain"`
	Bytes         int64  `json:"bytes"`
}

type Plan struct {
	PayloadBytes                int64       `json:"payload_bytes"`
	DataShards                  int         `json:"data_shards"`
	ParityShards                int         `json:"parity_shards"`
	TotalShards                 int         `json:"total_shards"`
	ShardBytes                  int64       `json:"shard_bytes"`
	EncodedBytes                int64       `json:"encoded_bytes"`
	RedundancyRatio             float64     `json:"redundancy_ratio"`
	FailureDomainsUsed          int         `json:"failure_domains_used"`
	MaxShardsInOneFailureDomain int         `json:"max_shards_in_one_failure_domain"`
	ProviderFailureMargin       int         `json:"provider_failure_margin"`
	Placements                  []Placement `json:"placements"`
}

// BatchBlockPlan is the placement for one independently encoded block in a
// file. VaultPool plans all blocks before the first write so free capacity is
// reserved cumulatively instead of being accidentally overcommitted block by
// block.
type BatchBlockPlan struct {
	BlockIndex   int         `json:"block_index"`
	PayloadBytes int64       `json:"payload_bytes"`
	ShardBytes   int64       `json:"shard_bytes"`
	Placements   []Placement `json:"placements"`
}

// BatchPlan uses one Reed-Solomon layout for the whole file while allowing
// placement to vary by block. Keeping the erasure geometry file-wide keeps the
// recovery manifest simple, while capacity accounting remains exact per block.
type BatchPlan struct {
	DataShards               int              `json:"data_shards"`
	ParityShards             int              `json:"parity_shards"`
	TotalShards              int              `json:"total_shards"`
	TotalEncodedBytes        int64            `json:"total_encoded_bytes"`
	MinProviderFailureMargin int              `json:"min_provider_failure_margin"`
	FailureDomainsUsed       int              `json:"failure_domains_used"`
	Blocks                   []BatchBlockPlan `json:"blocks"`
	ReservedBytesByTarget    map[string]int64 `json:"reserved_bytes_by_target"`
}

// ProtectionMode names the user-facing safety strategy selected for a plan.
// It is intentionally derived from geometry rather than provider brand names.
type ProtectionMode string

const (
	ModeMirror2       ProtectionMode = "mirror-2x"
	ModeTripleReplica ProtectionMode = "triple-replica"
	ModeReedSolomon   ProtectionMode = "reed-solomon"
)

func ModeForGeometry(data, parity int) ProtectionMode {
	switch {
	case data == 1 && parity == 1:
		return ModeMirror2
	case data == 1 && parity == 2:
		return ModeTripleReplica
	default:
		return ModeReedSolomon
	}
}

func (p Policy) validate() error {
	if p.MinProviderFailureMargin < 0 {
		return errors.New("minimum provider failure margin cannot be negative")
	}
	if p.MaxRedundancyRatio <= 0 {
		return errors.New("maximum redundancy ratio must be > 0")
	}
	if p.MaxDataShards < 1 || p.MaxParityShards < 1 {
		return errors.New("maximum shard counts must be positive")
	}
	return nil
}

func normalizeTargets(in []Target) ([]Target, error) {
	out := make([]Target, 0, len(in))
	seen := map[string]bool{}
	for _, t := range in {
		if !t.Enabled {
			continue
		}
		if t.ID == "" || t.FailureDomain == "" {
			return nil, errors.New("target id and failure domain are required")
		}
		if seen[t.ID] {
			return nil, fmt.Errorf("duplicate target id %q", t.ID)
		}
		seen[t.ID] = true
		if t.FreeBytes <= 0 {
			continue
		}
		if t.MaxObjectBytes < 0 {
			return nil, fmt.Errorf("target %q has negative max object size", t.ID)
		}
		if t.UploadBytesPerSec < 0 || t.DownloadBytesPerSec < 0 {
			return nil, fmt.Errorf("target %q has negative transfer speed", t.ID)
		}
		out = append(out, t)
	}
	if len(out) == 0 {
		return nil, errors.New("no enabled targets with free capacity")
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].FailureDomain == out[j].FailureDomain {
			return out[i].ID < out[j].ID
		}
		return out[i].FailureDomain < out[j].FailureDomain
	})
	return out, nil
}

func independentDomains(targets []Target) int {
	seen := map[string]bool{}
	for _, t := range targets {
		if t.Enabled && t.FreeBytes > 0 {
			seen[t.FailureDomain] = true
		}
	}
	return len(seen)
}

type targetCapacity struct {
	target Target
	slots  int
	used   int
}

type domainCapacity struct {
	name    string
	targets []*targetCapacity
	slots   int
	used    int
	speed   int64
}

func targetSpeed(t Target) int64 {
	if t.DownloadBytesPerSec > 0 {
		return t.DownloadBytesPerSec
	}
	return t.UploadBytesPerSec
}

func slotsForTarget(t Target, shardBytes int64, totalShards int) int {
	if shardBytes <= 0 || t.FreeBytes < shardBytes {
		return 0
	}
	if t.MaxObjectBytes > 0 && shardBytes > t.MaxObjectBytes {
		return 0
	}
	s := t.FreeBytes / shardBytes
	if s > int64(totalShards) {
		s = int64(totalShards)
	}
	return int(s)
}

func buildDomains(targets []Target, shardBytes int64, totalShards, perDomainCap int) []*domainCapacity {
	byName := map[string]*domainCapacity{}
	for _, t := range targets {
		slots := slotsForTarget(t, shardBytes, totalShards)
		if slots == 0 {
			continue
		}
		d := byName[t.FailureDomain]
		if d == nil {
			d = &domainCapacity{name: t.FailureDomain}
			byName[t.FailureDomain] = d
		}
		tc := &targetCapacity{target: t, slots: slots}
		d.targets = append(d.targets, tc)
		d.slots += slots
		if speed := targetSpeed(t); speed > d.speed {
			d.speed = speed
		}
	}
	out := make([]*domainCapacity, 0, len(byName))
	for _, d := range byName {
		if d.slots > perDomainCap {
			d.slots = perDomainCap
		}
		sort.Slice(d.targets, func(i, j int) bool {
			si, sj := targetSpeed(d.targets[i].target), targetSpeed(d.targets[j].target)
			if si != sj {
				return si > sj
			}
			if d.targets[i].slots == d.targets[j].slots {
				return d.targets[i].target.ID < d.targets[j].target.ID
			}
			return d.targets[i].slots > d.targets[j].slots
		})
		out = append(out, d)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].name < out[j].name })
	return out
}

func totalDomainSlots(ds []*domainCapacity) int {
	n := 0
	for _, d := range ds {
		n += d.slots
	}
	return n
}

func chooseTarget(d *domainCapacity) *targetCapacity {
	var best *targetCapacity
	for _, t := range d.targets {
		if t.used >= t.slots {
			continue
		}
		speed, bestSpeed := targetSpeed(t.target), int64(-1)
		if best != nil {
			bestSpeed = targetSpeed(best.target)
		}
		if best == nil || speed > bestSpeed || (speed == bestSpeed && (t.slots-t.used) > (best.slots-best.used)) || (speed == bestSpeed && (t.slots-t.used) == (best.slots-best.used) && t.target.ID < best.target.ID) {
			best = t
		}
	}
	return best
}

// place maximizes provider diversity for a fixed shard count by filling the
// least-used failure domains first. It never exceeds the provider safety cap.
func place(targets []Target, shardBytes int64, data, parity, minMargin int) ([]Placement, int, int, error) {
	total := data + parity
	perDomainCap := parity - minMargin
	if perDomainCap < 1 {
		return nil, 0, 0, fmt.Errorf("parity=%d cannot preserve provider-failure margin=%d", parity, minMargin)
	}
	domains := buildDomains(targets, shardBytes, total, perDomainCap)
	if totalDomainSlots(domains) < total {
		return nil, 0, 0, errors.New("insufficient safe provider capacity")
	}

	placements := make([]Placement, 0, total)
	for si := 0; si < total; si++ {
		sort.SliceStable(domains, func(i, j int) bool {
			ai, aj := domains[i], domains[j]
			if ai.used == aj.used {
				remI, remJ := ai.slots-ai.used, aj.slots-aj.used
				if remI == remJ {
					if ai.speed != aj.speed {
						return ai.speed > aj.speed
					}
					return ai.name < aj.name
				}
				return remI > remJ
			}
			return ai.used < aj.used
		})
		var chosen *domainCapacity
		for _, d := range domains {
			if d.used < d.slots {
				chosen = d
				break
			}
		}
		if chosen == nil {
			return nil, 0, 0, errors.New("safe placement became impossible")
		}
		tc := chooseTarget(chosen)
		if tc == nil {
			return nil, 0, 0, fmt.Errorf("failure domain %q has no target capacity", chosen.name)
		}
		placements = append(placements, Placement{ShardIndex: si, TargetID: tc.target.ID, FailureDomain: chosen.name, Bytes: shardBytes})
		chosen.used++
		tc.used++
	}

	counts := map[string]int{}
	for _, p := range placements {
		counts[p.FailureDomain]++
	}
	maxInDomain := 0
	for _, n := range counts {
		if n > maxInDomain {
			maxInDomain = n
		}
	}
	providerMargin := parity - maxInDomain
	return placements, len(counts), maxInDomain, nilIf(providerMargin < minMargin, "planner produced unsafe provider margin")
}

func nilIf(b bool, msg string) error {
	if b {
		return errors.New(msg)
	}
	return nil
}

func ceilDiv(a int64, b int) int64 {
	q := a / int64(b)
	if a%int64(b) != 0 {
		q++
	}
	return q
}

func replicatedPlan(payloadBytes int64, targets []Target, data, parity, minMargin int) (Plan, error) {
	shardBytes := ceilDiv(payloadBytes, data)
	placements, domainsUsed, maxInDomain, err := place(targets, shardBytes, data, parity, minMargin)
	if err != nil {
		return Plan{}, err
	}
	total := data + parity
	return Plan{
		PayloadBytes:                payloadBytes,
		DataShards:                  data,
		ParityShards:                parity,
		TotalShards:                 total,
		ShardBytes:                  shardBytes,
		EncodedBytes:                shardBytes * int64(total),
		RedundancyRatio:             float64(parity) / float64(data),
		FailureDomainsUsed:          domainsUsed,
		MaxShardsInOneFailureDomain: maxInDomain,
		ProviderFailureMargin:       parity - maxInDomain,
		Placements:                  placements,
	}, nil
}

func buildAdaptive(payloadBytes int64, targets []Target, policy Policy) (Plan, error) {
	var best *Plan
	for data := 1; data <= policy.MaxDataShards; data++ {
		for parity := policy.MinProviderFailureMargin + 1; parity <= policy.MaxParityShards; parity++ {
			ratio := float64(parity) / float64(data)
			if ratio-policy.MaxRedundancyRatio > 1e-12 {
				continue
			}
			total := data + parity
			if best != nil && total > best.TotalShards {
				continue
			}
			shardBytes := ceilDiv(payloadBytes, data)
			placements, domainsUsed, maxInDomain, err := place(targets, shardBytes, data, parity, policy.MinProviderFailureMargin)
			if err != nil {
				continue
			}
			encoded := shardBytes * int64(total)
			p := Plan{
				PayloadBytes:                payloadBytes,
				DataShards:                  data,
				ParityShards:                parity,
				TotalShards:                 total,
				ShardBytes:                  shardBytes,
				EncodedBytes:                encoded,
				RedundancyRatio:             ratio,
				FailureDomainsUsed:          domainsUsed,
				MaxShardsInOneFailureDomain: maxInDomain,
				ProviderFailureMargin:       parity - maxInDomain,
				Placements:                  placements,
			}
			if best == nil || better(p, *best) {
				cp := p
				best = &cp
			}
		}
	}
	if best == nil {
		return Plan{}, errors.New("no adaptive Reed-Solomon plan")
	}
	return *best, nil
}

// Build searches candidate Reed-Solomon layouts and returns the one with the
// fewest total shards that meets all hard safety/capacity constraints. The
// redundancy ceiling prevents "few shards" from winning by wasting absurd
// amounts of storage. Ties prefer lower encoded bytes, then more independent
// failure domains.
func Build(payloadBytes int64, targets []Target, policy Policy) (Plan, error) {
	if payloadBytes <= 0 {
		return Plan{}, errors.New("payload bytes must be positive")
	}
	if err := policy.validate(); err != nil {
		return Plan{}, err
	}
	targets, err := normalizeTargets(targets)
	if err != nil {
		return Plan{}, err
	}

	domains := independentDomains(targets)
	if domains < 2 {
		return Plan{}, fmt.Errorf("no safe storage plan: at least two independent provider failure domains are required")
	}

	// Two providers are a deliberate 1+1 full mirror. It survives complete
	// loss of either provider, but we explicitly record zero *additional* shard
	// margin after that provider loss rather than pretending otherwise.
	if domains == 2 {
		if p, err := replicatedPlan(payloadBytes, targets, 1, 1, 0); err == nil {
			return p, nil
		}
		return Plan{}, fmt.Errorf("no safe 2-provider mirror plan: insufficient provider capacity")
	}

	// With exactly three independent providers, prefer a true triple replica
	// (1+2). If the newly added third provider is too small for a particular
	// file, fall back to a 1+1 mirror across any two domains so adding a provider
	// can never make a previously viable two-provider pool unusable.
	if domains == 3 {
		if p, err := replicatedPlan(payloadBytes, targets, 1, 2, 1); err == nil {
			return p, nil
		}
		if p, err := replicatedPlan(payloadBytes, targets, 1, 1, 0); err == nil {
			return p, nil
		}
		return Plan{}, fmt.Errorf("no safe 3-provider replication plan: insufficient provider capacity")
	}

	// Four or more independent providers use the efficient adaptive
	// Reed-Solomon policy. Replication fallbacks preserve monotonicity when an
	// extra provider is present but temporarily too constrained to participate.
	if p, err := buildAdaptive(payloadBytes, targets, policy); err == nil {
		return p, nil
	}
	if p, err := replicatedPlan(payloadBytes, targets, 1, 2, 1); err == nil {
		return p, nil
	}
	if p, err := replicatedPlan(payloadBytes, targets, 1, 1, 0); err == nil {
		return p, nil
	}
	return Plan{}, fmt.Errorf("no safe storage plan: add/reconnect independent providers, free capacity, reduce object-size pressure, or explicitly change the redundancy policy")
}

func better(a, b Plan) bool {
	if a.TotalShards != b.TotalShards {
		return a.TotalShards < b.TotalShards
	}
	if a.EncodedBytes != b.EncodedBytes {
		return a.EncodedBytes < b.EncodedBytes
	}
	if a.FailureDomainsUsed != b.FailureDomainsUsed {
		return a.FailureDomainsUsed > b.FailureDomainsUsed
	}
	if math.Abs(a.RedundancyRatio-b.RedundancyRatio) > 1e-12 {
		return a.RedundancyRatio < b.RedundancyRatio
	}
	if a.DataShards != b.DataShards {
		return a.DataShards < b.DataShards
	}
	return a.ParityShards < b.ParityShards
}

type mutableTarget struct {
	Target
	remaining int64
}

func cloneMutableTargets(targets []Target) []mutableTarget {
	out := make([]mutableTarget, len(targets))
	for i, t := range targets {
		out[i] = mutableTarget{Target: t, remaining: t.FreeBytes}
	}
	return out
}

// placeBatchBlock places one block while consuming byte capacity from the
// mutable target set. A provider/failure domain can hold at most
// parity-minMargin shards for this block, preserving the configured recovery
// margin after complete loss of that provider.
func placeBatchBlock(targets []mutableTarget, shardBytes int64, data, parity, minMargin int) ([]Placement, int, int, error) {
	total := data + parity
	perDomainCap := parity - minMargin
	if perDomainCap < 1 {
		return nil, 0, 0, fmt.Errorf("parity=%d cannot preserve provider-failure margin=%d", parity, minMargin)
	}

	type domainState struct {
		name string
		used int
	}
	domains := map[string]*domainState{}
	for i := range targets {
		t := &targets[i]
		if !t.Enabled || t.remaining < shardBytes || (t.MaxObjectBytes > 0 && shardBytes > t.MaxObjectBytes) {
			continue
		}
		if domains[t.FailureDomain] == nil {
			domains[t.FailureDomain] = &domainState{name: t.FailureDomain}
		}
	}
	if len(domains) == 0 {
		return nil, 0, 0, errors.New("no target can hold this shard size")
	}

	placements := make([]Placement, 0, total)
	for si := 0; si < total; si++ {
		bestTarget := -1
		bestDomainUsed := int(^uint(0) >> 1)
		bestSpeed := int64(-1)
		bestRemaining := int64(-1)
		bestID := ""
		for i := range targets {
			t := &targets[i]
			if !t.Enabled || t.remaining < shardBytes || (t.MaxObjectBytes > 0 && shardBytes > t.MaxObjectBytes) {
				continue
			}
			d := domains[t.FailureDomain]
			if d == nil || d.used >= perDomainCap {
				continue
			}
			// Prefer the least-used failure domain to preserve provider diversity.
			// Within equally safe choices, favor faster accounts before capacity.
			speed := targetSpeed(t.Target)
			if bestTarget == -1 || d.used < bestDomainUsed ||
				(d.used == bestDomainUsed && speed > bestSpeed) ||
				(d.used == bestDomainUsed && speed == bestSpeed && t.remaining > bestRemaining) ||
				(d.used == bestDomainUsed && speed == bestSpeed && t.remaining == bestRemaining && t.ID < bestID) {
				bestTarget = i
				bestDomainUsed = d.used
				bestSpeed = speed
				bestRemaining = t.remaining
				bestID = t.ID
			}
		}
		if bestTarget < 0 {
			return nil, 0, 0, errors.New("insufficient cumulative safe provider capacity")
		}
		t := &targets[bestTarget]
		d := domains[t.FailureDomain]
		placements = append(placements, Placement{ShardIndex: si, TargetID: t.ID, FailureDomain: t.FailureDomain, Bytes: shardBytes})
		t.remaining -= shardBytes
		d.used++
	}

	maxInDomain := 0
	usedDomains := 0
	for _, d := range domains {
		if d.used == 0 {
			continue
		}
		usedDomains++
		if d.used > maxInDomain {
			maxInDomain = d.used
		}
	}
	if parity-maxInDomain < minMargin {
		return nil, 0, 0, errors.New("batch placement violated provider-failure margin")
	}
	return placements, usedDomains, maxInDomain, nil
}

func buildBatchGeometry(payloadBytes []int64, targets []Target, data, parity, minMargin int) (BatchPlan, error) {
	mutable := cloneMutableTargets(targets)
	candidate := BatchPlan{
		DataShards:               data,
		ParityShards:             parity,
		TotalShards:              data + parity,
		MinProviderFailureMargin: minMargin,
		ReservedBytesByTarget:    map[string]int64{},
	}
	minDomains := int(^uint(0) >> 1)
	for bi, payload := range payloadBytes {
		shardBytes := ceilDiv(payload, data)
		placements, domainsUsed, _, err := placeBatchBlock(mutable, shardBytes, data, parity, minMargin)
		if err != nil {
			return BatchPlan{}, err
		}
		if domainsUsed < minDomains {
			minDomains = domainsUsed
		}
		candidate.TotalEncodedBytes += shardBytes * int64(candidate.TotalShards)
		candidate.Blocks = append(candidate.Blocks, BatchBlockPlan{BlockIndex: bi, PayloadBytes: payload, ShardBytes: shardBytes, Placements: placements})
		for _, p := range placements {
			candidate.ReservedBytesByTarget[p.TargetID] += p.Bytes
		}
	}
	candidate.FailureDomainsUsed = minDomains
	return candidate, nil
}

func buildAdaptiveBatch(payloadBytes []int64, normalized []Target, policy Policy) (BatchPlan, error) {
	var best *BatchPlan
	for data := 1; data <= policy.MaxDataShards; data++ {
		for parity := policy.MinProviderFailureMargin + 1; parity <= policy.MaxParityShards; parity++ {
			ratio := float64(parity) / float64(data)
			if ratio-policy.MaxRedundancyRatio > 1e-12 {
				continue
			}
			total := data + parity
			if best != nil && total > best.TotalShards {
				continue
			}

			candidate, err := buildBatchGeometry(payloadBytes, normalized, data, parity, policy.MinProviderFailureMargin)
			if err != nil {
				continue
			}
			if best == nil || candidate.TotalShards < best.TotalShards ||
				(candidate.TotalShards == best.TotalShards && candidate.TotalEncodedBytes < best.TotalEncodedBytes) ||
				(candidate.TotalShards == best.TotalShards && candidate.TotalEncodedBytes == best.TotalEncodedBytes && candidate.FailureDomainsUsed > best.FailureDomainsUsed) {
				cp := candidate
				best = &cp
			}
		}
	}
	if best == nil {
		return BatchPlan{}, errors.New("no adaptive Reed-Solomon batch plan")
	}
	return *best, nil
}

// BuildBatch plans every independently encoded block before any provider write.
// Capacity is consumed across the whole batch, preventing a plan that is safe
// for block 0 from silently overbooking the same account for later blocks.
func BuildBatch(payloadBytes []int64, targets []Target, policy Policy) (BatchPlan, error) {
	if len(payloadBytes) == 0 {
		return BatchPlan{}, errors.New("at least one block payload is required")
	}
	for i, n := range payloadBytes {
		if n <= 0 {
			return BatchPlan{}, fmt.Errorf("block %d payload bytes must be positive", i)
		}
	}
	if err := policy.validate(); err != nil {
		return BatchPlan{}, err
	}
	normalized, err := normalizeTargets(targets)
	if err != nil {
		return BatchPlan{}, err
	}

	domains := independentDomains(normalized)
	if domains < 2 {
		return BatchPlan{}, fmt.Errorf("no safe batch storage plan: at least two independent provider failure domains are required")
	}
	if domains == 2 {
		if p, err := buildBatchGeometry(payloadBytes, normalized, 1, 1, 0); err == nil {
			return p, nil
		}
		return BatchPlan{}, fmt.Errorf("no safe 2-provider mirror batch plan: insufficient provider capacity")
	}
	if domains == 3 {
		if p, err := buildBatchGeometry(payloadBytes, normalized, 1, 2, 1); err == nil {
			return p, nil
		}
		if p, err := buildBatchGeometry(payloadBytes, normalized, 1, 1, 0); err == nil {
			return p, nil
		}
		return BatchPlan{}, fmt.Errorf("no safe 3-provider replication batch plan: insufficient provider capacity")
	}
	if p, err := buildAdaptiveBatch(payloadBytes, normalized, policy); err == nil {
		return p, nil
	}
	if p, err := buildBatchGeometry(payloadBytes, normalized, 1, 2, 1); err == nil {
		return p, nil
	}
	if p, err := buildBatchGeometry(payloadBytes, normalized, 1, 1, 0); err == nil {
		return p, nil
	}
	return BatchPlan{}, fmt.Errorf("no safe batch storage plan: add/reconnect independent providers, free capacity, reduce object-size pressure, or explicitly change the redundancy policy")
}

// MaxLogicalCapacity returns the largest logical payload that can be protected
// with the same safety rules as Build. It is intended for user-facing capacity
// reporting (for example the read-only Windows virtual drive), so callers may
// aggregate multiple accounts of one provider into a single Target first.
func MaxLogicalCapacity(targets []Target, policy Policy) int64 {
	if err := policy.validate(); err != nil {
		return 0
	}
	var upper int64
	for _, t := range targets {
		if t.Enabled && t.FreeBytes > 0 {
			if math.MaxInt64-upper < t.FreeBytes {
				upper = math.MaxInt64
				break
			}
			upper += t.FreeBytes
		}
	}
	if upper <= 0 {
		return 0
	}
	lo, hi := int64(0), upper
	for lo < hi {
		mid := lo + (hi-lo+1)/2
		if _, err := Build(mid, targets, policy); err == nil {
			lo = mid
		} else {
			hi = mid - 1
		}
	}
	return lo
}
