package storage

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

type fakeStore struct{ id string }

func (f fakeStore) ProviderID() string { return f.id }
func (f fakeStore) PutVerified(context.Context, string, string, []byte, string) (remoteobject.Object, error) {
	return remoteobject.Object{}, nil
}
func (f fakeStore) GetVerified(context.Context, string, string, int64, string) ([]byte, error) {
	return nil, nil
}
func (f fakeStore) Delete(context.Context, string, string) error { return nil }

func TestStableTargetIDSurvivesLocalAccountIDChanges(t *testing.T) {
	a, err := NewCloudTarget("google-drive", "acct-old", "permission-123", fakeStore{"google-drive"}, 100, 0)
	if err != nil {
		t.Fatal(err)
	}
	b, err := NewCloudTarget("google-drive", "acct-new", "permission-123", fakeStore{"google-drive"}, 100, 0)
	if err != nil {
		t.Fatal(err)
	}
	if a.ID != b.ID {
		t.Fatalf("stable id changed: %q != %q", a.ID, b.ID)
	}
	c, _ := NewCloudTarget("google-drive", "acct-new", "different", fakeStore{"google-drive"}, 100, 0)
	if c.ID == a.ID {
		t.Fatal("different provider subjects aliased")
	}
}

func TestLocalTargetsUseUnifiedVerifiedStoreContract(t *testing.T) {
	pool := t.TempDir()
	if err := os.Mkdir(filepath.Join(pool, "p1"), 0700); err != nil {
		t.Fatal(err)
	}
	ts, err := LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	data := []byte("vaultpool")
	h := remoteobject.SHA256Bytes(data)
	obj, err := ts[0].PutVerified(context.Background(), "objects/x", data, h)
	if err != nil {
		t.Fatal(err)
	}
	got, err := ts[0].GetVerified(context.Background(), obj.ID, int64(len(data)), h)
	if err != nil || string(got) != string(data) {
		t.Fatalf("get=%q err=%v", got, err)
	}
}
