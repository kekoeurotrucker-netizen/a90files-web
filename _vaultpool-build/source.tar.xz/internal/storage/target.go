package storage

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"sort"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/planner"
	"github.com/vaultpool-project/vaultpool/internal/provider"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
)

// Target is one authenticated storage account. ID must remain stable across a
// VaultPool reinstall; AccountID is the local credential-vault lookup key and is
// deliberately allowed to change after reauthentication.
type Target struct {
	ID                  string
	FailureDomain       string
	AccountID           string
	ProviderSubject     string
	Store               remoteobject.Store
	FreeBytes           int64
	MaxObjectBytes      int64
	UploadBytesPerSec   int64
	DownloadBytesPerSec int64
	Enabled             bool
}

func StableTargetID(providerID, providerSubject string) (string, error) {
	return connector.StableTargetID(providerID, providerSubject)
}

func NewCloudTarget(providerID, accountID, providerSubject string, store remoteobject.Store, freeBytes, maxObjectBytes int64) (Target, error) {
	if store == nil {
		return Target{}, errors.New("remote store required")
	}
	if store.ProviderID() != providerID {
		return Target{}, errors.New("remote store/provider mismatch")
	}
	id, err := StableTargetID(providerID, providerSubject)
	if err != nil {
		return Target{}, err
	}
	t := Target{ID: id, FailureDomain: providerID, AccountID: accountID, ProviderSubject: providerSubject, Store: store, FreeBytes: freeBytes, MaxObjectBytes: maxObjectBytes, Enabled: true}
	return t, t.Validate()
}

func (t Target) Validate() error {
	if strings.TrimSpace(t.ID) == "" || strings.TrimSpace(t.FailureDomain) == "" || strings.TrimSpace(t.AccountID) == "" || t.Store == nil {
		return errors.New("storage target missing id/failure-domain/account/store")
	}
	if t.FreeBytes < 0 || t.MaxObjectBytes < 0 || t.UploadBytesPerSec < 0 || t.DownloadBytesPerSec < 0 {
		return errors.New("negative target capacity/limit/speed")
	}
	return nil
}

func ValidateTargets(targets []Target) error {
	if len(targets) == 0 {
		return errors.New("no storage targets")
	}
	seen := map[string]bool{}
	for _, t := range targets {
		if err := t.Validate(); err != nil {
			return fmt.Errorf("target %q: %w", t.ID, err)
		}
		if seen[t.ID] {
			return fmt.Errorf("duplicate stable target id %q", t.ID)
		}
		seen[t.ID] = true
	}
	return nil
}

func Sorted(targets []Target) []Target {
	out := append([]Target(nil), targets...)
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

func ByID(targets []Target) map[string]Target {
	out := make(map[string]Target, len(targets))
	for _, t := range targets {
		out[t.ID] = t
	}
	return out
}

func PlannerTargets(targets []Target) []planner.Target {
	out := make([]planner.Target, 0, len(targets))
	for _, t := range targets {
		out = append(out, planner.Target{ID: t.ID, FailureDomain: t.FailureDomain, FreeBytes: t.FreeBytes, MaxObjectBytes: t.MaxObjectBytes, UploadBytesPerSec: t.UploadBytesPerSec, DownloadBytesPerSec: t.DownloadBytesPerSec, Enabled: t.Enabled})
	}
	return out
}

func (t Target) PutVerified(ctx context.Context, key string, data []byte, expectedSHA string) (remoteobject.Object, error) {
	return t.Store.PutVerified(ctx, t.AccountID, key, data, expectedSHA)
}
func (t Target) GetVerified(ctx context.Context, locator string, expectedSize int64, expectedSHA string) ([]byte, error) {
	return t.Store.GetVerified(ctx, t.AccountID, locator, expectedSize, expectedSHA)
}
func (t Target) Delete(ctx context.Context, locator string) error {
	return t.Store.Delete(ctx, t.AccountID, locator)
}

func (t Target) ManifestRecoveryStore() (remoteobject.ManifestRecoveryStore, bool) {
	r, ok := t.Store.(remoteobject.ManifestRecoveryStore)
	return r, ok
}

func (t Target) RecoveryRecordStore() (remoteobject.RecoveryRecordStore, bool) {
	r, ok := t.Store.(remoteobject.RecoveryRecordStore)
	return r, ok
}

// LocalStore adapts the destructive-test filesystem provider to the same
// contract used by real cloud stores.
type LocalStore struct {
	ID    string
	Local provider.Local
}

func (s *LocalStore) ProviderID() string { return s.ID }
func (s *LocalStore) PutVerified(_ context.Context, accountID, key string, data []byte, expected string) (remoteobject.Object, error) {
	if err := s.Local.PutVerified(key, data, expected); err != nil {
		return remoteobject.Object{}, err
	}
	return remoteobject.Object{ProviderID: s.ID, AccountID: accountID, ID: key, Key: key, Name: key, Size: int64(len(data)), SHA256: expected}, nil
}
func (s *LocalStore) GetVerified(_ context.Context, _ string, locator string, expectedSize int64, expectedSHA string) ([]byte, error) {
	b, err := s.Local.Get(locator)
	if err != nil {
		return nil, err
	}
	if int64(len(b)) != expectedSize {
		return nil, &remoteobject.IntegrityError{Reason: fmt.Sprintf("local target size mismatch: got %d want %d", len(b), expectedSize)}
	}
	if got := remoteobject.SHA256Bytes(b); !strings.EqualFold(got, expectedSHA) {
		return nil, &remoteobject.IntegrityError{Reason: fmt.Sprintf("local target SHA-256 mismatch: got %s want %s", got, expectedSHA)}
	}
	return b, nil
}
func (s *LocalStore) Delete(_ context.Context, _ string, locator string) error {
	return s.Local.Delete(locator)
}

func (s *LocalStore) ListManifestCandidates(_ context.Context, _ string) ([]remoteobject.ManifestCandidate, error) {
	objects, err := s.Local.List("metadata/manifests")
	if err != nil {
		return nil, err
	}
	out := make([]remoteobject.ManifestCandidate, 0, len(objects))
	for _, object := range objects {
		b, err := s.Local.Get(object)
		if err != nil || len(b) == 0 {
			continue
		}
		fileID := ""
		parts := strings.Split(object, "/")
		if len(parts) >= 3 && len(parts[2]) == 32 {
			if _, err := hex.DecodeString(parts[2]); err == nil {
				fileID = strings.ToLower(parts[2])
			}
		}
		out = append(out, remoteobject.ManifestCandidate{Locator: object, RecoveryID: fileID, Size: int64(len(b))})
	}
	return out, nil
}

func (s *LocalStore) ReadManifestCandidate(_ context.Context, _ string, locator string, maxBytes int64) ([]byte, error) {
	if !strings.HasPrefix(locator, "metadata/manifests/") {
		return nil, errors.New("local recovery object is not in manifest namespace")
	}
	b, err := s.Local.Get(locator)
	if err != nil {
		return nil, err
	}
	if maxBytes <= 0 || int64(len(b)) > maxBytes {
		return nil, errors.New("local recovery manifest exceeds size cap")
	}
	return b, nil
}

func (s *LocalStore) ListRecoveryRecordCandidates(_ context.Context, _ string) ([]remoteobject.RecoveryRecordCandidate, error) {
	objects, err := s.Local.List("metadata/recovery/filekeys")
	if err != nil {
		return nil, err
	}
	out := make([]remoteobject.RecoveryRecordCandidate, 0, len(objects))
	for _, object := range objects {
		parts := strings.Split(object, "/")
		if len(parts) != 4 || parts[0] != "metadata" || parts[1] != "recovery" || parts[2] != "filekeys" || !strings.HasSuffix(parts[3], ".vprk") {
			continue
		}
		id := strings.TrimSuffix(parts[3], ".vprk")
		if len(id) != 32 {
			continue
		}
		b, err := s.Local.Get(object)
		if err != nil || len(b) == 0 {
			continue
		}
		out = append(out, remoteobject.RecoveryRecordCandidate{Locator: object, RecoveryID: id, Size: int64(len(b))})
	}
	return out, nil
}

func (s *LocalStore) ReadRecoveryRecordCandidate(_ context.Context, _ string, locator string, maxBytes int64) ([]byte, error) {
	if !strings.HasPrefix(locator, "metadata/recovery/filekeys/") || !strings.HasSuffix(locator, ".vprk") {
		return nil, errors.New("local object is not in recovery-record namespace")
	}
	b, err := s.Local.Get(locator)
	if err != nil {
		return nil, err
	}
	if maxBytes <= 0 || int64(len(b)) > maxBytes {
		return nil, errors.New("local recovery record exceeds size cap")
	}
	return b, nil
}

func LocalTargets(pool string) ([]Target, error) {
	ps, err := provider.Discover(pool)
	if err != nil {
		return nil, err
	}
	const mockFree = int64(math.MaxInt64 / 1024)
	out := make([]Target, 0, len(ps))
	for _, p := range ps {
		store := &LocalStore{ID: p.Name, Local: p}
		out = append(out, Target{ID: p.Name, FailureDomain: p.Name, AccountID: p.Name, ProviderSubject: p.Name, Store: store, FreeBytes: mockFree, Enabled: true})
	}
	return Sorted(out), ValidateTargets(out)
}
