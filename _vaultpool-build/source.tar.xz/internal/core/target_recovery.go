package core

import (
	"bytes"
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"strings"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type RecoveryIssue struct {
	TargetID string `json:"target_id"`
	Stage    string `json:"stage"`
	Message  string `json:"message"`
}

type TargetRecoveryScan struct {
	Candidates []RecoveryCandidate `json:"candidates"`
	Issues     []RecoveryIssue     `json:"issues"`
}

// DiscoverRecoverableTargetManifests scans only the manifest-recovery surface
// exposed by each target. Individual provider/list/read failures are recorded as
// issues and do not stop recovery through independent providers. Authenticated
// same-generation conflicts are fatal because VaultPool must never guess which
// signed metadata is authoritative.
func (e *Engine) DiscoverRecoverableTargetManifests(ctx context.Context, key []byte, targets []storage.Target) (TargetRecoveryScan, error) {
	var result TargetRecoveryScan
	if err := storage.ValidateTargets(targets); err != nil {
		return result, err
	}
	targets = storage.Sorted(targets)
	best := map[string]*RecoveryCandidate{}
	canonical := map[string][]byte{}
	replicaTargets := map[string]map[string]bool{}

	for _, t := range targets {
		if err := ctx.Err(); err != nil {
			return result, err
		}
		if !t.Enabled {
			continue
		}
		rs, ok := t.ManifestRecoveryStore()
		if !ok {
			result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "capability", Message: "el conector no ofrece recuperación de manifiestos"})
			continue
		}
		items, err := rs.ListManifestCandidates(ctx, t.AccountID)
		if err != nil {
			result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "list", Message: err.Error()})
			continue
		}
		for _, item := range items {
			if err := ctx.Err(); err != nil {
				return result, err
			}
			if item.Locator == "" || item.Size <= 0 || item.Size > manifest.MaxSealedBytes {
				result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "candidate", Message: "réplica de manifiesto con tamaño/identificador inválido ignorada"})
				continue
			}
			sealed, err := rs.ReadManifestCandidate(ctx, t.AccountID, item.Locator, manifest.MaxSealedBytes)
			if err != nil {
				result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "read", Message: err.Error()})
				continue
			}
			m, err := manifest.Open(sealed, key)
			if err != nil {
				// Do not expose cryptographic detail in ordinary recovery output.
				result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "authenticate", Message: "réplica corrupta o no autenticada ignorada"})
				continue
			}
			canon, err := json.Marshal(m)
			if err != nil {
				return result, err
			}
			current := best[m.FileID]
			if current == nil || m.Generation > current.Generation {
				best[m.FileID] = &RecoveryCandidate{FileID: m.FileID, FileName: m.FileName, Generation: m.Generation, Replicas: 1, sealed: append([]byte(nil), sealed...), manifest: m}
				canonical[m.FileID] = canon
				replicaTargets[m.FileID] = map[string]bool{t.ID: true}
				continue
			}
			if m.Generation < current.Generation {
				continue
			}
			if !bytes.Equal(canon, canonical[m.FileID]) {
				return result, fmt.Errorf("conflicting authenticated manifest replicas for file %s at generation %d", m.FileID, m.Generation)
			}
			if !replicaTargets[m.FileID][t.ID] {
				replicaTargets[m.FileID][t.ID] = true
				current.Replicas++
			}
		}
	}

	result.Candidates = make([]RecoveryCandidate, 0, len(best))
	for _, c := range best {
		result.Candidates = append(result.Candidates, *c)
	}
	sort.Slice(result.Candidates, func(i, j int) bool {
		if result.Candidates[i].FileName == result.Candidates[j].FileName {
			return result.Candidates[i].FileID < result.Candidates[j].FileID
		}
		return result.Candidates[i].FileName < result.Candidates[j].FileName
	})
	return result, nil
}

// RecoverTargetManifest restores one selected file's newest unambiguous
// authenticated remote manifest to local state. With more than one recoverable
// file the caller must choose a FileID explicitly.
func (e *Engine) RecoverTargetManifest(ctx context.Context, out string, key []byte, targets []storage.Target, fileID string) (*manifest.Manifest, TargetRecoveryScan, error) {
	scan, err := e.DiscoverRecoverableTargetManifests(ctx, key, targets)
	if err != nil {
		return nil, scan, err
	}
	if len(scan.Candidates) == 0 {
		return nil, scan, errors.New("no authenticated remote manifest replica found")
	}
	var chosen *RecoveryCandidate
	if fileID == "" {
		if len(scan.Candidates) != 1 {
			return nil, scan, fmt.Errorf("%d recoverable files found; select an explicit file ID", len(scan.Candidates))
		}
		chosen = &scan.Candidates[0]
	} else {
		for i := range scan.Candidates {
			if scan.Candidates[i].FileID == fileID {
				chosen = &scan.Candidates[i]
				break
			}
		}
		if chosen == nil {
			return nil, scan, fmt.Errorf("recoverable file ID %q not found", fileID)
		}
	}
	if err := manifest.WriteAtomicBytes(out, chosen.sealed); err != nil {
		return nil, scan, err
	}
	return chosen.manifest, scan, nil
}

// DiscoverRecoverableTargetManifestsByKeys is the reinstall/catalog-rebuild
// variant of manifest discovery. Each VaultPool file has its own random data
// key, so recovery must never try to decrypt every manifest with one global
// key. Provider metadata may expose the opaque FileID as a routing hint; the
// manifest still has to authenticate with that file's recovered key before any
// metadata is trusted. Older candidates without a routing hint are supported by
// a bounded fallback over the locally recovered keys.
func (e *Engine) DiscoverRecoverableTargetManifestsByKeys(ctx context.Context, keys map[string][]byte, targets []storage.Target) (TargetRecoveryScan, error) {
	var result TargetRecoveryScan
	if err := storage.ValidateTargets(targets); err != nil {
		return result, err
	}
	if len(keys) == 0 {
		return result, errors.New("no recovered file keys available for manifest discovery")
	}
	validKeys := make(map[string][]byte, len(keys))
	keyIDs := make([]string, 0, len(keys))
	for id, key := range keys {
		id = strings.ToLower(strings.TrimSpace(id))
		if len(id) != 32 {
			continue
		}
		if _, err := hex.DecodeString(id); err != nil || len(key) != cryptokit.KeySize {
			continue
		}
		validKeys[id] = key
		keyIDs = append(keyIDs, id)
	}
	if len(validKeys) == 0 {
		return result, errors.New("no valid recovered file keys available for manifest discovery")
	}
	sort.Strings(keyIDs)

	targets = storage.Sorted(targets)
	best := map[string]*RecoveryCandidate{}
	canonical := map[string][]byte{}
	replicaTargets := map[string]map[string]bool{}

	for _, t := range targets {
		if err := ctx.Err(); err != nil {
			return result, err
		}
		if !t.Enabled {
			continue
		}
		rs, ok := t.ManifestRecoveryStore()
		if !ok {
			result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "capability", Message: "el conector no ofrece recuperación de manifiestos"})
			continue
		}
		items, err := rs.ListManifestCandidates(ctx, t.AccountID)
		if err != nil {
			result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "list", Message: err.Error()})
			continue
		}
		for _, item := range items {
			if err := ctx.Err(); err != nil {
				return result, err
			}
			if item.Locator == "" || item.Size <= 0 || item.Size > manifest.MaxSealedBytes {
				result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "candidate", Message: "réplica de manifiesto con tamaño/identificador inválido ignorada"})
				continue
			}
			sealed, err := rs.ReadManifestCandidate(ctx, t.AccountID, item.Locator, manifest.MaxSealedBytes)
			if err != nil {
				result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "read", Message: err.Error()})
				continue
			}

			routedID := strings.ToLower(strings.TrimSpace(item.RecoveryID))
			var opened *manifest.Manifest
			if key, ok := validKeys[routedID]; ok {
				m, openErr := manifest.Open(sealed, key)
				if openErr == nil && strings.EqualFold(m.FileID, routedID) {
					opened = m
				}
			} else if routedID == "" {
				// Backward-compatible recovery for pre-routing-hint replicas. This
				// is intentionally limited to locally authenticated recovery keys.
				for _, id := range keyIDs {
					m, openErr := manifest.Open(sealed, validKeys[id])
					if openErr == nil && strings.EqualFold(m.FileID, id) {
						opened = m
						break
					}
				}
			}
			if opened == nil {
				result.Issues = append(result.Issues, RecoveryIssue{TargetID: t.ID, Stage: "authenticate", Message: "réplica corrupta, no autenticada o sin clave recuperada ignorada"})
				continue
			}
			m := opened
			canon, err := json.Marshal(m)
			if err != nil {
				return result, err
			}
			current := best[m.FileID]
			if current == nil || m.Generation > current.Generation {
				best[m.FileID] = &RecoveryCandidate{FileID: m.FileID, FileName: m.FileName, Generation: m.Generation, Replicas: 1, sealed: append([]byte(nil), sealed...), manifest: m}
				canonical[m.FileID] = canon
				replicaTargets[m.FileID] = map[string]bool{t.ID: true}
				continue
			}
			if m.Generation < current.Generation {
				continue
			}
			if !bytes.Equal(canon, canonical[m.FileID]) {
				return result, fmt.Errorf("conflicting authenticated manifest replicas for file %s at generation %d", m.FileID, m.Generation)
			}
			if !replicaTargets[m.FileID][t.ID] {
				replicaTargets[m.FileID][t.ID] = true
				current.Replicas++
			}
		}
	}

	result.Candidates = make([]RecoveryCandidate, 0, len(best))
	for _, c := range best {
		result.Candidates = append(result.Candidates, *c)
	}
	sort.Slice(result.Candidates, func(i, j int) bool {
		if result.Candidates[i].FileName == result.Candidates[j].FileName {
			return result.Candidates[i].FileID < result.Candidates[j].FileID
		}
		return result.Candidates[i].FileName < result.Candidates[j].FileName
	})
	return result, nil
}

// SealedManifestCopy returns the authenticated encrypted manifest bytes found
// during recovery. The caller still needs the matching FileID key to use them.
func (c RecoveryCandidate) SealedManifestCopy() []byte {
	return append([]byte(nil), c.sealed...)
}
