package core

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

func TestPackRestoreTargetsSurvivesCompleteTargetLoss(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "targets.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.DataShards != 4 || m.ParityShards != 2 {
		t.Fatalf("geometry=%d+%d", m.DataShards, m.ParityShards)
	}
	lost := m.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lost)); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(filepath.Dir(in), "targets-out.bin")
	if err := e.RestoreTargets(context.Background(), mf, out, key, targets); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want) {
		t.Fatal("target roundtrip mismatch")
	}
}

type memoryStore struct {
	provider           string
	seq                int
	objects            map[string][]byte
	keys               map[string]string
	failPut            bool
	failManifestPut    bool
	failManifestDelete bool
}

func (m *memoryStore) ProviderID() string { return m.provider }
func (m *memoryStore) PutVerified(_ context.Context, accountID, key string, data []byte, expected string) (remoteobject.Object, error) {
	if m.failPut || (m.failManifestPut && strings.HasPrefix(key, "metadata/manifests/")) {
		return remoteobject.Object{}, errors.New("injected write failure")
	}
	if remoteobject.SHA256Bytes(data) != expected {
		return remoteobject.Object{}, errors.New("hash mismatch")
	}
	if m.objects == nil {
		m.objects = map[string][]byte{}
	}
	if m.keys == nil {
		m.keys = map[string]string{}
	}
	m.seq++
	id := fmt.Sprintf("opaque-%s-%d", m.provider, m.seq)
	m.objects[id] = append([]byte(nil), data...)
	m.keys[id] = key
	return remoteobject.Object{ProviderID: m.provider, AccountID: accountID, ID: id, Key: key, Size: int64(len(data)), SHA256: expected}, nil
}
func (m *memoryStore) GetVerified(_ context.Context, _ string, id string, size int64, expected string) ([]byte, error) {
	b, ok := m.objects[id]
	if !ok {
		return nil, os.ErrNotExist
	}
	if int64(len(b)) != size || remoteobject.SHA256Bytes(b) != expected {
		return nil, errors.New("verification failure")
	}
	return append([]byte(nil), b...), nil
}
func (m *memoryStore) Delete(_ context.Context, _ string, id string) error {
	if m.failManifestDelete && strings.HasPrefix(m.keys[id], "metadata/manifests/") {
		return errors.New("injected manifest delete failure")
	}
	delete(m.objects, id)
	delete(m.keys, id)
	return nil
}

func memoryTargets(n int, failIndex int) ([]storage.Target, []*memoryStore) {
	ts := make([]storage.Target, 0, n)
	stores := make([]*memoryStore, 0, n)
	for i := 0; i < n; i++ {
		p := fmt.Sprintf("p%d", i+1)
		st := &memoryStore{provider: p, failPut: i == failIndex}
		stores = append(stores, st)
		ts = append(ts, storage.Target{ID: "target-" + p, FailureDomain: p, AccountID: "acct-" + p, ProviderSubject: "subject-" + p, Store: st, FreeBytes: 1 << 30, Enabled: true})
	}
	return ts, stores
}

func TestPackTargetsStoresOpaqueProviderLocatorInManifest(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "in.bin")
	data := bytes.Repeat([]byte("opaque-locator-test"), 20000)
	if err := os.WriteFile(in, data, 0600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	e, err := New(Config{BlockSize: 128 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	targets, _ := memoryTargets(6, -1)
	mf := filepath.Join(root, "m.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	for _, s := range m.Blocks[0].Shards {
		if !strings.HasPrefix(s.Object, "opaque-") {
			t.Fatalf("manifest stored logical key instead of provider locator: %q", s.Object)
		}
	}
	out := filepath.Join(root, "out.bin")
	if err := e.RestoreTargets(context.Background(), mf, out, key, targets); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, data) {
		t.Fatal("opaque locator restore mismatch")
	}
}

func TestPackTargetsCleansVerifiedObjectsWhenLaterWriteFails(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "in.bin")
	if err := os.WriteFile(in, bytes.Repeat([]byte("cleanup"), 50000), 0600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, _ := New(Config{BlockSize: 128 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	defer e.Close()
	targets, stores := memoryTargets(6, 3)
	err := e.PackTargets(context.Background(), in, filepath.Join(root, "m.cpm"), key, targets)
	if err == nil {
		t.Fatal("expected injected failure")
	}
	for i, st := range stores {
		if len(st.objects) != 0 {
			t.Fatalf("target %d retained %d orphan objects after failed pack", i, len(st.objects))
		}
	}
	if _, statErr := os.Stat(filepath.Join(root, "m.cpm")); !os.IsNotExist(statErr) {
		t.Fatalf("manifest unexpectedly committed: %v", statErr)
	}
}

func TestFailedManifestCleanupRetainsNewDataIfAnyManifestSurvives(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "in.bin")
	if err := os.WriteFile(in, bytes.Repeat([]byte("retain-for-recovery"), 12000), 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, _ := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	defer e.Close()
	targets, stores := memoryTargets(6, -1)
	// First target will successfully receive a manifest but refuse to delete it.
	stores[0].failManifestDelete = true
	// Later target makes manifest replication fail, forcing cleanup.
	stores[5].failManifestPut = true
	err := e.PackTargets(context.Background(), in, filepath.Join(root, "m.cpm"), key, targets)
	if err == nil || !strings.Contains(err.Error(), "retained new data shards") {
		t.Fatalf("expected guarded cleanup failure, got %v", err)
	}
	manifestSurvives := false
	dataCount := 0
	for _, st := range stores {
		for id := range st.objects {
			if strings.HasPrefix(st.keys[id], "metadata/manifests/") {
				manifestSurvives = true
			} else {
				dataCount++
			}
		}
	}
	if !manifestSurvives {
		t.Fatal("test did not leave a manifest replica behind")
	}
	if dataCount == 0 {
		t.Fatal("data shards were deleted despite surviving authenticated manifest")
	}
}

func TestRecoverTargetManifestAfterLocalLossAndProviderLoss(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "remote-recovery.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	lost := m.Blocks[0].Shards[0].Provider
	if err := os.Remove(mf); err != nil {
		t.Fatal(err)
	}
	if err := os.RemoveAll(filepath.Join(pool, lost)); err != nil {
		t.Fatal(err)
	}
	rm, scan, err := e.RecoverTargetManifest(context.Background(), mf, key, targets, "")
	if err != nil {
		t.Fatal(err)
	}
	if rm.FileID != m.FileID || rm.Generation != m.Generation || len(scan.Candidates) != 1 {
		t.Fatalf("recovered=%+v scan=%+v", rm, scan)
	}
	out := filepath.Join(filepath.Dir(in), "remote-recovered.bin")
	if err := e.RestoreTargets(context.Background(), mf, out, key, targets); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want) {
		t.Fatal("reinstall/provider-loss recovery mismatch")
	}
}

func TestTargetRecoveryIgnoresCorruptReplicaButReportsIssue(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, _ := manifest.Load(mf, key)
	obj := manifestReplicaObject(m)
	path := filepath.Join(pool, targets[0].FailureDomain, filepath.FromSlash(obj))
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	b[len(b)/2] ^= 0x40
	if err := os.WriteFile(path, b, 0o600); err != nil {
		t.Fatal(err)
	}
	scan, err := e.DiscoverRecoverableTargetManifests(context.Background(), key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if len(scan.Candidates) != 1 || scan.Candidates[0].FileID != m.FileID {
		t.Fatalf("scan=%+v", scan)
	}
	found := false
	for _, issue := range scan.Issues {
		if issue.Stage == "authenticate" {
			found = true
		}
	}
	if !found {
		t.Fatalf("corrupt manifest did not produce authentication issue: %+v", scan.Issues)
	}
}

func TestTargetRecoveryRejectsAuthenticatedSameGenerationConflict(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	clone := *m
	clone.FileName = "conflicting-authenticated-name.bin"
	sealed, err := manifest.Seal(&clone, key)
	if err != nil {
		t.Fatal(err)
	}
	conflictKey := fmt.Sprintf("metadata/manifests/%s/conflict-generation-%020d.cpm", m.FileID, m.Generation)
	sum := remoteobject.SHA256Bytes(sealed)
	if _, err := targets[0].PutVerified(context.Background(), conflictKey, sealed, sum); err != nil {
		t.Fatal(err)
	}
	if _, err := e.DiscoverRecoverableTargetManifests(context.Background(), key, targets); err == nil || !strings.Contains(err.Error(), "conflicting authenticated manifest replicas") {
		t.Fatalf("expected authenticated conflict rejection, got %v", err)
	}
}

func TestTargetRecoveryMultipleFilesRequiresExplicitSelection(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf1 := filepath.Join(filepath.Dir(in), "one.cpm")
	if err := e.PackTargets(context.Background(), in, mf1, key, targets); err != nil {
		t.Fatal(err)
	}
	second := filepath.Join(filepath.Dir(in), "second-target.bin")
	if err := os.WriteFile(second, bytes.Repeat([]byte("second-target-file"), 5000), 0o600); err != nil {
		t.Fatal(err)
	}
	mf2 := filepath.Join(filepath.Dir(in), "two.cpm")
	if err := e.PackTargets(context.Background(), second, mf2, key, targets); err != nil {
		t.Fatal(err)
	}
	if _, _, err := e.RecoverTargetManifest(context.Background(), filepath.Join(filepath.Dir(in), "ambiguous.cpm"), key, targets, ""); err == nil {
		t.Fatal("multi-file remote recovery guessed a file instead of requiring selection")
	}
	scan, err := e.DiscoverRecoverableTargetManifests(context.Background(), key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if len(scan.Candidates) != 2 {
		t.Fatalf("candidates=%d want 2", len(scan.Candidates))
	}
	selected := scan.Candidates[0]
	rm, _, err := e.RecoverTargetManifest(context.Background(), filepath.Join(filepath.Dir(in), "selected.cpm"), key, targets, selected.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if rm.FileID != selected.FileID {
		t.Fatalf("fileID=%s want %s", rm.FileID, selected.FileID)
	}
}

func TestAuditTargetsDistinguishesCorruptFromUnavailable(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "audit-targets.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, _ := manifest.Load(mf, key)
	corrupt := m.Blocks[0].Shards[0]
	unavailable := m.Blocks[0].Shards[1]
	path := filepath.Join(pool, corrupt.Provider, filepath.FromSlash(corrupt.Object))
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	b[0] ^= 0x7f
	if err := os.WriteFile(path, b, 0o600); err != nil {
		t.Fatal(err)
	}
	for i := range targets {
		if targets[i].ID == unavailable.Provider {
			targets[i].Enabled = false
		}
	}
	r, err := e.AuditTargets(context.Background(), mf, key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if r.Blocks[0].Corrupt != 1 || r.Blocks[0].Unavailable != 1 || r.Blocks[0].Missing != 0 {
		t.Fatalf("audit block=%+v", r.Blocks[0])
	}
	if r.Healthy {
		t.Fatal("degraded target audit reported healthy")
	}
}

func TestRepairTargetsCorruptShardRestoresProtectionAndGeneration(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "repair-targets.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	before, _ := manifest.Load(mf, key)
	s := before.Blocks[0].Shards[0]
	path := filepath.Join(pool, s.Provider, filepath.FromSlash(s.Object))
	b, _ := os.ReadFile(path)
	b[len(b)/2] ^= 0x23
	if err := os.WriteFile(path, b, 0o600); err != nil {
		t.Fatal(err)
	}
	report, err := e.RepairTargets(context.Background(), mf, key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if report.RepairedShards < 1 || report.ManifestGeneration != before.Generation+1 || len(report.CleanupWarnings) != 0 {
		t.Fatalf("report=%+v", report)
	}
	audit, err := e.AuditTargets(context.Background(), mf, key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if !audit.Healthy || !audit.MeetsProviderSafety || audit.Blocks[0].Corrupt != 0 {
		t.Fatalf("audit=%+v", audit)
	}
	out := filepath.Join(filepath.Dir(in), "repair-targets-out.bin")
	if err := e.RestoreTargets(context.Background(), mf, out, key, targets); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, want) {
		t.Fatal("repaired target file mismatch")
	}
}

func TestRepairTargetsLostProviderRequiresAndUsesIndependentReplacement(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "repair-lost-provider.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	before, _ := manifest.Load(mf, key)
	lost := before.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lost)); err != nil {
		t.Fatal(err)
	}
	withoutLost := make([]storage.Target, 0, len(targets)-1)
	for _, target := range targets {
		if target.ID != lost {
			withoutLost = append(withoutLost, target)
		}
	}
	if _, err := e.RepairTargets(context.Background(), mf, key, withoutLost); err == nil || !strings.Contains(err.Error(), "independent provider") {
		t.Fatalf("repair without replacement should be rejected, got %v", err)
	}
	if err := os.MkdirAll(filepath.Join(pool, "provider-07"), 0o700); err != nil {
		t.Fatal(err)
	}
	replacements, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	report, err := e.RepairTargets(context.Background(), mf, key, replacements)
	if err != nil {
		t.Fatal(err)
	}
	if report.RepairedShards < 1 {
		t.Fatalf("report=%+v", report)
	}
	after, _ := manifest.Load(mf, key)
	for _, shard := range after.Blocks[0].Shards {
		if shard.Provider == lost {
			t.Fatalf("lost provider still referenced after repair: %+v", shard)
		}
	}
	if !strings.Contains(fmt.Sprint(after.Blocks[0].Shards), "provider-07") {
		t.Fatalf("replacement provider not used: %+v", after.Blocks[0].Shards)
	}
}

func TestRepairTargetsDefersTemporarilyUnavailableShard(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "defer-unavailable.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	before, _ := manifest.Load(mf, key)
	unavailable := before.Blocks[0].Shards[0].Provider
	for i := range targets {
		if targets[i].ID == unavailable {
			targets[i].Enabled = false
		}
	}
	report, err := e.RepairTargets(context.Background(), mf, key, targets)
	if err != nil {
		t.Fatal(err)
	}
	if report.RepairedShards != 0 || report.DeferredUnavailableShards == 0 || report.ManifestGeneration != before.Generation {
		t.Fatalf("report=%+v", report)
	}
	after, _ := manifest.Load(mf, key)
	if after.Generation != before.Generation {
		t.Fatalf("unavailable-only repair changed generation: %d -> %d", before.Generation, after.Generation)
	}
}

func TestTargetRecoveryByPerFileKeysDiscoversMultipleFiles(t *testing.T) {
	e, pool, in, key1, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf1 := filepath.Join(filepath.Dir(in), "per-key-one.cpm")
	if err := e.PackTargets(context.Background(), in, mf1, key1, targets); err != nil {
		t.Fatal(err)
	}
	m1, err := manifest.Load(mf1, key1)
	if err != nil {
		t.Fatal(err)
	}
	in2 := filepath.Join(filepath.Dir(in), "per-key-two.bin")
	if err := os.WriteFile(in2, bytes.Repeat([]byte("second-independent-file"), 7000), 0o600); err != nil {
		t.Fatal(err)
	}
	key2, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	mf2 := filepath.Join(filepath.Dir(in), "per-key-two.cpm")
	if err := e.PackTargets(context.Background(), in2, mf2, key2, targets); err != nil {
		t.Fatal(err)
	}
	m2, err := manifest.Load(mf2, key2)
	if err != nil {
		t.Fatal(err)
	}

	scan, err := e.DiscoverRecoverableTargetManifestsByKeys(context.Background(), map[string][]byte{
		m1.FileID: key1,
		m2.FileID: key2,
	}, targets)
	if err != nil {
		t.Fatal(err)
	}
	if len(scan.Candidates) != 2 {
		t.Fatalf("candidates=%d want 2; issues=%+v", len(scan.Candidates), scan.Issues)
	}
	seen := map[string]bool{}
	for _, c := range scan.Candidates {
		seen[c.FileID] = true
		if len(c.SealedManifestCopy()) == 0 {
			t.Fatalf("candidate %s lost sealed manifest bytes", c.FileID)
		}
	}
	if !seen[m1.FileID] || !seen[m2.FileID] {
		t.Fatalf("wrong recovered ids: %+v", seen)
	}
}

func TestTargetRecoveryByPerFileKeysDoesNotCrossDecryptFiles(t *testing.T) {
	e, pool, in, key1, _ := fixture(t)
	defer e.Close()
	targets, err := storage.LocalTargets(pool)
	if err != nil {
		t.Fatal(err)
	}
	mf1 := filepath.Join(filepath.Dir(in), "key-routing.cpm")
	if err := e.PackTargets(context.Background(), in, mf1, key1, targets); err != nil {
		t.Fatal(err)
	}
	m1, err := manifest.Load(mf1, key1)
	if err != nil {
		t.Fatal(err)
	}
	wrong, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	scan, err := e.DiscoverRecoverableTargetManifestsByKeys(context.Background(), map[string][]byte{m1.FileID: wrong}, targets)
	if err != nil {
		t.Fatal(err)
	}
	if len(scan.Candidates) != 0 {
		t.Fatalf("manifest authenticated with wrong recovered key: %+v", scan.Candidates)
	}
	if len(scan.Issues) == 0 {
		t.Fatal("wrong key produced no recovery issue")
	}
}

func TestPackTargetsWithIDObservedCancellationCleansUncommittedObjects(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "in.bin")
	if err := os.WriteFile(in, bytes.Repeat([]byte("cancel-cleanup"), 70000), 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, _ := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	defer e.Close()
	targets, stores := memoryTargets(6, -1)
	ctx, cancel := context.WithCancel(context.Background())
	fileID := "00112233445566778899aabbccddeeff"
	mf := filepath.Join(root, "m.cpm")
	err := e.PackTargetsWithIDObserved(ctx, in, mf, key, targets, fileID, func(p TransferProgress) {
		if p.Phase == "uploading" && p.BlocksDone == 1 {
			cancel()
		}
	})
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("expected context cancellation, got %v", err)
	}
	for i, st := range stores {
		if len(st.objects) != 0 {
			t.Fatalf("target %d retained %d objects after canceled uncommitted upload", i, len(st.objects))
		}
	}
	if _, statErr := os.Stat(mf); !os.IsNotExist(statErr) {
		t.Fatalf("manifest committed despite cancellation: %v", statErr)
	}
}

func TestPackTargetsWithExplicitFileIDPersistsThatID(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "in.bin")
	if err := os.WriteFile(in, bytes.Repeat([]byte("explicit-id"), 10000), 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, _ := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	defer e.Close()
	targets, _ := memoryTargets(6, -1)
	fileID := "ffeeddccbbaa99887766554433221100"
	mf := filepath.Join(root, "m.cpm")
	if err := e.PackTargetsWithID(context.Background(), in, mf, key, targets, fileID); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.FileID != fileID {
		t.Fatalf("manifest file id=%s want=%s", m.FileID, fileID)
	}
}

func TestPackTargetsReservesManifestCommitHeadroomBeforeUploading(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "in.bin")
	if err := os.WriteFile(in, bytes.Repeat([]byte("manifest-headroom"), 4096), 0o600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	e, err := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	targets, stores := memoryTargets(6, -1)
	// A target that cannot keep the full current recovery-safe manifest reserve
	// must reject the operation before the first shard is uploaded.
	targets[0].FreeBytes = manifest.MaxSealedBytes
	err = e.PackTargets(context.Background(), in, filepath.Join(root, "m.cpm"), key, targets)
	if err == nil || !strings.Contains(err.Error(), "manifest commit headroom") {
		t.Fatalf("expected manifest headroom rejection, got %v", err)
	}
	for i, st := range stores {
		if len(st.objects) != 0 {
			t.Fatalf("target %d received objects before preflight rejection: %d", i, len(st.objects))
		}
	}
}

func TestReadTargetsRangeReconstructsOnlyRequestedPlaintext(t *testing.T) {
	root := t.TempDir()
	in := filepath.Join(root, "range.bin")
	want := bytes.Repeat([]byte("0123456789abcdef"), 40000)
	if err := os.WriteFile(in, want, 0o600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	e, err := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	targets, stores := memoryTargets(6, -1)
	mf := filepath.Join(root, "range.cpm")
	if err := e.PackTargets(context.Background(), in, mf, key, targets); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	// Remove one complete failure domain to prove the range reader reconstructs
	// from the same redundancy model as full restore.
	lost := m.Blocks[0].Shards[0].Provider
	for i, target := range targets {
		if target.FailureDomain == lost {
			stores[i].objects = map[string][]byte{}
			stores[i].keys = map[string]string{}
		}
	}
	offset := int64((64 << 10) - 23)
	length := (64 << 10) + 101
	got, err := e.ReadTargetsRange(context.Background(), mf, key, targets, offset, length)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want[offset:offset+int64(length)]) {
		t.Fatal("range read mismatch")
	}
	// EOF clipping must be deterministic rather than returning a short-read error.
	got, err = e.ReadTargetsRange(context.Background(), mf, key, targets, int64(len(want)-17), 4096)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want[len(want)-17:]) {
		t.Fatal("EOF-clipped range mismatch")
	}
}
