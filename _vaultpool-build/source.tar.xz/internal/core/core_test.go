package core

import (
	"bytes"
	"crypto/rand"
	"os"
	"path/filepath"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
)

func makeProviders(t *testing.T, pool string, n int) {
	t.Helper()
	for i := 1; i <= n; i++ {
		if err := os.MkdirAll(filepath.Join(pool, providerName(i)), 0o700); err != nil {
			t.Fatal(err)
		}
	}
}

func providerName(i int) string {
	if i < 10 {
		return "provider-0" + string(rune('0'+i))
	}
	return "provider-" + string(rune('0'+i/10)) + string(rune('0'+i%10))
}

func fixture(t *testing.T) (*Engine, string, string, []byte, []byte) {
	t.Helper()
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	// 4+2 with min provider-failure margin 1 requires each of the six shards
	// to live in a distinct provider failure domain.
	makeProviders(t, pool, 6)
	data := make([]byte, 900_000)
	copy(data, bytes.Repeat([]byte("VaultPool-safety-test|"), 20000))
	if _, err := rand.Read(data[500_000:]); err != nil {
		t.Fatal(err)
	}
	in := filepath.Join(root, "input.bin")
	if err := os.WriteFile(in, data, 0o600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	e, err := New(Config{BlockSize: 128 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	return e, pool, in, key, data
}

func TestRoundTripAndTwoShardLoss(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Blocks) == 0 {
		t.Fatal("no blocks")
	}
	// Lose two independent shards from the first block: 4+2 must recover.
	for _, s := range m.Blocks[0].Shards[:2] {
		if err := os.Remove(filepath.Join(pool, s.Provider, filepath.FromSlash(s.Object))); err != nil {
			t.Fatal(err)
		}
	}
	r, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if r.Blocks[0].Margin != 0 {
		t.Fatalf("margin=%d want 0", r.Blocks[0].Margin)
	}
	out := filepath.Join(filepath.Dir(in), "out.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want) {
		t.Fatal("roundtrip mismatch")
	}
}

func TestWholeProviderLossLeavesRecoveryMargin(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	lostProvider := m.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lostProvider)); err != nil {
		t.Fatal(err)
	}
	r, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if r.Blocks[0].Margin != 1 {
		t.Fatalf("margin after provider loss=%d want 1", r.Blocks[0].Margin)
	}
	if r.Healthy {
		t.Fatal("provider loss must degrade healthy state")
	}
	out := filepath.Join(filepath.Dir(in), "out-provider-loss.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want) {
		t.Fatal("provider-loss recovery mismatch")
	}
}

func TestThreeShardLossFails(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	for _, s := range m.Blocks[0].Shards[:3] {
		if err := os.Remove(filepath.Join(pool, s.Provider, filepath.FromSlash(s.Object))); err != nil {
			t.Fatal(err)
		}
	}
	out := filepath.Join(filepath.Dir(in), "out.bin")
	if err := e.Restore(mf, pool, out, key); err == nil {
		t.Fatal("expected unrecoverable failure")
	}
}

func TestCorruptionDetectedAndRecovered(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	s := m.Blocks[0].Shards[0]
	path := filepath.Join(pool, s.Provider, filepath.FromSlash(s.Object))
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	b[len(b)/2] ^= 0xff
	if err := os.WriteFile(path, b, 0o600); err != nil {
		t.Fatal(err)
	}
	r, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if r.Blocks[0].Corrupt != 1 {
		t.Fatalf("corrupt=%d want 1", r.Blocks[0].Corrupt)
	}
	out := filepath.Join(filepath.Dir(in), "out.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, want) {
		t.Fatal("recovery mismatch")
	}
}

func TestProviderDiversityPolicyRejected(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 4)
	in := filepath.Join(root, "in")
	_ = os.WriteFile(in, []byte("hello"), 0o600)
	key, _ := cryptokit.GenerateKey()
	e, err := New(Config{BlockSize: 1024, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	if err := e.Pack(in, pool, filepath.Join(root, "m.cpm"), key); err == nil {
		t.Fatal("expected provider-diversity rejection")
	}
}

func TestNormalPolicyCanAllowZeroMarginAfterProviderLoss(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 4)
	in := filepath.Join(root, "in")
	_ = os.WriteFile(in, []byte("hello"), 0o600)
	key, _ := cryptokit.GenerateKey()
	e, err := New(Config{BlockSize: 1024, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 0})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	if err := e.Pack(in, pool, filepath.Join(root, "m.cpm"), key); err != nil {
		t.Fatalf("normal policy should accept survivable zero-margin provider loss: %v", err)
	}
}

func TestMoveRejectsProviderConcentration(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	from := m.Blocks[0].Shards[0]
	dst := m.Blocks[0].Shards[1].Provider
	if err := e.MoveShard(mf, pool, key, 0, from.Index, dst); err == nil {
		t.Fatal("expected move to be rejected because it concentrates two shards in one provider")
	}
}

func TestMoveCopyVerifyCommitDeleteToEmptyProvider(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	if err := os.MkdirAll(filepath.Join(pool, "provider-07"), 0o700); err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	before, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	s := before.Blocks[0].Shards[0]
	oldPath := filepath.Join(pool, s.Provider, filepath.FromSlash(s.Object))
	if err := e.MoveShard(mf, pool, key, 0, s.Index, "provider-07"); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(oldPath); !os.IsNotExist(err) {
		t.Fatalf("old shard must be deleted only after commit; stat err=%v", err)
	}
	after, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if after.Blocks[0].Shards[s.Index].Provider != "provider-07" {
		t.Fatalf("manifest provider=%q want provider-07", after.Blocks[0].Shards[s.Index].Provider)
	}
	newPath := filepath.Join(pool, "provider-07", filepath.FromSlash(s.Object))
	if _, err := os.Stat(newPath); err != nil {
		t.Fatalf("destination shard missing: %v", err)
	}
}

func TestRecoverManifestAfterLocalLossAndProviderLoss(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.Generation != 1 {
		t.Fatalf("generation=%d want 1", m.Generation)
	}
	// Simulate PC/local database loss plus one complete provider outage.
	if err := os.Remove(mf); err != nil {
		t.Fatal(err)
	}
	lostProvider := m.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lostProvider)); err != nil {
		t.Fatal(err)
	}
	recoveredManifest := filepath.Join(filepath.Dir(in), "recovered.cpm")
	rm, err := e.RecoverManifest(pool, recoveredManifest, key, "")
	if err != nil {
		t.Fatal(err)
	}
	if rm.FileID != m.FileID || rm.Generation != m.Generation {
		t.Fatalf("recovered wrong manifest: file=%s gen=%d", rm.FileID, rm.Generation)
	}
	out := filepath.Join(filepath.Dir(in), "out-after-manifest-loss.bin")
	if err := e.Restore(recoveredManifest, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, want) {
		t.Fatal("recovery after manifest + provider loss mismatch")
	}
}

func TestRepairProtectionAfterWholeProviderLoss(t *testing.T) {
	e, pool, in, key, want := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	before, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	lostProvider := before.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lostProvider)); err != nil {
		t.Fatal(err)
	}
	// User reconnects/adds an independent provider and explicitly requests repair.
	if err := os.MkdirAll(filepath.Join(pool, "provider-07"), 0o700); err != nil {
		t.Fatal(err)
	}
	r, err := e.RepairProtection(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if r.RepairedShards == 0 || r.ManifestGeneration != before.Generation+1 {
		t.Fatalf("unexpected repair report: %+v", r)
	}
	audit, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if !audit.Healthy || !audit.MeetsProviderSafety || audit.WorstMargin != 2 || audit.WorstProviderFailureMargin != 1 {
		t.Fatalf("repair did not restore full protection: %+v", audit)
	}
	out := filepath.Join(filepath.Dir(in), "out-after-repair.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, want) {
		t.Fatal("repaired file mismatch")
	}
}

func TestRepairCorruptShardRestoresFullHealth(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	s := m.Blocks[0].Shards[0]
	path := filepath.Join(pool, s.Provider, filepath.FromSlash(s.Object))
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	b[0] ^= 0x55
	if err := os.WriteFile(path, b, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := e.RepairProtection(mf, pool, key); err != nil {
		t.Fatal(err)
	}
	audit, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if !audit.Healthy || audit.Blocks[0].Corrupt != 0 {
		t.Fatalf("corruption not repaired: %+v", audit.Blocks[0])
	}
}

func TestMoveIncrementsReplicatedManifestGeneration(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	if err := os.MkdirAll(filepath.Join(pool, "provider-07"), 0o700); err != nil {
		t.Fatal(err)
	}
	mf := filepath.Join(filepath.Dir(in), "m.cpm")
	if err := e.Pack(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	before, _ := manifest.Load(mf, key)
	s := before.Blocks[0].Shards[0]
	if err := e.MoveShard(mf, pool, key, 0, s.Index, "provider-07"); err != nil {
		t.Fatal(err)
	}
	after, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if after.Generation != before.Generation+1 {
		t.Fatalf("generation=%d want %d", after.Generation, before.Generation+1)
	}
	// Delete local manifest and verify recovery chooses the new mapping.
	if err := os.Remove(mf); err != nil {
		t.Fatal(err)
	}
	rm, err := e.RecoverManifest(pool, mf, key, "")
	if err != nil {
		t.Fatal(err)
	}
	if rm.Generation != after.Generation || rm.Blocks[0].Shards[s.Index].Provider != "provider-07" {
		t.Fatalf("stale recovered manifest: gen=%d provider=%s", rm.Generation, rm.Blocks[0].Shards[s.Index].Provider)
	}
}

func TestMultiFileRecoveryRequiresExplicitFileID(t *testing.T) {
	e, pool, in, key, _ := fixture(t)
	defer e.Close()
	mf1 := filepath.Join(filepath.Dir(in), "m1.cpm")
	if err := e.Pack(in, pool, mf1, key); err != nil {
		t.Fatal(err)
	}
	second := filepath.Join(filepath.Dir(in), "second.bin")
	if err := os.WriteFile(second, bytes.Repeat([]byte("second-file|"), 2000), 0o600); err != nil {
		t.Fatal(err)
	}
	mf2 := filepath.Join(filepath.Dir(in), "m2.cpm")
	if err := e.Pack(second, pool, mf2, key); err != nil {
		t.Fatal(err)
	}
	candidates, err := e.DiscoverRecoverableManifests(pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if len(candidates) != 2 {
		t.Fatalf("recoverable candidates=%d want 2", len(candidates))
	}
	if _, err := e.RecoverManifest(pool, filepath.Join(filepath.Dir(in), "ambiguous.cpm"), key, ""); err == nil {
		t.Fatal("expected ambiguous recovery to require explicit file ID")
	}
	chosen := candidates[0]
	out := filepath.Join(filepath.Dir(in), "selected.cpm")
	rm, err := e.RecoverManifest(pool, out, key, chosen.FileID)
	if err != nil {
		t.Fatal(err)
	}
	if rm.FileID != chosen.FileID {
		t.Fatalf("recovered file ID=%s want %s", rm.FileID, chosen.FileID)
	}
}

func TestBlockAEADBindsFileID(t *testing.T) {
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	sealed, err := cryptokit.Seal(key, []byte("payload"), blockAAD("file-A", 0))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := cryptokit.Open(key, sealed, blockAAD("file-B", 0)); err == nil {
		t.Fatal("ciphertext from one file ID must not authenticate as another file")
	}
}

func TestAdaptivePackFiveProvidersChoosesSixPlusThreeAndRestores(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 5)
	data := bytes.Repeat([]byte("vaultpool-adaptive-five|"), 20000)
	in := filepath.Join(root, "input.bin")
	if err := os.WriteFile(in, data, 0o600); err != nil {
		t.Fatal(err)
	}
	key, err := cryptokit.GenerateKey()
	if err != nil {
		t.Fatal(err)
	}
	e, err := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	mf := filepath.Join(root, "adaptive.cpm")
	if err := e.PackAdaptive(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.DataShards != 6 || m.ParityShards != 3 {
		t.Fatalf("adaptive geometry=%d+%d want 6+3", m.DataShards, m.ParityShards)
	}
	out := filepath.Join(root, "out.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, data) {
		t.Fatal("adaptive roundtrip mismatch")
	}
}

func TestAdaptivePackProviderLossStillRestores(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 5)
	data := make([]byte, 700000)
	if _, err := rand.Read(data); err != nil {
		t.Fatal(err)
	}
	in := filepath.Join(root, "input.bin")
	if err := os.WriteFile(in, data, 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, err := New(Config{BlockSize: 128 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	mf := filepath.Join(root, "adaptive.cpm")
	if err := e.PackAdaptive(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	lost := m.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lost)); err != nil {
		t.Fatal(err)
	}
	a, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if a.WorstMargin < 1 {
		t.Fatalf("provider loss must leave at least one shard of recovery margin: %+v", a)
	}
	out := filepath.Join(root, "out-after-loss.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, data) {
		t.Fatal("adaptive provider-loss restore mismatch")
	}
}

func TestAdaptivePackTwoProvidersMirrorSurvivesWholeProviderLoss(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 2)
	data := bytes.Repeat([]byte("two-provider-mirror|"), 20000)
	in := filepath.Join(root, "input.bin")
	if err := os.WriteFile(in, data, 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, err := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	mf := filepath.Join(root, "mirror.cpm")
	if err := e.PackAdaptive(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.DataShards != 1 || m.ParityShards != 1 || m.MinProviderFailureMargin != 0 {
		t.Fatalf("unexpected mirror manifest geometry: %+v", m)
	}
	lost := m.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lost)); err != nil {
		t.Fatal(err)
	}
	a, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if a.WorstMargin != 0 || a.WorstProviderFailureMargin != -1 || a.MeetsProviderSafety {
		t.Fatalf("mirror must remain recoverable, with no additional-provider safety after the first provider is gone: %+v", a)
	}
	out := filepath.Join(root, "mirror-out.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, data) {
		t.Fatal("2-provider mirror restore mismatch after provider loss")
	}
}

func TestAdaptivePackThreeProvidersTripleReplicaSurvivesWholeProviderLossWithMargin(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 3)
	data := bytes.Repeat([]byte("three-provider-triple|"), 20000)
	in := filepath.Join(root, "input.bin")
	if err := os.WriteFile(in, data, 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, err := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	mf := filepath.Join(root, "triple.cpm")
	if err := e.PackAdaptive(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.DataShards != 1 || m.ParityShards != 2 || m.MinProviderFailureMargin != 1 {
		t.Fatalf("unexpected triple-replica manifest geometry: %+v", m)
	}
	lost := m.Blocks[0].Shards[0].Provider
	if err := os.RemoveAll(filepath.Join(pool, lost)); err != nil {
		t.Fatal(err)
	}
	a, err := e.Audit(mf, pool, key)
	if err != nil {
		t.Fatal(err)
	}
	if a.WorstMargin != 1 || a.WorstProviderFailureMargin != 0 || a.MeetsProviderSafety {
		t.Fatalf("triple replica should retain one raw copy margin after provider loss without pretending the original provider-safety target is still intact: %+v", a)
	}
	out := filepath.Join(root, "triple-out.bin")
	if err := e.Restore(mf, pool, out, key); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, data) {
		t.Fatal("3-provider triple-replica restore mismatch after provider loss")
	}
}

func TestAdaptivePackFourProvidersChoosesEightPlusFour(t *testing.T) {
	root := t.TempDir()
	pool := filepath.Join(root, "pool")
	makeProviders(t, pool, 4)
	in := filepath.Join(root, "input.bin")
	if err := os.WriteFile(in, bytes.Repeat([]byte("four-provider|"), 10000), 0o600); err != nil {
		t.Fatal(err)
	}
	key, _ := cryptokit.GenerateKey()
	e, err := New(Config{BlockSize: 64 << 10, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1})
	if err != nil {
		t.Fatal(err)
	}
	defer e.Close()
	mf := filepath.Join(root, "adaptive.cpm")
	if err := e.PackAdaptive(in, pool, mf, key); err != nil {
		t.Fatal(err)
	}
	m, err := manifest.Load(mf, key)
	if err != nil {
		t.Fatal(err)
	}
	if m.DataShards != 8 || m.ParityShards != 4 {
		t.Fatalf("adaptive geometry=%d+%d want 8+4", m.DataShards, m.ParityShards)
	}
}
