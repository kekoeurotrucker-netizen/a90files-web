package core

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"os"
	"sort"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/health"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type targetShardState uint8

const (
	targetShardValid targetShardState = iota
	targetShardMissing
	targetShardCorrupt
	targetShardUnavailable
)

func classifyTargetReadError(err error) targetShardState {
	if err == nil {
		return targetShardValid
	}
	if errors.Is(err, os.ErrNotExist) {
		return targetShardMissing
	}
	var apiErr *remoteobject.APIError
	if errors.As(err, &apiErr) {
		if apiErr.StatusCode == http.StatusNotFound {
			return targetShardMissing
		}
		return targetShardUnavailable
	}
	var integrityErr *remoteobject.IntegrityError
	if errors.As(err, &integrityErr) {
		return targetShardCorrupt
	}
	// Unknown transport/auth/provider failures are not evidence of corruption.
	return targetShardUnavailable
}

func targetFailureDomain(targetID string, targets map[string]storage.Target) string {
	if t, ok := targets[targetID]; ok && t.FailureDomain != "" {
		return t.FailureDomain
	}
	// Stable cloud target IDs are provider-id:sha256(subject). This fallback lets
	// an old manifest still contribute its provider failure domain even if that
	// account is not currently authenticated.
	if i := strings.IndexByte(targetID, ':'); i > 0 {
		return targetID[:i]
	}
	return targetID
}

func readTargetBlockDetailed(ctx context.Context, b manifest.Block, targets map[string]storage.Target) ([][]byte, []targetShardState, map[string]int, error) {
	shards := make([][]byte, len(b.Shards))
	states := make([]targetShardState, len(b.Shards))
	validByDomain := map[string]int{}
	for _, s := range b.Shards {
		if err := ctx.Err(); err != nil {
			return nil, nil, nil, err
		}
		t, ok := targets[s.Provider]
		if !ok {
			states[s.Index] = targetShardMissing
			continue
		}
		if !t.Enabled {
			states[s.Index] = targetShardUnavailable
			continue
		}
		data, err := t.GetVerified(ctx, s.Object, int64(b.ShardSize), s.SHA256)
		if err != nil {
			if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
				return nil, nil, nil, err
			}
			states[s.Index] = classifyTargetReadError(err)
			continue
		}
		states[s.Index] = targetShardValid
		shards[s.Index] = data
		validByDomain[t.FailureDomain]++
	}
	return shards, states, validByDomain, nil
}

func summarizeTargetStates(states []targetShardState) (valid, missing, corrupt, unavailable int) {
	for _, st := range states {
		switch st {
		case targetShardValid:
			valid++
		case targetShardMissing:
			missing++
		case targetShardCorrupt:
			corrupt++
		case targetShardUnavailable:
			unavailable++
		}
	}
	return
}

// AuditTargets verifies every reachable shard against trusted manifest size and
// SHA-256. Provider/API failures are reported as unavailable, not mislabeled as
// corruption or permanent loss.
func (e *Engine) AuditTargets(ctx context.Context, manifestPath string, key []byte, targets []storage.Target) (AuditReport, error) {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return AuditReport{}, err
	}
	if err := storage.ValidateTargets(targets); err != nil {
		return AuditReport{}, err
	}
	targetMap := storage.ByID(targets)
	r := AuditReport{
		FileName:                   m.FileName,
		WorstMargin:                m.ParityShards,
		WorstProviderFailureMargin: m.ParityShards,
		Healthy:                    true,
		MeetsProviderSafety:        true,
		Risk: health.Assessment{
			Level:                   health.VeryLow,
			TotalShards:             m.DataShards + m.ParityShards,
			ValidShards:             m.DataShards + m.ParityShards,
			RecoveryMargin:          m.ParityShards,
			ProviderFailureMargin:   m.ParityShards,
			ProviderSafetySatisfied: true,
		},
	}
	for _, b := range m.Blocks {
		_, states, counts, err := readTargetBlockDetailed(ctx, b, targetMap)
		if err != nil {
			return AuditReport{}, err
		}
		valid, missing, corrupt, unavailable := summarizeTargetStates(states)
		margin := valid - m.DataShards
		providerMargin := minMarginAfterProviderLoss(counts, valid, m.DataShards)
		assessment := health.Assess(health.Input{DataShards: m.DataShards, ParityShards: m.ParityShards, ValidShards: valid, ProviderFailureMargin: providerMargin, RequiredProviderMargin: m.MinProviderFailureMargin})
		r.Risk = health.Worse(r.Risk, assessment)
		if margin < r.WorstMargin {
			r.WorstMargin = margin
		}
		if providerMargin < r.WorstProviderFailureMargin {
			r.WorstProviderFailureMargin = providerMargin
		}
		if margin < m.ParityShards {
			r.Healthy = false
		}
		if providerMargin < m.MinProviderFailureMargin {
			r.MeetsProviderSafety = false
		}
		r.Blocks = append(r.Blocks, AuditBlock{Index: b.Index, Total: len(b.Shards), Valid: valid, Missing: missing, Corrupt: corrupt, Unavailable: unavailable, Margin: margin, ProviderFailureMargin: providerMargin})
	}
	return r, nil
}

func blockProviderMarginAfterTargetMove(b manifest.Block, shardIndex int, destination storage.Target, targets map[string]storage.Target, dataShards int) int {
	counts := map[string]int{}
	for _, s := range b.Shards {
		id := s.Provider
		if s.Index == shardIndex {
			id = destination.ID
		}
		counts[targetFailureDomain(id, targets)]++
	}
	return minMarginAfterProviderLoss(counts, len(b.Shards), dataShards)
}

func targetCanHold(t storage.Target, size int64, remaining map[string]int64) bool {
	if !t.Enabled || size <= 0 {
		return false
	}
	if t.MaxObjectBytes > 0 && size > t.MaxObjectBytes {
		return false
	}
	return remaining[t.ID] >= size
}

func chooseTargetRepairDestination(b manifest.Block, shardIndex int, originalID string, size int64, targets []storage.Target, targetMap map[string]storage.Target, remaining map[string]int64, dataShards, minMargin int) (storage.Target, error) {
	if original, ok := targetMap[originalID]; ok && targetCanHold(original, size, remaining) && blockProviderMarginAfterTargetMove(b, shardIndex, original, targetMap, dataShards) >= minMargin {
		return original, nil
	}
	usedDomains := map[string]bool{}
	for _, s := range b.Shards {
		if s.Index == shardIndex {
			continue
		}
		usedDomains[targetFailureDomain(s.Provider, targetMap)] = true
	}
	candidates := append([]storage.Target(nil), targets...)
	sort.Slice(candidates, func(i, j int) bool {
		iUnused := !usedDomains[candidates[i].FailureDomain]
		jUnused := !usedDomains[candidates[j].FailureDomain]
		if iUnused != jUnused {
			return iUnused
		}
		if remaining[candidates[i].ID] != remaining[candidates[j].ID] {
			return remaining[candidates[i].ID] > remaining[candidates[j].ID]
		}
		return candidates[i].ID < candidates[j].ID
	})
	for _, t := range candidates {
		if !targetCanHold(t, size, remaining) {
			continue
		}
		if blockProviderMarginAfterTargetMove(b, shardIndex, t, targetMap, dataShards) < minMargin {
			continue
		}
		return t, nil
	}
	return storage.Target{}, errors.New("no enabled storage target can restore the configured provider-failure margin and capacity; reconnect/add an independent provider")
}

type oldTargetObject struct {
	target  storage.Target
	locator string
}

// RepairTargets repairs only confirmed missing/corrupt shards. Temporarily
// unavailable shards are deliberately deferred; an outage/rate-limit/auth issue
// is not treated as proof that the user's data disappeared.
func (e *Engine) RepairTargets(ctx context.Context, manifestPath string, key []byte, targets []storage.Target) (report RepairReport, err error) {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return report, err
	}
	if err := storage.ValidateTargets(targets); err != nil {
		return report, err
	}
	rs, err := coderFor(m.DataShards, m.ParityShards)
	if err != nil {
		return report, err
	}
	targets = storage.Sorted(targets)
	targetMap := storage.ByID(targets)
	remaining := map[string]int64{}
	for _, t := range targets {
		remaining[t.ID] = t.FreeBytes
	}
	report = RepairReport{FileName: m.FileName, ManifestGeneration: m.Generation}
	created := make([]createdTargetObject, 0)
	oldObjects := make([]oldTargetObject, 0)
	committed := false
	defer func() {
		if committed || len(created) == 0 {
			return
		}
		cleanupCtx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		defer cancel()
		if cleanupErr := cleanupTargetObjects(cleanupCtx, created); cleanupErr != nil {
			if err == nil {
				err = cleanupErr
			} else {
				err = fmt.Errorf("%w; repair cleanup incomplete: %v", err, cleanupErr)
			}
		}
	}()

	changed := false
	for bi := range m.Blocks {
		if err := ctx.Err(); err != nil {
			return report, err
		}
		b := &m.Blocks[bi]
		shards, states, _, err := readTargetBlockDetailed(ctx, *b, targetMap)
		if err != nil {
			return report, err
		}
		_, missing, corrupt, unavailable := summarizeTargetStates(states)
		report.DeferredUnavailableShards += unavailable
		if missing+corrupt == 0 {
			continue
		}
		if missing+corrupt+unavailable > m.ParityShards {
			return report, fmt.Errorf("block %d cannot be repaired now: missing=%d corrupt=%d unavailable=%d parity=%d", b.Index, missing, corrupt, unavailable, m.ParityShards)
		}
		if err := rs.Reconstruct(shards); err != nil {
			return report, fmt.Errorf("reconstruct block %d: %w", b.Index, err)
		}
		blockRepaired := 0
		for si := range b.Shards {
			if states[si] != targetShardMissing && states[si] != targetShardCorrupt {
				continue
			}
			s := &b.Shards[si]
			data := shards[s.Index]
			if got := remoteobject.SHA256Bytes(data); !strings.EqualFold(got, s.SHA256) {
				return report, fmt.Errorf("reconstructed block %d shard %d SHA-256 mismatch", b.Index, s.Index)
			}
			dst, err := chooseTargetRepairDestination(*b, s.Index, s.Provider, int64(len(data)), targets, targetMap, remaining, m.DataShards, m.MinProviderFailureMargin)
			if err != nil {
				return report, fmt.Errorf("block %d shard %d: %w", b.Index, s.Index, err)
			}
			logicalKey := fmt.Sprintf("objects/%s/%08d/shard-%03d.cps", m.FileID, b.Index, s.Index)
			obj, err := dst.PutVerified(ctx, logicalKey, data, s.SHA256)
			if err != nil {
				return report, fmt.Errorf("repair block %d shard %d to %s: %w", b.Index, s.Index, dst.ID, err)
			}
			if obj.ID == "" || obj.Size != int64(len(data)) || !strings.EqualFold(obj.SHA256, s.SHA256) {
				return report, fmt.Errorf("repair target %s returned untrusted object metadata", dst.ID)
			}
			created = append(created, createdTargetObject{target: dst, locator: obj.ID})
			if old, ok := targetMap[s.Provider]; ok && s.Object != "" && (old.ID != dst.ID || s.Object != obj.ID) {
				oldObjects = append(oldObjects, oldTargetObject{target: old, locator: s.Object})
			}
			remaining[dst.ID] -= int64(len(data))
			s.Provider = dst.ID
			s.Object = obj.ID
			blockRepaired++
			changed = true
		}
		if blockRepaired > 0 {
			report.RepairedBlocks++
			report.RepairedShards += blockRepaired
		}
	}
	if !changed {
		return report, nil
	}
	m.Generation++
	if err := e.commitTargetManifest(ctx, manifestPath, m, key, targets, &created); err != nil {
		return report, fmt.Errorf("repair data written but manifest commit failed; old references remain authoritative: %w", err)
	}
	committed = true
	report.ManifestGeneration = m.Generation

	// Old corrupt/missing locators are now unreferenced. Cleanup failure leaves a
	// harmless duplicate/orphan and is reported as a warning, never rolled back.
	for _, old := range oldObjects {
		if err := old.target.Delete(ctx, old.locator); err != nil {
			report.CleanupWarnings = append(report.CleanupWarnings, fmt.Sprintf("%s/%s: %v", old.target.ID, old.locator, err))
		}
	}
	return report, nil
}
