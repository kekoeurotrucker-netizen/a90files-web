package core

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/compression"
	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/erasure"
	"github.com/vaultpool-project/vaultpool/internal/health"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/planner"
	"github.com/vaultpool-project/vaultpool/internal/provider"
	"github.com/vaultpool-project/vaultpool/internal/safefile"
)

var blockAADPrefix = []byte("vaultpool-block-v1:")

func blockAAD(fileID string, index int) []byte {
	return []byte(fmt.Sprintf("%s%s:%d", blockAADPrefix, fileID, index))
}

type Config struct {
	BlockSize                int
	DataShards               int
	ParityShards             int
	MinProviderFailureMargin int
	// SkipCompression is used for formats that are already compressed. It avoids
	// spending CPU on data that cannot usefully shrink before encryption.
	SkipCompression bool
}

// DefaultConfig is deliberately conservative for M0.1: losing one complete
// provider must still leave one further shard of recovery margin.
func DefaultConfig() Config {
	// Smaller blocks let media streaming begin sooner; existing manifests keep their own layout.
	return Config{BlockSize: 1 << 20, DataShards: 4, ParityShards: 2, MinProviderFailureMargin: 1}
}

type AuditBlock struct {
	Index, Total, Valid, Missing, Corrupt, Unavailable, Margin int
	// ProviderFailureMargin is the recovery margin that would remain if the
	// currently worst single provider disappeared in addition to current faults.
	ProviderFailureMargin int
}

type AuditReport struct {
	FileName                   string
	Blocks                     []AuditBlock
	WorstMargin                int
	WorstProviderFailureMargin int
	Healthy                    bool
	MeetsProviderSafety        bool
	Risk                       health.Assessment
}

type Engine struct {
	codec   compression.Codec
	codecMu sync.Mutex
	rs      erasure.Coder
	cfg     Config
}

func New(cfg Config) (*Engine, error) {
	if cfg.BlockSize <= 0 || cfg.DataShards < 1 || cfg.ParityShards < 1 {
		return nil, errors.New("invalid config")
	}
	if cfg.MinProviderFailureMargin < 0 || cfg.MinProviderFailureMargin >= cfg.ParityShards {
		return nil, fmt.Errorf("invalid provider failure margin %d for parity %d", cfg.MinProviderFailureMargin, cfg.ParityShards)
	}
	c, err := compression.New()
	if err != nil {
		return nil, err
	}
	r, err := erasure.New(cfg.DataShards, cfg.ParityShards)
	if err != nil {
		return nil, err
	}
	return &Engine{codec: c, rs: r, cfg: cfg}, nil
}

func (e *Engine) Close() {
	if c, ok := e.codec.(interface{ Close() }); ok {
		c.Close()
	}
}

func (e *Engine) tryCompress(src []byte) ([]byte, bool, error) {
	if e.cfg.SkipCompression {
		return append([]byte(nil), src...), false, nil
	}
	e.codecMu.Lock()
	defer e.codecMu.Unlock()
	return e.codec.TryCompress(src)
}

func (e *Engine) decompress(name string, src []byte) ([]byte, error) {
	e.codecMu.Lock()
	defer e.codecMu.Unlock()
	return compression.DecompressNamed(name, e.codec, src)
}

func coderFor(data, parity int) (erasure.Coder, error) {
	return erasure.New(data, parity)
}

func placementCounts(providerNames []string, total int) map[string]int {
	counts := make(map[string]int, len(providerNames))
	for i := 0; i < total; i++ {
		counts[providerNames[i%len(providerNames)]]++
	}
	return counts
}

func minMarginAfterProviderLoss(counts map[string]int, totalValid, dataShards int) int {
	if len(counts) == 0 {
		return totalValid - dataShards
	}
	worst := totalValid - dataShards
	for _, n := range counts {
		m := totalValid - n - dataShards
		if m < worst {
			worst = m
		}
	}
	return worst
}

func validatePlacement(providers []provider.Local, total, data, parity, minProviderFailureMargin int) error {
	if len(providers) == 0 {
		return errors.New("no providers")
	}
	names := make([]string, len(providers))
	for i, p := range providers {
		names[i] = p.Name
	}
	counts := placementCounts(names, total)
	margin := minMarginAfterProviderLoss(counts, total, data)
	if margin < minProviderFailureMargin {
		maxPer := 0
		for _, n := range counts {
			if n > maxPer {
				maxPer = n
			}
		}
		return fmt.Errorf("unsafe provider layout: worst provider holds %d/%d shards; losing it leaves recovery margin %d, required >= %d (data=%d parity=%d providers=%d)", maxPer, total, margin, minProviderFailureMargin, data, parity, len(providers))
	}
	return nil
}

func sortedProviders(ps []provider.Local) []provider.Local {
	out := append([]provider.Local(nil), ps...)
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}

func (e *Engine) Pack(input, pool, manifestPath string, key []byte) error {
	ps, err := provider.Discover(pool)
	if err != nil {
		return err
	}
	ps = sortedProviders(ps)
	total := e.cfg.DataShards + e.cfg.ParityShards
	if err := validatePlacement(ps, total, e.cfg.DataShards, e.cfg.ParityShards, e.cfg.MinProviderFailureMargin); err != nil {
		return err
	}
	f, err := os.Open(input)
	if err != nil {
		return err
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil {
		return err
	}
	fileID, err := cryptokit.RandomID(16)
	if err != nil {
		return err
	}
	m := &manifest.Manifest{
		Version:                  manifest.Version,
		Generation:               1,
		FileID:                   fileID,
		FileName:                 filepath.Base(input),
		OriginalSize:             st.Size(),
		BlockSize:                e.cfg.BlockSize,
		DataShards:               e.cfg.DataShards,
		ParityShards:             e.cfg.ParityShards,
		MinProviderFailureMargin: e.cfg.MinProviderFailureMargin,
		CreatedAt:                time.Now().UTC(),
	}
	fileHash := sha256.New()
	reader := bufio.NewReaderSize(io.TeeReader(f, fileHash), e.cfg.BlockSize)
	for idx := 0; ; idx++ {
		plain := make([]byte, e.cfg.BlockSize)
		n, readErr := io.ReadFull(reader, plain)
		if readErr == io.EOF {
			break
		}
		if readErr != nil && readErr != io.ErrUnexpectedEOF {
			return readErr
		}
		plain = plain[:n]
		stored, compressed, err := e.tryCompress(plain)
		if err != nil {
			return fmt.Errorf("compress block %d: %w", idx, err)
		}
		aad := blockAAD(m.FileID, idx)
		ciphertext, err := cryptokit.Seal(key, stored, aad)
		if err != nil {
			return fmt.Errorf("encrypt block %d: %w", idx, err)
		}
		shards, shardSize, err := e.rs.Encode(ciphertext)
		if err != nil {
			return fmt.Errorf("erasure block %d: %w", idx, err)
		}
		b := manifest.Block{Index: idx, PlainSize: len(plain), StoredSize: len(stored), Compressed: compressed, Compression: e.codec.Name(), CipherSize: len(ciphertext), ShardSize: shardSize}
		for si, data := range shards {
			p := ps[si%len(ps)]
			object := fmt.Sprintf("objects/%s/%08d/shard-%03d.cps", m.FileID, idx, si)
			sum := provider.HashBytes(data)
			if err := p.PutVerified(object, data, sum); err != nil {
				return fmt.Errorf("store block %d shard %d provider %s: %w", idx, si, p.Name, err)
			}
			b.Shards = append(b.Shards, manifest.Shard{Index: si, Provider: p.Name, Object: object, SHA256: sum})
		}
		m.Blocks = append(m.Blocks, b)
		if readErr == io.ErrUnexpectedEOF {
			break
		}
	}
	m.OriginalSHA256 = hex.EncodeToString(fileHash.Sum(nil))
	return e.commitManifest(manifestPath, m, key, ps)
}

type packPreflight struct {
	OriginalSize   int64
	OriginalSHA256 string
	PayloadBytes   []int64
	StoredBytes    int64
}

func sumPayloadBytes(payload []int64) int64 {
	var total int64
	for _, size := range payload {
		total += size
	}
	return total
}

// preflightPack computes exact post-compression/pre-encryption block sizes and
// the original file hash without writing anything to a provider. Seal adds a
// deterministic amount of overhead, so the planner can reserve exact capacity
// before the first shard is created.
func (e *Engine) preflightPack(input string) (packPreflight, error) {
	f, err := os.Open(input)
	if err != nil {
		return packPreflight{}, err
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil {
		return packPreflight{}, err
	}
	h := sha256.New()
	reader := bufio.NewReaderSize(io.TeeReader(f, h), e.cfg.BlockSize)
	result := packPreflight{OriginalSize: st.Size()}
	for idx := 0; ; idx++ {
		plain := make([]byte, e.cfg.BlockSize)
		n, readErr := io.ReadFull(reader, plain)
		if readErr == io.EOF {
			break
		}
		if readErr != nil && readErr != io.ErrUnexpectedEOF {
			return packPreflight{}, readErr
		}
		plain = plain[:n]
		stored, _, err := e.tryCompress(plain)
		if err != nil {
			return packPreflight{}, fmt.Errorf("preflight compress block %d: %w", idx, err)
		}
		result.StoredBytes += int64(len(stored))
		sealedSize, err := cryptokit.SealedSize(len(stored))
		if err != nil {
			return packPreflight{}, fmt.Errorf("preflight sealed size block %d: %w", idx, err)
		}
		result.PayloadBytes = append(result.PayloadBytes, int64(sealedSize))
		if readErr == io.ErrUnexpectedEOF {
			break
		}
	}
	result.OriginalSHA256 = hex.EncodeToString(h.Sum(nil))
	return result, nil
}

func mockPlannerTargets(ps []provider.Local) []planner.Target {
	// Local providers are destructive-test doubles, not real cloud accounts.
	// Capacity/object-limit behavior is tested directly in internal/planner;
	// the local filesystem pool intentionally supplies a very large logical
	// capacity so integration tests exercise placement without depending on the
	// sandbox host's free-space reporting.
	const mockFree = int64(math.MaxInt64 / 1024)
	out := make([]planner.Target, 0, len(ps))
	for _, p := range ps {
		out = append(out, planner.Target{ID: p.Name, FailureDomain: p.Name, FreeBytes: mockFree, Enabled: true})
	}
	return out
}

// PackAdaptive is the M0.2 integration path. It plans the complete file before
// any provider write, then uses the selected file-wide Reed-Solomon geometry
// with per-block placements. The proven fixed M0.1 Pack remains available
// until this path completes destructive regression testing.
func (e *Engine) PackAdaptive(input, pool, manifestPath string, key []byte) error {
	ps, err := provider.Discover(pool)
	if err != nil {
		return err
	}
	ps = sortedProviders(ps)
	pre, err := e.preflightPack(input)
	if err != nil {
		return err
	}
	if len(pre.PayloadBytes) == 0 {
		return errors.New("empty files are not supported yet")
	}
	policy := planner.DefaultPolicy()
	policy.MinProviderFailureMargin = e.cfg.MinProviderFailureMargin
	plan, err := planner.BuildBatch(pre.PayloadBytes, mockPlannerTargets(ps), policy)
	if err != nil {
		return fmt.Errorf("adaptive storage plan: %w", err)
	}
	rs, err := coderFor(plan.DataShards, plan.ParityShards)
	if err != nil {
		return fmt.Errorf("adaptive erasure coder: %w", err)
	}
	pm := providerMap(ps)

	f, err := os.Open(input)
	if err != nil {
		return err
	}
	defer f.Close()
	fileID, err := cryptokit.RandomID(16)
	if err != nil {
		return err
	}
	m := &manifest.Manifest{
		Version:                  manifest.Version,
		Generation:               1,
		FileID:                   fileID,
		FileName:                 filepath.Base(input),
		OriginalSize:             pre.OriginalSize,
		BlockSize:                e.cfg.BlockSize,
		DataShards:               plan.DataShards,
		ParityShards:             plan.ParityShards,
		MinProviderFailureMargin: plan.MinProviderFailureMargin,
		CreatedAt:                time.Now().UTC(),
	}

	fileHash := sha256.New()
	reader := bufio.NewReaderSize(io.TeeReader(f, fileHash), e.cfg.BlockSize)
	for idx := 0; ; idx++ {
		plain := make([]byte, e.cfg.BlockSize)
		n, readErr := io.ReadFull(reader, plain)
		if readErr == io.EOF {
			break
		}
		if readErr != nil && readErr != io.ErrUnexpectedEOF {
			return readErr
		}
		if idx >= len(plan.Blocks) {
			return errors.New("input changed after preflight: unexpected additional block")
		}
		plain = plain[:n]
		stored, compressed, err := e.tryCompress(plain)
		if err != nil {
			return fmt.Errorf("compress block %d: %w", idx, err)
		}
		aad := blockAAD(m.FileID, idx)
		ciphertext, err := cryptokit.Seal(key, stored, aad)
		if err != nil {
			return fmt.Errorf("encrypt block %d: %w", idx, err)
		}
		bp := plan.Blocks[idx]
		if int64(len(ciphertext)) != bp.PayloadBytes {
			return fmt.Errorf("input/compression changed after preflight at block %d: planned payload=%d actual=%d", idx, bp.PayloadBytes, len(ciphertext))
		}
		shards, shardSize, err := rs.Encode(ciphertext)
		if err != nil {
			return fmt.Errorf("erasure block %d: %w", idx, err)
		}
		if int64(shardSize) != bp.ShardBytes || len(shards) != len(bp.Placements) {
			return fmt.Errorf("planner/encoder mismatch at block %d", idx)
		}
		b := manifest.Block{Index: idx, PlainSize: len(plain), StoredSize: len(stored), Compressed: compressed, Compression: e.codec.Name(), CipherSize: len(ciphertext), ShardSize: shardSize}
		for si, data := range shards {
			placement := bp.Placements[si]
			p, ok := pm[placement.TargetID]
			if !ok {
				return fmt.Errorf("planned target %q disappeared before write", placement.TargetID)
			}
			object := fmt.Sprintf("objects/%s/%08d/shard-%03d.cps", m.FileID, idx, si)
			sum := provider.HashBytes(data)
			if err := p.PutVerified(object, data, sum); err != nil {
				return fmt.Errorf("store block %d shard %d provider %s: %w", idx, si, p.Name, err)
			}
			b.Shards = append(b.Shards, manifest.Shard{Index: si, Provider: p.Name, Object: object, SHA256: sum})
		}
		m.Blocks = append(m.Blocks, b)
		if readErr == io.ErrUnexpectedEOF {
			break
		}
	}
	if len(m.Blocks) != len(plan.Blocks) {
		return fmt.Errorf("input changed after preflight: planned blocks=%d actual=%d", len(plan.Blocks), len(m.Blocks))
	}
	m.OriginalSHA256 = hex.EncodeToString(fileHash.Sum(nil))
	if m.OriginalSHA256 != pre.OriginalSHA256 {
		return errors.New("input changed after preflight: SHA-256 mismatch; manifest not committed")
	}
	return e.commitManifest(manifestPath, m, key, ps)
}

func providerMap(ps []provider.Local) map[string]provider.Local {
	m := map[string]provider.Local{}
	for _, p := range ps {
		m[p.Name] = p
	}
	return m
}

func manifestReplicaObject(m *manifest.Manifest) string {
	return fmt.Sprintf("metadata/manifests/%s/generation-%020d.cpm", m.FileID, m.Generation)
}

// commitManifest seals once, atomically stores the local authoritative copy,
// then verifies an exact encrypted replica on every currently available provider.
// Callers must not delete superseded data until this function succeeds.
func (e *Engine) commitManifest(localPath string, m *manifest.Manifest, key []byte, ps []provider.Local) error {
	sealed, err := manifest.Seal(m, key)
	if err != nil {
		return err
	}
	if err := manifest.WriteAtomicBytes(localPath, sealed); err != nil {
		return fmt.Errorf("write local manifest: %w", err)
	}
	sum := provider.HashBytes(sealed)
	object := manifestReplicaObject(m)
	for _, p := range sortedProviders(ps) {
		if err := p.PutVerified(object, sealed, sum); err != nil {
			return fmt.Errorf("replicate manifest generation %d to %s: %w", m.Generation, p.Name, err)
		}
	}
	return nil
}

type RecoveryCandidate struct {
	FileID     string
	FileName   string
	Generation uint64
	Replicas   int
	sealed     []byte
	manifest   *manifest.Manifest
}

// DiscoverRecoverableManifests scans authenticated remote replicas and returns
// the newest unambiguous manifest for every file ID. Corrupt/unauthenticated
// replicas are ignored; conflicting authenticated copies of the same generation
// are treated as an integrity error rather than guessed around.
func (e *Engine) DiscoverRecoverableManifests(pool string, key []byte) ([]RecoveryCandidate, error) {
	ps, err := provider.Discover(pool)
	if err != nil {
		return nil, err
	}
	best := map[string]*RecoveryCandidate{}
	canonical := map[string][]byte{}
	for _, p := range ps {
		objects, err := p.List("metadata/manifests")
		if err != nil {
			return nil, fmt.Errorf("list manifest replicas on %s: %w", p.Name, err)
		}
		for _, object := range objects {
			sealed, err := p.Get(object)
			if err != nil {
				continue
			}
			m, err := manifest.Open(sealed, key)
			if err != nil {
				continue
			}
			canon, err := json.Marshal(m)
			if err != nil {
				return nil, err
			}
			c := best[m.FileID]
			if c == nil || m.Generation > c.Generation {
				best[m.FileID] = &RecoveryCandidate{FileID: m.FileID, FileName: m.FileName, Generation: m.Generation, Replicas: 1, sealed: sealed, manifest: m}
				canonical[m.FileID] = canon
				continue
			}
			if m.Generation == c.Generation {
				if !bytes.Equal(canon, canonical[m.FileID]) {
					return nil, fmt.Errorf("conflicting authenticated manifest replicas for file %s at generation %d", m.FileID, m.Generation)
				}
				c.Replicas++
			}
		}
	}
	out := make([]RecoveryCandidate, 0, len(best))
	for _, c := range best {
		out = append(out, *c)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].FileName == out[j].FileName {
			return out[i].FileID < out[j].FileID
		}
		return out[i].FileName < out[j].FileName
	})
	return out, nil
}

// RecoverManifest restores one file's newest authenticated manifest. If fileID
// is empty it is accepted only when the pool contains exactly one recoverable
// file, preventing accidental recovery of the wrong object in multi-file pools.
func (e *Engine) RecoverManifest(pool, out string, key []byte, fileID string) (*manifest.Manifest, error) {
	candidates, err := e.DiscoverRecoverableManifests(pool, key)
	if err != nil {
		return nil, err
	}
	if len(candidates) == 0 {
		return nil, errors.New("no authenticated manifest replica found")
	}
	var chosen *RecoveryCandidate
	if fileID == "" {
		if len(candidates) != 1 {
			return nil, fmt.Errorf("%d recoverable files found; select an explicit file ID", len(candidates))
		}
		chosen = &candidates[0]
	} else {
		for i := range candidates {
			if candidates[i].FileID == fileID {
				chosen = &candidates[i]
				break
			}
		}
		if chosen == nil {
			return nil, fmt.Errorf("recoverable file ID %q not found", fileID)
		}
	}
	if err := manifest.WriteAtomicBytes(out, chosen.sealed); err != nil {
		return nil, err
	}
	return chosen.manifest, nil
}

func (e *Engine) loadBlock(b manifest.Block, pm map[string]provider.Local) ([][]byte, int, int) {
	shards := make([][]byte, len(b.Shards))
	missing, corrupt := 0, 0
	for _, s := range b.Shards {
		p, ok := pm[s.Provider]
		if !ok {
			missing++
			continue
		}
		data, err := p.Get(s.Object)
		if err != nil {
			missing++
			continue
		}
		if provider.HashBytes(data) != s.SHA256 {
			corrupt++
			continue
		}
		shards[s.Index] = data
	}
	return shards, missing, corrupt
}

func (e *Engine) Restore(manifestPath, pool, out string, key []byte) error {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return err
	}
	rs, err := coderFor(m.DataShards, m.ParityShards)
	if err != nil {
		return fmt.Errorf("manifest erasure geometry: %w", err)
	}
	ps, err := provider.Discover(pool)
	if err != nil {
		return err
	}
	pm := providerMap(ps)
	dir := filepath.Dir(out)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".vaultpool-restore-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	ok := false
	defer func() {
		tmp.Close()
		if !ok {
			_ = os.Remove(tmpName)
		}
	}()
	h := sha256.New()
	w := io.MultiWriter(tmp, h)
	for _, b := range m.Blocks {
		shards, missing, corrupt := e.loadBlock(b, pm)
		if missing+corrupt > m.ParityShards {
			return fmt.Errorf("block %d unrecoverable: missing=%d corrupt=%d parity=%d", b.Index, missing, corrupt, m.ParityShards)
		}
		if missing+corrupt > 0 {
			if err := rs.Reconstruct(shards); err != nil {
				return fmt.Errorf("reconstruct block %d: %w", b.Index, err)
			}
		}
		ciphertext, err := rs.Join(shards, b.CipherSize)
		if err != nil {
			return fmt.Errorf("join block %d: %w", b.Index, err)
		}
		aad := blockAAD(m.FileID, b.Index)
		stored, err := cryptokit.Open(key, ciphertext, aad)
		if err != nil {
			return fmt.Errorf("authenticate/decrypt block %d: %w", b.Index, err)
		}
		plain := stored
		if b.Compressed {
			plain, err = e.decompress(b.Compression, stored)
			if err != nil {
				return fmt.Errorf("decompress block %d: %w", b.Index, err)
			}
		}
		if len(plain) != b.PlainSize {
			return fmt.Errorf("block %d size mismatch", b.Index)
		}
		if _, err := w.Write(plain); err != nil {
			return err
		}
	}
	if err := tmp.Sync(); err != nil {
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	got := hex.EncodeToString(h.Sum(nil))
	if got != m.OriginalSHA256 {
		return fmt.Errorf("final SHA-256 mismatch: got %s want %s", got, m.OriginalSHA256)
	}
	if err := safefile.CommitTemp(tmpName, out); err != nil {
		return err
	}
	ok = true
	return nil
}

func currentProviderFailureMargin(b manifest.Block, pm map[string]provider.Local, dataShards int) (valid, missing, corrupt, margin, providerMargin int) {
	counts := map[string]int{}
	valid = 0
	for _, s := range b.Shards {
		p, ok := pm[s.Provider]
		if !ok {
			missing++
			continue
		}
		data, err := p.Get(s.Object)
		if err != nil {
			missing++
			continue
		}
		if provider.HashBytes(data) != s.SHA256 {
			corrupt++
			continue
		}
		valid++
		counts[s.Provider]++
	}
	margin = valid - dataShards
	providerMargin = minMarginAfterProviderLoss(counts, valid, dataShards)
	return
}

func (e *Engine) Audit(manifestPath, pool string, key []byte) (AuditReport, error) {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return AuditReport{}, err
	}
	ps, err := provider.Discover(pool)
	if err != nil {
		return AuditReport{}, err
	}
	pm := providerMap(ps)
	r := AuditReport{
		FileName:                   m.FileName,
		WorstMargin:                m.ParityShards,
		WorstProviderFailureMargin: m.ParityShards,
		Healthy:                    true,
		MeetsProviderSafety:        true,
		Risk: health.Assessment{
			Level:                   health.VeryLow,
			TotalShards:             m.DataShards + m.ParityShards,
			ValidShards:             m.DataShards + m.ParityShards,
			RecoveryMargin:          m.ParityShards,
			ProviderFailureMargin:   m.ParityShards,
			ProviderSafetySatisfied: true,
		},
	}
	for _, b := range m.Blocks {
		valid, missing, corrupt, margin, providerMargin := currentProviderFailureMargin(b, pm, m.DataShards)
		assessment := health.Assess(health.Input{
			DataShards:             m.DataShards,
			ParityShards:           m.ParityShards,
			ValidShards:            valid,
			ProviderFailureMargin:  providerMargin,
			RequiredProviderMargin: m.MinProviderFailureMargin,
		})
		r.Risk = health.Worse(r.Risk, assessment)
		if margin < r.WorstMargin {
			r.WorstMargin = margin
		}
		if providerMargin < r.WorstProviderFailureMargin {
			r.WorstProviderFailureMargin = providerMargin
		}
		if margin < m.ParityShards {
			r.Healthy = false
		}
		if providerMargin < m.MinProviderFailureMargin {
			r.MeetsProviderSafety = false
		}
		r.Blocks = append(r.Blocks, AuditBlock{Index: b.Index, Total: len(b.Shards), Valid: valid, Missing: missing, Corrupt: corrupt, Margin: margin, ProviderFailureMargin: providerMargin})
	}
	if len(m.Blocks) == 0 {
		r.Risk = health.Assess(health.Input{
			DataShards:             m.DataShards,
			ParityShards:           m.ParityShards,
			ValidShards:            m.DataShards + m.ParityShards,
			ProviderFailureMargin:  m.ParityShards,
			RequiredProviderMargin: m.MinProviderFailureMargin,
		})
	}
	return r, nil
}

func blockProviderMarginAfterMove(b manifest.Block, shardIndex int, destination string, dataShards int) int {
	counts := map[string]int{}
	for _, s := range b.Shards {
		name := s.Provider
		if s.Index == shardIndex {
			name = destination
		}
		counts[name]++
	}
	return minMarginAfterProviderLoss(counts, len(b.Shards), dataShards)
}

// MoveShard performs the VaultPool migration invariant for one shard:
// copy -> verify destination -> commit manifest -> delete source.
// If deletion of the source fails after the manifest commit, the safe outcome is
// a harmless duplicate rather than data loss; the returned error tells the caller
// cleanup is still needed.
func (e *Engine) MoveShard(manifestPath, pool string, key []byte, blockIndex, shardIndex int, destinationProvider string) error {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return err
	}
	if blockIndex < 0 || blockIndex >= len(m.Blocks) {
		return fmt.Errorf("invalid block index %d", blockIndex)
	}
	b := &m.Blocks[blockIndex]
	if shardIndex < 0 || shardIndex >= len(b.Shards) {
		return fmt.Errorf("invalid shard index %d", shardIndex)
	}
	ps, err := provider.Discover(pool)
	if err != nil {
		return err
	}
	pm := providerMap(ps)
	s := &b.Shards[shardIndex]
	src, ok := pm[s.Provider]
	if !ok {
		return fmt.Errorf("source provider %q unavailable", s.Provider)
	}
	dst, ok := pm[destinationProvider]
	if !ok {
		return fmt.Errorf("destination provider %q unavailable", destinationProvider)
	}
	if src.Name == dst.Name {
		return nil
	}
	if margin := blockProviderMarginAfterMove(*b, s.Index, dst.Name, m.DataShards); margin < m.MinProviderFailureMargin {
		return fmt.Errorf("move rejected: destination would reduce provider-failure margin to %d; required >= %d", margin, m.MinProviderFailureMargin)
	}
	data, err := src.Get(s.Object)
	if err != nil {
		return fmt.Errorf("read source: %w", err)
	}
	if got := provider.HashBytes(data); got != s.SHA256 {
		return fmt.Errorf("source integrity mismatch: got %s want %s", got, s.SHA256)
	}
	if err := dst.PutVerified(s.Object, data, s.SHA256); err != nil {
		return fmt.Errorf("write/verify destination: %w", err)
	}
	if got, err := dst.Hash(s.Object); err != nil || got != s.SHA256 {
		if err != nil {
			return fmt.Errorf("destination verification: %w", err)
		}
		return fmt.Errorf("destination verification hash mismatch")
	}

	oldProvider := s.Provider
	oldGeneration := m.Generation
	s.Provider = dst.Name
	m.Generation++
	if err := e.commitManifest(manifestPath, m, key, ps); err != nil {
		// Source remains intact. A partially replicated newer manifest is also
		// safe because it points at the already-verified destination.
		s.Provider = oldProvider
		m.Generation = oldGeneration
		return fmt.Errorf("manifest commit/replication failed; source preserved: %w", err)
	}
	if err := src.Delete(s.Object); err != nil {
		return fmt.Errorf("manifest committed to destination, but old duplicate could not be deleted: %w", err)
	}
	return nil
}

type RepairReport struct {
	FileName                  string
	RepairedShards            int
	RepairedBlocks            int
	DeferredUnavailableShards int
	ManifestGeneration        uint64
	CleanupWarnings           []string
}

func usedProvidersForBlock(b manifest.Block) map[string]bool {
	used := make(map[string]bool, len(b.Shards))
	for _, s := range b.Shards {
		used[s.Provider] = true
	}
	return used
}

func chooseRepairProvider(b manifest.Block, shardIndex int, ps []provider.Local, dataShards, minMargin int) (provider.Local, error) {
	used := usedProvidersForBlock(b)
	for _, p := range sortedProviders(ps) {
		if used[p.Name] {
			continue
		}
		if blockProviderMarginAfterMove(b, shardIndex, p.Name, dataShards) >= minMargin {
			return p, nil
		}
	}
	// If no unused provider works, allow a used one only if the configured
	// provider-failure margin is still preserved. This supports weaker policies
	// while never silently weakening the configured safety target.
	for _, p := range sortedProviders(ps) {
		if blockProviderMarginAfterMove(b, shardIndex, p.Name, dataShards) >= minMargin {
			return p, nil
		}
	}
	return provider.Local{}, errors.New("no available provider can restore the configured provider-failure margin; add/reconnect an independent provider")
}

// RepairProtection reconstructs missing/corrupt shards and restores the
// configured redundancy. It never rebalances healthy shards. The caller is
// expected to invoke it only after explicit user approval.
func (e *Engine) RepairProtection(manifestPath, pool string, key []byte) (RepairReport, error) {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return RepairReport{}, err
	}
	rs, err := coderFor(m.DataShards, m.ParityShards)
	if err != nil {
		return RepairReport{}, fmt.Errorf("manifest erasure geometry: %w", err)
	}
	ps, err := provider.Discover(pool)
	if err != nil {
		return RepairReport{}, err
	}
	pm := providerMap(ps)
	report := RepairReport{FileName: m.FileName, ManifestGeneration: m.Generation}
	changed := false
	for bi := range m.Blocks {
		b := &m.Blocks[bi]
		shards, missing, corrupt := e.loadBlock(*b, pm)
		if missing+corrupt == 0 {
			continue
		}
		if missing+corrupt > m.ParityShards {
			return report, fmt.Errorf("block %d cannot be repaired: missing=%d corrupt=%d parity=%d", b.Index, missing, corrupt, m.ParityShards)
		}
		if err := rs.Reconstruct(shards); err != nil {
			return report, fmt.Errorf("reconstruct block %d: %w", b.Index, err)
		}
		blockRepaired := 0
		for si := range b.Shards {
			s := &b.Shards[si]
			p, providerExists := pm[s.Provider]
			valid := false
			if providerExists {
				if data, err := p.Get(s.Object); err == nil && provider.HashBytes(data) == s.SHA256 {
					valid = true
				}
			}
			if valid {
				continue
			}
			target := p
			if !providerExists {
				target, err = chooseRepairProvider(*b, s.Index, ps, m.DataShards, m.MinProviderFailureMargin)
				if err != nil {
					return report, fmt.Errorf("block %d shard %d: %w", b.Index, s.Index, err)
				}
			}
			data := shards[s.Index]
			sum := provider.HashBytes(data)
			if sum != s.SHA256 {
				return report, fmt.Errorf("reconstructed block %d shard %d hash mismatch: got %s want %s", b.Index, s.Index, sum, s.SHA256)
			}
			if err := target.PutVerified(s.Object, data, s.SHA256); err != nil {
				return report, fmt.Errorf("repair block %d shard %d to %s: %w", b.Index, s.Index, target.Name, err)
			}
			s.Provider = target.Name
			blockRepaired++
			changed = true
		}
		if blockRepaired > 0 {
			report.RepairedBlocks++
			report.RepairedShards += blockRepaired
		}
	}
	if !changed {
		return report, nil
	}
	m.Generation++
	if err := e.commitManifest(manifestPath, m, key, ps); err != nil {
		return report, fmt.Errorf("repair data written but manifest commit/replication failed; no old data was deleted: %w", err)
	}
	report.ManifestGeneration = m.Generation
	return report, nil
}
