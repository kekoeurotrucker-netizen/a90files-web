package core

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/cryptokit"
	"github.com/vaultpool-project/vaultpool/internal/manifest"
	"github.com/vaultpool-project/vaultpool/internal/planner"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/safefile"
	"github.com/vaultpool-project/vaultpool/internal/storage"
)

type createdTargetObject struct {
	target     storage.Target
	locator    string
	isManifest bool
}

// cleanupTargetObjects preserves recoverability over tidiness. Manifest replicas
// are removed first. If even one authenticated manifest replica cannot be
// removed, newly-created data shards are deliberately retained so a surviving
// manifest can never be left pointing at shards VaultPool itself deleted.
func cleanupTargetObjects(ctx context.Context, created []createdTargetObject) error {
	var manifestErrs []error
	for i := len(created) - 1; i >= 0; i-- {
		c := created[i]
		if !c.isManifest {
			continue
		}
		if err := c.target.Delete(ctx, c.locator); err != nil {
			manifestErrs = append(manifestErrs, fmt.Errorf("cleanup manifest %s/%s: %w", c.target.ID, c.locator, err))
		}
	}
	if len(manifestErrs) != 0 {
		return fmt.Errorf("manifest cleanup incomplete; retained new data shards for recoverability: %w", errors.Join(manifestErrs...))
	}
	var dataErrs []error
	for i := len(created) - 1; i >= 0; i-- {
		c := created[i]
		if c.isManifest {
			continue
		}
		if err := c.target.Delete(ctx, c.locator); err != nil {
			dataErrs = append(dataErrs, fmt.Errorf("cleanup data %s/%s: %w", c.target.ID, c.locator, err))
		}
	}
	return errors.Join(dataErrs...)
}

func (e *Engine) commitTargetManifest(ctx context.Context, manifestPath string, m *manifest.Manifest, key []byte, targets []storage.Target, created *[]createdTargetObject) error {
	sealed, err := manifest.Seal(m, key)
	if err != nil {
		return err
	}
	if int64(len(sealed)) > manifest.MaxSealedBytes {
		return fmt.Errorf("sealed manifest exceeds current recovery-safe limit: %d > %d bytes", len(sealed), manifest.MaxSealedBytes)
	}
	for _, t := range targets {
		if !t.Enabled {
			continue
		}
		if t.MaxObjectBytes > 0 && int64(len(sealed)) > t.MaxObjectBytes {
			return fmt.Errorf("manifest cannot fit target %s object limit: %d > %d bytes", t.ID, len(sealed), t.MaxObjectBytes)
		}
	}
	manifestHash := remoteobject.SHA256Bytes(sealed)
	manifestKey := manifestReplicaObject(m)
	for _, t := range storage.Sorted(targets) {
		if err := ctx.Err(); err != nil {
			return err
		}
		if !t.Enabled {
			continue
		}
		obj, err := t.PutVerified(ctx, manifestKey, sealed, manifestHash)
		if err != nil {
			return fmt.Errorf("replicate manifest generation %d to %s: %w", m.Generation, t.ID, err)
		}
		*created = append(*created, createdTargetObject{target: t, locator: obj.ID, isManifest: true})
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := manifest.WriteAtomicBytes(manifestPath, sealed); err != nil {
		return fmt.Errorf("write local manifest: %w", err)
	}
	return nil
}

// TransferProgress reports coarse-grained progress without exposing plaintext
// content or provider credentials. It is intentionally file-relative: callers
// can display it, persist only sanitized fields, and cancel via the context.
type TransferProgress struct {
	Phase            string
	BlocksDone       int
	BlocksTotal      int
	BytesProcessed   int64
	BytesTotal       int64
	OriginalBytes    int64
	StoredBytes      int64
	EncryptedBytes   int64
	DistributedBytes int64
}

type ProgressFunc func(TransferProgress)

func emitProgress(fn ProgressFunc, p TransferProgress) {
	if fn != nil {
		fn(p)
	}
}

func wipeBytes(b []byte) {
	for i := range b {
		b[i] = 0
	}
}

func wipeShards(shards [][]byte) {
	for _, shard := range shards {
		wipeBytes(shard)
	}
}

func validateTargetFileID(fileID string) error {
	if len(fileID) != 32 {
		return errors.New("invalid file id")
	}
	b, err := hex.DecodeString(fileID)
	if err != nil || len(b) != 16 {
		return errors.New("invalid file id")
	}
	return nil
}

// PackTargets is the cloud-capable storage path. A random FileID is generated
// before delegating to the explicit-ID variant used by the managed-file layer.
func (e *Engine) PackTargets(ctx context.Context, input, manifestPath string, key []byte, targets []storage.Target) error {
	fileID, err := cryptokit.RandomID(16)
	if err != nil {
		return err
	}
	return e.PackTargetsWithIDObserved(ctx, input, manifestPath, key, targets, fileID, nil)
}

// PackTargetsObserved is equivalent to PackTargets but reports safe progress.
func (e *Engine) PackTargetsObserved(ctx context.Context, input, manifestPath string, key []byte, targets []storage.Target, progress ProgressFunc) error {
	fileID, err := cryptokit.RandomID(16)
	if err != nil {
		return err
	}
	return e.PackTargetsWithIDObserved(ctx, input, manifestPath, key, targets, fileID, progress)
}

// PackTargetsWithID lets the recovery layer establish durable key replicas
// before any data object is uploaded. This ordering deliberately prefers a tiny
// orphan recovery record over remote data whose encryption key could be lost.
func (e *Engine) PackTargetsWithID(ctx context.Context, input, manifestPath string, key []byte, targets []storage.Target, fileID string) error {
	return e.PackTargetsWithIDObserved(ctx, input, manifestPath, key, targets, fileID, nil)
}

func (e *Engine) PackTargetsWithIDObserved(ctx context.Context, input, manifestPath string, key []byte, targets []storage.Target, fileID string, progress ProgressFunc) (err error) {
	if err := validateTargetFileID(fileID); err != nil {
		return err
	}
	if err := storage.ValidateTargets(targets); err != nil {
		return err
	}
	targets = storage.Sorted(targets)
	emitProgress(progress, TransferProgress{Phase: "preflight"})
	pre, err := e.preflightPack(input)
	if err != nil {
		return err
	}
	if len(pre.PayloadBytes) == 0 {
		return errors.New("empty files are not supported yet")
	}
	policy := planner.DefaultPolicy()
	policy.MinProviderFailureMargin = e.cfg.MinProviderFailureMargin
	// Every enabled target receives an authenticated manifest replica. Reserve
	// the full currently-supported manifest ceiling before planning data so a
	// nearly-full account cannot accept all shards and then fail at commit. The
	// reserve is planning-only; providers consume only the manifest's real size.
	plannerTargets := storage.PlannerTargets(targets)
	for i := range plannerTargets {
		if !plannerTargets[i].Enabled {
			continue
		}
		if plannerTargets[i].FreeBytes <= manifest.MaxSealedBytes {
			return fmt.Errorf("target %s lacks manifest commit headroom: free=%d required>%d", plannerTargets[i].ID, plannerTargets[i].FreeBytes, manifest.MaxSealedBytes)
		}
		plannerTargets[i].FreeBytes -= manifest.MaxSealedBytes
	}
	plan, err := planner.BuildBatch(pre.PayloadBytes, plannerTargets, policy)
	if err != nil {
		return fmt.Errorf("adaptive storage plan: %w", err)
	}
	var distributedBytes int64
	for _, block := range plan.Blocks {
		distributedBytes += block.ShardBytes * int64(len(block.Placements))
	}
	stats := TransferProgress{
		BlocksTotal:      len(plan.Blocks),
		BytesTotal:       pre.OriginalSize,
		OriginalBytes:    pre.OriginalSize,
		StoredBytes:      pre.StoredBytes,
		EncryptedBytes:   sumPayloadBytes(pre.PayloadBytes),
		DistributedBytes: distributedBytes,
	}
	rs, err := coderFor(plan.DataShards, plan.ParityShards)
	if err != nil {
		return fmt.Errorf("adaptive erasure coder: %w", err)
	}
	targetMap := storage.ByID(targets)
	created := make([]createdTargetObject, 0)
	committed := false
	defer func() {
		if committed {
			return
		}
		cleanupCtx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		defer cancel()
		if cleanupErr := cleanupTargetObjects(cleanupCtx, created); cleanupErr != nil {
			if err == nil {
				err = cleanupErr
			} else {
				err = fmt.Errorf("%w; remote cleanup incomplete: %v", err, cleanupErr)
			}
		}
	}()

	f, err := os.Open(input)
	if err != nil {
		return err
	}
	defer f.Close()
	m := &manifest.Manifest{
		Version:                  manifest.Version,
		Generation:               1,
		FileID:                   fileID,
		FileName:                 filepath.Base(input),
		OriginalSize:             pre.OriginalSize,
		BlockSize:                e.cfg.BlockSize,
		DataShards:               plan.DataShards,
		ParityShards:             plan.ParityShards,
		MinProviderFailureMargin: plan.MinProviderFailureMargin,
		CreatedAt:                time.Now().UTC(),
	}
	fileHash := sha256.New()
	reader := bufio.NewReaderSize(io.TeeReader(f, fileHash), e.cfg.BlockSize)
	var processed int64
	for idx := 0; ; idx++ {
		if err := ctx.Err(); err != nil {
			return err
		}
		plain := make([]byte, e.cfg.BlockSize)
		n, readErr := io.ReadFull(reader, plain)
		if readErr == io.EOF {
			break
		}
		if readErr != nil && readErr != io.ErrUnexpectedEOF {
			return readErr
		}
		if idx >= len(plan.Blocks) {
			return errors.New("input changed after preflight: unexpected additional block")
		}
		plain = plain[:n]
		stats.Phase = "compressing"
		stats.BlocksDone = idx
		stats.BytesProcessed = processed
		emitProgress(progress, stats)
		stored, compressed, err := e.tryCompress(plain)
		if err != nil {
			return fmt.Errorf("compress block %d: %w", idx, err)
		}
		stats.Phase = "encrypting"
		emitProgress(progress, stats)
		ciphertext, err := cryptokit.Seal(key, stored, blockAAD(m.FileID, idx))
		if err != nil {
			return fmt.Errorf("encrypt block %d: %w", idx, err)
		}
		bp := plan.Blocks[idx]
		if int64(len(ciphertext)) != bp.PayloadBytes {
			return fmt.Errorf("input/compression changed after preflight at block %d", idx)
		}
		stats.Phase = "fragmenting"
		emitProgress(progress, stats)
		shards, shardSize, err := rs.Encode(ciphertext)
		if err != nil {
			return fmt.Errorf("erasure block %d: %w", idx, err)
		}
		if int64(shardSize) != bp.ShardBytes || len(shards) != len(bp.Placements) {
			return fmt.Errorf("planner/encoder mismatch at block %d", idx)
		}
		b := manifest.Block{Index: idx, PlainSize: len(plain), StoredSize: len(stored), Compressed: compressed, Compression: e.codec.Name(), CipherSize: len(ciphertext), ShardSize: shardSize}
		stats.Phase = "uploading"
		emitProgress(progress, stats)
		for si, data := range shards {
			placement := bp.Placements[si]
			t, ok := targetMap[placement.TargetID]
			if !ok || !t.Enabled {
				return fmt.Errorf("planned target %q disappeared before write", placement.TargetID)
			}
			logicalKey := fmt.Sprintf("objects/%s/%08d/shard-%03d.cps", m.FileID, idx, si)
			sum := remoteobject.SHA256Bytes(data)
			obj, err := t.PutVerified(ctx, logicalKey, data, sum)
			if err != nil {
				return fmt.Errorf("store block %d shard %d target %s: %w", idx, si, t.ID, err)
			}
			if obj.ID == "" || obj.Size != int64(len(data)) || obj.SHA256 != sum {
				return fmt.Errorf("target %s returned untrusted object metadata", t.ID)
			}
			created = append(created, createdTargetObject{target: t, locator: obj.ID})
			b.Shards = append(b.Shards, manifest.Shard{Index: si, Provider: t.ID, Object: obj.ID, SHA256: sum})
		}
		m.Blocks = append(m.Blocks, b)
		processed += int64(len(plain))
		wipeShards(shards)
		wipeBytes(ciphertext)
		wipeBytes(stored)
		wipeBytes(plain)
		stats.Phase = "uploading"
		stats.BlocksDone = idx + 1
		stats.BytesProcessed = processed
		emitProgress(progress, stats)
		if readErr == io.ErrUnexpectedEOF {
			break
		}
	}
	if len(m.Blocks) != len(plan.Blocks) {
		return fmt.Errorf("input changed after preflight: planned blocks=%d actual=%d", len(plan.Blocks), len(m.Blocks))
	}
	m.OriginalSHA256 = hex.EncodeToString(fileHash.Sum(nil))
	if m.OriginalSHA256 != pre.OriginalSHA256 {
		return errors.New("input changed after preflight: SHA-256 mismatch; manifest not committed")
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	stats.Phase = "finalizing"
	stats.BlocksDone = len(plan.Blocks)
	stats.BytesProcessed = pre.OriginalSize
	emitProgress(progress, stats)
	// Replicate the authenticated manifest to every enabled target before the
	// local authoritative pointer is committed. Each replica is itself verified.
	if err := e.commitTargetManifest(ctx, manifestPath, m, key, targets, &created); err != nil {
		return err
	}
	committed = true
	stats.Phase = "complete"
	emitProgress(progress, stats)
	return nil
}

type targetBlockShardResult struct {
	index   int
	data    []byte
	err     error
	stopped bool
}

func drainTargetBlockResults(results <-chan targetBlockShardResult, n int) {
	for i := 0; i < n; i++ {
		r := <-results
		wipeBytes(r.data)
	}
}

func loadTargetBlock(ctx context.Context, b manifest.Block, targets map[string]storage.Target, dataShards int) ([][]byte, int, int, error) {
	shards := make([][]byte, len(b.Shards))
	missing, corrupt := 0, 0
	if dataShards <= 0 || dataShards > len(b.Shards) {
		dataShards = len(b.Shards)
	}
	readCtx, cancel := context.WithCancel(ctx)
	defer cancel()
	results := make(chan targetBlockShardResult, len(b.Shards))
	launched := 0
	for _, s := range b.Shards {
		t, ok := targets[s.Provider]
		if !ok || !t.Enabled {
			missing++
			continue
		}
		launched++
		go func(s manifest.Shard, t storage.Target) {
			data, err := t.GetVerified(readCtx, s.Object, int64(b.ShardSize), s.SHA256)
			if err != nil {
				results <- targetBlockShardResult{index: s.Index, err: err, stopped: readCtx.Err() != nil && ctx.Err() == nil}
				return
			}
			results <- targetBlockShardResult{index: s.Index, data: data}
		}(s, t)
	}
	valid := 0
	completed := 0
	for completed < launched {
		select {
		case <-ctx.Done():
			cancel()
			wipeShards(shards)
			go drainTargetBlockResults(results, launched-completed)
			return nil, missing, corrupt, ctx.Err()
		case r := <-results:
			completed++
			if r.err != nil {
				if r.stopped {
					missing++
				} else {
					// Remote stores deliberately collapse any failed integrity check into
					// an unusable shard. AuditTargets later distinguishes provider errors.
					corrupt++
				}
				continue
			}
			if r.index < 0 || r.index >= len(shards) || shards[r.index] != nil {
				wipeBytes(r.data)
				corrupt++
				continue
			}
			shards[r.index] = r.data
			valid++
			if valid >= dataShards {
				cancel()
				missing += len(b.Shards) - valid - missing - corrupt
				go drainTargetBlockResults(results, launched-completed)
				return shards, missing, corrupt, nil
			}
		}
	}
	return shards, missing, corrupt, nil
}

func (e *Engine) decodeTargetBlock(ctx context.Context, m *manifest.Manifest, b manifest.Block, rs interface {
	Reconstruct([][]byte) error
	Join([][]byte, int) ([]byte, error)
}, targetMap map[string]storage.Target, key []byte) ([]byte, error) {
	shards, missing, corrupt, err := loadTargetBlock(ctx, b, targetMap, m.DataShards)
	if err != nil {
		return nil, err
	}
	defer wipeShards(shards)
	if missing+corrupt > m.ParityShards {
		return nil, fmt.Errorf("block %d unrecoverable: missing=%d invalid=%d parity=%d", b.Index, missing, corrupt, m.ParityShards)
	}
	if missing+corrupt > 0 {
		if err := rs.Reconstruct(shards); err != nil {
			return nil, fmt.Errorf("reconstruct block %d: %w", b.Index, err)
		}
	}
	ciphertext, err := rs.Join(shards, b.CipherSize)
	if err != nil {
		return nil, fmt.Errorf("join block %d: %w", b.Index, err)
	}
	defer wipeBytes(ciphertext)
	stored, err := cryptokit.Open(key, ciphertext, blockAAD(m.FileID, b.Index))
	if err != nil {
		return nil, fmt.Errorf("authenticate/decrypt block %d: %w", b.Index, err)
	}
	plain := stored
	if b.Compressed {
		plain, err = e.decompress(b.Compression, stored)
		wipeBytes(stored)
		if err != nil {
			return nil, fmt.Errorf("decompress block %d: %w", b.Index, err)
		}
	}
	if len(plain) != b.PlainSize {
		if b.Compressed {
			wipeBytes(plain)
		} else {
			wipeBytes(stored)
		}
		return nil, fmt.Errorf("block %d size mismatch", b.Index)
	}
	return plain, nil
}

// ReadTargetsRange authenticates and reconstructs only the plaintext blocks
// needed for a random-access read. The authenticated manifest plus per-object
// SHA-256 and block AEAD provide integrity without reconstructing the whole
// file. This is the read primitive used by the optional Windows virtual drive.
func (e *Engine) ReadTargetsRange(ctx context.Context, manifestPath string, key []byte, targets []storage.Target, offset int64, length int) ([]byte, error) {
	if offset < 0 || length < 0 {
		return nil, errors.New("invalid read range")
	}
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return nil, err
	}
	if err := storage.ValidateTargets(targets); err != nil {
		return nil, err
	}
	if offset >= m.OriginalSize || length == 0 {
		return []byte{}, nil
	}
	wantEnd := offset + int64(length)
	if wantEnd < offset || wantEnd > m.OriginalSize {
		wantEnd = m.OriginalSize
	}
	rs, err := coderFor(m.DataShards, m.ParityShards)
	if err != nil {
		return nil, fmt.Errorf("manifest erasure geometry: %w", err)
	}
	targetMap := storage.ByID(targets)
	out := make([]byte, 0, int(wantEnd-offset))
	var pos int64
	for _, b := range m.Blocks {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		blockStart, blockEnd := pos, pos+int64(b.PlainSize)
		pos = blockEnd
		if blockEnd <= offset {
			continue
		}
		if blockStart >= wantEnd {
			break
		}
		plain, err := e.decodeTargetBlock(ctx, m, b, rs, targetMap, key)
		if err != nil {
			return nil, err
		}
		start, end := int64(0), int64(len(plain))
		if offset > blockStart {
			start = offset - blockStart
		}
		if wantEnd < blockEnd {
			end = wantEnd - blockStart
		}
		out = append(out, plain[start:end]...)
		wipeBytes(plain)
	}
	if int64(len(out)) != wantEnd-offset {
		wipeBytes(out)
		return nil, errors.New("manifest block layout did not cover requested range")
	}
	return out, nil
}

func (e *Engine) RestoreTargets(ctx context.Context, manifestPath, out string, key []byte, targets []storage.Target) error {
	return e.RestoreTargetsObserved(ctx, manifestPath, out, key, targets, nil)
}

func (e *Engine) RestoreTargetsObserved(ctx context.Context, manifestPath, out string, key []byte, targets []storage.Target, progress ProgressFunc) error {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return err
	}
	if err := storage.ValidateTargets(targets); err != nil {
		return err
	}
	emitProgress(progress, TransferProgress{Phase: "restoring", BlocksTotal: len(m.Blocks), BytesTotal: m.OriginalSize})
	rs, err := coderFor(m.DataShards, m.ParityShards)
	if err != nil {
		return fmt.Errorf("manifest erasure geometry: %w", err)
	}
	targetMap := storage.ByID(targets)
	dir := filepath.Dir(out)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".vaultpool-restore-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	ok := false
	defer func() {
		_ = tmp.Close()
		if !ok {
			_ = os.Remove(tmpName)
		}
	}()
	h := sha256.New()
	w := io.MultiWriter(tmp, h)
	var processed int64
	for i, b := range m.Blocks {
		if err := ctx.Err(); err != nil {
			return err
		}
		plain, err := e.decodeTargetBlock(ctx, m, b, rs, targetMap, key)
		if err != nil {
			return err
		}
		if _, err := w.Write(plain); err != nil {
			return err
		}
		processed += int64(len(plain))
		wipeBytes(plain)
		emitProgress(progress, TransferProgress{Phase: "restoring", BlocksDone: i + 1, BlocksTotal: len(m.Blocks), BytesProcessed: processed, BytesTotal: m.OriginalSize})
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if err := tmp.Sync(); err != nil {
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	emitProgress(progress, TransferProgress{Phase: "verifying", BlocksDone: len(m.Blocks), BlocksTotal: len(m.Blocks), BytesProcessed: m.OriginalSize, BytesTotal: m.OriginalSize})
	if got := hex.EncodeToString(h.Sum(nil)); got != m.OriginalSHA256 {
		return fmt.Errorf("final SHA-256 mismatch: got %s want %s", got, m.OriginalSHA256)
	}
	if err := safefile.CommitTemp(tmpName, out); err != nil {
		return err
	}
	ok = true
	emitProgress(progress, TransferProgress{Phase: "complete", BlocksDone: len(m.Blocks), BlocksTotal: len(m.Blocks), BytesProcessed: m.OriginalSize, BytesTotal: m.OriginalSize})
	return nil
}

// DeleteReport summarizes an explicitly requested deletion of VaultPool-owned
// remote objects. It deliberately only targets objects referenced by an
// authenticated manifest plus VaultPool metadata/recovery candidates; it never
// enumerates or deletes arbitrary user files from the cloud provider.
type DeleteReport struct {
	DataObjectsDeleted      int      `json:"data_objects_deleted"`
	ManifestReplicasDeleted int      `json:"manifest_replicas_deleted"`
	RecoveryRecordsDeleted  int      `json:"recovery_records_deleted"`
	Warnings                []string `json:"warnings,omitempty"`
}

// DeleteTargets best-effort deletes every VaultPool-owned remote object for one
// authenticated file. The local catalog should only be removed by callers after
// this returns nil, so a partial provider outage leaves enough metadata to retry.
func (e *Engine) DeleteTargets(ctx context.Context, manifestPath string, key []byte, targets []storage.Target) (DeleteReport, error) {
	m, err := manifest.Load(manifestPath, key)
	if err != nil {
		return DeleteReport{}, err
	}
	if err := storage.ValidateTargets(targets); err != nil {
		return DeleteReport{}, err
	}
	targetMap := storage.ByID(targets)
	var report DeleteReport
	var errs []error
	seenData := map[string]bool{}
	for _, b := range m.Blocks {
		for _, sh := range b.Shards {
			if err := ctx.Err(); err != nil {
				return report, err
			}
			t, ok := targetMap[sh.Provider]
			if !ok || !t.Enabled {
				errs = append(errs, fmt.Errorf("target %s unavailable for data shard deletion", sh.Provider))
				continue
			}
			key := t.ID + "\x00" + sh.Object
			if seenData[key] {
				continue
			}
			seenData[key] = true
			if err := t.Delete(ctx, sh.Object); err != nil {
				errs = append(errs, fmt.Errorf("delete data object %s/%s: %w", t.ID, sh.Object, err))
				continue
			}
			report.DataObjectsDeleted++
		}
	}

	for _, t := range storage.Sorted(targets) {
		if err := ctx.Err(); err != nil {
			return report, err
		}
		if !t.Enabled {
			errs = append(errs, fmt.Errorf("target %s unavailable for metadata deletion", t.ID))
			continue
		}
		if ms, ok := t.ManifestRecoveryStore(); ok {
			cands, err := ms.ListManifestCandidates(ctx, t.AccountID)
			if err != nil {
				errs = append(errs, fmt.Errorf("list manifest replicas on %s: %w", t.ID, err))
			} else {
				for _, c := range cands {
					if c.RecoveryID != m.FileID || c.Locator == "" {
						continue
					}
					if err := t.Delete(ctx, c.Locator); err != nil {
						errs = append(errs, fmt.Errorf("delete manifest replica %s/%s: %w", t.ID, c.Locator, err))
						continue
					}
					report.ManifestReplicasDeleted++
				}
			}
		} else {
			report.Warnings = append(report.Warnings, "El proveedor "+t.ID+" no permite enumerar réplicas de manifiesto para limpieza completa.")
		}
		if rs, ok := t.RecoveryRecordStore(); ok {
			cands, err := rs.ListRecoveryRecordCandidates(ctx, t.AccountID)
			if err != nil {
				errs = append(errs, fmt.Errorf("list recovery records on %s: %w", t.ID, err))
			} else {
				for _, c := range cands {
					if c.RecoveryID != m.FileID || c.Locator == "" {
						continue
					}
					if err := t.Delete(ctx, c.Locator); err != nil {
						errs = append(errs, fmt.Errorf("delete recovery record %s/%s: %w", t.ID, c.Locator, err))
						continue
					}
					report.RecoveryRecordsDeleted++
				}
			}
		} else {
			report.Warnings = append(report.Warnings, "El proveedor "+t.ID+" no permite enumerar registros de recuperación para limpieza completa.")
		}
	}
	if len(errs) != 0 {
		return report, errors.Join(errs...)
	}
	return report, nil
}
