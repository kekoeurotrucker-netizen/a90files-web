package webdavgeneric

import (
	"encoding/xml"
	"testing"
)

func TestNormalizeHTTPSRejectsUnsafeEndpoints(t *testing.T) {
	bad := []string{
		"http://example.com/dav",
		"https://localhost/dav",
		"https://server.local/dav",
		"https://user:pass@example.com/dav",
		"https://example.com/dav?token=secret",
	}
	for _, raw := range bad {
		if _, err := normalizeHTTPS(raw); err == nil {
			t.Fatalf("expected unsafe URL rejection for %q", raw)
		}
	}
	if _, err := normalizeHTTPS("https://dav.example.com/remote.php/dav/files/user/"); err != nil {
		t.Fatalf("valid HTTPS WebDAV URL rejected: %v", err)
	}
}

func TestQuotaParsing(t *testing.T) {
	raw := []byte(`<?xml version="1.0"?><d:multistatus xmlns:d="DAV:"><d:response><d:href>/dav/</d:href><d:propstat><d:prop><d:quota-available-bytes>900</d:quota-available-bytes><d:quota-used-bytes>100</d:quota-used-bytes></d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response></d:multistatus>`)
	var ms multistatus
	if err := xml.Unmarshal(raw, &ms); err != nil {
		t.Fatal(err)
	}
	used, total, ok := quotaFromResponses(ms.Responses)
	if !ok || used != 100 || total != 1000 {
		t.Fatalf("quota = used %d total %d ok %v", used, total, ok)
	}
}

func TestWebDAVURLStaysUnderConfiguredBase(t *testing.T) {
	base, err := normalizeHTTPS("https://dav.example.com/remote.php/dav/files/alice/")
	if err != nil {
		t.Fatal(err)
	}
	got := webdavURL(base, "VaultPool/vp-test.cps")
	want := "https://dav.example.com/remote.php/dav/files/alice/VaultPool/vp-test.cps"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}
