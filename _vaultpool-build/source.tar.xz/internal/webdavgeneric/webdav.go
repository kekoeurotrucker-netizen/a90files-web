package webdavgeneric

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"path"
	"strconv"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/catalog"
	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/remoteobject"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

const defaultRoot = "VaultPool"
const maxResponseBytes = int64(70 << 20)

type Credentials struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type AuditInput struct {
	Name        string `json:"name"`
	OfficialURL string `json:"official_url"`
	EndpointURL string `json:"endpoint_url"`
	Username    string `json:"username"`
	Password    string `json:"password"`
}

type AuditStep struct {
	ID     string `json:"id"`
	Label  string `json:"label"`
	Passed bool   `json:"passed"`
	Detail string `json:"detail"`
}

type AuditResult struct {
	Passed        bool             `json:"passed"`
	ReasonCode    string           `json:"reason_code,omitempty"`
	Reason        string           `json:"reason,omitempty"`
	Guidance      string           `json:"guidance,omitempty"`
	Steps         []AuditStep      `json:"steps"`
	TotalBytes    int64            `json:"total_bytes,omitempty"`
	UsedBytes     int64            `json:"used_bytes,omitempty"`
	FreeBytes     int64            `json:"free_bytes,omitempty"`
	PolicyVersion string           `json:"policy_version,omitempty"`
	Provider      catalog.Provider `json:"provider"`
	Credentials   Credentials      `json:"-"`
}

type davResponse struct {
	Href      string `xml:"href"`
	PropStats []struct {
		Prop struct {
			QuotaAvailable string `xml:"quota-available-bytes"`
			QuotaUsed      string `xml:"quota-used-bytes"`
			ContentLength  string `xml:"getcontentlength"`
			ResourceType   struct {
				Collection *struct{} `xml:"collection"`
			} `xml:"resourcetype"`
		} `xml:"prop"`
		Status string `xml:"status"`
	} `xml:"propstat"`
}
type multistatus struct {
	Responses []davResponse `xml:"response"`
}

func isPublicIP(ip net.IP) bool {
	return ip != nil && !ip.IsLoopback() && !ip.IsPrivate() && !ip.IsLinkLocalUnicast() && !ip.IsLinkLocalMulticast() && !ip.IsUnspecified() && !ip.IsMulticast()
}

func safeTransport() *http.Transport {
	d := &net.Dialer{Timeout: 8 * time.Second, KeepAlive: 20 * time.Second}
	return &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			host, port, err := net.SplitHostPort(addr)
			if err != nil {
				return nil, err
			}
			ips, err := net.DefaultResolver.LookupIPAddr(ctx, host)
			if err != nil {
				return nil, err
			}
			var last error
			for _, item := range ips {
				if !isPublicIP(item.IP) {
					continue
				}
				conn, err := d.DialContext(ctx, network, net.JoinHostPort(item.IP.String(), port))
				if err == nil {
					return conn, nil
				}
				last = err
			}
			if last != nil {
				return nil, last
			}
			return nil, errors.New("endpoint resolves only to local/private addresses")
		},
		TLSHandshakeTimeout:   8 * time.Second,
		ResponseHeaderTimeout: 12 * time.Second,
		IdleConnTimeout:       30 * time.Second,
		MaxIdleConns:          4,
	}
}

func safeClient(timeout time.Duration) *http.Client {
	return &http.Client{
		Transport: safeTransport(), Timeout: timeout,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}

func normalizeHTTPS(raw string) (*url.URL, error) {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return nil, err
	}
	if u.Scheme != "https" || u.Hostname() == "" {
		return nil, errors.New("must use an https URL")
	}
	if u.User != nil {
		return nil, errors.New("credentials must not be embedded in the URL")
	}
	if u.RawQuery != "" {
		return nil, errors.New("query parameters are not accepted in a storage endpoint")
	}
	u.Fragment = ""
	host := strings.ToLower(u.Hostname())
	if host == "localhost" || strings.HasSuffix(host, ".local") {
		return nil, errors.New("local/private endpoints are not accepted")
	}
	return u, nil
}

func webdavURL(base *url.URL, relative string) string {
	cp := *base
	basePath := strings.TrimSuffix(cp.Path, "/")
	parts := strings.Split(relative, "/")
	clean := make([]string, 0, len(parts))
	for _, p := range parts {
		if p == "" {
			continue
		}
		clean = append(clean, p)
	}
	cp.RawPath = ""
	cp.Path = strings.TrimSuffix(basePath, "/") + "/" + strings.Join(clean, "/")
	return cp.String()
}

func do(ctx context.Context, c *http.Client, method, target string, creds Credentials, body io.Reader, headers map[string]string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, target, body)
	if err != nil {
		return nil, err
	}
	if creds.Username != "" || creds.Password != "" {
		req.SetBasicAuth(creds.Username, creds.Password)
	}
	req.Header.Set("User-Agent", "VaultPool/field-test WebDAV")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	return c.Do(req)
}

func readBounded(resp *http.Response, max int64) ([]byte, error) {
	defer resp.Body.Close()
	b, err := io.ReadAll(io.LimitReader(resp.Body, max+1))
	if err != nil {
		return nil, err
	}
	if int64(len(b)) > max {
		return nil, errors.New("provider response exceeded safety limit")
	}
	return b, nil
}

func propfind(ctx context.Context, c *http.Client, target string, creds Credentials, depth string, props string) ([]davResponse, error) {
	body := `<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:"><d:prop>` + props + `</d:prop></d:propfind>`
	resp, err := do(ctx, c, "PROPFIND", target, creds, strings.NewReader(body), map[string]string{"Depth": depth, "Content-Type": "application/xml; charset=utf-8"})
	if err != nil {
		return nil, err
	}
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		_, _ = readBounded(resp, 4096)
		return nil, errors.New("authentication rejected by the WebDAV server")
	}
	if resp.StatusCode != 207 {
		_, _ = readBounded(resp, 4096)
		return nil, fmt.Errorf("WebDAV PROPFIND returned HTTP %d", resp.StatusCode)
	}
	b, err := readBounded(resp, 2<<20)
	if err != nil {
		return nil, err
	}
	var ms multistatus
	if err := xml.Unmarshal(b, &ms); err != nil {
		return nil, errors.New("invalid WebDAV XML response")
	}
	return ms.Responses, nil
}

func quotaFromResponses(rs []davResponse) (used, total int64, ok bool) {
	for _, r := range rs {
		for _, ps := range r.PropStats {
			a := strings.TrimSpace(ps.Prop.QuotaAvailable)
			u := strings.TrimSpace(ps.Prop.QuotaUsed)
			if a == "" || u == "" {
				continue
			}
			av, e1 := strconv.ParseInt(a, 10, 64)
			us, e2 := strconv.ParseInt(u, 10, 64)
			if e1 != nil || e2 != nil || av < 0 || us < 0 || av > (1<<62)-us {
				continue
			}
			return us, us + av, true
		}
	}
	return 0, 0, false
}

func randomHex(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func ensureCollection(ctx context.Context, c *http.Client, base *url.URL, creds Credentials, rel string) error {
	target := webdavURL(base, rel)
	resp, err := do(ctx, c, "MKCOL", target, creds, nil, nil)
	if err != nil {
		return err
	}
	_, _ = readBounded(resp, 4096)
	if resp.StatusCode == 201 || resp.StatusCode == 405 {
		return nil
	}
	if resp.StatusCode == 401 || resp.StatusCode == 403 {
		return errors.New("WebDAV credentials do not allow creating the VaultPool folder")
	}
	return fmt.Errorf("WebDAV MKCOL returned HTTP %d", resp.StatusCode)
}

func testRoundTrip(ctx context.Context, c *http.Client, base *url.URL, creds Credentials) error {
	if err := ensureCollection(ctx, c, base, creds, defaultRoot); err != nil {
		return err
	}
	suffix, err := randomHex(8)
	if err != nil {
		return err
	}
	rel := defaultRoot + "/vp-selftest-" + suffix + ".bin"
	payload := []byte("VaultPool WebDAV capability test " + suffix)
	target := webdavURL(base, rel)
	resp, err := do(ctx, c, "PUT", target, creds, bytes.NewReader(payload), map[string]string{"Content-Type": "application/octet-stream"})
	if err != nil {
		return err
	}
	_, _ = readBounded(resp, 4096)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("WebDAV PUT returned HTTP %d", resp.StatusCode)
	}
	cleanup := func() {
		r, e := do(context.Background(), c, "DELETE", target, creds, nil, nil)
		if e == nil {
			_, _ = readBounded(r, 4096)
		}
	}
	defer cleanup()
	resp, err = do(ctx, c, "GET", target, creds, nil, nil)
	if err != nil {
		return err
	}
	if resp.StatusCode != 200 {
		_, _ = readBounded(resp, 4096)
		return fmt.Errorf("WebDAV GET returned HTTP %d", resp.StatusCode)
	}
	got, err := readBounded(resp, 1<<20)
	if err != nil {
		return err
	}
	if !bytes.Equal(got, payload) {
		return errors.New("downloaded test object did not match uploaded bytes")
	}
	resp, err = do(ctx, c, "DELETE", target, creds, nil, nil)
	if err != nil {
		return err
	}
	_, _ = readBounded(resp, 4096)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("WebDAV DELETE returned HTTP %d", resp.StatusCode)
	}
	cleanup = func() {}
	return nil
}

func fetchFavicon(ctx context.Context, raw string) string {
	u, err := normalizeHTTPS(raw)
	if err != nil {
		return ""
	}
	u.Path = "/favicon.ico"
	u.RawPath = ""
	u.RawQuery = ""
	u.Fragment = ""
	resp, err := do(ctx, safeClient(8*time.Second), "GET", u.String(), Credentials{}, nil, nil)
	if err != nil {
		return ""
	}
	if resp.StatusCode != 200 {
		_, _ = readBounded(resp, 1024)
		return ""
	}
	ct := strings.ToLower(strings.TrimSpace(strings.Split(resp.Header.Get("Content-Type"), ";")[0]))
	switch ct {
	case "image/png", "image/x-icon", "image/vnd.microsoft.icon":
	default:
		_, _ = readBounded(resp, 1024)
		return ""
	}
	b, err := readBounded(resp, 64<<10)
	if err != nil || len(b) == 0 {
		return ""
	}
	return "data:" + ct + ";base64," + base64.StdEncoding.EncodeToString(b)
}

func slug(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	var b strings.Builder
	dash := false
	for _, r := range s {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			b.WriteRune(r)
			dash = false
		} else if !dash && b.Len() > 0 {
			b.WriteByte('-')
			dash = true
		}
	}
	out := strings.Trim(b.String(), "-")
	if len(out) > 28 {
		out = out[:28]
	}
	if out == "" {
		out = "webdav"
	}
	return out
}

func Audit(ctx context.Context, in AuditInput) AuditResult {
	result := AuditResult{Steps: []AuditStep{}, PolicyVersion: catalog.GenericWebDAVPolicyVersion}
	fail := func(code, reason, guidance string) AuditResult {
		result.Passed = false
		result.ReasonCode = code
		result.Reason = reason
		result.Guidance = guidance
		return result
	}
	name := strings.TrimSpace(in.Name)
	if len(name) < 2 || len(name) > 80 {
		return fail("invalid_name", "El nombre debe tener entre 2 y 80 caracteres.", "Usa el nombre comercial del servicio.")
	}
	result.Steps = append(result.Steps, AuditStep{ID: "vaultpool_policy", Label: "Política VaultPool", Passed: true, Detail: "Solo WebDAV estándar HTTPS, varias cuentas legítimas separadas, sin código externo, scraping ni evasión de límites."})
	official, err := normalizeHTTPS(in.OfficialURL)
	if err != nil {
		return fail("official_url", "La web oficial no es una URL HTTPS pública válida.", "Usa la web HTTPS oficial del proveedor; no se aceptan localhost ni URLs con credenciales.")
	}
	result.Steps = append(result.Steps, AuditStep{ID: "official_https", Label: "Web oficial HTTPS", Passed: true, Detail: official.Hostname()})
	endpoint, err := normalizeHTTPS(in.EndpointURL)
	if err != nil {
		return fail("endpoint_url", "El endpoint WebDAV no es una URL HTTPS pública válida.", "Busca en la ayuda oficial del proveedor su dirección WebDAV HTTPS.")
	}
	result.Steps = append(result.Steps, AuditStep{ID: "endpoint_https", Label: "Endpoint HTTPS", Passed: true, Detail: endpoint.Hostname()})
	creds := Credentials{Username: strings.TrimSpace(in.Username), Password: in.Password}
	if creds.Username == "" || creds.Password == "" {
		return fail("credentials", "Faltan usuario o contraseña/token de aplicación.", "Usa una contraseña específica de aplicación si el proveedor la ofrece; evita reutilizar la contraseña principal.")
	}
	c := safeClient(18 * time.Second)
	rs, err := propfind(ctx, c, endpoint.String(), creds, "0", `<d:quota-available-bytes/><d:quota-used-bytes/><d:resourcetype/>`)
	if err != nil {
		return fail("webdav_probe", "No se pudo validar WebDAV: "+err.Error(), "Comprueba que la URL sea el endpoint WebDAV exacto y que las credenciales sean válidas. VaultPool no intentará scraping ni APIs privadas como alternativa.")
	}
	result.Steps = append(result.Steps, AuditStep{ID: "webdav", Label: "WebDAV estándar", Passed: true, Detail: "PROPFIND autenticado aceptado"})
	used, total, ok := quotaFromResponses(rs)
	if !ok || total <= 0 {
		return fail("quota", "El servidor no publica cuota WebDAV utilizable.", "VaultPool necesita una cuota verificable para no planificar subidas que excedan el espacio. Este servicio queda bloqueado en el modo automático.")
	}
	result.UsedBytes, result.TotalBytes, result.FreeBytes = used, total, total-used
	result.Steps = append(result.Steps, AuditStep{ID: "quota", Label: "Cuota verificable", Passed: true, Detail: fmt.Sprintf("%d bytes libres", total-used)})
	if err := testRoundTrip(ctx, c, endpoint, creds); err != nil {
		return fail("roundtrip", "La prueba segura de escritura/lectura/borrado falló: "+err.Error(), "VaultPool requiere crear, leer y borrar únicamente sus propios objetos. Revisa permisos WebDAV o usa otro servicio.")
	}
	result.Steps = append(result.Steps, AuditStep{ID: "roundtrip", Label: "Subida + lectura + borrado", Passed: true, Detail: "Objeto de prueba verificado byte a byte y eliminado"})
	suffix, _ := randomHex(4)
	host := strings.ToLower(endpoint.Hostname())
	id := "custom-" + slug(name) + "-" + suffix
	icon := fetchFavicon(ctx, official.String())
	result.Provider = catalog.Provider{ID: id, Name: name, ShortName: strings.ToUpper(string([]rune(name)[0:1])), Status: catalog.Allowed, StatusNote: "Servicio añadido por el usuario tras auditoría WebDAV local y la política " + catalog.GenericWebDAVPolicyVersion + ". Admite varias credenciales legítimas separadas para el mismo endpoint. Solo se usa WebDAV estándar sobre HTTPS; no se carga código del proveedor.", MaxAccounts: 0, AccountTypes: []string{"WebDAV"}, AuthStrategy: catalog.AuthDirectCredentials, CaptchaManualOnly: true, OfficialURL: official.String(), LastReviewed: time.Now().UTC().Format("2006-01-02"), FailureDomain: "webdav:" + host, IconURL: icon, GenericProtocol: "webdav", EndpointURL: endpoint.String(), PolicyVersion: catalog.GenericWebDAVPolicyVersion}
	result.Credentials = creds
	result.Passed = true
	return result
}

type Connector struct {
	Provider catalog.Provider
	Vault    *secretvault.Vault
}

func NewConnector(p catalog.Provider, v *secretvault.Vault) *Connector {
	return &Connector{Provider: p, Vault: v}
}
func (c *Connector) ProviderID() string { return c.Provider.ID }
func (c *Connector) Ready() bool {
	return c != nil && c.Vault != nil && c.Provider.GenericProtocol == "webdav" && strings.HasPrefix(c.Provider.EndpointURL, "https://")
}
func (c *Connector) creds(accountID string) (Credentials, error) {
	if !c.Ready() {
		return Credentials{}, errors.New("generic WebDAV connector is not ready")
	}
	b, ok, err := c.Vault.Get(accountID, secretvault.ProviderSession)
	if err != nil {
		return Credentials{}, err
	}
	if !ok {
		return Credentials{}, errors.New("WebDAV credentials are not stored")
	}
	var cr Credentials
	if err := json.Unmarshal(b, &cr); err != nil {
		return Credentials{}, errors.New("invalid stored WebDAV credentials")
	}
	if cr.Username == "" || cr.Password == "" {
		return Credentials{}, errors.New("incomplete stored WebDAV credentials")
	}
	return cr, nil
}
func (c *Connector) Probe(ctx context.Context, accountID string) (connector.Snapshot, error) {
	cr, err := c.creds(accountID)
	if err != nil {
		return connector.Snapshot{}, err
	}
	u, err := normalizeHTTPS(c.Provider.EndpointURL)
	if err != nil {
		return connector.Snapshot{}, err
	}
	rs, err := propfind(ctx, safeClient(15*time.Second), u.String(), cr, "0", `<d:quota-available-bytes/><d:quota-used-bytes/>`)
	if err != nil {
		return connector.Snapshot{}, err
	}
	used, total, ok := quotaFromResponses(rs)
	if !ok || total <= 0 {
		return connector.Snapshot{}, errors.New("WebDAV quota unavailable")
	}
	subject := strings.ToLower(u.Hostname()) + "\x00" + strings.TrimSuffix(u.EscapedPath(), "/") + "\x00" + strings.ToLower(cr.Username)
	return connector.Snapshot{ProviderID: c.Provider.ID, AccountID: accountID, ProviderSubject: subject, Identity: cr.Username + " @ " + u.Hostname(), PlanName: "WebDAV", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: total, UsedBytes: used, FreeBytes: total - used, Limits: connector.Limits{UploadLimitNote: "Según límites WebDAV del proveedor.", DownloadLimitNote: "Según límites WebDAV del proveedor.", RateLimitNote: "VaultPool respeta respuestas y límites del servidor WebDAV."}, LastChecked: time.Now().UTC().Format(time.RFC3339), StatusNote: "WebDAV HTTPS verificado por VaultPool."}, nil
}
func (c *Connector) RemoteStore() remoteobject.Store {
	return &Store{Provider: c.Provider, Vault: c.Vault}
}
func (c *Connector) RemoteStoreFor(_ string, stable string) remoteobject.Store {
	return &Store{Provider: c.Provider, Vault: c.Vault, ExpectedTargetID: strings.TrimSpace(stable)}
}

// Store is a flat, reserved VaultPool namespace over standard WebDAV.
type Store struct {
	Provider         catalog.Provider
	Vault            *secretvault.Vault
	ExpectedTargetID string
}

func (s *Store) ProviderID() string { return s.Provider.ID }
func (s *Store) creds(accountID string) (Credentials, error) {
	return NewConnector(s.Provider, s.Vault).creds(accountID)
}
func (s *Store) base() (*url.URL, error) { return normalizeHTTPS(s.Provider.EndpointURL) }
func (s *Store) verify(ctx context.Context, accountID string) (Credentials, *url.URL, error) {
	cr, err := s.creds(accountID)
	if err != nil {
		return Credentials{}, nil, err
	}
	u, err := s.base()
	if err != nil {
		return Credentials{}, nil, err
	}
	if s.ExpectedTargetID != "" {
		subject := strings.ToLower(u.Hostname()) + "\x00" + strings.TrimSuffix(u.EscapedPath(), "/") + "\x00" + strings.ToLower(cr.Username)
		tid, err := connector.StableTargetID(s.Provider.ID, subject)
		if err != nil || tid != s.ExpectedTargetID {
			return Credentials{}, nil, errors.New("active WebDAV credentials belong to a different configured account")
		}
	}
	return cr, u, nil
}
func flatName(key string) (string, error) {
	suffix, err := randomHex(6)
	if err != nil {
		return "", err
	}
	if strings.HasPrefix(key, "metadata/manifests/") {
		parts := strings.Split(strings.TrimPrefix(key, "metadata/manifests/"), "/")
		if len(parts) != 2 || len(parts[0]) != 32 {
			return "", errors.New("invalid manifest key")
		}
		return "vp-manifest-" + strings.ToLower(parts[0]) + "-" + suffix + ".cpm", nil
	}
	if strings.HasPrefix(key, "metadata/recovery/filekeys/") && strings.HasSuffix(key, ".vprk") {
		id := strings.TrimSuffix(strings.TrimPrefix(key, "metadata/recovery/filekeys/"), ".vprk")
		if len(id) != 32 {
			return "", errors.New("invalid recovery key")
		}
		return "vp-filekey-" + strings.ToLower(id) + "-" + suffix + ".vprk", nil
	}
	return "vp-" + remoteobject.SHA256Bytes([]byte(key)) + "-" + suffix + ".cps", nil
}
func (s *Store) PutVerified(ctx context.Context, accountID, key string, data []byte, expected string) (remoteobject.Object, error) {
	if err := remoteobject.ValidateKey(key); err != nil {
		return remoteobject.Object{}, err
	}
	if len(data) == 0 {
		return remoteobject.Object{}, errors.New("empty remote objects are not supported")
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(data), expected) {
		return remoteobject.Object{}, errors.New("local SHA-256 mismatch before WebDAV upload")
	}
	cr, u, err := s.verify(ctx, accountID)
	if err != nil {
		return remoteobject.Object{}, err
	}
	c := safeClient(30 * time.Second)
	if err := ensureCollection(ctx, c, u, cr, defaultRoot); err != nil {
		return remoteobject.Object{}, err
	}
	name, err := flatName(key)
	if err != nil {
		return remoteobject.Object{}, err
	}
	loc := defaultRoot + "/" + name
	target := webdavURL(u, loc)
	resp, err := do(ctx, c, "PUT", target, cr, bytes.NewReader(data), map[string]string{"Content-Type": "application/octet-stream"})
	if err != nil {
		return remoteobject.Object{}, err
	}
	_, _ = readBounded(resp, 4096)
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return remoteobject.Object{}, fmt.Errorf("WebDAV upload HTTP %d", resp.StatusCode)
	}
	obj := remoteobject.Object{ProviderID: s.Provider.ID, AccountID: accountID, ID: loc, Key: key, Name: name, Size: int64(len(data)), SHA256: strings.ToLower(expected)}
	if _, err := s.GetVerified(ctx, accountID, loc, obj.Size, obj.SHA256); err != nil {
		_ = s.Delete(ctx, accountID, loc)
		return remoteobject.Object{}, fmt.Errorf("WebDAV post-upload verification failed: %w", err)
	}
	return obj, nil
}
func (s *Store) GetVerified(ctx context.Context, accountID, loc string, expectedSize int64, expectedSHA string) ([]byte, error) {
	cr, u, err := s.verify(ctx, accountID)
	if err != nil {
		return nil, err
	}
	if !strings.HasPrefix(loc, defaultRoot+"/") || strings.Contains(loc, "..") || expectedSize < 0 {
		return nil, errors.New("invalid WebDAV object locator")
	}
	resp, err := do(ctx, safeClient(30*time.Second), "GET", webdavURL(u, loc), cr, nil, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != 200 {
		_, _ = readBounded(resp, 4096)
		return nil, fmt.Errorf("WebDAV download HTTP %d", resp.StatusCode)
	}
	b, err := readBounded(resp, maxResponseBytes)
	if err != nil {
		return nil, err
	}
	if int64(len(b)) != expectedSize {
		return nil, fmt.Errorf("remote size mismatch: got %d want %d", len(b), expectedSize)
	}
	if !strings.EqualFold(remoteobject.SHA256Bytes(b), expectedSHA) {
		return nil, errors.New("remote SHA-256 mismatch")
	}
	return b, nil
}
func (s *Store) Delete(ctx context.Context, accountID, loc string) error {
	cr, u, err := s.verify(ctx, accountID)
	if err != nil {
		return err
	}
	if !strings.HasPrefix(loc, defaultRoot+"/") || strings.Contains(loc, "..") {
		return errors.New("invalid WebDAV object locator")
	}
	resp, err := do(ctx, safeClient(20*time.Second), "DELETE", webdavURL(u, loc), cr, nil, nil)
	if err != nil {
		return err
	}
	_, _ = readBounded(resp, 4096)
	if (resp.StatusCode >= 200 && resp.StatusCode < 300) || resp.StatusCode == 404 {
		return nil
	}
	return fmt.Errorf("WebDAV delete HTTP %d", resp.StatusCode)
}

func parseDepth1(rs []davResponse, base *url.URL, prefix, suffix string) ([]struct {
	Loc  string
	Size int64
	ID   string
}, error) {
	out := []struct {
		Loc  string
		Size int64
		ID   string
	}{}
	for _, r := range rs {
		href, err := url.Parse(strings.TrimSpace(r.Href))
		if err != nil {
			continue
		}
		name, err := url.PathUnescape(path.Base(href.Path))
		if err != nil {
			continue
		}
		if !strings.HasPrefix(name, prefix) || !strings.HasSuffix(name, suffix) {
			continue
		}
		var size int64 = -1
		for _, ps := range r.PropStats {
			if v := strings.TrimSpace(ps.Prop.ContentLength); v != "" {
				if n, e := strconv.ParseInt(v, 10, 64); e == nil {
					size = n
				}
			}
		}
		if size <= 0 {
			continue
		}
		body := strings.TrimSuffix(strings.TrimPrefix(name, prefix), suffix)
		id := ""
		if len(body) >= 32 {
			id = body[:32]
		}
		out = append(out, struct {
			Loc  string
			Size int64
			ID   string
		}{defaultRoot + "/" + name, size, id})
	}
	return out, nil
}
func (s *Store) listRecovery(ctx context.Context, accountID, prefix, suffix string) ([]struct {
	Loc  string
	Size int64
	ID   string
}, error) {
	cr, u, err := s.verify(ctx, accountID)
	if err != nil {
		return nil, err
	}
	if err := ensureCollection(ctx, safeClient(15*time.Second), u, cr, defaultRoot); err != nil {
		return nil, err
	}
	rs, err := propfind(ctx, safeClient(20*time.Second), webdavURL(u, defaultRoot), cr, "1", `<d:getcontentlength/><d:resourcetype/>`)
	if err != nil {
		return nil, err
	}
	return parseDepth1(rs, u, prefix, suffix)
}
func (s *Store) ListManifestCandidates(ctx context.Context, accountID string) ([]remoteobject.ManifestCandidate, error) {
	items, err := s.listRecovery(ctx, accountID, "vp-manifest-", ".cpm")
	if err != nil {
		return nil, err
	}
	out := make([]remoteobject.ManifestCandidate, 0, len(items))
	for _, x := range items {
		out = append(out, remoteobject.ManifestCandidate{Locator: x.Loc, RecoveryID: x.ID, Size: x.Size})
	}
	return out, nil
}
func (s *Store) ReadManifestCandidate(ctx context.Context, accountID, loc string, max int64) ([]byte, error) {
	return s.readCandidate(ctx, accountID, loc, max)
}
func (s *Store) ListRecoveryRecordCandidates(ctx context.Context, accountID string) ([]remoteobject.RecoveryRecordCandidate, error) {
	items, err := s.listRecovery(ctx, accountID, "vp-filekey-", ".vprk")
	if err != nil {
		return nil, err
	}
	out := make([]remoteobject.RecoveryRecordCandidate, 0, len(items))
	for _, x := range items {
		out = append(out, remoteobject.RecoveryRecordCandidate{Locator: x.Loc, RecoveryID: x.ID, Size: x.Size})
	}
	return out, nil
}
func (s *Store) ReadRecoveryRecordCandidate(ctx context.Context, accountID, loc string, max int64) ([]byte, error) {
	return s.readCandidate(ctx, accountID, loc, max)
}
func (s *Store) readCandidate(ctx context.Context, accountID, loc string, max int64) ([]byte, error) {
	if max <= 0 {
		return nil, errors.New("invalid recovery size cap")
	}
	cr, u, err := s.verify(ctx, accountID)
	if err != nil {
		return nil, err
	}
	if !strings.HasPrefix(loc, defaultRoot+"/") || strings.Contains(loc, "..") {
		return nil, errors.New("invalid WebDAV recovery locator")
	}
	resp, err := do(ctx, safeClient(20*time.Second), "GET", webdavURL(u, loc), cr, nil, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != 200 {
		_, _ = readBounded(resp, 4096)
		return nil, fmt.Errorf("WebDAV recovery download HTTP %d", resp.StatusCode)
	}
	return readBounded(resp, max)
}
