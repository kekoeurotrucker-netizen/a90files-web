package connector

import "testing"

func TestSnapshotRejectsInconsistentQuota(t *testing.T) {
	s := Snapshot{ProviderID: "x", AccountID: "a", TotalBytes: 100, UsedBytes: 80, FreeBytes: 30}
	if s.Validate() == nil {
		t.Fatal("expected inconsistent quota error")
	}
}
func TestRegistryRejectsDuplicate(t *testing.T) {
	r := NewRegistry()
	if err := r.Register(Unconfigured{ID: "x"}); err != nil {
		t.Fatal(err)
	}
	if err := r.Register(Unconfigured{ID: "x"}); err == nil {
		t.Fatal("expected duplicate error")
	}
}
