package connector

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"
)

type AuthState string

const (
	AuthPending    AuthState = "pending"
	Authenticated  AuthState = "authenticated"
	ReauthRequired AuthState = "reauth_required"
	AuthFailed     AuthState = "failed"
)

type HealthState string

const (
	HealthUnknown     HealthState = "unknown"
	HealthOK          HealthState = "ok"
	HealthAttention   HealthState = "attention"
	HealthUnavailable HealthState = "unavailable"
)

type TransferState string

const (
	TransferReady   TransferState = "ready"
	TransferLimited TransferState = "limited"
	TransferPaused  TransferState = "paused"
	TransferUnknown TransferState = "unknown"
)

type Limits struct {
	MaxObjectBytes    int64  `json:"max_object_bytes"`
	UploadLimitNote   string `json:"upload_limit_note"`
	DownloadLimitNote string `json:"download_limit_note"`
	RateLimitNote     string `json:"rate_limit_note"`
}

type Snapshot struct {
	ProviderID string `json:"provider_id"`
	AccountID  string `json:"account_id"`
	// ProviderSubject is ephemeral probe output only. It must never be persisted or exposed by the UI.
	ProviderSubject     string        `json:"-"`
	Identity            string        `json:"identity"`
	PlanName            string        `json:"plan_name"`
	Auth                AuthState     `json:"auth"`
	Health              HealthState   `json:"health"`
	Transfer            TransferState `json:"transfer"`
	TotalBytes          int64         `json:"total_bytes"`
	UsedBytes           int64         `json:"used_bytes"`
	FreeBytes           int64         `json:"free_bytes"`
	UploadBytesPerSec   int64         `json:"upload_bytes_per_sec"`
	DownloadBytesPerSec int64         `json:"download_bytes_per_sec"`
	Limits              Limits        `json:"limits"`
	LastChecked         string        `json:"last_checked"`
	StatusNote          string        `json:"status_note"`
	ErrorCode           string        `json:"error_code"`
}

func (s Snapshot) Validate() error {
	if s.ProviderID == "" || s.AccountID == "" {
		return errors.New("provider_id and account_id required")
	}
	if s.TotalBytes < 0 || s.UsedBytes < 0 || s.FreeBytes < 0 {
		return errors.New("negative quota")
	}
	if s.TotalBytes > 0 && s.UsedBytes > s.TotalBytes {
		return errors.New("used exceeds total")
	}
	if s.TotalBytes > 0 && s.FreeBytes != s.TotalBytes-s.UsedBytes {
		return errors.New("free quota inconsistent")
	}
	if s.Auth == Authenticated && s.ProviderSubject == "" {
		return errors.New("authenticated snapshot missing stable provider subject")
	}
	return nil
}

func StableTargetID(providerID, providerSubject string) (string, error) {
	providerID = strings.ToLower(strings.TrimSpace(providerID))
	providerSubject = strings.TrimSpace(providerSubject)
	if providerID == "" || providerSubject == "" {
		return "", errors.New("provider id and stable provider subject required")
	}
	h := sha256.Sum256([]byte(providerID + "\x00" + providerSubject))
	return providerID + ":" + hex.EncodeToString(h[:]), nil
}

type Connector interface {
	ProviderID() string
	Probe(context.Context, string) (Snapshot, error)
}

type ReadyConnector interface{ Ready() bool }

type Registry struct {
	mu         sync.RWMutex
	byProvider map[string]Connector
}

func NewRegistry() *Registry { return &Registry{byProvider: map[string]Connector{}} }
func (r *Registry) Register(c Connector) error {
	if c == nil || c.ProviderID() == "" {
		return errors.New("invalid connector")
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, exists := r.byProvider[c.ProviderID()]; exists {
		return fmt.Errorf("connector already registered for %s", c.ProviderID())
	}
	r.byProvider[c.ProviderID()] = c
	return nil
}

// Set installs or replaces the connector for a provider. This is used by the
// local settings UI when a public OAuth client ID is configured at runtime.
// Replacement is atomic for readers; existing account metadata is untouched.
func (r *Registry) Set(c Connector) error {
	if c == nil || c.ProviderID() == "" {
		return errors.New("invalid connector")
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	r.byProvider[c.ProviderID()] = c
	return nil
}
func (r *Registry) Get(providerID string) (Connector, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	c, ok := r.byProvider[providerID]
	return c, ok
}
func (r *Registry) Ready(providerID string) bool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	c, ok := r.byProvider[providerID]
	if !ok {
		return false
	}
	rc, ok := c.(ReadyConnector)
	return ok && rc.Ready()
}
func (r *Registry) ProviderIDs() []string {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]string, 0, len(r.byProvider))
	for id := range r.byProvider {
		out = append(out, id)
	}
	sort.Strings(out)
	return out
}

// Unconfigured is deliberately non-functional. It lets VaultPool expose a
// stable connector contract without pretending a real cloud account has been
// authenticated or probed.
type Unconfigured struct{ ID string }

func (u Unconfigured) ProviderID() string { return u.ID }
func (u Unconfigured) Ready() bool        { return false }
func (u Unconfigured) Probe(_ context.Context, accountID string) (Snapshot, error) {
	return Snapshot{ProviderID: u.ID, AccountID: accountID, Auth: AuthPending, Health: HealthUnknown, Transfer: TransferUnknown, LastChecked: time.Now().UTC().Format(time.RFC3339), StatusNote: "Conector real todavía no configurado."}, errors.New("connector not configured")
}
