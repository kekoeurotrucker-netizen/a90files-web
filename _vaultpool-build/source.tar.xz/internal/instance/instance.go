package instance

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type Record struct {
	PID     int    `json:"pid"`
	Listen  string `json:"listen"`
	Profile string `json:"profile"`
}

type Lock struct {
	path string
	rec  Record
}

type AlreadyRunningError struct{ Record Record }

func (e *AlreadyRunningError) Error() string {
	if strings.TrimSpace(e.Record.Listen) != "" {
		return fmt.Sprintf("VaultPool is already running for this profile at %s", e.Record.Listen)
	}
	return "VaultPool is already running for this profile"
}

func Read(path string) (Record, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Record{}, err
	}
	var r Record
	if err := json.Unmarshal(b, &r); err != nil {
		return Record{}, err
	}
	if r.PID <= 0 || strings.TrimSpace(r.Listen) == "" || strings.TrimSpace(r.Profile) == "" {
		return Record{}, errors.New("invalid VaultPool instance record")
	}
	return r, nil
}

func Acquire(path, listen, profile string) (*Lock, error) {
	if strings.TrimSpace(path) == "" || strings.TrimSpace(listen) == "" || strings.TrimSpace(profile) == "" {
		return nil, errors.New("instance path, listen address and profile are required")
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, err
	}
	rec := Record{PID: os.Getpid(), Listen: listen, Profile: profile}
	data, err := json.Marshal(rec)
	if err != nil {
		return nil, err
	}
	for attempt := 0; attempt < 2; attempt++ {
		f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
		if err == nil {
			writeErr := func() error {
				defer f.Close()
				if _, err := f.Write(data); err != nil {
					return err
				}
				return f.Sync()
			}()
			if writeErr != nil {
				_ = os.Remove(path)
				return nil, writeErr
			}
			return &Lock{path: path, rec: rec}, nil
		}
		if !os.IsExist(err) {
			return nil, err
		}
		existing, readErr := Read(path)
		if readErr == nil && processAlive(existing.PID) {
			return nil, &AlreadyRunningError{Record: existing}
		}
		// A crashed process may leave the tiny lock record behind. Only remove it
		// after its recorded PID is confirmed dead (or the record is unreadable).
		if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
			return nil, fmt.Errorf("remove stale instance record: %w", err)
		}
	}
	return nil, errors.New("could not acquire VaultPool profile instance lock")
}

func (l *Lock) Release() error {
	if l == nil || l.path == "" {
		return nil
	}
	current, err := Read(l.path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if current.PID != l.rec.PID || current.Profile != l.rec.Profile {
		return errors.New("refusing to remove instance record owned by another process")
	}
	return os.Remove(l.path)
}
