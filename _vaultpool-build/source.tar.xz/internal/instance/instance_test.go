package instance

import (
	"errors"
	"path/filepath"
	"testing"
)

func TestAcquireRejectsSecondLiveProcessRecordAndReleaseAllowsReuse(t *testing.T) {
	path := filepath.Join(t.TempDir(), "instance.json")
	first, err := Acquire(path, "127.0.0.1:8742", "profile-a")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := Acquire(path, "127.0.0.1:9999", "profile-a"); err == nil {
		t.Fatal("second live instance was accepted")
	} else {
		var running *AlreadyRunningError
		if !errors.As(err, &running) || running.Record.Listen != "127.0.0.1:8742" {
			t.Fatalf("unexpected second-acquire error: %v", err)
		}
	}
	if err := first.Release(); err != nil {
		t.Fatal(err)
	}
	second, err := Acquire(path, "127.0.0.1:9999", "profile-a")
	if err != nil {
		t.Fatal(err)
	}
	defer second.Release()
}
