package cloudconnector

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"github.com/vaultpool-project/vaultpool/internal/oauthnative"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type memSecrets struct {
	mu sync.Mutex
	m  map[string][]byte
}

func (s *memSecrets) Get(a string, k secretvault.Kind) ([]byte, bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	b, ok := s.m[a+"/"+string(k)]
	return append([]byte(nil), b...), ok, nil
}
func (s *memSecrets) Put(a string, k secretvault.Kind, b []byte) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.m == nil {
		s.m = map[string][]byte{}
	}
	s.m[a+"/"+string(k)] = append([]byte(nil), b...)
	return nil
}
func tokenStore(t *testing.T, s *memSecrets, account string) {
	t.Helper()
	if err := StoreToken(s, account, oauthnative.Token{AccessToken: "access", RefreshToken: "refresh", TokenType: "Bearer"}); err != nil {
		t.Fatal(err)
	}
}

func TestGoogleProbeUsesBearerAndReturnsQuota(t *testing.T) {
	seenAuth := ""
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seenAuth = r.Header.Get("Authorization")
		_ = json.NewEncoder(w).Encode(map[string]any{"user": map[string]any{"emailAddress": "a@example.com", "permissionId": "g-perm"}, "storageQuota": map[string]string{"limit": "1000", "usage": "250"}})
	}))
	defer ts.Close()
	s := &memSecrets{}
	tokenStore(t, s, "acct")
	c := &OAuthConnector{ID: "google-drive", OAuth: &oauthnative.Client{}, Secrets: s, HTTP: ts.Client(), GoogleAboutURL: ts.URL}
	snap, err := c.Probe(context.Background(), "acct")
	if err != nil {
		t.Fatal(err)
	}
	if seenAuth != "Bearer access" {
		t.Fatalf("auth=%q", seenAuth)
	}
	if snap.TotalBytes != 1000 || snap.UsedBytes != 250 || snap.FreeBytes != 750 || snap.Identity != "a@example.com" {
		t.Fatalf("snap=%+v", snap)
	}
}

func TestMicrosoftProbeRequiresConsistentQuota(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/me":
			_ = json.NewEncoder(w).Encode(map[string]string{"id": "ms-sub", "mail": "m@example.com"})
		case "/me/drive":
			_ = json.NewEncoder(w).Encode(map[string]any{"id": "drive-123", "quota": map[string]any{"total": 1000, "used": 200, "remaining": 800, "state": "normal"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer ts.Close()
	s := &memSecrets{}
	tokenStore(t, s, "acct")
	c := &OAuthConnector{ID: "onedrive", OAuth: &oauthnative.Client{}, Secrets: s, HTTP: ts.Client(), MSGraphBaseURL: ts.URL}
	snap, err := c.Probe(context.Background(), "acct")
	if err != nil {
		t.Fatal(err)
	}
	if snap.FreeBytes != 800 || snap.Identity != "m@example.com" {
		t.Fatalf("snap=%+v", snap)
	}
}

func TestProbeDoesNotForwardBearerAcrossRedirect(t *testing.T) {
	hit := false
	evil := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hit = true
		if r.Header.Get("Authorization") != "" {
			t.Errorf("bearer leaked across redirect: %q", r.Header.Get("Authorization"))
		}
	}))
	defer evil.Close()
	source := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, evil.URL, http.StatusTemporaryRedirect)
	}))
	defer source.Close()
	s := &memSecrets{}
	tokenStore(t, s, "acct")
	c := &OAuthConnector{ID: "google-drive", OAuth: &oauthnative.Client{}, Secrets: s, HTTP: source.Client(), GoogleAboutURL: source.URL}
	if _, err := c.Probe(context.Background(), "acct"); err == nil {
		t.Fatal("redirected provider probe unexpectedly succeeded")
	}
	if hit {
		t.Fatal("provider probe followed redirect with authenticated request")
	}
}
