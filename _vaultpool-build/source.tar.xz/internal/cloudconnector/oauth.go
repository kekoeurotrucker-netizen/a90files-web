package cloudconnector

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/vaultpool-project/vaultpool/internal/connector"
	"github.com/vaultpool-project/vaultpool/internal/oauthnative"
	"github.com/vaultpool-project/vaultpool/internal/secretvault"
)

type SecretStore interface {
	Get(string, secretvault.Kind) ([]byte, bool, error)
	Put(string, secretvault.Kind, []byte) error
}

type OAuthConnector struct {
	ID                string
	OAuth             *oauthnative.Client
	Secrets           SecretStore
	HTTP              *http.Client
	GoogleAboutURL    string
	MSGraphBaseURL    string
	DropboxAPIBaseURL string
}

func (c *OAuthConnector) ProviderID() string { return c.ID }
func (c *OAuthConnector) Ready() bool        { return c.OAuth != nil && c.Secrets != nil }

func StoreToken(s SecretStore, accountID string, t oauthnative.Token) error {
	b, err := json.Marshal(t)
	if err != nil {
		return err
	}
	defer zero(b)
	return s.Put(accountID, secretvault.ProviderSession, b)
}
func loadToken(s SecretStore, accountID string) (oauthnative.Token, error) {
	b, ok, err := s.Get(accountID, secretvault.ProviderSession)
	if err != nil {
		return oauthnative.Token{}, err
	}
	if !ok {
		return oauthnative.Token{}, errors.New("OAuth session not found")
	}
	defer zero(b)
	var t oauthnative.Token
	if err := json.Unmarshal(b, &t); err != nil {
		return oauthnative.Token{}, errors.New("invalid encrypted OAuth session")
	}
	return t, nil
}
func zero(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
func tokenExpired(t oauthnative.Token) bool {
	if t.ExpiresIn <= 0 || t.ObtainedAt == "" {
		return false
	}
	at, err := time.Parse(time.RFC3339Nano, t.ObtainedAt)
	if err != nil {
		return true
	}
	return time.Now().UTC().After(at.Add(time.Duration(t.ExpiresIn)*time.Second - 60*time.Second))
}
func (c *OAuthConnector) accessToken(ctx context.Context, accountID string) (string, error) {
	t, err := loadToken(c.Secrets, accountID)
	if err != nil {
		return "", err
	}
	if tokenExpired(t) {
		if t.RefreshToken == "" {
			return "", errors.New("OAuth reauthentication required")
		}
		n, err := c.OAuth.Refresh(ctx, t.RefreshToken)
		if err != nil {
			return "", err
		}
		if n.RefreshToken == "" {
			n.RefreshToken = t.RefreshToken
		}
		if err := StoreToken(c.Secrets, accountID, n); err != nil {
			return "", err
		}
		t = n
	}
	if t.AccessToken == "" {
		return "", errors.New("OAuth access token missing")
	}
	return t.AccessToken, nil
}

// AccessToken returns a current bearer token for provider API calls. Refresh is
// handled inside the connector and any rotated token is written back to the
// encrypted secret store before it is returned. Callers must never persist or
// log the returned token.
func (c *OAuthConnector) AccessToken(ctx context.Context, accountID string) (string, error) {
	if !c.Ready() {
		return "", errors.New("connector not ready")
	}
	return c.accessToken(ctx, accountID)
}
func (c *OAuthConnector) Probe(ctx context.Context, accountID string) (connector.Snapshot, error) {
	if !c.Ready() {
		return connector.Snapshot{}, errors.New("connector not ready")
	}
	token, err := c.accessToken(ctx, accountID)
	if err != nil {
		return connector.Snapshot{}, err
	}
	switch c.ID {
	case "google-drive":
		return c.probeGoogle(ctx, accountID, token)
	case "onedrive":
		return c.probeMicrosoft(ctx, accountID, token)
	case "dropbox":
		return c.probeDropbox(ctx, accountID, token)
	case "pcloud":
		return c.probePCloud(ctx, accountID, token)
	default:
		return connector.Snapshot{}, fmt.Errorf("unsupported OAuth probe %s", c.ID)
	}
}
func (c *OAuthConnector) doJSON(ctx context.Context, method, rawURL, token string, dst any) error {
	hc := c.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 20 * time.Second}
	}
	clone := *hc
	clone.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	req, err := http.NewRequestWithContext(ctx, method, rawURL, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Accept", "application/json")
	resp, err := clone.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("provider API returned %s", resp.Status)
	}
	dec := json.NewDecoder(io.LimitReader(resp.Body, 1<<20))
	if err := dec.Decode(dst); err != nil {
		return errors.New("invalid provider API response")
	}
	return nil
}

func (c *OAuthConnector) dropboxBase() string {
	base := strings.TrimRight(c.DropboxAPIBaseURL, "/")
	if base == "" {
		base = "https://api.dropboxapi.com/2"
	}
	return base
}

func (c *OAuthConnector) doDropboxJSON(ctx context.Context, rawURL, token string, dst any) error {
	hc := c.HTTP
	if hc == nil {
		hc = &http.Client{Timeout: 20 * time.Second}
	}
	clone := *hc
	clone.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, rawURL, strings.NewReader("null"))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Content-Type", "application/json")
	resp, err := clone.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("provider API returned %s", resp.Status)
	}
	dec := json.NewDecoder(io.LimitReader(resp.Body, 1<<20))
	if err := dec.Decode(dst); err != nil {
		return errors.New("invalid provider API response")
	}
	return nil
}

func intString(s string) (int64, error) {
	if s == "" {
		return 0, nil
	}
	return strconv.ParseInt(s, 10, 64)
}
func (c *OAuthConnector) probeGoogle(ctx context.Context, accountID, token string) (connector.Snapshot, error) {
	raw := c.GoogleAboutURL
	if raw == "" {
		raw = "https://www.googleapis.com/drive/v3/about"
	}
	u, err := url.Parse(raw)
	if err != nil {
		return connector.Snapshot{}, err
	}
	q := u.Query()
	q.Set("fields", "user(displayName,emailAddress,permissionId),storageQuota(limit,usage)")
	u.RawQuery = q.Encode()
	var r struct {
		User struct {
			DisplayName  string `json:"displayName"`
			Email        string `json:"emailAddress"`
			PermissionID string `json:"permissionId"`
		} `json:"user"`
		StorageQuota struct {
			Limit string `json:"limit"`
			Usage string `json:"usage"`
		} `json:"storageQuota"`
	}
	if err := c.doJSON(ctx, http.MethodGet, u.String(), token, &r); err != nil {
		return connector.Snapshot{}, err
	}
	total, err := intString(r.StorageQuota.Limit)
	if err != nil {
		return connector.Snapshot{}, err
	}
	used, err := intString(r.StorageQuota.Usage)
	if err != nil {
		return connector.Snapshot{}, err
	}
	free := int64(0)
	if total > 0 {
		if used > total {
			return connector.Snapshot{}, errors.New("Google quota usage exceeds limit")
		}
		free = total - used
	}
	identity := r.User.Email
	if identity == "" {
		identity = r.User.DisplayName
	}
	s := connector.Snapshot{ProviderID: c.ID, AccountID: accountID, ProviderSubject: r.User.PermissionID, Identity: identity, PlanName: "Google Drive", Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: total, UsedBytes: used, FreeBytes: free, LastChecked: time.Now().UTC().Format(time.RFC3339Nano), StatusNote: "Cuota verificada mediante Google Drive API."}
	return s, s.Validate()
}
func (c *OAuthConnector) probeMicrosoft(ctx context.Context, accountID, token string) (connector.Snapshot, error) {
	base := strings.TrimRight(c.MSGraphBaseURL, "/")
	if base == "" {
		base = "https://graph.microsoft.com/v1.0"
	}
	var me struct {
		ID          string `json:"id"`
		DisplayName string `json:"displayName"`
		Mail        string `json:"mail"`
		UPN         string `json:"userPrincipalName"`
	}
	if err := c.doJSON(ctx, http.MethodGet, base+"/me?$select=id,displayName,mail,userPrincipalName", token, &me); err != nil {
		return connector.Snapshot{}, err
	}
	var d struct {
		ID    string `json:"id"`
		Quota struct {
			Total     int64  `json:"total"`
			Used      int64  `json:"used"`
			Remaining int64  `json:"remaining"`
			State     string `json:"state"`
		} `json:"quota"`
	}
	if err := c.doJSON(ctx, http.MethodGet, base+"/me/drive?$select=id,quota", token, &d); err != nil {
		return connector.Snapshot{}, err
	}
	if d.Quota.Total > 0 && d.Quota.Used+d.Quota.Remaining != d.Quota.Total {
		return connector.Snapshot{}, errors.New("OneDrive quota response inconsistent")
	}
	identity := me.Mail
	if identity == "" {
		identity = me.UPN
	}
	if identity == "" {
		identity = me.DisplayName
	}
	health := connector.HealthOK
	if strings.ToLower(d.Quota.State) != "normal" && d.Quota.State != "" {
		health = connector.HealthAttention
	}
	s := connector.Snapshot{ProviderID: c.ID, AccountID: accountID, ProviderSubject: d.ID, Identity: identity, PlanName: "OneDrive", Auth: connector.Authenticated, Health: health, Transfer: connector.TransferReady, TotalBytes: d.Quota.Total, UsedBytes: d.Quota.Used, FreeBytes: d.Quota.Remaining, LastChecked: time.Now().UTC().Format(time.RFC3339Nano), StatusNote: "Cuota verificada mediante Microsoft Graph."}
	return s, s.Validate()
}

func dropboxPlanName(tag string) string {
	switch strings.ToLower(strings.Trim(tag, ". _")) {
	case "basic":
		return "Dropbox Basic"
	case "pro":
		return "Dropbox Plus"
	case "business":
		return "Dropbox Business"
	default:
		if strings.TrimSpace(tag) == "" {
			return "Dropbox"
		}
		return "Dropbox " + strings.Trim(tag, ". _")
	}
}

func (c *OAuthConnector) probeDropbox(ctx context.Context, accountID, token string) (connector.Snapshot, error) {
	base := c.dropboxBase()
	var me struct {
		AccountID string `json:"account_id"`
		Email     string `json:"email"`
		Name      struct {
			DisplayName string `json:"display_name"`
		} `json:"name"`
		AccountType struct {
			Tag string `json:".tag"`
		} `json:"account_type"`
	}
	if err := c.doDropboxJSON(ctx, base+"/users/get_current_account", token, &me); err != nil {
		return connector.Snapshot{}, err
	}
	var usage struct {
		Used       int64 `json:"used"`
		Allocation struct {
			Tag       string `json:".tag"`
			Allocated int64  `json:"allocated"`
		} `json:"allocation"`
	}
	if err := c.doDropboxJSON(ctx, base+"/users/get_space_usage", token, &usage); err != nil {
		return connector.Snapshot{}, err
	}
	total := usage.Allocation.Allocated
	used := usage.Used
	if total > 0 && used > total {
		return connector.Snapshot{}, errors.New("Dropbox quota usage exceeds allocation")
	}
	identity := me.Email
	if identity == "" {
		identity = me.Name.DisplayName
	}
	free := int64(0)
	if total > 0 {
		free = total - used
	}
	plan := dropboxPlanName(me.AccountType.Tag)
	s := connector.Snapshot{ProviderID: c.ID, AccountID: accountID, ProviderSubject: me.AccountID, Identity: identity, PlanName: plan, Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: total, UsedBytes: used, FreeBytes: free, LastChecked: time.Now().UTC().Format(time.RFC3339Nano), StatusNote: "Cuota y plan verificados mediante Dropbox API.", Limits: connector.Limits{MaxObjectBytes: 150 * 1000 * 1000, UploadLimitNote: "Subida simple Dropbox hasta 150 MB por objeto en esta build.", DownloadLimitNote: "Sujeto a cuota y límites de Dropbox.", RateLimitNote: "VaultPool no elude límites ni throttling de Dropbox."}}
	return s, s.Validate()
}

func (c *OAuthConnector) PCloudAPIHost(accountID string) (string, error) {
	if c.ID != "pcloud" {
		return "", errors.New("not a pCloud connector")
	}
	t, err := loadToken(c.Secrets, accountID)
	if err != nil {
		return "", err
	}
	h := strings.TrimSpace(strings.ToLower(t.PCloudHostname))
	if h != "api.pcloud.com" && h != "eapi.pcloud.com" {
		return "", errors.New("pCloud regional API hostname missing or invalid; reauthorize account")
	}
	return h, nil
}

func (c *OAuthConnector) probePCloud(ctx context.Context, accountID, token string) (connector.Snapshot, error) {
	host, err := c.PCloudAPIHost(accountID)
	if err != nil {
		return connector.Snapshot{}, err
	}
	var u struct {
		Result    int    `json:"result"`
		UserID    int64  `json:"userid"`
		Email     string `json:"email"`
		Premium   bool   `json:"premium"`
		Quota     int64  `json:"quota"`
		UsedQuota int64  `json:"usedquota"`
	}
	if err := c.doJSON(ctx, http.MethodGet, "https://"+host+"/userinfo", token, &u); err != nil {
		return connector.Snapshot{}, err
	}
	if u.Result != 0 {
		return connector.Snapshot{}, fmt.Errorf("pCloud userinfo result %d", u.Result)
	}
	if u.UserID <= 0 {
		return connector.Snapshot{}, errors.New("pCloud userinfo missing userid")
	}
	if u.Quota > 0 && u.UsedQuota > u.Quota {
		return connector.Snapshot{}, errors.New("pCloud quota usage exceeds quota")
	}
	free := int64(0)
	if u.Quota > 0 {
		free = u.Quota - u.UsedQuota
	}
	plan := "pCloud Free"
	if u.Premium {
		plan = "pCloud Premium"
	}
	snap := connector.Snapshot{ProviderID: c.ID, AccountID: accountID, ProviderSubject: strconv.FormatInt(u.UserID, 10), Identity: u.Email, PlanName: plan, Auth: connector.Authenticated, Health: connector.HealthOK, Transfer: connector.TransferReady, TotalBytes: u.Quota, UsedBytes: u.UsedQuota, FreeBytes: free, LastChecked: time.Now().UTC().Format(time.RFC3339Nano), StatusNote: "Cuota verificada mediante pCloud API regional.", Limits: connector.Limits{UploadLimitNote: "Sujeto a los límites de pCloud del plan/cuenta.", DownloadLimitNote: "Sujeto a los límites de pCloud del plan/cuenta.", RateLimitNote: "VaultPool no elude límites ni throttling de pCloud."}}
	return snap, snap.Validate()
}
